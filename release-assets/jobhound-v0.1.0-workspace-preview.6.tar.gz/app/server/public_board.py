"""Public feed access and favourites. Never creates or runs a company monitor."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlsplit

import httpx
from fastapi import HTTPException
from .external_http import external_trust_env, external_client_kwargs, network_failure_hint
from .db import iso_now
from .public_board_contracts import BoardQuery, FavouritesTransfer, PublicJob
from .public_board_store import PublicBoardStore
from .tracker_contracts import FavouriteRequest
from .public_jobs.publish import MAX_INDEX_BYTES

FEED_URL = "https://crudmaster92.github.io/job-hound-jobs/api/v1/manifest.json"
ROOT = Path(__file__).resolve().parents[1]
MAX_FILE = 12 * 1024 * 1024
MAX_FEED = MAX_INDEX_BYTES


class PublicBoard:
    def __init__(self, db, trackers, *, feed_url=None, transport=None):
        self.db, self.trackers = db, trackers
        self.store = PublicBoardStore(db)
        self.feed_url = feed_url or os.getenv("JOBHOUND_PUBLIC_BOARD_URL") or FEED_URL
        parsed = urlsplit(self.feed_url)
        if parsed.scheme != "https" or parsed.username or parsed.password or parsed.port not in (None, 443):
            raise ValueError("Public board feed must use credential-free HTTPS")
        # Explicit administrator configuration is the only way to choose a feed host.
        self.base = self.feed_url.rsplit("/", 1)[0] + "/"
        self.transport = transport
        self.cache = Path(db.path).parent / "public-board"
        self.cache.mkdir(parents=True, exist_ok=True)
        self.manifest = None
        self.jobs = []
        self.error = None
        self.checked = 0.0
        self.lock = threading.RLock()
        self.previews = {}
        self._load_cache()

    def _load_cache(self):
        try:
            cached = json.loads((self.cache / "latest.json").read_text("utf-8"))
            if cached.get("feed_url") != self.feed_url:
                return
            manifest = self._manifest(cached["manifest"])
            jobs = []
            for ref in manifest["search_pages"]:
                data = (self.cache / (ref["sha256"] + ".json")).read_bytes()
                jobs.extend(self._page(data, ref, manifest["generation"]))
            self.manifest, self.jobs = manifest, self._deduplicate(jobs)
        except (OSError, ValueError, KeyError, TypeError):
            pass

    def _url(self, ref):
        path, digest = ref.get("path", ""), ref.get("sha256", "")
        if not re.fullmatch(r"snapshots/[A-Za-z0-9_.-]+/[A-Za-z0-9_./-]+\.json", path) or ".." in path or not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError("Invalid feed reference")
        url = urljoin(self.base, path)
        if not url.startswith(self.base) or urlsplit(url).netloc != urlsplit(self.feed_url).netloc:
            raise ValueError("Feed reference leaves the configured feed origin")
        return url

    def _download(self, url):
        with httpx.Client(timeout=20, follow_redirects=False, **external_client_kwargs(transport=self.transport)) as client:
            with client.stream("GET", url) as response:
                response.raise_for_status()
                if int(response.headers.get("content-length", "0")) > MAX_FILE:
                    raise ValueError("Public feed file exceeds size limit")
                data = bytearray()
                for part in response.iter_bytes():
                    data.extend(part)
                    if len(data) > MAX_FILE:
                        raise ValueError("Public feed file exceeds size limit")
                return bytes(data)

    def _manifest(self, value):
        if not isinstance(value, dict) or value.get("format") != "jobhound-public-jobs" or value.get("version") != 1:
            raise ValueError("Unsupported public feed format")
        if not isinstance(value.get("generation"), str) or not value["generation"]:
            raise ValueError("Missing feed generation")
        refs = value.get("search_pages")
        if not isinstance(refs, list) or len(refs) > 500:
            raise ValueError("Invalid search page list")
        for ref in refs + value.get("detail_pages", []):
            self._url(ref)
            if not ref["path"].startswith("snapshots/" + value["generation"] + "/"):
                raise ValueError("Feed reference generation mismatch")
        return value

    def _page(self, data, ref, generation):
        if len(data) > MAX_FILE or hashlib.sha256(data).hexdigest() != ref["sha256"]:
            raise ValueError("Public feed integrity check failed")
        value = json.loads(data)
        if value.get("generation") != generation or not isinstance(value.get("jobs"), list) or len(value["jobs"]) > 2000:
            raise ValueError("Invalid public feed page")
        return [PublicJob.model_validate(job).model_dump(exclude_none=True) for job in value["jobs"]]

    @staticmethod
    def _deduplicate(jobs):
        if len({job["id"] for job in jobs}) != len(jobs):
            raise ValueError("Duplicate public job identities in feed")
        return jobs

    def refresh(self):
        with self.lock:
            if self.checked and time.monotonic() - self.checked < 900:
                return
            self.checked = time.monotonic()
            try:
                manifest = self._manifest(json.loads(self._download(self.feed_url)))
                jobs, total_bytes = [], 0
                for ref in manifest["search_pages"]:
                    cached = self.cache / (ref["sha256"] + ".json")
                    data = cached.read_bytes() if cached.exists() else self._download(self._url(ref))
                    total_bytes += len(data)
                    if total_bytes > MAX_FEED:
                        raise ValueError("Public feed exceeds aggregate size limit")
                    jobs.extend(self._page(data, ref, manifest["generation"]))
                    cached.write_bytes(data)
                jobs = self._deduplicate(jobs)
                payload = {"feed_url": self.feed_url, "manifest": manifest}
                temporary = self.cache / "latest.tmp"
                temporary.write_text(json.dumps(payload), "utf-8")
                temporary.replace(self.cache / "latest.json")
                self.manifest, self.jobs, self.error = manifest, jobs, None
            except (httpx.HTTPError, OSError, ValueError, TypeError, KeyError) as exc:
                self.error = (str(exc)[:300] + (network_failure_hint() if isinstance(exc, httpx.HTTPError) else ""))[:500]

    def favourites(self):
        return self.trackers.favourites().get("items", [])

    def favourite_ids(self):
        values = self.favourites()
        ids = {v["catalog_company_id"] for v in values if v.get("catalog_company_id")}
        urls = {v["careers_url"] for v in values if v.get("careers_url")}
        with self.db.connect() as connection:
            for row in connection.execute("SELECT c.id,c.careers_url,s.catalog_company_id FROM companies c LEFT JOIN company_catalog_sources s ON s.company_id=c.id WHERE c.kind='monitor'"):
                if row["careers_url"] in urls or row["catalog_company_id"] in ids:
                    ids.add("local-company:" + str(row["id"]))
        return sorted(ids)

    def status(self):
        self.refresh()
        value = self.manifest or {}
        try:
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(value.get("generated_at", "").replace("Z", "+00:00"))).total_seconds()
        except (ValueError, TypeError):
            age = float("inf")
        return {"state": "stale" if (self.error or age > 36 * 3600) and self.manifest else "ready" if self.manifest else "unavailable",
                "generation": value.get("generation"), "generated_at": value.get("generated_at"),
                "collections": value.get("collections", []), "sources": value.get("sources", []),
                "error": self.error, "saved_job_ids": [job["id"] for job in self.local_saved()],
                "favourite_company_ids": self.favourite_ids()}

    def overlay(self):
        rows = {row["public_job_id"]: row for row in self.store.rows()}
        jobs = {job["id"]: dict(job) for job in self.jobs}
        trusted_ids = set(jobs)
        for key, row in rows.items():
            if key not in jobs and row["saved"]:
                jobs[key] = {**json.loads(row["snapshot_json"]), "status": "expired"}
        for key, job in jobs.items():
            row = rows.get(key)
            job.update(saved=bool(row and row["saved"]), local_job_id=row["job_id"] if row else None,
                       verified=key in trusted_ids or bool(row and row["verified"]))
        return list(jobs.values())

    def local_job(self, job, catalog_id=None):
        return {"id": "local:" + str(job["id"]), "local_job_id": job["id"],
                "company_id": catalog_id or "local-company:" + str(job["company_id"]),
                "company_name": job.get("company_name", ""), "title": job["title"],
                "location": job.get("location") or "", "work_mode": job.get("remote_mode") or "unknown",
                "employment_type": job.get("employment_type"), "salary_min": job.get("salary_min"),
                "salary_max": job.get("salary_max"), "salary_currency": job.get("salary_currency"),
                "salary_period": job.get("salary_period"), "source_url": job.get("url") or "",
                "source_job_id": job.get("source_job_id"), "posted_at": job.get("posted_date"),
                "first_seen_at": job["first_seen_at"], "last_seen_at": job["last_seen_at"],
                "status": "active" if job.get("is_active") else "closed", "collection_ids": [], "monitor_ids": [],
                "description": job.get("description") or "", "search_text": job.get("description") or "",
                "saved": bool(job.get("is_saved")), "origin": "local"}

    def local_saved(self):
        mapped = {row["job_id"]: row for row in self.store.rows()}
        jobs = self.db.list_jobs(saved=True, matching=None, active=None, dismissed=None, include_hidden=True, limit=100000)
        result = []
        for job in jobs:
            row = mapped.get(job["id"])
            if row:
                result.append({**json.loads(row["snapshot_json"]), "local_job_id": job["id"], "saved": True})
            else:
                result.append(self.local_job(job))
        return result

    def favourite_local(self):
        favourites = self.favourites()
        catalog_ids = {v.get("catalog_company_id") for v in favourites if v.get("catalog_company_id")}
        urls = {v.get("careers_url") for v in favourites if v.get("careers_url")}
        with self.db.connect() as connection:
            companies = list(connection.execute("SELECT c.id,c.careers_url,s.catalog_company_id FROM companies c LEFT JOIN company_catalog_sources s ON s.company_id=c.id WHERE c.kind='monitor'"))
        chosen = {row["id"]: row["catalog_company_id"] for row in companies if row["catalog_company_id"] in catalog_ids or row["careers_url"] in urls}
        if not chosen:
            return []
        return [self.local_job(job, chosen[job["company_id"]]) for job in self.db.list_jobs(
            company_ids=list(chosen), matching=None, dismissed=False, active=True, limit=100000)]

    def search(self, query: BoardQuery):
        self.refresh()
        jobs = self.overlay()
        if query.view == "saved":
            known = {job["id"] for job in jobs}
            jobs.extend(job for job in self.local_saved() if job["id"] not in known)
        if not self.manifest and query.view == "all":
            raise HTTPException(503, "Public jobs are unavailable. Saved roles remain available; retry later.")
        if query.view == "favourite_companies":
            ids = {v.get("catalog_company_id") for v in self.favourites()}
            jobs = [job for job in jobs if job["company_id"] in ids]
            local = self.favourite_local()
            # The local monitor owns its own lifecycle. Prefer that posting when
            # it also exists in the public feed, which may have expired earlier.
            merged = {(job["company_id"], job["source_url"]): job for job in jobs}
            for job in local:
                identity = (job["company_id"], job["source_url"])
                public = merged.get(identity)
                if public:
                    job = {**job, "collection_ids": public.get("collection_ids", []), "monitor_ids": public.get("monitor_ids", [])}
                merged[identity] = job
            jobs = list(merged.values())
        # Search carries bounded text, while full descriptions remain a detail operation.
        jobs = [{**{key: value for key, value in job.items() if key != "description"},
                 "search_text": str(job.get("search_text") or job.get("description") or "")[:30000]} for job in jobs]
        node = shutil.which("node")
        runner = ROOT / "web/src/shared/job-board-ui/query-runner.mjs"
        if not node or not runner.is_file():
            raise HTTPException(503, "Public board query runtime unavailable. Run the JobHound installer/build.")
        payload = {"jobs": jobs, "query": query.model_dump(), "now": iso_now(), "generation": (self.manifest or {}).get("generation")}
        try:
            result = subprocess.run([node, str(runner)], input=json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8",
                                    capture_output=True, timeout=20, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if result.returncode == 2 and result.stderr.strip() == "JOBHOUND_QUERY_INPUT_LIMIT":
                raise HTTPException(503, "Public board search exceeds its bounded input budget. Try a saved or favourite-company view; report this feed size to the maintainer.")
            if result.returncode or len(result.stdout) > MAX_FILE:
                raise ValueError("Query failed")
            return json.loads(result.stdout)
        except subprocess.TimeoutExpired as exc:
            raise HTTPException(503, "Public board search exceeded its time budget. Retry or try a saved or favourite-company view.") from exc
        except (OSError, ValueError) as exc:
            raise HTTPException(503, "Public board query failed. Retry; if it persists, inspect the installed query runtime and report the feed generation.") from exc

    def detail(self, job_id):
        if job_id.startswith("local:"):
            value = job_id.removeprefix("local:")
            job = self.db.get_job(int(value)) if value.isdecimal() else None
            if not job:
                raise HTTPException(404, "Local job not found")
            return self.local_job(job)
        self.refresh()
        job = next((job for job in self.overlay() if job["id"] == job_id), None)
        if not job:
            raise HTTPException(404, "Public job not found in feed or saved roles")
        ref = job.get("detail_ref")
        if ref and self.manifest:
            trusted = next((r for r in self.manifest.get("detail_pages", []) if r["path"] == ref.get("path") and r["sha256"] == ref.get("sha256")), None)
            if not trusted:
                return {**job, "detail_unavailable": True}
            try:
                path = self.cache / (ref["sha256"] + ".json")
                data = path.read_bytes() if path.exists() else self._download(self._url(ref))
                full = next((j for j in self._page(data, ref, self.manifest["generation"]) if j["id"] == job_id), None)
                if not full:
                    raise ValueError("Job missing from detail page")
                path.write_bytes(data)
                return {**full, "saved": job["saved"], "local_job_id": job["local_job_id"]}
            except (OSError, ValueError, httpx.HTTPError, KeyError):
                return {**job, "detail_unavailable": True}
        return job

    def save(self, job_id, saved, actor_type="human"):
        job = self.detail(job_id)
        if job_id.startswith("local:"):
            result = self.db.update_job_tracking(job["local_job_id"], saved=saved, actor_type=actor_type)
            return self.local_job(result)
        clean = PublicJob.model_validate({key: value for key, value in job.items() if key in PublicJob.model_fields}).model_dump(exclude_none=True)
        if not saved and job.get("local_job_id") is None:
            return {**clean, "saved": False, "local_job_id": None}
        return self.store.save(clean, saved, verified=job.get("verified", True), actor_type=actor_type)

    def export(self):
        jobs = [json.loads(row["snapshot_json"]) for row in self.store.rows() if row["saved"]]
        companies = [{"id": v["catalog_company_id"], "name": v["name"], **({"careers_url": v["careers_url"]} if v.get("careers_url") else {})}
                     for v in self.favourites() if v.get("catalog_company_id")]
        if len(jobs) > 500 or len(companies) > 500:
            raise HTTPException(422, "Transfer supports up to 500 saved jobs and 500 companies")
        omitted = sum(1 for job in self.local_saved() if job["id"].startswith("local:"))
        return FavouritesTransfer(format="jobhound-board-favourites", version=1, exported_at=iso_now(), jobs=jobs, companies=companies, omitted_local_jobs=omitted).model_dump(exclude_none=True)

    @staticmethod
    def fingerprint(transfer):
        return hashlib.sha256(transfer.model_dump_json().encode()).hexdigest()

    def preview(self, transfer: FavouritesTransfer):
        self.refresh()
        known = {job["id"] for job in self.jobs}
        existing = {row["public_job_id"] for row in self.store.rows() if row["saved"]}
        jobs = {job.id: job for job in transfer.jobs}
        companies = {company.id: company for company in transfer.companies}
        unavailable = [key for key in jobs if key not in known]
        token = secrets.token_hex(24)
        with self.lock:
            self.previews = {key: value for key, value in self.previews.items() if value[1] > time.monotonic()}
            if len(self.previews) >= 100:
                self.previews.pop(next(iter(self.previews)))
            self.previews[token] = (self.fingerprint(transfer), time.monotonic() + 1800)
        return {"preview_token": token, "counts": {"jobs": len(jobs), "new_jobs": len(set(jobs) - existing), "companies": len(companies)},
                "unavailable": unavailable, "warnings": (["Unavailable postings will be retained as unverified saved snapshots."] if unavailable else []), "additive": True}

    def import_favourites(self, transfer: FavouritesTransfer, token, actor_type="human"):
        with self.lock:
            preview = self.previews.get(token)
            if not preview or preview[1] < time.monotonic() or preview[0] != self.fingerprint(transfer):
                raise HTTPException(409, "Preview this exact favourites file before importing; preview expires after 30 minutes")
            known = {job["id"]: job for job in self.jobs}
            imported = []
            for incoming in {job.id: job for job in transfer.jobs}.values():
                job = known.get(incoming.id) or incoming.model_dump(exclude_none=True)
                if incoming.id not in known:
                    job = {**job, "status": "expired"}
                result = self.store.save(job, verified=incoming.id in known, actor_type=actor_type)
                imported.append({"id": incoming.id, "local_job_id": result["local_job_id"], "verified": result["verified"]})
            for company in {v.id: v for v in transfer.companies}.values():
                self.trackers.favourite(FavouriteRequest(name=company.name, catalog_company_id=company.id, careers_url=company.careers_url, favourite=True))
            return {"jobs": imported, "count": len(imported), "companies": len({v.id for v in transfer.companies}), "additive": True}
