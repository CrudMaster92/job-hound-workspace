/** Shared deterministic public-board query. Browser and Python's fixed Node bridge use this file. */
const DAY = 86400000;
const text = value => String(value ?? '').toLocaleLowerCase('en-US');
const timestamp = value => Number.isFinite(Date.parse(value)) ? Date.parse(value) : 0;
export function lifecycle(job, now = Date.now()) {
  if (job.status === 'closed') return 'closed';
  if (job.status === 'expired') return 'expired';
  // Local monitor closure is owned by the local database's successful-run policy.
  if (job.origin === 'local') return 'active';
  if (now - timestamp(job.last_seen_at) >= 7 * DAY) return 'expired';
  return 'active';
}
export function queryJobs({ jobs = [], query = {}, now = Date.now(), generation = null } = {}) {
  const clock = typeof now === 'string' ? timestamp(now) : now;
  const wanted = (values, value) => !values?.length || values.includes(value);
  const seen = new Set();
  const available = jobs.filter(job => {
    if (!job?.id || seen.has(job.id)) return false;
    seen.add(job.id);
    return query.view === 'saved' ? job.saved === true : lifecycle(job, clock) === 'active';
  });
  const facets = { companies: [], collections: [], work_modes: [], employment_types: [] };
  const companies = new Map(), collections = new Set(), work = new Set(), employment = new Set();
  for (const job of available) {
    companies.set(job.company_id, job.company_name);
    (job.collection_ids || []).forEach(id => collections.add(id));
    if (job.work_mode) work.add(job.work_mode);
    if (job.employment_type) employment.add(job.employment_type);
  }
  facets.companies = [...companies].map(([id, name]) => ({ id, name })).sort((a,b) => String(a.name).localeCompare(String(b.name)));
  facets.collections = [...collections].sort(); facets.work_modes = [...work].sort(); facets.employment_types = [...employment].sort();
  const terms = text(query.query).trim().split(/\s+/).filter(Boolean);
  const items = available.filter(job => {
    const haystack = text([job.title,job.company_name,job.location,job.search_text].join(' '));
    return terms.every(term => haystack.includes(term))
      && wanted(query.company_ids, job.company_id)
      && (!query.collection_ids?.length || (job.collection_ids || []).some(id => query.collection_ids.includes(id)))
      && wanted(query.work_modes, job.work_mode)
      && wanted(query.employment_types, job.employment_type)
      && (!query.location || text(job.location).includes(text(query.location)))
      && (!query.salary_listed || Boolean(job.salary_text || job.salary_min != null || job.salary_max != null))
      && (!query.posted_within_days || clock - timestamp(job.posted_at || job.first_seen_at) <= Number(query.posted_within_days) * DAY);
  });
  const date = job => timestamp(job.posted_at || job.first_seen_at);
  items.sort((a,b) => {
    const order = query.sort === 'oldest' ? date(a)-date(b) : query.sort === 'title' ? String(a.title).localeCompare(String(b.title)) : query.sort === 'company' ? String(a.company_name).localeCompare(String(b.company_name)) : date(b)-date(a);
    return order || String(a.id).localeCompare(String(b.id));
  });
  const limit = Math.max(1, Math.min(100, Math.floor(Number(query.limit) || 25)));
  const offset = Math.max(0, Math.floor(Number(query.offset) || 0));
  return { items: items.slice(offset, offset + limit).map(job => ({ ...job, status: lifecycle(job, clock) })), total: items.length, offset, limit, facets, generation };
}
