import { queryJobs } from './query.mjs';
let input = '';
let bytes = 0;
process.stdin.setEncoding('utf8');
for await (const chunk of process.stdin) { bytes += Buffer.byteLength(chunk, 'utf8'); if (bytes > 64 * 1024 * 1024) throw new Error('Query input exceeds 64 MiB'); input += chunk; }
try { process.stdout.write(JSON.stringify(queryJobs(JSON.parse(input)))); }
catch (error) { process.stderr.write(String(error.message)); process.exitCode = 1; }
