"""SQLite persistence and matching logic for JobHound."""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import RLock
from typing import Any, Iterable, Iterator

from .models import ClaimedRun
from .tracker_contracts import TRACKER_SCHEMA
from .application_tracker import (
    APPLICATION_MILESTONES,
    MILESTONE_LABELS,
    OUTCOME_LABELS,
    legacy_stage,
    milestone_rank,
)


DEFAULT_DASHBOARD_LAYOUT = [
    {"key": "daily_recap", "visible": True, "size": "tall", "width": "wide"},
    {"key": "saved_jobs", "visible": True, "size": "tall"},
    {"key": "recent_chats", "visible": True, "size": "standard"},
    {"key": "scraper_alerts", "visible": True, "size": "standard"},
    {"key": "recent_ats_activity", "visible": True, "size": "tall"},
    {"key": "new_roles", "visible": True, "size": "tall"},
    {"key": "profile_visibility", "visible": True, "size": "standard"},
    {"key": "application_funnel", "visible": True, "size": "standard"},
    {"key": "create_widget", "visible": True, "size": "standard"},
]


class DashboardLayoutConflict(RuntimeError):
    """Raised when a dashboard layout update uses a stale revision."""


def iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize(value: str | None) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(char for char in value if not unicodedata.combining(char))
    return " ".join(re.sub(r"[^\w]+", " ", value.casefold()).split())


def _loads(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default


def _row(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    result = dict(row)
    for key in ("criteria_json", "recipe_json", "diagnostics_json", "match_reasons_json", "progress_detail_json"):
        if key in result:
            result[key.removesuffix("_json")] = _loads(result.pop(key), {} if key != "match_reasons_json" else [])
    for key in ("is_active", "unread", "dismissed", "is_saved", "saved"):
        if key in result:
            result[key] = bool(result[key])
    return result


SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  criteria_json TEXT NOT NULL,
  timezone TEXT NOT NULL,
  default_schedule_kind TEXT NOT NULL,
  default_interval_hours INTEGER NOT NULL,
  default_local_time TEXT NOT NULL,
  default_weekday INTEGER NOT NULL,
  criteria_version INTEGER NOT NULL DEFAULT 1,
  chat_provider TEXT NOT NULL DEFAULT 'codex',
  chat_model TEXT,
  chat_web_browsing INTEGER NOT NULL DEFAULT 1,
  chat_auto_create_monitors INTEGER NOT NULL DEFAULT 1,
  ai_connection TEXT,
  ai_model TEXT,
  onboarding_completed_at TEXT,
  agent_instructions_json TEXT NOT NULL DEFAULT '{}',
  agent_instructions_revision INTEGER NOT NULL DEFAULT 1,
  agent_instructions_updated_at TEXT,
  default_document_seed_keys_json TEXT NOT NULL DEFAULT '[]',
  home_location_json TEXT,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS platform_profiles (
  platform TEXT PRIMARY KEY,
  tracked INTEGER NOT NULL DEFAULT 1,
  visibility TEXT NOT NULL DEFAULT 'unknown',
  reminder_days INTEGER NOT NULL DEFAULT 30,
  confirmed_at TEXT,
  confirmation_source TEXT,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  careers_url TEXT NOT NULL,
  logo_url TEXT,
  kind TEXT NOT NULL DEFAULT 'monitor',
  adapter TEXT,
  state TEXT NOT NULL DEFAULT 'building',
  schedule_kind TEXT NOT NULL DEFAULT 'daily',
  interval_hours INTEGER NOT NULL DEFAULT 24,
  local_time TEXT NOT NULL DEFAULT '09:00',
  weekday INTEGER NOT NULL DEFAULT 0,
  timezone TEXT,
  criteria_json TEXT NOT NULL,
  active_recipe_version INTEGER,
  next_run_at TEXT,
  last_run_at TEXT,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  archived_at TEXT,
  lease_owner TEXT,
  lease_until TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS recipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  recipe_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'candidate',
  validation_message TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(company_id, version)
);
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  progress INTEGER NOT NULL DEFAULT 0,
  message TEXT,
  raw_count INTEGER NOT NULL DEFAULT 0,
  matched_count INTEGER NOT NULL DEFAULT 0,
  recipe_version INTEGER,
  full_run INTEGER NOT NULL DEFAULT 1,
  diagnostics_json TEXT,
  queued_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT,
  lease_owner TEXT,
  lease_until TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_queue ON runs(status, queued_at);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  source_job_id TEXT,
  stable_key TEXT NOT NULL,
  title TEXT NOT NULL,
  location TEXT NOT NULL DEFAULT '',
  location_city TEXT,
  remote_mode TEXT NOT NULL DEFAULT 'unknown',
  employment_type TEXT,
  posted_date TEXT,
  description TEXT NOT NULL DEFAULT '',
  salary_min REAL,
  salary_max REAL,
  salary_currency TEXT,
  salary_period TEXT,
  url TEXT NOT NULL,
  canonical_url TEXT,
  source TEXT,
  origin TEXT NOT NULL DEFAULT 'scraped',
  manual_request_id TEXT,
  content_hash TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  miss_count INTEGER NOT NULL DEFAULT 0,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  closed_at TEXT,
  last_run_id INTEGER REFERENCES runs(id),
  UNIQUE(company_id, stable_key)
);
CREATE INDEX IF NOT EXISTS idx_jobs_company_active ON jobs(company_id, is_active);
CREATE TABLE IF NOT EXISTS job_matches (
  job_id INTEGER PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,
  criteria_version INTEGER NOT NULL,
  is_match INTEGER NOT NULL,
  match_reasons_json TEXT NOT NULL,
  unread INTEGER NOT NULL DEFAULT 1,
  dismissed INTEGER NOT NULL DEFAULT 0,
  first_matched_at TEXT,
  last_matched_at TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  csrf_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_threads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  request_id TEXT UNIQUE,
  command_id TEXT,
  context_type TEXT,
  context_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
  content TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_thread ON chat_messages(thread_id, id);
CREATE TABLE IF NOT EXISTS chat_turns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  user_message_id INTEGER REFERENCES chat_messages(id) ON DELETE SET NULL,
  assistant_message_id INTEGER REFERENCES chat_messages(id) ON DELETE SET NULL,
  request_id TEXT NOT NULL UNIQUE,
  retry_of_turn_id INTEGER REFERENCES chat_turns(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK(status IN ('queued','running','complete','failed','cancelled','interrupted')),
  stage TEXT NOT NULL DEFAULT 'queued',
  progress INTEGER NOT NULL DEFAULT 0,
  request_json TEXT NOT NULL DEFAULT '{}',
  provider TEXT,
  model TEXT,
  instruction_revision INTEGER,
  error TEXT,
  cancel_requested INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT,
  updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_chat_turns_one_active
  ON chat_turns(thread_id) WHERE status IN ('queued','running');
CREATE INDEX IF NOT EXISTS idx_chat_turns_thread ON chat_turns(thread_id, id DESC);
CREATE TABLE IF NOT EXISTS chat_attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  source_document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
  original_filename TEXT NOT NULL,
  stored_filename TEXT,
  mime_type TEXT NOT NULL,
  extension TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  extracted_text TEXT NOT NULL DEFAULT '',
  extraction_status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT,
  attached_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_chat_attachments_thread ON chat_attachments(thread_id, id);
CREATE TABLE IF NOT EXISTS job_tracking (
  job_id INTEGER PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,
  saved INTEGER NOT NULL DEFAULT 0,
  saved_at TEXT,
  current_stage TEXT,
  milestone TEXT,
  outcome TEXT,
  applied_at TEXT,
  applied_at_inferred INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_job_tracking_saved ON job_tracking(saved, updated_at DESC);
CREATE TABLE IF NOT EXISTS job_activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('saved','unsaved','stage_changed','note','custom','chat','skill')),
  label TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  stage TEXT,
  milestone TEXT,
  outcome TEXT,
  actor_type TEXT NOT NULL DEFAULT 'human' CHECK(actor_type IN ('human','agent','system')),
  command_id TEXT,
  icon_key TEXT,
  thread_id INTEGER REFERENCES chat_threads(id) ON DELETE SET NULL,
  message_id INTEGER REFERENCES chat_messages(id) ON DELETE SET NULL,
  request_id TEXT,
  occurred_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_job_activities_job ON job_activities(job_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_job_activities_feed ON job_activities(id DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_job_activities_request
  ON job_activities(actor_type, request_id) WHERE request_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_job_activities_chat_message
  ON job_activities(thread_id, message_id) WHERE thread_id IS NOT NULL AND message_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS chat_run_links (
  run_id INTEGER PRIMARY KEY REFERENCES runs(id) ON DELETE CASCADE,
  thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  terminal_message_id INTEGER REFERENCES chat_messages(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chat_run_links_thread ON chat_run_links(thread_id, run_id);
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL CHECK(kind IN ('resume','intro_letter')),
  label TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  stored_filename TEXT NOT NULL UNIQUE,
  mime_type TEXT NOT NULL,
  extension TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  extracted_text TEXT NOT NULL DEFAULT '',
  extraction_status TEXT NOT NULL,
  template_key TEXT,
  layout_key TEXT,
  source_document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
  structured_content_json TEXT,
  fit_status TEXT,
  supersedes_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_documents_kind_archived ON documents(kind, archived_at, created_at);
CREATE INDEX IF NOT EXISTS idx_documents_hash ON documents(kind, sha256);
CREATE TABLE IF NOT EXISTS document_drafts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL CHECK(kind IN ('resume','intro_letter')),
  label TEXT NOT NULL,
  layout_key TEXT NOT NULL CHECK(layout_key IN ('corporate','creative','intro_letter')),
  source_document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
  content_json TEXT NOT NULL,
  fit_status TEXT NOT NULL CHECK(fit_status IN ('underfilled','balanced','overflow')),
  published_document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_document_drafts_source ON document_drafts(source_document_id, updated_at);
CREATE TABLE IF NOT EXISTS dashboard_layout (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  revision INTEGER NOT NULL DEFAULT 1,
  items_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS dashboard_widgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  manifest_json TEXT NOT NULL,
  javascript TEXT NOT NULL,
  css TEXT NOT NULL DEFAULT '',
  source_draft_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE TABLE IF NOT EXISTS dashboard_widget_drafts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  revision INTEGER NOT NULL DEFAULT 1,
  manifest_json TEXT NOT NULL,
  javascript TEXT NOT NULL,
  css TEXT NOT NULL DEFAULT '',
  thread_id INTEGER REFERENCES chat_threads(id) ON DELETE SET NULL,
  request_id TEXT UNIQUE,
  installed_widget_id INTEGER REFERENCES dashboard_widgets(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_widget_drafts_thread
  ON dashboard_widget_drafts(thread_id, updated_at DESC);
CREATE TABLE IF NOT EXISTS imported_presets (
  preset_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS preset_installations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  preset_id TEXT NOT NULL,
  preset_name TEXT NOT NULL,
  request_id TEXT NOT NULL UNIQUE,
  installed_at TEXT NOT NULL,
  archived_at TEXT,
  result_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS preset_installation_companies (
  installation_id INTEGER NOT NULL REFERENCES preset_installations(id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  company_key TEXT NOT NULL,
  installed_at TEXT NOT NULL,
  PRIMARY KEY(installation_id, company_id)
);
CREATE INDEX IF NOT EXISTS idx_preset_installation_companies_company
  ON preset_installation_companies(company_id, installation_id);
CREATE TABLE IF NOT EXISTS preset_pack_state (
  preset_id TEXT PRIMARY KEY,
  preset_name TEXT NOT NULL,
  hidden_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS company_preset_memberships (
  preset_id TEXT NOT NULL REFERENCES preset_pack_state(preset_id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  company_key TEXT,
  origin TEXT NOT NULL CHECK(origin IN ('installed','restored','matched_existing','manual')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(preset_id, company_id)
);
CREATE INDEX IF NOT EXISTS idx_company_preset_memberships_company
  ON company_preset_memberships(company_id, preset_id);
CREATE TABLE IF NOT EXISTS company_catalog_sources (
  company_id INTEGER PRIMARY KEY REFERENCES companies(id) ON DELETE CASCADE,
  catalog_company_id TEXT NOT NULL,
  catalog_monitor_id TEXT NOT NULL UNIQUE,
  installed_revision INTEGER NOT NULL,
  installed_sha256 TEXT,
  source_commit TEXT,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_company_catalog_company
  ON company_catalog_sources(catalog_company_id, catalog_monitor_id);
CREATE TABLE IF NOT EXISTS catalog_update_runs (
  run_id INTEGER PRIMARY KEY REFERENCES runs(id) ON DELETE CASCADE,
  request_id TEXT NOT NULL UNIQUE,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  recipe_version INTEGER NOT NULL,
  catalog_company_id TEXT NOT NULL,
  catalog_monitor_id TEXT NOT NULL,
  catalog_revision INTEGER NOT NULL,
  catalog_sha256 TEXT,
  source_commit TEXT,
  created_at TEXT NOT NULL
);
"""


class Database:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        self._lock = RLock()
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.migrate()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=15, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 15000")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def migrate(self) -> None:
        with self.connect() as connection:
            previous_version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            had_settings = bool(connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='settings'"
            ).fetchone())
            old_columns = ({row["name"] for row in connection.execute("PRAGMA table_info(settings)")}
                           if had_settings else set())
            connection.executescript("PRAGMA journal_mode = WAL;" + SCHEMA + TRACKER_SCHEMA)
            run_columns = {row["name"] for row in connection.execute("PRAGMA table_info(runs)")}
            if "progress_detail_json" not in run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN progress_detail_json TEXT NOT NULL DEFAULT '{}'")
            for count_column in ("new_count", "new_matched_count"):
                if count_column not in run_columns:
                    connection.execute(f"ALTER TABLE runs ADD COLUMN {count_column} INTEGER NOT NULL DEFAULT 0")
            thread_columns = {row["name"] for row in connection.execute("PRAGMA table_info(chat_threads)")}
            if "private_local" not in thread_columns:
                connection.execute("ALTER TABLE chat_threads ADD COLUMN private_local INTEGER NOT NULL DEFAULT 0")
            attachment_columns = {row["name"] for row in connection.execute("PRAGMA table_info(chat_attachments)")}
            if "source_interview_id" not in attachment_columns:
                connection.execute("ALTER TABLE chat_attachments ADD COLUMN source_interview_id INTEGER")
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(settings)")}
            for name, declaration in {
                "chat_provider": "TEXT NOT NULL DEFAULT 'codex'",
                "chat_model": "TEXT",
                "chat_web_browsing": "INTEGER NOT NULL DEFAULT 1",
                "chat_auto_create_monitors": "INTEGER NOT NULL DEFAULT 1",
                "ai_connection": "TEXT",
                "ai_model": "TEXT",
                "openai_model": "TEXT",
                "openai_reasoning_effort": "TEXT",
                "onboarding_completed_at": "TEXT",
                "agent_instructions_json": "TEXT NOT NULL DEFAULT '{}'",
                "agent_instructions_revision": "INTEGER NOT NULL DEFAULT 1",
                "agent_instructions_updated_at": "TEXT",
                "default_document_seed_keys_json": "TEXT NOT NULL DEFAULT '[]'",
                "home_location_json": "TEXT",
            }.items():
                if name not in columns:
                    connection.execute(f"ALTER TABLE settings ADD COLUMN {name} {declaration}")
            job_columns = {row["name"] for row in connection.execute("PRAGMA table_info(jobs)")}
            if "salary_period" not in job_columns:
                connection.execute("ALTER TABLE jobs ADD COLUMN salary_period TEXT")
            for name, declaration in {
                "origin": "TEXT NOT NULL DEFAULT 'scraped'",
                "manual_request_id": "TEXT",
            }.items():
                if name not in job_columns:
                    connection.execute(f"ALTER TABLE jobs ADD COLUMN {name} {declaration}")
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_manual_request "
                "ON jobs(manual_request_id) WHERE manual_request_id IS NOT NULL"
            )
            company_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(companies)")
            }
            if "kind" not in company_columns:
                connection.execute(
                    "ALTER TABLE companies ADD COLUMN kind TEXT NOT NULL DEFAULT 'monitor'"
                )
            if "logo_url" not in company_columns:
                connection.execute("ALTER TABLE companies ADD COLUMN logo_url TEXT")
            tracking_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(job_tracking)")
            }
            for name, declaration in {
                "milestone": "TEXT",
                "outcome": "TEXT",
                "applied_at": "TEXT",
                "applied_at_inferred": "INTEGER NOT NULL DEFAULT 0",
            }.items():
                if name not in tracking_columns:
                    connection.execute(f"ALTER TABLE job_tracking ADD COLUMN {name} {declaration}")
            activity_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(job_activities)")
            }
            for name, declaration in {
                "milestone": "TEXT",
                "outcome": "TEXT",
                "occurred_at": "TEXT",
            }.items():
                if name not in activity_columns:
                    connection.execute(f"ALTER TABLE job_activities ADD COLUMN {name} {declaration}")
            connection.execute(
                "UPDATE job_activities SET occurred_at=created_at WHERE occurred_at IS NULL"
            )
            if previous_version < 14:
                legacy_rows = connection.execute(
                    "SELECT job_id,current_stage,updated_at FROM job_tracking "
                    "WHERE current_stage IS NOT NULL AND milestone IS NULL AND outcome IS NULL"
                ).fetchall()
                for row in legacy_rows:
                    raw = str(row["current_stage"] or "").strip().casefold()
                    milestone = {
                        "applied": "applied", "interviewing": "interview", "offer": "offer",
                    }.get(raw)
                    outcome = {"rejected": "rejected", "withdrawn": "withdrawn"}.get(raw)
                    if not milestone and outcome:
                        earlier = connection.execute(
                            "SELECT stage FROM job_activities WHERE job_id=? AND kind='stage_changed' "
                            "AND LOWER(stage) IN ('applied','interviewing','offer') ORDER BY id DESC LIMIT 1",
                            (row["job_id"],),
                        ).fetchone()
                        milestone = {
                            "applied": "applied", "interviewing": "interview", "offer": "offer",
                        }.get(str(earlier["stage"] or "").casefold() if earlier else "", "applied")
                    if milestone or outcome:
                        first = connection.execute(
                            "SELECT COALESCE(occurred_at,created_at) at FROM job_activities "
                            "WHERE job_id=? AND kind='stage_changed' "
                            "AND LOWER(COALESCE(stage,'')) IN ('applied','interviewing','offer','rejected','withdrawn') "
                            "ORDER BY id LIMIT 1",
                            (row["job_id"],),
                        ).fetchone()
                        applied_at = (first["at"] if first else row["updated_at"])
                        connection.execute(
                            "UPDATE job_tracking SET milestone=?,outcome=?,applied_at=?,"
                            "applied_at_inferred=1 WHERE job_id=?",
                            (milestone or "applied", outcome, applied_at, row["job_id"]),
                        )
            chat_thread_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(chat_threads)")
            }
            for name, declaration in {
                "request_id": "TEXT",
                "command_id": "TEXT",
                "context_type": "TEXT",
                "context_id": "INTEGER",
            }.items():
                if name not in chat_thread_columns:
                    connection.execute(f"ALTER TABLE chat_threads ADD COLUMN {name} {declaration}")
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_chat_threads_request_id "
                "ON chat_threads(request_id) WHERE request_id IS NOT NULL"
            )
            document_columns = {row["name"] for row in connection.execute("PRAGMA table_info(documents)")}
            for name, declaration in {
                "template_key": "TEXT",
                "layout_key": "TEXT",
                "source_document_id": "INTEGER REFERENCES documents(id) ON DELETE SET NULL",
                "structured_content_json": "TEXT",
                "fit_status": "TEXT",
            }.items():
                if name not in document_columns:
                    connection.execute(f"ALTER TABLE documents ADD COLUMN {name} {declaration}")
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_documents_template_key "
                "ON documents(template_key) WHERE template_key IS NOT NULL"
            )
            connection.execute(
                """INSERT OR IGNORE INTO settings
                (id, criteria_json, timezone, default_schedule_kind, default_interval_hours,
                 default_local_time, default_weekday, criteria_version, updated_at)
                VALUES (1, ?, 'America/Toronto', 'daily', 24, '09:00', 0, 1, ?)""",
                (json.dumps({"cities": [], "title_terms": [], "keywords": []}), iso_now()),
            )
            if had_settings and "ai_connection" not in old_columns:
                connection.execute(
                    "UPDATE settings SET ai_connection=chat_provider, ai_model=chat_model WHERE id=1"
                )
            if "openai_model" not in columns:
                connection.execute("UPDATE settings SET openai_model=ai_model WHERE ai_connection='codex'")
            if previous_version < 7:
                connection.execute(
                    """UPDATE chat_threads SET command_id=NULL
                    WHERE command_id='find_recruiters' AND EXISTS (
                      SELECT 1 FROM chat_messages
                      WHERE chat_messages.thread_id=chat_threads.id
                        AND metadata_json LIKE '%\"recruiter_search\"%'
                    )"""
                )
            if previous_version < 9:
                connection.execute(
                    """INSERT OR IGNORE INTO job_activities
                    (job_id,kind,label,detail,actor_type,command_id,icon_key,thread_id,message_id,created_at)
                    SELECT t.context_id,
                      CASE WHEN COALESCE(t.command_id,
                        (SELECT json_extract(a.metadata_json,'$.command_used.id') FROM chat_messages a
                         WHERE a.thread_id=t.id AND a.role='assistant'
                           AND json_extract(a.metadata_json,'$.command_used.id') IS NOT NULL
                         ORDER BY a.id LIMIT 1)) IN ('find_recruiters','interview_prep')
                        THEN 'skill' ELSE 'chat' END,
                      CASE COALESCE(t.command_id,
                        (SELECT json_extract(a.metadata_json,'$.command_used.id') FROM chat_messages a
                         WHERE a.thread_id=t.id AND a.role='assistant'
                           AND json_extract(a.metadata_json,'$.command_used.id') IS NOT NULL
                         ORDER BY a.id LIMIT 1))
                        WHEN 'find_recruiters' THEN 'Find potential recruiters'
                        WHEN 'interview_prep' THEN 'Prepare for an interview'
                        ELSE 'Chat about this role' END,
                      t.title,'human',COALESCE(t.command_id,
                        (SELECT json_extract(a.metadata_json,'$.command_used.id') FROM chat_messages a
                         WHERE a.thread_id=t.id AND a.role='assistant'
                           AND json_extract(a.metadata_json,'$.command_used.id') IS NOT NULL
                         ORDER BY a.id LIMIT 1)),
                      CASE COALESCE(t.command_id,
                        (SELECT json_extract(a.metadata_json,'$.command_used.id') FROM chat_messages a
                         WHERE a.thread_id=t.id AND a.role='assistant'
                           AND json_extract(a.metadata_json,'$.command_used.id') IS NOT NULL
                         ORDER BY a.id LIMIT 1))
                        WHEN 'find_recruiters' THEN 'search'
                        WHEN 'interview_prep' THEN 'sparkles'
                        ELSE 'message' END,
                      t.id,u.id,u.created_at
                    FROM chat_threads t JOIN chat_messages u ON u.id=(
                      SELECT id FROM chat_messages WHERE thread_id=t.id AND role='user' ORDER BY id LIMIT 1)
                    WHERE t.context_type='job' AND EXISTS(SELECT 1 FROM jobs j WHERE j.id=t.context_id)"""
                )
            platform_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(platform_profiles)")
            }
            platform_sql_row = connection.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='platform_profiles'"
            ).fetchone()
            platform_sql = str(platform_sql_row["sql"] or "") if platform_sql_row else ""
            if "tracked" not in platform_columns or "CHECK (platform IN" in platform_sql:
                connection.executescript(
                    """CREATE TABLE platform_profiles_v13 (
                      platform TEXT PRIMARY KEY,
                      tracked INTEGER NOT NULL DEFAULT 1,
                      visibility TEXT NOT NULL DEFAULT 'unknown',
                      reminder_days INTEGER NOT NULL DEFAULT 30,
                      confirmed_at TEXT,
                      confirmation_source TEXT,
                      updated_at TEXT NOT NULL
                    );
                    INSERT INTO platform_profiles_v13
                      (platform,tracked,visibility,reminder_days,confirmed_at,confirmation_source,updated_at)
                    SELECT platform,1,visibility,reminder_days,confirmed_at,confirmation_source,updated_at
                    FROM platform_profiles;
                    DROP TABLE platform_profiles;
                    ALTER TABLE platform_profiles_v13 RENAME TO platform_profiles;"""
                )
            connection.execute(
                """INSERT OR IGNORE INTO dashboard_layout(id,revision,items_json,updated_at)
                VALUES(1,1,?,?)""",
                (json.dumps(DEFAULT_DASHBOARD_LAYOUT), iso_now()),
            )
            if previous_version < 13:
                for platform in ("linkedin", "indeed"):
                    connection.execute(
                        """INSERT OR IGNORE INTO platform_profiles
                        (platform,tracked,visibility,reminder_days,updated_at)
                        VALUES(?,1,'unknown',30,?)""",
                        (platform, iso_now()),
                    )
            layout_row = connection.execute(
                "SELECT revision,items_json FROM dashboard_layout WHERE id=1"
            ).fetchone()
            layout_items = _loads(layout_row["items_json"], [])
            existing_layout_keys = {item.get("key") for item in layout_items}
            missing_layout_items = [
                dict(item) for item in DEFAULT_DASHBOARD_LAYOUT
                if item["key"] not in existing_layout_keys
            ]
            if missing_layout_items:
                connection.execute(
                    "UPDATE dashboard_layout SET revision=?,items_json=?,updated_at=? WHERE id=1",
                    (int(layout_row["revision"]) + 1,
                     json.dumps([*[item for item in missing_layout_items if item["key"] == "daily_recap"],
                                 *layout_items, *[item for item in missing_layout_items if item["key"] != "daily_recap"]]), iso_now()),
                )
            if previous_version < 15:
                installations = connection.execute(
                    "SELECT id,preset_id,preset_name,result_json FROM preset_installations "
                    "WHERE archived_at IS NULL ORDER BY id"
                ).fetchall()
                for installation in installations:
                    now = iso_now()
                    connection.execute(
                        """INSERT INTO preset_pack_state
                        (preset_id,preset_name,created_at,updated_at) VALUES(?,?,?,?)
                        ON CONFLICT(preset_id) DO UPDATE SET
                        preset_name=excluded.preset_name,updated_at=excluded.updated_at""",
                        (installation["preset_id"], installation["preset_name"], now, now),
                    )
                    result = _loads(installation["result_json"], {})
                    linked = {
                        int(row["company_id"]): row["company_key"]
                        for row in connection.execute(
                            "SELECT company_id,company_key FROM preset_installation_companies "
                            "WHERE installation_id=?", (installation["id"],)
                        ).fetchall()
                    }
                    entries = {
                        company_id: (company_key, "installed")
                        for company_id, company_key in linked.items()
                    }
                    for item in result.get("installed", []):
                        if item.get("company_id"):
                            entries[int(item["company_id"])] = (
                                item.get("key"),
                                "restored" if item.get("operation") == "restored" else "installed",
                            )
                    for item in result.get("skipped", []):
                        if item.get("company_id"):
                            entries[int(item["company_id"])] = (item.get("key"), "matched_existing")
                    for company_id, (company_key, origin) in entries.items():
                        connection.execute(
                            """INSERT OR IGNORE INTO company_preset_memberships
                            (preset_id,company_id,company_key,origin,created_at,updated_at)
                            SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM companies WHERE id=?)""",
                            (installation["preset_id"], company_id, company_key, origin,
                             now, now, company_id),
                        )
            connection.execute("PRAGMA user_version = 15")

    def list_platform_profiles(self, *, tracked_only: bool = True) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT platform,tracked,visibility,reminder_days,confirmed_at,
                confirmation_source,updated_at FROM platform_profiles
                WHERE tracked=1 OR ?=0
                ORDER BY CASE platform WHEN 'linkedin' THEN 0 WHEN 'indeed' THEN 1 ELSE 2 END,
                platform""", (1 if tracked_only else 0,)
            ).fetchall()
        return [{**dict(row), "tracked": bool(row["tracked"])} for row in rows]

    def track_platform_profile(self, platform: str) -> dict[str, Any]:
        now = iso_now()
        with self.connect() as connection:
            connection.execute(
                """INSERT INTO platform_profiles
                (platform,tracked,visibility,reminder_days,updated_at) VALUES(?,1,'unknown',30,?)
                ON CONFLICT(platform) DO UPDATE SET tracked=1,updated_at=excluded.updated_at""",
                (platform, now),
            )
            row = connection.execute(
                """SELECT platform,tracked,visibility,reminder_days,confirmed_at,
                confirmation_source,updated_at FROM platform_profiles WHERE platform=?""",
                (platform,),
            ).fetchone()
        return {**dict(row), "tracked": True}

    def untrack_platform_profile(self, platform: str) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                "UPDATE platform_profiles SET tracked=0,updated_at=? WHERE platform=?",
                (iso_now(), platform),
            )
            row = connection.execute(
                """SELECT platform,tracked,visibility,reminder_days,confirmed_at,
                confirmation_source,updated_at FROM platform_profiles WHERE platform=?""",
                (platform,),
            ).fetchone()
        if not row:
            raise ValueError("platform is not tracked")
        return {**dict(row), "tracked": False}

    def update_platform_profile(
        self, *, platform: str, visibility: str, reminder_days: int,
        confirmation_source: str,
    ) -> dict[str, Any]:
        now = iso_now()
        confirmed_at = None if visibility == "unknown" else now
        with self.connect() as connection:
            connection.execute(
                """UPDATE platform_profiles SET visibility=?,reminder_days=?,confirmed_at=?,
                confirmation_source=?,updated_at=? WHERE platform=?""",
                (visibility, reminder_days, confirmed_at,
                 None if visibility == "unknown" else confirmation_source, now, platform),
            )
            row = connection.execute(
                """SELECT platform,tracked,visibility,reminder_days,confirmed_at,
                confirmation_source,updated_at FROM platform_profiles WHERE platform=?""",
                (platform,),
            ).fetchone()
        if not row:
            raise ValueError("unknown job platform")
        if not bool(row["tracked"]):
            raise ValueError("platform is not tracked")
        return {**dict(row), "tracked": True}

    def get_dashboard_layout(self) -> dict[str, Any]:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT revision,items_json,updated_at FROM dashboard_layout WHERE id=1"
            ).fetchone()
        if not row:
            # Defensive fallback for an externally modified database. Normal migrations always seed it.
            return {"revision": 1, "items": [dict(item) for item in DEFAULT_DASHBOARD_LAYOUT],
                    "updated_at": None}
        return {
            "revision": int(row["revision"]),
            "items": _loads(row["items_json"], [dict(item) for item in DEFAULT_DASHBOARD_LAYOUT]),
            "updated_at": row["updated_at"],
        }

    def update_dashboard_layout(
        self, *, expected_revision: int, items: list[dict[str, Any]],
    ) -> dict[str, Any]:
        now = iso_now()
        with self._lock, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT revision FROM dashboard_layout WHERE id=1"
            ).fetchone()
            current_revision = int(row["revision"]) if row else 1
            if current_revision != expected_revision:
                raise DashboardLayoutConflict(
                    f"Dashboard layout changed from revision {expected_revision} to "
                    f"{current_revision}. Reload it before saving again."
                )
            next_revision = current_revision + 1
            connection.execute(
                """INSERT INTO dashboard_layout(id,revision,items_json,updated_at)
                VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET
                revision=excluded.revision,items_json=excluded.items_json,
                updated_at=excluded.updated_at""",
                (next_revision, json.dumps(items), now),
            )
        return {"revision": next_revision, "items": items, "updated_at": now}

    def get_settings(self) -> dict[str, Any]:
        with self.connect() as connection:
            row = dict(connection.execute("SELECT * FROM settings WHERE id=1").fetchone())
        row["criteria"] = _loads(row.pop("criteria_json"), {})
        row["agent_instruction_overrides"] = _loads(row.pop("agent_instructions_json", "{}"), {})
        row["default_document_seed_keys"] = _loads(
            row.pop("default_document_seed_keys_json", "[]"), []
        )
        row["home_location"] = _loads(row.pop("home_location_json", "null"), None)
        row["chat_web_browsing"] = bool(row.get("chat_web_browsing", 1))
        row["chat_auto_create_monitors"] = bool(row.get("chat_auto_create_monitors", 1))
        row["onboarding_completed"] = bool(row.get("onboarding_completed_at"))
        return row

    def set_home_location(self, value: dict[str, Any] | None) -> dict[str, Any] | None:
        with self.connect() as connection:
            connection.execute(
                "UPDATE settings SET home_location_json=?, updated_at=? WHERE id=1",
                (json.dumps(value) if value is not None else None, iso_now()),
            )
        return self.get_settings().get("home_location")

    def mark_default_document_seeded(self, template_key: str) -> None:
        settings = self.get_settings()
        keys = list(dict.fromkeys([
            *settings.get("default_document_seed_keys", []), template_key,
        ]))
        with self.connect() as connection:
            connection.execute(
                "UPDATE settings SET default_document_seed_keys_json=?, updated_at=? WHERE id=1",
                (json.dumps(keys), iso_now()),
            )

    def set_agent_instruction_overrides(self, overrides: dict[str, str]) -> dict[str, Any]:
        current = self.get_settings()
        if current.get("agent_instruction_overrides", {}) == overrides:
            return current
        now = iso_now()
        with self.connect() as connection:
            connection.execute(
                """UPDATE settings SET agent_instructions_json=?,
                agent_instructions_revision=agent_instructions_revision+1,
                agent_instructions_updated_at=?, updated_at=? WHERE id=1""",
                (json.dumps(overrides, ensure_ascii=False), now, now),
            )
        return self.get_settings()

    def update_settings(self, data: dict[str, Any]) -> dict[str, Any]:
        current = self.get_settings()
        changed = current["criteria"] != data["criteria"]
        version = current["criteria_version"] + int(changed)
        with self.connect() as connection:
            connection.execute(
                """UPDATE settings SET criteria_json=?, timezone=?, default_schedule_kind=?,
                default_interval_hours=?, default_local_time=?, default_weekday=?, criteria_version=?,
                chat_provider=?, chat_model=?, chat_web_browsing=?, chat_auto_create_monitors=?, updated_at=? WHERE id=1""",
                (json.dumps(data["criteria"]), data["timezone"], data["default_schedule_kind"],
                 data["default_interval_hours"], data["default_local_time"], data["default_weekday"],
                 version, data.get("chat_provider", current.get("chat_provider", "codex")),
                 data.get("chat_model"), int(data.get("chat_web_browsing", True)),
                 int(data.get("chat_auto_create_monitors", True)), iso_now()),
            )
        if changed:
            self.recompute_matches()
        return self.get_settings()

    def set_ai_selection(self, connection_id: str | None, model: str | None = None, *, openai_options: dict | None = None) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                "UPDATE settings SET ai_connection=?, ai_model=?, updated_at=? WHERE id=1",
                (connection_id, model, iso_now()),
            )
            if connection_id == "codex":
                connection.execute("UPDATE settings SET openai_model=? WHERE id=1", (model,))
                if openai_options is not None and "reasoning_effort" in openai_options:
                    connection.execute("UPDATE settings SET openai_reasoning_effort=? WHERE id=1",
                                       (openai_options["reasoning_effort"],))
        return self.get_settings()

    def complete_onboarding(self) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                "UPDATE settings SET onboarding_completed_at=COALESCE(onboarding_completed_at, ?), updated_at=? WHERE id=1",
                (iso_now(), iso_now()),
            )
        return self.get_settings()

    def create_chat_thread(
        self, title: str = "New chat", *, command_id: str | None = None,
        context_type: str | None = None, context_id: int | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        now = iso_now()
        with self.connect() as connection:
            cursor = connection.execute(
                """INSERT OR IGNORE INTO chat_threads
                (title, request_id, command_id, context_type, context_id, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?)""",
                (title.strip() or "New chat", request_id, command_id, context_type, context_id, now, now),
            )
            if cursor.rowcount:
                thread_id = int(cursor.lastrowid)
            else:
                row = connection.execute("SELECT id FROM chat_threads WHERE request_id=?", (request_id,)).fetchone()
                thread_id = int(row["id"])
        return self.get_chat_thread(thread_id) or {}

    def list_chat_threads(
        self, *, role_id: int | None = None, company_id: int | None = None,
        command_id: str | None = None, query: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        conditions: list[str] = []
        params: list[Any] = []
        if role_id is not None:
            conditions.append("(t.context_type='job' AND t.context_id=? OR EXISTS "
                              "(SELECT 1 FROM job_activities a WHERE a.thread_id=t.id AND a.job_id=?))")
            params.extend([role_id, role_id])
        if company_id is not None:
            conditions.append("((t.context_type='job' AND EXISTS (SELECT 1 FROM jobs j "
                              "WHERE j.id=t.context_id AND j.company_id=?)) OR EXISTS "
                              "(SELECT 1 FROM job_activities a JOIN jobs j ON j.id=a.job_id "
                              "WHERE a.thread_id=t.id AND j.company_id=?))")
            params.extend([company_id, company_id])
        if command_id:
            conditions.append("(t.command_id=? OR EXISTS (SELECT 1 FROM chat_messages cm "
                              "WHERE cm.thread_id=t.id AND json_extract(cm.metadata_json,'$.command_used.id')=?))")
            params.extend([command_id, command_id])
        if query and query.strip():
            pattern = f"%{query.strip()}%"
            conditions.append("(t.title LIKE ? OR EXISTS (SELECT 1 FROM chat_messages cm "
                              "WHERE cm.thread_id=t.id AND cm.content LIKE ?) OR EXISTS "
                              "(SELECT 1 FROM jobs j JOIN companies c ON c.id=j.company_id "
                              "WHERE (j.id=t.context_id AND t.context_type='job' OR EXISTS "
                              "(SELECT 1 FROM job_activities a WHERE a.thread_id=t.id AND a.job_id=j.id)) "
                              "AND (j.title LIKE ? OR c.name LIKE ?)))")
            params.extend([pattern, pattern, pattern, pattern])
        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        suffix = " LIMIT ?" if limit is not None else ""
        if limit is not None:
            params.append(limit)
        with self.connect() as connection:
            rows = connection.execute(
                f"""SELECT t.*, COUNT(m.id) message_count,
                (SELECT content FROM chat_messages WHERE thread_id=t.id ORDER BY id DESC LIMIT 1) preview
                FROM chat_threads t LEFT JOIN chat_messages m ON m.thread_id=t.id
                {where} GROUP BY t.id ORDER BY t.updated_at DESC{suffix}""", params,
            ).fetchall()
        return [dict(row) for row in rows]

    def list_dashboard_chat_threads(
        self, *, limit: int = 3, include_document_context: bool = True,
    ) -> list[dict[str, Any]]:
        privacy_filter = "" if include_document_context else "WHERE t.private_local=0 AND (t.context_type IS NULL OR t.context_type!='document')"
        with self.connect() as connection:
            rows = connection.execute(
                f"""SELECT t.*, COUNT(m.id) message_count,
                (SELECT content FROM chat_messages WHERE thread_id=t.id ORDER BY id DESC LIMIT 1) preview
                FROM chat_threads t LEFT JOIN chat_messages m ON m.thread_id=t.id
                {privacy_filter} GROUP BY t.id ORDER BY t.updated_at DESC, t.id DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def get_chat_thread(self, thread_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            thread = connection.execute("SELECT * FROM chat_threads WHERE id=?", (thread_id,)).fetchone()
            if not thread:
                return None
            messages = connection.execute(
                "SELECT * FROM chat_messages WHERE thread_id=? ORDER BY id", (thread_id,)
            ).fetchall()
        result = dict(thread)
        result["messages"] = []
        for message in messages:
            item = dict(message)
            item["metadata"] = _loads(item.pop("metadata_json"), {})
            result["messages"].append(item)
        return result

    def rename_chat_thread(self, thread_id: int, title: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            connection.execute("UPDATE chat_threads SET title=?, updated_at=? WHERE id=?", (title.strip(), iso_now(), thread_id))
        return self.get_chat_thread(thread_id)

    def delete_chat_thread(self, thread_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute("DELETE FROM chat_threads WHERE id=?", (thread_id,))
        return cursor.rowcount > 0

    def update_chat_thread(self, thread_id: int, **changes: Any) -> dict[str, Any] | None:
        allowed = {key: value for key, value in changes.items() if key in {
            "title", "command_id", "context_type", "context_id"
        }}
        if "title" in allowed:
            allowed["title"] = str(allowed["title"]).strip()
        if allowed:
            allowed["updated_at"] = iso_now()
            with self.connect() as connection:
                connection.execute(
                    "UPDATE chat_threads SET " + ",".join(f"{key}=?" for key in allowed) + " WHERE id=?",
                    (*allowed.values(), thread_id),
                )
        return self.get_chat_thread(thread_id)

    def add_chat_message(self, thread_id: int, role: str, content: str, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
        now = iso_now()
        with self.connect() as connection:
            cursor = connection.execute(
                "INSERT INTO chat_messages(thread_id, role, content, metadata_json, created_at) VALUES(?,?,?,?,?)",
                (thread_id, role, content, json.dumps(metadata or {}), now),
            )
            connection.execute("UPDATE chat_threads SET updated_at=? WHERE id=?", (now, thread_id))
            row = connection.execute("SELECT * FROM chat_messages WHERE id=?", (cursor.lastrowid,)).fetchone()
        result = dict(row)
        result["metadata"] = _loads(result.pop("metadata_json"), {})
        return result

    def get_chat_activity_summary(self, thread_id: int) -> dict[str, Any]:
        with self.connect() as connection:
            role_rows = connection.execute(
                """SELECT DISTINCT j.id,j.title,j.company_id,c.name AS company
                FROM jobs j JOIN companies c ON c.id=j.company_id
                WHERE j.id IN (
                  SELECT context_id FROM chat_threads WHERE id=? AND context_type='job'
                  UNION SELECT job_id FROM job_activities WHERE thread_id=?
                ) ORDER BY j.id""", (thread_id, thread_id),
            ).fetchall()
            message_rows = connection.execute(
                "SELECT metadata_json FROM chat_messages WHERE thread_id=? ORDER BY id", (thread_id,),
            ).fetchall()
            thread = connection.execute(
                "SELECT command_id,context_type,context_id FROM chat_threads WHERE id=?", (thread_id,),
            ).fetchone()
        commands: dict[str, dict[str, Any]] = {}
        for row in message_rows:
            command = (_loads(row["metadata_json"], {}) or {}).get("command_used")
            if isinstance(command, dict) and command.get("id"):
                key = str(command["id"])
                current = commands.setdefault(key, {**command, "count": 0})
                current["count"] += 1
        roles = [dict(row) for row in role_rows]
        companies = sorted(
            {
                int(role["company_id"]): {
                    "id": int(role["company_id"]),
                    "name": str(role["company"]),
                }
                for role in roles
                if role.get("company_id") is not None and role.get("company")
            }.values(),
            key=lambda company: company["name"].casefold(),
        )
        return {
            "roles": roles,
            "companies": companies,
            "skills": list(commands.values()),
            "current_command_id": thread["command_id"] if thread else None,
            "context": ({"type": thread["context_type"], "id": thread["context_id"]}
                        if thread and thread["context_type"] else None),
        }

    def create_chat_turn(self, thread_id: int, request_id: str, request: dict[str, Any], *,
                         user_message_id: int | None = None,
                         retry_of_turn_id: int | None = None) -> tuple[dict[str, Any], bool]:
        now = iso_now()
        with self.connect() as connection:
            existing = connection.execute("SELECT * FROM chat_turns WHERE request_id=?", (request_id,)).fetchone()
            if existing:
                return self._present_chat_turn(dict(existing)), True
            try:
                cursor = connection.execute(
                    """INSERT INTO chat_turns(thread_id,user_message_id,request_id,retry_of_turn_id,
                    status,stage,progress,request_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (thread_id, user_message_id, request_id, retry_of_turn_id, "queued", "queued", 0,
                     json.dumps(request), now, now),
                )
            except sqlite3.IntegrityError as exc:
                if "chat_turns.thread_id" in str(exc) or "idx_chat_turns_one_active" in str(exc):
                    raise RuntimeError("This chat already has an active turn") from exc
                raise
            row = connection.execute("SELECT * FROM chat_turns WHERE id=?", (cursor.lastrowid,)).fetchone()
        return self._present_chat_turn(dict(row)), False

    @staticmethod
    def _present_chat_turn(row: dict[str, Any]) -> dict[str, Any]:
        row["request"] = _loads(row.pop("request_json", None), {})
        row["cancel_requested"] = bool(row.get("cancel_requested"))
        return row

    def get_chat_turn(self, turn_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM chat_turns WHERE id=?", (turn_id,)).fetchone()
        return self._present_chat_turn(dict(row)) if row else None

    def get_active_chat_turn(self, thread_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM chat_turns WHERE thread_id=? AND status IN ('queued','running') "
                "ORDER BY id DESC LIMIT 1", (thread_id,),
            ).fetchone()
        return self._present_chat_turn(dict(row)) if row else None

    def update_chat_turn(self, turn_id: int, **changes: Any) -> dict[str, Any] | None:
        allowed = {key: value for key, value in changes.items() if key in {
            "user_message_id", "assistant_message_id", "status", "stage", "progress", "provider",
            "model", "instruction_revision", "error", "cancel_requested", "started_at", "finished_at",
        }}
        if allowed:
            allowed["updated_at"] = iso_now()
            with self.connect() as connection:
                connection.execute("UPDATE chat_turns SET " + ",".join(f"{key}=?" for key in allowed) +
                                   " WHERE id=?", (*allowed.values(), turn_id))
        return self.get_chat_turn(turn_id)

    def update_running_chat_stage(self, turn_id: int, stage: str) -> dict[str, Any] | None:
        # Terminal status wins even when a provider callback arrives after cancellation.
        with self.connect() as connection:
            changed = connection.execute(
                "UPDATE chat_turns SET stage=?,updated_at=? WHERE id=? "
                "AND status='running' AND cancel_requested=0",
                (stage, iso_now(), turn_id),
            ).rowcount
        return self.get_chat_turn(turn_id) if changed else None

    def interrupt_active_chat_turns(self) -> int:
        now = iso_now()
        with self.connect() as connection:
            cursor = connection.execute(
                """UPDATE chat_turns SET status='interrupted',stage='interrupted',progress=100,
                error='JobHound restarted before this turn completed',finished_at=?,updated_at=?
                WHERE status IN ('queued','running')""", (now, now),
            )
        return cursor.rowcount

    def create_chat_attachment(self, value: dict[str, Any]) -> dict[str, Any]:
        with self.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO chat_attachments(thread_id,source_document_id,original_filename,
                stored_filename,mime_type,extension,size_bytes,sha256,extracted_text,extraction_status,
                created_at,expires_at,attached_at,source_interview_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (value["thread_id"], value.get("source_document_id"), value["original_filename"],
                 value.get("stored_filename"), value["mime_type"], value["extension"], value["size_bytes"],
                 value["sha256"], value.get("extracted_text", ""), value["extraction_status"],
                 value.get("created_at", iso_now()), value.get("expires_at"), value.get("attached_at"), value.get("source_interview_id")),
            )
            row = connection.execute("SELECT * FROM chat_attachments WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def get_chat_attachment(self, attachment_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM chat_attachments WHERE id=?", (attachment_id,)).fetchone()
        return dict(row) if row else None

    def list_chat_attachments(self, thread_id: int) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM chat_attachments WHERE thread_id=? ORDER BY id", (thread_id,)).fetchall()
        return [dict(row) for row in rows]

    def mark_chat_attachments_used(self, ids: list[int]) -> None:
        if not ids:
            return
        with self.connect() as connection:
            connection.execute(
                f"UPDATE chat_attachments SET attached_at=?,expires_at=NULL WHERE id IN ({','.join('?' for _ in ids)})",
                (iso_now(), *ids),
            )

    def delete_chat_attachment(self, attachment_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM chat_attachments WHERE id=?", (attachment_id,)).fetchone()
            if row:
                connection.execute("DELETE FROM chat_attachments WHERE id=?", (attachment_id,))
        return dict(row) if row else None

    def link_chat_run(self, run_id: int, thread_id: int, action: str) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO chat_run_links(run_id, thread_id, action, terminal_message_id, created_at) VALUES(?,?,?,?,?)",
                (run_id, thread_id, action, None, iso_now()),
            )
            row = connection.execute("SELECT * FROM chat_run_links WHERE run_id=?", (run_id,)).fetchone()
        return dict(row)

    def get_chat_run_link(self, run_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM chat_run_links WHERE run_id=?", (run_id,)).fetchone()
        return dict(row) if row else None

    def pending_chat_run_links(self, thread_id: int) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT l.*, r.status, r.kind, r.message, r.raw_count, r.matched_count,
                r.company_id, c.name AS company_name
                FROM chat_run_links l JOIN runs r ON r.id=l.run_id
                JOIN companies c ON c.id=r.company_id
                WHERE l.thread_id=? AND l.terminal_message_id IS NULL
                AND r.status IN ('complete','partial','failed') ORDER BY l.run_id""",
                (thread_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def mark_chat_run_announced(self, run_id: int, message_id: int) -> None:
        with self.connect() as connection:
            connection.execute(
                "UPDATE chat_run_links SET terminal_message_id=? WHERE run_id=? AND terminal_message_id IS NULL",
                (message_id, run_id),
            )

    def list_documents(self, *, kind: str | None = None, include_archived: bool = False) -> list[dict[str, Any]]:
        conditions: list[str] = []
        params: list[Any] = []
        if kind:
            conditions.append("kind=?")
            params.append(kind)
        if not include_archived:
            conditions.append("archived_at IS NULL")
        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM documents" + where + " ORDER BY archived_at IS NOT NULL, updated_at DESC, id DESC",
                params,
            ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _present_draft(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
        value = dict(row)
        value["content"] = _loads(value.pop("content_json"), {})
        value["record_type"] = "draft"
        value["published"] = bool(value.get("published_document_id"))
        return value

    def list_document_drafts(self, *, kind: str | None = None) -> list[dict[str, Any]]:
        query = "SELECT * FROM document_drafts"
        params: tuple[Any, ...] = ()
        if kind:
            query += " WHERE kind=?"; params = (kind,)
        query += " ORDER BY updated_at DESC, id DESC"
        with self.connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [self._present_draft(row) for row in rows]

    def get_document_draft(self, draft_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM document_drafts WHERE id=?", (draft_id,)).fetchone()
        return self._present_draft(row) if row else None

    def create_document_draft(self, data: dict[str, Any]) -> dict[str, Any]:
        now = iso_now()
        with self.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO document_drafts
                (kind,label,layout_key,source_document_id,content_json,fit_status,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?)""",
                (data["kind"], data["label"], data["layout_key"], data.get("source_document_id"),
                 json.dumps(data["content"], ensure_ascii=False), data["fit_status"], now, now),
            )
            draft_id = int(cursor.lastrowid)
        return self.get_document_draft(draft_id) or {}

    def update_document_draft(self, draft_id: int, data: dict[str, Any]) -> dict[str, Any] | None:
        current = self.get_document_draft(draft_id)
        if not current:
            return None
        changes = {
            "kind": data["kind"], "label": data["label"], "layout_key": data["layout_key"],
            "content_json": json.dumps(data["content"], ensure_ascii=False),
            "fit_status": data["fit_status"], "updated_at": iso_now(),
        }
        with self.connect() as connection:
            connection.execute(
                "UPDATE document_drafts SET " + ",".join(f"{key}=?" for key in changes) + " WHERE id=?",
                (*changes.values(), draft_id),
            )
        return self.get_document_draft(draft_id)

    def publish_document_draft(self, draft_id: int, document_id: int) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                "UPDATE document_drafts SET published_document_id=COALESCE(published_document_id,?),updated_at=? WHERE id=?",
                (document_id, iso_now(), draft_id),
            )
        draft = self.get_document_draft(draft_id)
        if not draft:
            raise KeyError(draft_id)
        return draft

    def get_document(self, document_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM documents WHERE id=?", (document_id,)).fetchone()
        return dict(row) if row else None

    def find_document_by_hash(self, kind: str, sha256: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM documents WHERE kind=? AND sha256=? AND archived_at IS NULL ORDER BY id DESC LIMIT 1",
                (kind, sha256),
            ).fetchone()
        return dict(row) if row else None

    def assign_document_template_key(self, document_id: int, template_key: str) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                "UPDATE documents SET template_key=?, updated_at=? WHERE id=?",
                (template_key, iso_now(), document_id),
            )
        document = self.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        return document

    def create_document(self, data: dict[str, Any], replace_document_id: int | None = None) -> dict[str, Any]:
        now = iso_now()
        with self._lock, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if replace_document_id is not None:
                replaced = connection.execute(
                    "SELECT id FROM documents WHERE id=? AND archived_at IS NULL",
                    (replace_document_id,),
                ).fetchone()
                if not replaced:
                    raise KeyError(replace_document_id)
            cursor = connection.execute(
                """INSERT INTO documents
                (kind,label,original_filename,stored_filename,mime_type,extension,size_bytes,sha256,
                 extracted_text,extraction_status,template_key,layout_key,source_document_id,
                 structured_content_json,fit_status,supersedes_id,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    data["kind"], data["label"], data["original_filename"], data["stored_filename"],
                    data["mime_type"], data["extension"], data["size_bytes"], data["sha256"],
                    data["extracted_text"], data["extraction_status"], data.get("template_key"),
                    data.get("layout_key"), data.get("source_document_id"),
                    json.dumps(data.get("structured_content"), ensure_ascii=False) if data.get("structured_content") else None,
                    data.get("fit_status"), replace_document_id, now, now,
                ),
            )
            if replace_document_id is not None:
                connection.execute(
                    "UPDATE documents SET archived_at=?, updated_at=? WHERE id=?",
                    (now, now, replace_document_id),
                )
            document_id = int(cursor.lastrowid)
        return self.get_document(document_id) or {}

    def update_document(self, document_id: int, *, label: str | None = None,
                        archived: bool | None = None) -> dict[str, Any] | None:
        current = self.get_document(document_id)
        if not current:
            return None
        if archived is False:
            duplicate = self.find_document_by_hash(current["kind"], current["sha256"])
            if duplicate and duplicate["id"] != document_id:
                raise ValueError("An active copy of this document already exists")
        changes: dict[str, Any] = {}
        if label is not None:
            changes["label"] = label
        if archived is not None:
            changes["archived_at"] = iso_now() if archived else None
        if not changes:
            return current
        changes["updated_at"] = iso_now()
        assignments = ", ".join(f"{key}=?" for key in changes)
        with self.connect() as connection:
            changed = connection.execute(
                f"UPDATE documents SET {assignments} WHERE id=?",
                (*changes.values(), document_id),
            ).rowcount
        return self.get_document(document_id) if changed else None

    def delete_document(self, document_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM documents WHERE id=?", (document_id,)).rowcount)

    def create_company(self, data: dict[str, Any]) -> dict[str, Any]:
        now = iso_now()
        with self.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO companies
                (name, careers_url, logo_url, kind, state, schedule_kind, interval_hours, local_time, weekday,
                 criteria_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (data["name"], str(data["careers_url"]), data.get("logo_url"),
                 "monitor",
                 "building" if data.get("build_now", True) else "paused",
                 data["schedule_kind"], data["interval_hours"], data["local_time"], data["weekday"],
                 json.dumps(data["criteria"]), now, now),
            )
            company_id = cursor.lastrowid
        return self.get_company(int(company_id))

    def list_companies(self, include_archived: bool = False) -> list[dict[str, Any]]:
        query = """SELECT c.*,
            COUNT(CASE WHEN j.is_active=1 THEN 1 END) AS raw_job_count,
            COUNT(CASE WHEN j.is_active=1 AND m.is_match=1 AND m.dismissed=0 THEN 1 END) AS matching_job_count
            FROM companies c
            LEFT JOIN jobs j ON j.company_id=c.id
            LEFT JOIN job_matches m ON m.job_id=j.id"""
        conditions = ["c.kind='monitor'"]
        if not include_archived:
            conditions.append("c.archived_at IS NULL")
        query += " WHERE " + " AND ".join(conditions)
        query += " GROUP BY c.id ORDER BY c.name COLLATE NOCASE"
        with self.connect() as connection:
            return [_row(row) for row in connection.execute(query).fetchall()]  # type: ignore[misc]

    def list_dashboard_scraper_alerts(self, *, limit: int = 5) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT c.*,r.id latest_run_id,r.kind latest_run_kind,
                r.status latest_run_status,r.message latest_run_message,
                r.diagnostics_json,r.finished_at latest_run_finished_at,
                r.queued_at latest_run_queued_at
                FROM companies c LEFT JOIN runs r ON r.id=(
                  SELECT id FROM runs WHERE company_id=c.id ORDER BY id DESC LIMIT 1
                )
                WHERE c.archived_at IS NULL
                AND (NOT EXISTS(SELECT 1 FROM company_preset_memberships pm WHERE pm.company_id=c.id)
                  OR EXISTS(SELECT 1 FROM company_preset_memberships pm
                    JOIN preset_pack_state ps ON ps.preset_id=pm.preset_id
                    WHERE pm.company_id=c.id AND ps.hidden_at IS NULL))
                AND (
                  c.state='needs_attention' OR c.consecutive_failures>0 OR r.status='failed'
                )
                ORDER BY CASE WHEN c.state='needs_attention' THEN 0 ELSE 1 END,
                c.consecutive_failures DESC,COALESCE(r.finished_at,r.queued_at,c.updated_at) DESC
                LIMIT ?""",
                (limit,),
            ).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    def get_company(self, company_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            return _row(connection.execute(
                """SELECT c.*,
                COUNT(CASE WHEN j.is_active=1 THEN 1 END) AS raw_job_count,
                COUNT(CASE WHEN j.is_active=1 AND m.is_match=1 AND m.dismissed=0 THEN 1 END) AS matching_job_count
                FROM companies c
                LEFT JOIN jobs j ON j.company_id=c.id
                LEFT JOIN job_matches m ON m.job_id=j.id
                WHERE c.id=? GROUP BY c.id""",
                (company_id,),
            ).fetchone())

    def update_company(self, company_id: int, changes: dict[str, Any]) -> dict[str, Any] | None:
        allowed = {"name", "careers_url", "logo_url", "schedule_kind", "interval_hours", "local_time", "weekday", "criteria_json", "state", "adapter", "active_recipe_version", "next_run_at", "last_run_at", "consecutive_failures", "archived_at"}
        values: dict[str, Any] = {}
        for key, value in changes.items():
            column = "criteria_json" if key == "criteria" else key
            if column not in allowed:
                continue
            if key == "criteria":
                value = json.dumps(value)
            if key == "careers_url":
                value = str(value)
            values[column] = value
        if not values:
            return self.get_company(company_id)
        values["updated_at"] = iso_now()
        assignments = ", ".join(f"{key}=?" for key in values)
        with self.connect() as connection:
            connection.execute(f"UPDATE companies SET {assignments} WHERE id=?", (*values.values(), company_id))
        if "criteria_json" in values:
            self.recompute_matches(company_id)
        return self.get_company(company_id)

    def delete_company(self, company_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM companies WHERE id=?", (company_id,)).rowcount)

    def list_company_preset_memberships(self, company_id: int | None = None) -> list[dict[str, Any]]:
        condition = "WHERE m.company_id=?" if company_id is not None else ""
        params = (company_id,) if company_id is not None else ()
        with self.connect() as connection:
            rows = connection.execute(
                f"""SELECT m.preset_id,p.preset_name,m.company_id,m.company_key,m.origin,
                p.hidden_at,m.created_at,m.updated_at
                FROM company_preset_memberships m JOIN preset_pack_state p ON p.preset_id=m.preset_id
                {condition} ORDER BY p.preset_name COLLATE NOCASE""", params,
            ).fetchall()
        return [dict(row) for row in rows]

    def set_company_preset_memberships(self, company_id: int, preset_ids: list[str],
                                       preset_names: dict[str, str]) -> list[dict[str, Any]]:
        wanted = list(dict.fromkeys(preset_ids))
        now = iso_now()
        with self.connect() as connection:
            existing = {row["preset_id"]: dict(row) for row in connection.execute(
                "SELECT * FROM company_preset_memberships WHERE company_id=?", (company_id,)
            ).fetchall()}
            for preset_id in wanted:
                name = preset_names[preset_id]
                connection.execute(
                    """INSERT INTO preset_pack_state(preset_id,preset_name,created_at,updated_at)
                    VALUES(?,?,?,?) ON CONFLICT(preset_id) DO UPDATE SET
                    preset_name=excluded.preset_name,updated_at=excluded.updated_at""",
                    (preset_id, name, now, now),
                )
                if preset_id not in existing:
                    connection.execute(
                        """INSERT INTO company_preset_memberships
                        (preset_id,company_id,origin,created_at,updated_at) VALUES(?,?,'manual',?,?)""",
                        (preset_id, company_id, now, now),
                    )
            if wanted:
                connection.execute(
                    "DELETE FROM company_preset_memberships WHERE company_id=? AND preset_id NOT IN ("
                    + ",".join("?" for _ in wanted) + ")", (company_id, *wanted),
                )
            else:
                connection.execute("DELETE FROM company_preset_memberships WHERE company_id=?", (company_id,))
        return self.list_company_preset_memberships(company_id)

    def upsert_preset_membership(self, *, preset_id: str, preset_name: str, company_id: int,
                                 company_key: str | None, origin: str) -> None:
        now = iso_now()
        with self.connect() as connection:
            connection.execute(
                """INSERT INTO preset_pack_state(preset_id,preset_name,created_at,updated_at)
                VALUES(?,?,?,?) ON CONFLICT(preset_id) DO UPDATE SET
                preset_name=excluded.preset_name,updated_at=excluded.updated_at""",
                (preset_id, preset_name, now, now),
            )
            connection.execute(
                """INSERT INTO company_preset_memberships
                (preset_id,company_id,company_key,origin,created_at,updated_at)
                VALUES(?,?,?,?,?,?) ON CONFLICT(preset_id,company_id) DO UPDATE SET
                company_key=COALESCE(excluded.company_key,company_preset_memberships.company_key),
                updated_at=excluded.updated_at""",
                (preset_id, company_id, company_key, origin, now, now),
            )

    def set_preset_hidden(self, preset_id: str, hidden: bool) -> dict[str, Any] | None:
        now = iso_now()
        with self.connect() as connection:
            changed = connection.execute(
                "UPDATE preset_pack_state SET hidden_at=?,updated_at=? WHERE preset_id=?",
                (now if hidden else None, now, preset_id),
            ).rowcount
        return self.get_preset_pack_state(preset_id) if changed else None

    def get_preset_pack_state(self, preset_id: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                """SELECT p.*,COUNT(m.company_id) member_count
                FROM preset_pack_state p LEFT JOIN company_preset_memberships m
                ON m.preset_id=p.preset_id WHERE p.preset_id=? GROUP BY p.preset_id""",
                (preset_id,),
            ).fetchone()
        return dict(row) if row else None

    def list_preset_pack_states(self) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT p.*,COUNT(m.company_id) member_count
                FROM preset_pack_state p LEFT JOIN company_preset_memberships m
                ON m.preset_id=p.preset_id GROUP BY p.preset_id
                ORDER BY p.preset_name COLLATE NOCASE"""
            ).fetchall()
        return [dict(row) for row in rows]

    def is_company_hidden(self, company_id: int) -> bool:
        with self.connect() as connection:
            row = connection.execute(
                """SELECT COUNT(*) memberships,
                SUM(CASE WHEN p.hidden_at IS NULL THEN 1 ELSE 0 END) visible
                FROM company_preset_memberships m JOIN preset_pack_state p ON p.preset_id=m.preset_id
                WHERE m.company_id=?""", (company_id,),
            ).fetchone()
        return bool(row and row["memberships"] and not row["visible"])

    def save_recipe(self, company_id: int, recipe: dict[str, Any], validation_message: str | None = None, activate: bool = False) -> dict[str, Any]:
        with self.connect() as connection:
            version = connection.execute("SELECT COALESCE(MAX(version), 0)+1 FROM recipes WHERE company_id=?", (company_id,)).fetchone()[0]
            connection.execute(
                "INSERT INTO recipes(company_id, version, recipe_json, status, validation_message, created_at) VALUES(?,?,?,?,?,?)",
                (company_id, version, json.dumps(recipe), "active" if activate else "candidate", validation_message, iso_now()),
            )
            if activate:
                connection.execute("UPDATE recipes SET status='superseded' WHERE company_id=? AND version<>? AND status='active'", (company_id, version))
                connection.execute("UPDATE companies SET active_recipe_version=?, adapter=?, state='active', updated_at=? WHERE id=?", (version, recipe.get("strategy"), iso_now(), company_id))
        return self.get_recipe(company_id, int(version)) or {}

    def get_catalog_source(self, company_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM company_catalog_sources WHERE company_id=?", (company_id,)
            ).fetchone()
        return dict(row) if row else None

    def find_company_by_catalog_monitor(self, monitor_id: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                """SELECT c.* FROM companies c JOIN company_catalog_sources s ON s.company_id=c.id
                WHERE s.catalog_monitor_id=?""", (monitor_id,)
            ).fetchone()
        return _row(row)

    def set_catalog_source(self, company_id: int, *, company_key: str, monitor_id: str,
                           revision: int, sha256: str | None, source_commit: str | None) -> dict[str, Any]:
        now = iso_now()
        with self.connect() as connection:
            connection.execute(
                """INSERT INTO company_catalog_sources
                (company_id,catalog_company_id,catalog_monitor_id,installed_revision,installed_sha256,source_commit,updated_at)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(company_id) DO UPDATE SET
                catalog_company_id=excluded.catalog_company_id,catalog_monitor_id=excluded.catalog_monitor_id,
                installed_revision=excluded.installed_revision,installed_sha256=excluded.installed_sha256,
                source_commit=excluded.source_commit,updated_at=excluded.updated_at""",
                (company_id, company_key, monitor_id, revision, sha256, source_commit, now),
            )
        return self.get_catalog_source(company_id) or {}

    def link_catalog_update(self, run_id: int, *, request_id: str, company_id: int,
                            recipe_version: int, company_key: str, monitor_id: str,
                            revision: int, sha256: str | None, source_commit: str | None) -> dict[str, Any]:
        with self.connect() as connection:
            connection.execute(
                """INSERT INTO catalog_update_runs
                (run_id,request_id,company_id,recipe_version,catalog_company_id,catalog_monitor_id,
                 catalog_revision,catalog_sha256,source_commit,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (run_id, request_id, company_id, recipe_version, company_key, monitor_id,
                 revision, sha256, source_commit, iso_now()),
            )
        return self.get_catalog_update(run_id) or {}

    def get_catalog_update(self, run_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM catalog_update_runs WHERE run_id=?", (run_id,)).fetchone()
        return dict(row) if row else None

    def get_catalog_update_by_request(self, request_id: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                """SELECT u.*,r.status,r.progress,r.message FROM catalog_update_runs u
                JOIN runs r ON r.id=u.run_id WHERE u.request_id=?""", (request_id,)
            ).fetchone()
        return dict(row) if row else None

    def get_recipe(self, company_id: int, version: int | None = None) -> dict[str, Any] | None:
        with self.connect() as connection:
            if version is None:
                row = connection.execute(
                    "SELECT r.* FROM recipes r JOIN companies c ON c.id=r.company_id AND c.active_recipe_version=r.version WHERE r.company_id=?",
                    (company_id,),
                ).fetchone()
            else:
                row = connection.execute("SELECT * FROM recipes WHERE company_id=? AND version=?", (company_id, version)).fetchone()
        return _row(row)

    def list_recipes(self, company_id: int) -> list[dict[str, Any]]:
        with self.connect() as connection:
            return [_row(row) for row in connection.execute("SELECT * FROM recipes WHERE company_id=? ORDER BY version DESC", (company_id,)).fetchall()]  # type: ignore[misc]

    def activate_recipe(self, company_id: int, version: int) -> bool:
        with self.connect() as connection:
            recipe = connection.execute("SELECT recipe_json FROM recipes WHERE company_id=? AND version=?", (company_id, version)).fetchone()
            if not recipe:
                return False
            strategy = _loads(recipe[0], {}).get("strategy")
            connection.execute("UPDATE recipes SET status=CASE WHEN version=? THEN 'active' ELSE 'superseded' END WHERE company_id=?", (version, company_id))
            connection.execute("UPDATE companies SET active_recipe_version=?, adapter=?, state='active', updated_at=? WHERE id=?", (version, strategy, iso_now(), company_id))
        return True

    def enqueue_run(self, company_id: int, kind: str = "scrape", *, reuse_active: bool = False) -> dict[str, Any]:
        company = self.get_company(company_id)
        if not company:
            raise KeyError(company_id)
        with self._lock, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if reuse_active:
                active = connection.execute("SELECT * FROM runs WHERE company_id=? AND status IN ('queued','running') ORDER BY id LIMIT 1", (company_id,)).fetchone()
                if active:
                    return {**_row(active), "reused": True}
            cursor = connection.execute(
                "INSERT INTO runs(company_id, kind, status, progress, recipe_version, queued_at) VALUES(?,?,'queued',0,?,?)",
                (company_id, kind, company.get("active_recipe_version"), iso_now()),
            )
            run_id = cursor.lastrowid
        return self.get_run(int(run_id)) or {}

    def claim_run(self, owner: str, lease_seconds: int = 300) -> ClaimedRun | None:
        with self._lock, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            now = datetime.now(timezone.utc)
            row = connection.execute(
                """SELECT id, company_id, kind, recipe_version FROM runs
                WHERE status='queued' OR (status='running' AND lease_until < ?)
                ORDER BY queued_at LIMIT 1""", (now.isoformat(),),
            ).fetchone()
            if not row:
                return None
            lease_until = datetime.fromtimestamp(now.timestamp() + lease_seconds, timezone.utc).isoformat()
            changed = connection.execute(
                """UPDATE runs SET status='running', progress=MAX(progress,1), started_at=COALESCE(started_at,?),
                lease_owner=?, lease_until=? WHERE id=? AND (status='queued' OR lease_until < ?)""",
                (now.isoformat(), owner, lease_until, row["id"], now.isoformat()),
            ).rowcount
            if not changed:
                return None
            return ClaimedRun(row["id"], row["company_id"], row["kind"], row["recipe_version"])

    def update_run(self, run_id: int, **changes: Any) -> dict[str, Any] | None:
        allowed = {"status", "progress", "message", "raw_count", "matched_count", "new_count", "new_matched_count", "recipe_version", "full_run", "diagnostics_json", "progress_detail_json", "started_at", "finished_at", "lease_owner", "lease_until"}
        values = {key: (json.dumps(value) if key in {"diagnostics_json", "progress_detail_json"} else value) for key, value in changes.items() if key in allowed}
        if not values:
            return self.get_run(run_id)
        assignments = ", ".join(f"{key}=?" for key in values)
        with self.connect() as connection:
            connection.execute(f"UPDATE runs SET {assignments} WHERE id=?", (*values.values(), run_id))
        return self.get_run(run_id)

    def get_run(self, run_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            return _row(connection.execute(
                "SELECT r.*, c.name AS company_name FROM runs r JOIN companies c ON c.id=r.company_id WHERE r.id=?",
                (run_id,),
            ).fetchone())

    def list_runs(self, company_id: int | None = None, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as connection:
            if company_id is None:
                rows = connection.execute(
                    "SELECT r.*, c.name AS company_name FROM runs r JOIN companies c ON c.id=r.company_id ORDER BY r.id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            else:
                rows = connection.execute(
                    "SELECT r.*, c.name AS company_name FROM runs r JOIN companies c ON c.id=r.company_id WHERE r.company_id=? ORDER BY r.id DESC LIMIT ?",
                    (company_id, limit),
                ).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    @staticmethod
    def effective_criteria(global_criteria: dict[str, list[str]], overrides: dict[str, Any]) -> dict[str, list[str]]:
        effective: dict[str, list[str]] = {}
        for category in ("cities", "title_terms", "keywords"):
            override = overrides.get(category, {}) or {}
            mode = override.get("mode", "inherit")
            if mode == "any":
                effective[category] = []
            elif mode == "replace":
                effective[category] = list(override.get("values", []))
            else:
                effective[category] = list(global_criteria.get(category, []))
        return effective

    @staticmethod
    def match_job(job: dict[str, Any], criteria: dict[str, list[str]]) -> tuple[bool, list[str]]:
        title = normalize(job.get("title"))
        location = normalize(" ".join(filter(None, [job.get("location", ""), job.get("location_city", "")])))
        haystack = normalize(f"{job.get('title', '')} {job.get('description', '')}")
        remote = job.get("remote_mode") == "remote" or "remote" in location
        reasons: list[str] = []
        checks: list[bool] = []
        for category, target in (("cities", location), ("title_terms", title), ("keywords", haystack)):
            terms = criteria.get(category, [])
            if not terms:
                continue
            matched: list[str] = []
            for term in terms:
                normalized = normalize(term)
                is_match = bool(normalized and normalized in target)
                if category == "cities" and normalized == "remote":
                    is_match = remote
                if is_match:
                    matched.append(term)
            checks.append(bool(matched))
            reasons.extend(f"{category}:{term}" for term in matched)
        return all(checks), reasons

    @staticmethod
    def _stable_key(job: dict[str, Any]) -> str:
        identity = job.get("source_job_id") or job.get("canonical_url") or job.get("url")
        if not identity:
            identity = f"{normalize(job.get('title'))}|{normalize(job.get('location'))}"
        return hashlib.sha256(str(identity).encode("utf-8")).hexdigest()

    def upsert_jobs(self, company_id: int, jobs: Iterable[dict[str, Any]], run_id: int, full_run: bool = True) -> dict[str, int]:
        incoming = list(jobs)
        seen: set[str] = set()
        now = iso_now()
        with self.connect() as connection:
            company = connection.execute("SELECT criteria_json FROM companies WHERE id=?", (company_id,)).fetchone()
            settings = connection.execute("SELECT criteria_json, criteria_version FROM settings WHERE id=1").fetchone()
            if not company or not settings:
                raise KeyError(company_id)
            criteria = self.effective_criteria(_loads(settings["criteria_json"], {}), _loads(company["criteria_json"], {}))
            matched_count = 0
            new_count = new_matched_count = 0
            previous_keys = {row[0] for row in connection.execute("SELECT stable_key FROM jobs WHERE company_id=?", (company_id,))}
            for job in incoming:
                stable_key = self._stable_key(job)
                if stable_key in seen:
                    continue
                seen.add(stable_key)
                content_payload = {key: job.get(key) for key in sorted(job)}
                content_hash = hashlib.sha256(json.dumps(content_payload, sort_keys=True, default=str).encode()).hexdigest()
                values = (
                    company_id, job.get("source_job_id"), stable_key, job.get("title", ""), job.get("location", ""),
                    job.get("location_city"), job.get("remote_mode", "unknown"), job.get("employment_type"),
                    str(job.get("posted_date")) if job.get("posted_date") else None, job.get("description", ""),
                    job.get("salary_min"), job.get("salary_max"), job.get("salary_currency"), job.get("salary_period"), job.get("url", ""),
                    job.get("canonical_url"), job.get("source"), content_hash, now, now, run_id,
                )
                connection.execute(
                    """INSERT INTO jobs(company_id,source_job_id,stable_key,title,location,location_city,remote_mode,
                    employment_type,posted_date,description,salary_min,salary_max,salary_currency,salary_period,url,canonical_url,
                    source,content_hash,first_seen_at,last_seen_at,last_run_id)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(company_id,stable_key) DO UPDATE SET
                    source_job_id=excluded.source_job_id,title=excluded.title,location=excluded.location,
                    location_city=excluded.location_city,remote_mode=excluded.remote_mode,employment_type=excluded.employment_type,
                    posted_date=excluded.posted_date,description=excluded.description,salary_min=excluded.salary_min,
                    salary_max=excluded.salary_max,salary_currency=excluded.salary_currency,salary_period=excluded.salary_period,url=excluded.url,
                    canonical_url=excluded.canonical_url,source=excluded.source,content_hash=excluded.content_hash,
                    is_active=1,miss_count=0,last_seen_at=excluded.last_seen_at,closed_at=NULL,last_run_id=excluded.last_run_id""",
                    values,
                )
                row = connection.execute("SELECT id FROM jobs WHERE company_id=? AND stable_key=?", (company_id, stable_key)).fetchone()
                is_match, reasons = self.match_job(job, criteria)
                matched_count += int(is_match)
                new_count += int(stable_key not in previous_keys)
                new_matched_count += int(stable_key not in previous_keys and is_match)
                existing = connection.execute("SELECT is_match,first_matched_at,unread,dismissed FROM job_matches WHERE job_id=?", (row["id"],)).fetchone()
                first = existing["first_matched_at"] if existing and existing["first_matched_at"] else (now if is_match else None)
                last = now if is_match else None
                unread = existing["unread"] if existing else int(is_match)
                dismissed = existing["dismissed"] if existing else 0
                if existing and not existing["is_match"] and is_match:
                    unread, dismissed = 1, 0
                connection.execute(
                    """INSERT INTO job_matches(job_id,criteria_version,is_match,match_reasons_json,unread,dismissed,first_matched_at,last_matched_at)
                    VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(job_id) DO UPDATE SET criteria_version=excluded.criteria_version,
                    is_match=excluded.is_match,match_reasons_json=excluded.match_reasons_json,unread=?,dismissed=?,
                    first_matched_at=COALESCE(job_matches.first_matched_at,excluded.first_matched_at),last_matched_at=excluded.last_matched_at""",
                    (row["id"], settings["criteria_version"], int(is_match), json.dumps(reasons), unread, dismissed, first, last, unread, dismissed),
                )
            if full_run:
                if seen:
                    placeholders = ",".join("?" for _ in seen)
                    connection.execute(f"UPDATE jobs SET miss_count=miss_count+1 WHERE company_id=? AND is_active=1 AND stable_key NOT IN ({placeholders})", (company_id, *seen))
                else:
                    connection.execute("UPDATE jobs SET miss_count=miss_count+1 WHERE company_id=? AND is_active=1", (company_id,))
                connection.execute("UPDATE jobs SET is_active=0,closed_at=? WHERE company_id=? AND is_active=1 AND miss_count>=2", (now, company_id))
        return {"raw_count": len(seen), "matched_count": matched_count, "new_count": new_count, "new_matched_count": new_matched_count}

    def recompute_matches(self, company_id: int | None = None) -> None:
        settings = self.get_settings()
        companies = [self.get_company(company_id)] if company_id is not None else self.list_companies(include_archived=True)
        with self.connect() as connection:
            for company in filter(None, companies):
                criteria = self.effective_criteria(settings["criteria"], company["criteria"])
                jobs = connection.execute("SELECT * FROM jobs WHERE company_id=?", (company["id"],)).fetchall()
                for job_row in jobs:
                    job = dict(job_row)
                    is_match, reasons = self.match_job(job, criteria)
                    old = connection.execute("SELECT is_match,unread,dismissed,first_matched_at FROM job_matches WHERE job_id=?", (job["id"],)).fetchone()
                    unread = old["unread"] if old else int(is_match)
                    dismissed = old["dismissed"] if old else 0
                    if old and not old["is_match"] and is_match:
                        unread, dismissed = 1, 0
                    now = iso_now()
                    connection.execute(
                        """INSERT INTO job_matches(job_id,criteria_version,is_match,match_reasons_json,unread,dismissed,first_matched_at,last_matched_at)
                        VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(job_id) DO UPDATE SET criteria_version=excluded.criteria_version,
                        is_match=excluded.is_match,match_reasons_json=excluded.match_reasons_json,unread=?,dismissed=?,
                        first_matched_at=COALESCE(job_matches.first_matched_at,excluded.first_matched_at),last_matched_at=excluded.last_matched_at""",
                        (job["id"], settings["criteria_version"], int(is_match), json.dumps(reasons), unread, dismissed,
                         now if is_match else None, now if is_match else None, unread, dismissed),
                    )

    @staticmethod
    def _job_filters(
        *, matching: bool | None = True, company_id: int | None = None,
        company_ids: Iterable[int] | None = None, unread: bool | None = None,
        dismissed: bool | None = False, active: bool | None = True, query: str | None = None,
        remote_modes: Iterable[str] | None = None, employment_types: Iterable[str] | None = None,
        salary_listed: bool | None = None, posted_within_days: int | None = None,
        saved: bool | None = None, include_hidden: bool = False,
    ) -> tuple[str, list[Any]]:
        conditions: list[str] = []
        params: list[Any] = []
        if saved is not True:
            conditions.append("j.origin<>'public'")
        if not include_hidden:
            conditions.append("(NOT EXISTS(SELECT 1 FROM company_preset_memberships pm "
                              "WHERE pm.company_id=c.id) OR EXISTS(SELECT 1 FROM "
                              "company_preset_memberships pm JOIN preset_pack_state ps "
                              "ON ps.preset_id=pm.preset_id WHERE pm.company_id=c.id "
                              "AND ps.hidden_at IS NULL))")
        if matching is not None:
            conditions.append("m.is_match=?"); params.append(int(matching))
        selected_companies = list(dict.fromkeys([
            *([company_id] if company_id is not None else []), *(company_ids or [])
        ]))
        if selected_companies:
            conditions.append("j.company_id IN (" + ",".join("?" for _ in selected_companies) + ")")
            params.extend(selected_companies)
        if unread is not None:
            conditions.append("m.unread=?"); params.append(int(unread))
        if dismissed is not None:
            conditions.append("m.dismissed=?"); params.append(int(dismissed))
        if active is not None:
            conditions.append("j.is_active=?"); params.append(int(active))
        if saved is not None:
            conditions.append("COALESCE(t.saved,0)=?"); params.append(int(saved))
        if query and query.strip():
            escaped = query.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            like = f"%{escaped}%"
            conditions.append("(j.title LIKE ? ESCAPE '\\' OR c.name LIKE ? ESCAPE '\\' OR "
                              "j.location LIKE ? ESCAPE '\\' OR j.description LIKE ? ESCAPE '\\')")
            params.extend([like] * 4)
        modes = list(dict.fromkeys(remote_modes or []))
        if modes:
            conditions.append("j.remote_mode IN (" + ",".join("?" for _ in modes) + ")")
            params.extend(modes)
        types = [normalize(str(value).replace("_", " ")) for value in (employment_types or [])
                 if normalize(str(value).replace("_", " "))]
        if types:
            expression = "LOWER(REPLACE(REPLACE(REPLACE(j.employment_type, '-', ' '), '/', ' '), ',', ' '))"
            conditions.append("(" + " OR ".join(f"{expression} LIKE ?" for _ in types) + ")")
            params.extend(f"%{value}%" for value in types)
        if salary_listed is not None:
            conditions.append("(j.salary_min IS NOT NULL OR j.salary_max IS NOT NULL) = ?")
            params.append(int(salary_listed))
        if posted_within_days is not None:
            conditions.append("datetime(COALESCE(NULLIF(j.posted_date,''), j.first_seen_at)) >= datetime('now', ?)")
            params.append(f"-{posted_within_days} days")
        return (" WHERE " + " AND ".join(conditions) if conditions else ""), params

    def list_jobs(self, *, matching: bool | None = True, company_id: int | None = None,
                  company_ids: Iterable[int] | None = None, unread: bool | None = None,
                  dismissed: bool | None = False, active: bool | None = True,
                  query: str | None = None, remote_modes: Iterable[str] | None = None,
                  employment_types: Iterable[str] | None = None, salary_listed: bool | None = None,
                  posted_within_days: int | None = None, saved: bool | None = None,
                  include_hidden: bool = False, limit: int = 100,
                  offset: int = 0, sort_by: str = "default",
                  home_location: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        where, params = self._job_filters(
            matching=matching, company_id=company_id, company_ids=company_ids, unread=unread,
            dismissed=dismissed, active=active, query=query, remote_modes=remote_modes,
            employment_types=employment_types, salary_listed=salary_listed,
            posted_within_days=posted_within_days, saved=saved, include_hidden=include_hidden,
        )
        ordering = {
            "default": "COALESCE(t.updated_at,j.posted_date,j.first_seen_at) DESC, j.id DESC",
            "newest": "datetime(COALESCE(NULLIF(j.posted_date,''),j.first_seen_at)) DESC, j.id DESC",
            "oldest": "datetime(COALESCE(NULLIF(j.posted_date,''),j.first_seen_at)) ASC, j.id ASC",
            "title": "LOWER(j.title) ASC, LOWER(c.name) ASC, j.id DESC",
            "company": "LOWER(c.name) ASC, LOWER(j.title) ASC, j.id DESC",
        }.get(sort_by)
        distance_sort = sort_by in {"nearest", "farthest"}
        if ordering is None and not distance_sort:
            raise ValueError("unsupported job sort")
        home = home_location or {}
        if distance_sort and (home.get("latitude") is None or home.get("longitude") is None):
            ordering = "COALESCE(t.updated_at,j.posted_date,j.first_seen_at) DESC, j.id DESC"
            distance_sort = False
        if distance_sort:
            direction = "ASC" if sort_by == "nearest" else "DESC"
            ordering = (
                "jobhound_distance_km(j.location) IS NULL ASC, "
                f"jobhound_distance_km(j.location) {direction}, j.id DESC"
            )
        query = """SELECT j.*, c.name company_name, m.is_match, m.match_reasons_json, m.unread, m.dismissed,
                   m.first_matched_at, m.last_matched_at, COALESCE(t.saved,0) is_saved,
                   t.saved_at,t.current_stage,t.milestone,t.outcome,t.applied_at,
                   t.applied_at_inferred,t.updated_at tracking_updated_at,
                   (SELECT COUNT(*) FROM job_activities a WHERE a.job_id=j.id) activity_count
                   FROM jobs j JOIN companies c ON c.id=j.company_id
                   LEFT JOIN job_matches m ON m.job_id=j.id LEFT JOIN job_tracking t ON t.job_id=j.id""" + where + f" ORDER BY {ordering} LIMIT ? OFFSET ?"
        with self.connect() as connection:
            if distance_sort:
                from .geography import distance_km, resolve_location
                home_latitude = float(home["latitude"])
                home_longitude = float(home["longitude"])

                def jobhound_distance(location: str | None) -> float | None:
                    point = resolve_location(str(location or ""))
                    return distance_km(home_latitude, home_longitude, *point) if point else None

                connection.create_function("jobhound_distance_km", 1, jobhound_distance, deterministic=True)
            rows = connection.execute(query, (*params, limit, offset)).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    def list_dashboard_jobs(self, *, kind: str, limit: int = 5) -> list[dict[str, Any]]:
        if kind not in {"saved", "new"}:
            raise ValueError("dashboard job kind must be saved or new")
        if kind == "saved":
            condition = "COALESCE(t.saved,0)=1"
            ordering = "t.saved_at DESC,j.id DESC"
        else:
            condition = "j.is_active=1 AND m.is_match=1 AND m.dismissed=0"
            ordering = "j.first_seen_at DESC,j.id DESC"
        query = f"""SELECT j.*,c.name company_name,m.is_match,m.match_reasons_json,
                   m.unread,m.dismissed,m.first_matched_at,m.last_matched_at,
                   COALESCE(t.saved,0) is_saved,t.saved_at,t.current_stage,t.milestone,t.outcome,
                   t.applied_at,t.applied_at_inferred,
                   t.updated_at tracking_updated_at,
                   (SELECT COUNT(*) FROM job_activities a WHERE a.job_id=j.id) activity_count
                   FROM jobs j JOIN companies c ON c.id=j.company_id
                   LEFT JOIN job_matches m ON m.job_id=j.id
                   LEFT JOIN job_tracking t ON t.job_id=j.id
                   WHERE ({condition}) AND (NOT EXISTS(SELECT 1 FROM company_preset_memberships pm
                   WHERE pm.company_id=c.id) OR EXISTS(SELECT 1 FROM company_preset_memberships pm
                   JOIN preset_pack_state ps ON ps.preset_id=pm.preset_id
                   WHERE pm.company_id=c.id AND ps.hidden_at IS NULL))
                   ORDER BY {ordering} LIMIT ?"""
        with self.connect() as connection:
            rows = connection.execute(query, (limit,)).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    def count_jobs(self, **filters: Any) -> int:
        where, params = self._job_filters(**filters)
        with self.connect() as connection:
            return int(connection.execute(
                """SELECT COUNT(*) FROM jobs j JOIN companies c ON c.id=j.company_id
                LEFT JOIN job_matches m ON m.job_id=j.id LEFT JOIN job_tracking t ON t.job_id=j.id""" + where,
                params,
            ).fetchone()[0])

    def job_rich_field_coverage(self, company_id: int) -> dict[str, int]:
        with self.connect() as connection:
            row = connection.execute(
                """SELECT COUNT(*) jobs,
                COALESCE(SUM(CASE WHEN LENGTH(TRIM(description))>0 THEN 1 ELSE 0 END),0) description,
                COALESCE(SUM(CASE WHEN employment_type IS NOT NULL THEN 1 ELSE 0 END),0) employment_type,
                COALESCE(SUM(CASE WHEN remote_mode!='unknown' THEN 1 ELSE 0 END),0) remote_mode,
                COALESCE(SUM(CASE WHEN salary_min IS NOT NULL OR salary_max IS NOT NULL THEN 1 ELSE 0 END),0) salary,
                COALESCE(SUM(CASE WHEN salary_currency IS NOT NULL THEN 1 ELSE 0 END),0) salary_currency,
                COALESCE(SUM(CASE WHEN salary_period IS NOT NULL THEN 1 ELSE 0 END),0) salary_period
                FROM jobs WHERE company_id=? AND is_active=1""",
                (company_id,),
            ).fetchone()
        return {key: int(row[key]) for key in row.keys()}

    def get_job(self, job_id: int) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute("""SELECT j.*, c.name company_name, m.is_match, m.match_reasons_json,
                m.unread,m.dismissed,m.first_matched_at,m.last_matched_at,COALESCE(t.saved,0) is_saved,
                t.saved_at,t.current_stage,t.milestone,t.outcome,t.applied_at,
                t.applied_at_inferred,t.updated_at tracking_updated_at,
                (SELECT COUNT(*) FROM job_activities a WHERE a.job_id=j.id) activity_count
                FROM jobs j JOIN companies c ON c.id=j.company_id
                LEFT JOIN job_matches m ON m.job_id=j.id LEFT JOIN job_tracking t ON t.job_id=j.id
                WHERE j.id=?""", (job_id,)).fetchone()
        return _row(row)

    def update_job_state(self, job_id: int, **changes: bool) -> dict[str, Any] | None:
        allowed = {key: int(value) for key, value in changes.items() if key in {"unread", "dismissed"} and value is not None}
        if allowed:
            with self.connect() as connection:
                connection.execute("INSERT OR IGNORE INTO job_matches(job_id,criteria_version,is_match,match_reasons_json) VALUES(?,1,0,'[]')", (job_id,))
                connection.execute("UPDATE job_matches SET " + ",".join(f"{key}=?" for key in allowed) + " WHERE job_id=?", (*allowed.values(), job_id))
        return self.get_job(job_id)

    @staticmethod
    def _insert_job_activity(connection: sqlite3.Connection, *, job_id: int, kind: str,
                             label: str, detail: str = "", stage: str | None = None,
                             milestone: str | None = None, outcome: str | None = None,
                             actor_type: str = "human", command_id: str | None = None,
                             icon_key: str | None = None, thread_id: int | None = None,
                             message_id: int | None = None, request_id: str | None = None,
                             occurred_at: str | None = None,
                             created_at: str | None = None) -> dict[str, Any]:
        now = created_at or iso_now()
        try:
            cursor = connection.execute(
                """INSERT INTO job_activities
                (job_id,kind,label,detail,stage,milestone,outcome,actor_type,command_id,icon_key,
                 thread_id,message_id,request_id,occurred_at,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (job_id, kind, label, detail, stage, milestone, outcome, actor_type, command_id,
                 icon_key, thread_id, message_id, request_id, occurred_at or now, now),
            )
            row = connection.execute("SELECT * FROM job_activities WHERE id=?", (cursor.lastrowid,)).fetchone()
        except sqlite3.IntegrityError:
            if request_id:
                row = connection.execute(
                    "SELECT * FROM job_activities WHERE actor_type=? AND request_id=?", (actor_type, request_id)
                ).fetchone()
            elif thread_id is not None and message_id is not None:
                row = connection.execute(
                    "SELECT * FROM job_activities WHERE thread_id=? AND message_id=?", (thread_id, message_id)
                ).fetchone()
            else:
                raise
        if row is None:
            raise RuntimeError("Could not create job activity")
        return _row(row) or {}

    def update_job_tracking(self, job_id: int, *, saved: bool | None = None,
                            stage: str | None = None, stage_supplied: bool = False,
                            milestone: str | None = None, milestone_supplied: bool = False,
                            outcome: str | None = None, outcome_supplied: bool = False,
                            occurred_at: str | None = None, detail: str = "",
                            request_id: str | None = None,
                            actor_type: str = "human") -> dict[str, Any] | None:
        with self.connect() as connection:
            if not connection.execute("SELECT 1 FROM jobs WHERE id=?", (job_id,)).fetchone():
                return None
            existing = connection.execute("SELECT * FROM job_tracking WHERE job_id=?", (job_id,)).fetchone()
            old_saved = bool(existing["saved"]) if existing else False
            old_stage = existing["current_stage"] if existing else None
            old_milestone = existing["milestone"] if existing else None
            old_outcome = existing["outcome"] if existing else None
            new_saved = old_saved if saved is None else bool(saved)
            new_stage = old_stage if not stage_supplied else (stage.strip() if stage else None)
            if stage_supplied and not milestone_supplied and not outcome_supplied:
                normalized = (new_stage or "").casefold()
                mapped_milestone = {
                    "applied": "applied", "recruiter screen": "recruiter_screen",
                    "interviewing": "interview", "interview": "interview",
                    "later-stage interview": "later_stage_interview", "offer": "offer",
                }.get(normalized)
                mapped_outcome = {
                    "accepted": "accepted", "declined": "declined",
                    "rejected": "rejected", "withdrawn": "withdrawn",
                }.get(normalized)
                if mapped_milestone:
                    milestone, milestone_supplied, outcome, outcome_supplied = mapped_milestone, True, None, True
                elif mapped_outcome:
                    outcome, outcome_supplied = mapped_outcome, True
            new_milestone = old_milestone if not milestone_supplied else milestone
            new_outcome = old_outcome if not outcome_supplied else outcome
            if new_milestone and new_milestone not in APPLICATION_MILESTONES:
                raise ValueError("unknown application milestone")
            if new_outcome and new_outcome not in OUTCOME_LABELS:
                raise ValueError("unknown application outcome")
            if new_outcome in {"accepted", "declined"} and new_milestone != "offer":
                raise ValueError("accepted or declined requires the offer milestone")
            if new_outcome and milestone_supplied and milestone != old_milestone:
                raise ValueError("reopen an ended application before changing its milestone")
            if new_milestone and milestone_supplied:
                new_saved = True
                if old_outcome and not outcome_supplied:
                    raise ValueError("clear the application outcome before advancing it")
            if milestone_supplied or outcome_supplied:
                new_stage = legacy_stage(new_milestone, new_outcome)
            now = iso_now()
            saved_at = existing["saved_at"] if existing else None
            if new_saved != old_saved:
                saved_at = now if new_saved else None
            applied_at = existing["applied_at"] if existing else None
            applied_at_inferred = bool(existing["applied_at_inferred"]) if existing else False
            if new_milestone and not applied_at:
                applied_at = occurred_at or now
                applied_at_inferred = False
            connection.execute(
                """INSERT INTO job_tracking
                (job_id,saved,saved_at,current_stage,milestone,outcome,applied_at,applied_at_inferred,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(job_id) DO UPDATE SET saved=excluded.saved,
                saved_at=excluded.saved_at,current_stage=excluded.current_stage,
                milestone=excluded.milestone,outcome=excluded.outcome,applied_at=excluded.applied_at,
                applied_at_inferred=excluded.applied_at_inferred,updated_at=excluded.updated_at""",
                (job_id, int(new_saved), saved_at, new_stage, new_milestone, new_outcome,
                 applied_at, int(applied_at_inferred), now),
            )
            if new_saved != old_saved:
                self._insert_job_activity(
                    connection, job_id=job_id, kind="saved" if new_saved else "unsaved",
                    label="Saved role" if new_saved else "Removed from Saved Roles",
                    actor_type=actor_type, icon_key="bookmark",
                )
            if (milestone_supplied and new_milestone != old_milestone) or (
                outcome_supplied and new_outcome != old_outcome
            ) or (stage_supplied and new_stage != old_stage and not milestone_supplied and not outcome_supplied):
                label = (
                    f"Moved to {MILESTONE_LABELS[new_milestone]}" if new_milestone != old_milestone and new_milestone
                    else f"Process ended · {OUTCOME_LABELS[new_outcome]}" if new_outcome
                    else "Application reopened" if old_outcome and not new_outcome
                    else f"Stage changed to {new_stage}" if new_stage else "Stage cleared"
                )
                self._insert_job_activity(
                    connection, job_id=job_id, kind="stage_changed",
                    label=label, detail=detail, stage=new_stage, milestone=new_milestone,
                    outcome=new_outcome, actor_type=actor_type, icon_key="stage",
                    request_id=request_id, occurred_at=occurred_at,
                )
        return self.get_job(job_id)

    def create_manual_application(
        self, *, company_name: str, title: str, applied_at: str,
        location: str = "", url: str = "", description: str = "",
        note: str = "", request_id: str, actor_type: str = "human",
    ) -> dict[str, Any]:
        """Create one retry-safe manual job and start its application pipeline."""
        now = iso_now()
        company_name = " ".join(company_name.split())
        title = " ".join(title.split())
        with self.connect() as connection:
            existing = connection.execute(
                "SELECT id FROM jobs WHERE manual_request_id=?", (request_id,)
            ).fetchone()
            if existing:
                return self.get_job(int(existing["id"])) or {}
            company = connection.execute(
                "SELECT id FROM companies WHERE kind='manual' AND LOWER(name)=LOWER(?) LIMIT 1",
                (company_name,),
            ).fetchone()
            if company:
                company_id = int(company["id"])
            else:
                cursor = connection.execute(
                    """INSERT INTO companies
                    (name,careers_url,kind,state,schedule_kind,interval_hours,local_time,weekday,
                     criteria_json,created_at,updated_at)
                    VALUES(?,'','manual','manual','manual',24,'09:00',0,'{}',?,?)""",
                    (company_name, now, now),
                )
                company_id = int(cursor.lastrowid)
            identity = url.strip() or f"manual|{company_name.casefold()}|{title.casefold()}|{applied_at}"
            stable_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
            duplicate = connection.execute(
                "SELECT id FROM jobs WHERE company_id=? AND stable_key=?",
                (company_id, stable_key),
            ).fetchone()
            if duplicate:
                raise ValueError("This manual application already exists")
            content = {
                "company": company_name, "title": title, "location": location,
                "url": url, "description": description, "origin": "manual",
            }
            content_hash = hashlib.sha256(
                json.dumps(content, sort_keys=True).encode("utf-8")
            ).hexdigest()
            cursor = connection.execute(
                """INSERT INTO jobs
                (company_id,stable_key,title,location,description,url,canonical_url,source,origin,
                 manual_request_id,content_hash,first_seen_at,last_seen_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (company_id, stable_key, title, location.strip(), description.strip(), url.strip(),
                 url.strip() or None, "manual", "manual", request_id, content_hash, now, now),
            )
            job_id = int(cursor.lastrowid)
            connection.execute(
                """INSERT INTO job_matches
                (job_id,criteria_version,is_match,match_reasons_json,unread,dismissed)
                VALUES(?,1,0,'[]',0,0)""",
                (job_id,),
            )
            connection.execute(
                """INSERT INTO job_tracking
                (job_id,saved,saved_at,current_stage,milestone,outcome,applied_at,
                 applied_at_inferred,updated_at)
                VALUES(?,1,?,'Applied','applied',NULL,?,0,?)""",
                (job_id, now, applied_at, now),
            )
            self._insert_job_activity(
                connection, job_id=job_id, kind="saved", label="Saved role",
                actor_type=actor_type, icon_key="bookmark", occurred_at=applied_at,
            )
            self._insert_job_activity(
                connection, job_id=job_id, kind="stage_changed", label="Moved to Applied",
                detail=note.strip(), stage="Applied", milestone="applied",
                actor_type=actor_type, icon_key="stage", request_id=request_id,
                occurred_at=applied_at,
            )
        return self.get_job(job_id) or {}

    def application_tracker(
        self, *, from_date: str | None = None, to_date: str | None = None,
        include_closed: bool = False,
    ) -> dict[str, Any]:
        """Return the canonical application cohort, funnel, trend, and cards."""
        conditions = ["t.milestone IS NOT NULL", "t.applied_at IS NOT NULL"]
        params: list[Any] = []
        if from_date:
            conditions.append("date(t.applied_at)>=date(?)")
            params.append(from_date)
        if to_date:
            conditions.append("date(t.applied_at)<=date(?)")
            params.append(to_date)
        with self.connect() as connection:
            cohort = [_row(row) or {} for row in connection.execute(
                """SELECT j.*,c.name company_name,m.is_match,m.unread,m.dismissed,
                COALESCE(t.saved,0) is_saved,t.saved_at,t.current_stage,t.milestone,t.outcome,
                t.applied_at,t.applied_at_inferred,t.updated_at tracking_updated_at,
                (SELECT COUNT(*) FROM job_activities a WHERE a.job_id=j.id) activity_count,
                (SELECT COALESCE(a.occurred_at,a.created_at) FROM job_activities a
                 WHERE a.job_id=j.id ORDER BY a.id DESC LIMIT 1) latest_activity_at
                FROM job_tracking t JOIN jobs j ON j.id=t.job_id
                JOIN companies c ON c.id=j.company_id LEFT JOIN job_matches m ON m.job_id=j.id
                WHERE """ + " AND ".join(conditions) +
                " ORDER BY COALESCE(latest_activity_at,t.updated_at) DESC,j.id DESC",
                params,
            ).fetchall()]
        total = len(cohort)
        funnel = []
        for milestone in APPLICATION_MILESTONES:
            count = sum(milestone_rank(item.get("milestone")) >= milestone_rank(milestone) for item in cohort)
            funnel.append({
                "milestone": milestone, "label": MILESTONE_LABELS[milestone], "count": count,
                "conversion_rate": round((count / total) * 100, 1) if total else 0.0,
            })
        active = sum(not item.get("outcome") for item in cohort)
        by_period: dict[str, int] = {}
        parsed_dates = []
        for item in cohort:
            try:
                parsed_dates.append(datetime.fromisoformat(str(item["applied_at"]).replace("Z", "+00:00")))
            except (TypeError, ValueError):
                continue
        weekly = bool(parsed_dates and (max(parsed_dates) - min(parsed_dates)).days <= 180)
        for value in parsed_dates:
            if weekly:
                start = value.date() - timedelta(days=value.weekday())
                key = start.isoformat()
            else:
                key = value.strftime("%Y-%m")
            by_period[key] = by_period.get(key, 0) + 1
        cards = cohort if include_closed else [item for item in cohort if not item.get("outcome")]
        return {
            "cohort": {"from": from_date, "to": to_date, "application_count": total},
            "metrics": {
                "applications": total, "active": active,
                "positive_response_rate": funnel[1]["conversion_rate"] if total else 0.0,
                "interview_conversion_rate": funnel[2]["conversion_rate"] if total else 0.0,
                "offer_conversion_rate": funnel[4]["conversion_rate"] if total else 0.0,
            },
            "funnel": funnel,
            "trend": [{"period": key, "count": by_period[key]} for key in sorted(by_period)],
            "trend_granularity": "week" if weekly else "month",
            "applications": cards,
            "closed_count": total - active,
        }

    def add_job_activity(self, job_id: int, *, kind: str, label: str | None,
                         detail: str, actor_type: str = "human",
                         request_id: str | None = None) -> dict[str, Any] | None:
        with self.connect() as connection:
            if not connection.execute("SELECT 1 FROM jobs WHERE id=?", (job_id,)).fetchone():
                return None
            return self._insert_job_activity(
                connection, job_id=job_id, kind=kind,
                label=(label or ("Note" if kind == "note" else "Update")).strip(),
                detail=detail.strip(), actor_type=actor_type,
                icon_key="note" if kind == "note" else "activity", request_id=request_id,
            )

    def record_job_chat_activity(self, *, job_id: int, thread_id: int, message_id: int,
                                 command_id: str | None, label: str, detail: str,
                                 icon_key: str, actor_type: str = "human") -> dict[str, Any] | None:
        with self.connect() as connection:
            if not connection.execute("SELECT 1 FROM jobs WHERE id=?", (job_id,)).fetchone():
                return None
            return self._insert_job_activity(
                connection, job_id=job_id,
                kind="skill" if command_id in {"find_recruiters", "interview_prep"} else "chat",
                label=label, detail=detail, actor_type=actor_type, command_id=command_id,
                icon_key=icon_key, thread_id=thread_id, message_id=message_id,
            )

    def record_job_skill_activity(self, *, job_id: int, command_id: str,
                                  label: str, detail: str,
                                  actor_type: str = "agent") -> dict[str, Any] | None:
        with self.connect() as connection:
            if not connection.execute("SELECT 1 FROM jobs WHERE id=?", (job_id,)).fetchone():
                return None
            return self._insert_job_activity(
                connection, job_id=job_id, kind="skill", label=label, detail=detail,
                actor_type=actor_type, command_id=command_id, icon_key=command_id,
            )

    def list_job_activities(self, *, job_id: int | None = None, limit: int = 20,
                            before_id: int | None = None) -> list[dict[str, Any]]:
        conditions: list[str] = []
        params: list[Any] = []
        if job_id is not None:
            conditions.append("a.job_id=?"); params.append(job_id)
        if before_id is not None:
            conditions.append("a.id<?"); params.append(before_id)
        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT a.*,j.title job_title,c.name company FROM job_activities a
                JOIN jobs j ON j.id=a.job_id JOIN companies c ON c.id=j.company_id"""
                + where + " ORDER BY a.id DESC LIMIT ?", (*params, limit),
            ).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    def list_dashboard_job_activities(self, *, limit: int = 5) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT a.*,j.title job_title,c.name company FROM job_activities a
                JOIN jobs j ON j.id=a.job_id JOIN companies c ON c.id=j.company_id
                WHERE a.kind NOT IN ('saved','unsaved') ORDER BY a.id DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    def list_job_tracking(self) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT job_id,saved is_saved,saved_at,current_stage,milestone,outcome,"
                "applied_at,applied_at_inferred,updated_at FROM job_tracking ORDER BY updated_at DESC"
            ).fetchall()
        return [_row(row) for row in rows]  # type: ignore[misc]

    def counts(self) -> dict[str, int]:
        with self.connect() as connection:
            return {
                "companies": connection.execute("SELECT COUNT(*) FROM companies WHERE kind='monitor' AND archived_at IS NULL").fetchone()[0],
                "active_monitors": connection.execute("SELECT COUNT(*) FROM companies WHERE state='active' AND archived_at IS NULL").fetchone()[0],
                "matching_jobs": connection.execute("SELECT COUNT(*) FROM job_matches m JOIN jobs j ON j.id=m.job_id WHERE m.is_match=1 AND m.dismissed=0 AND j.is_active=1").fetchone()[0],
                "unread_jobs": connection.execute("SELECT COUNT(*) FROM job_matches m JOIN jobs j ON j.id=m.job_id WHERE m.is_match=1 AND m.unread=1 AND m.dismissed=0 AND j.is_active=1").fetchone()[0],
                "failing_monitors": connection.execute("SELECT COUNT(*) FROM companies WHERE state='needs_attention' AND archived_at IS NULL").fetchone()[0],
                "due_monitors": connection.execute(
                    "SELECT COUNT(*) FROM companies WHERE state='active' AND archived_at IS NULL AND next_run_at IS NOT NULL AND next_run_at<=?",
                    (iso_now(),),
                ).fetchone()[0],
                "documents": connection.execute("SELECT COUNT(*) FROM documents WHERE archived_at IS NULL").fetchone()[0],
            }

    def create_session(self, token_hash: str, csrf_hash: str, expires_at: datetime) -> None:
        with self.connect() as connection:
            connection.execute("DELETE FROM sessions WHERE expires_at < ?", (iso_now(),))
            connection.execute("INSERT OR REPLACE INTO sessions VALUES(?,?,?,?)", (token_hash, csrf_hash, expires_at.isoformat(), iso_now()))

    def session_valid(self, token_hash: str, csrf_hash: str) -> bool:
        with self.connect() as connection:
            row = connection.execute("SELECT 1 FROM sessions WHERE token_hash=? AND csrf_hash=? AND expires_at>?", (token_hash, csrf_hash, iso_now())).fetchone()
        return bool(row)
