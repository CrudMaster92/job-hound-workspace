"""FastAPI application for the local JobHound MVP."""

from __future__ import annotations

import asyncio
import json
import os
import re
import secrets
import uuid
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from threading import Event
from typing import Any, AsyncIterator, Literal

import httpx

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Request, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from fastapi.responses import JSONResponse
from starlette.background import BackgroundTask

from .ai_connections import (AIConnectionError, AIConnectionRegistry, AILoginManager, ConnectionErrorCategory,
                             OpenRouterConnection, create_default_registry)
from .agent_instructions import apply_patch as apply_instruction_patch, snapshot as instruction_snapshot
from .chat_provider import AgentAnswer, DocumentAgentAnswer, LocalAgentProvider
from .chat_attachments import ChatAttachmentStore
from .library import LibraryService, mount_library
from .job_queries import JobQueries
from .chat_jobs import ChatJobs
from .chat_progress import present_progress
from .ai_connections.cancellation import ProviderCancelled
from .library_chat import retrieve_answer, consent as library_consent, declined as library_declined
from .chat_commands import get_command, list_commands, public_command, resolved_context
from .company_branding import discover_company_branding, fetch_company_logo, resolve_company_logo
from .company_discovery import (
    CompanyDiscoveryRequest, LocalCompanyAnswer, SignalExtractionAnswer,
    company_discovery_options, compose_local_company_prompt, compose_signal_prompt,
    criteria_values, fallback_signals, normalize_local_candidates, rank_catalog, render_company_discovery,
)
from .db import DashboardLayoutConflict, Database
from .dashboard_widgets import (
    RUNTIME_CSP, WidgetAgentAnswer, WidgetDraftCreate, WidgetDraftUpdate,
    WidgetInstallRequest, get_widget, get_widget_draft, install_widget,
    latest_thread_draft, list_widgets, runtime_document, save_widget_draft,
    widget_agent_provider_schema, widget_sdk, widget_snapshot,
)
from .dashboard_card_export import (
    DashboardCardExporter, DashboardCardExportTimeout, DashboardCardExportUnavailable,
)
from .document_store import DocumentError, DocumentStore, MAX_FILE_BYTES
from .interviews.service import InterviewService
from .activity import activity_summary
from .tracker_routes import mount_trackers
from .interviews.routes import mount_interviews
from .geography import HomeAddressError, geocode_home_address
from .interview_prep import (InterviewPrepAnswer, InterviewPrepRequest,
                             compose_interview_prep_prompt, interview_prep_options,
                             normalize_interview_prep_answer, render_interview_prep)
from .intro_letter import (IntroLetterAnswer, IntroLetterRequest, compose_intro_letter_prompt,
                           intro_letter_options, normalize_intro_letter_answer, render_intro_letter)
from .recruiter_search import find_recruiters, recruiter_reply
from .platform_profiles import present_profile, present_profiles, validate_visibility
from .platform_catalog_store import PlatformCatalog
from .presets import (CatalogSelectionInstallRequest, CatalogSelectionRequest,
                      PresetExportRequest, PresetInstallRequest, PresetManifest,
                      PresetRemovalRequest, PresetService, PresetVisibilityRequest)
from .preset_catalog_client import PresetCatalogError
from .scheduler import Scheduler, next_occurrence
from .recap import RecapService
from .recap_routes import mount_recaps
from .schemas import (AISelectionUpdate, AgentInstructionsUpdate, BuildRequest, ChatDocumentAttachmentCreate, ChatMessageCreate, ChatMonitorActionCreate, ChatSuggestionCreate, ChatThreadCreate, ChatTurnRetry,
                      ChatThreadUpdate, CompanyCreate, CompanyUpdate, HomeLocationUpdate, JobActivityCreate, JobStateUpdate,
                      JobTrackingUpdate, ManualApplicationCreate, PairRequest,
                      DashboardLayoutUpdate,
                      DocumentDraftCreate, DocumentDraftUpdate, DocumentUpdate, OpenRouterCredentialUpdate,
                      CatalogRecipeUpdateRequest, PlatformCatalogCreate, PlatformProfileUpdate,
                      RecipeActivate, RecruiterSearchRequest, SettingsUpdate)
from .schemas import BUILTIN_DASHBOARD_KEYS
from .security import SecurityManager, is_loopback
from .capabilities import capabilities, require_local_scrapers
from .contributions.service import ContributionService
from .contributions.routes import mount_contributions


class EventBroker:
    def __init__(self) -> None:
        self.subscribers: set[asyncio.Queue[dict[str, Any]]] = set()

    async def publish(self, event: dict[str, Any]) -> None:
        for queue in tuple(self.subscribers):
            if queue.full():
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            queue.put_nowait(event)

    async def stream(self, visible=None) -> AsyncIterator[str]:
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=100)
        self.subscribers.add(queue)
        try:
            yield 'event: connected\ndata: {"ok":true}\n\n'
            while True:
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=15)
                    if visible and not visible(item):
                        continue
                    yield f"event: {item.get('type', 'message')}\ndata: {json.dumps(item, default=str)}\n\n"
                except TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            self.subscribers.discard(queue)


def create_app(*, db_path: str | Path | None = None, start_scheduler: bool = True,
               scheduler_gateway: Any = None, ai_connections: AIConnectionRegistry | None = None,
               chat_provider: LocalAgentProvider | None = None,
               ai_login_manager: AILoginManager | None = None,
               seed_default_documents: bool = True,
               dashboard_card_exporter: DashboardCardExporter | None = None) -> FastAPI:
    database = Database(
        db_path
        or os.getenv("JOBHOUND_DB_PATH")
        or os.getenv("JOBHOUND_DB", "data/jobhound.sqlite3")
    )
    platform_catalog = PlatformCatalog(Path(database.path).parent / "platform-catalog")
    security = SecurityManager(database)
    events = EventBroker()
    connections = ai_connections or create_default_registry()
    connections.settings_reader = database.get_settings
    login_manager = ai_login_manager or AILoginManager(connections)
    from .artifacts.service import ArtifactService
    from .artifacts.routes import mount_artifacts
    from .artifacts.agent import ArtifactTools, GUIDANCE as FILE_GUIDANCE
    from .artifacts.contracts import ArtifactProposal
    artifacts = ArtifactService(database)
    contributions = ContributionService(database)
    documents = DocumentStore(database)
    chat_attachments = ChatAttachmentStore(database)
    interviews = InterviewService(database)
    card_exporter = dashboard_card_exporter or DashboardCardExporter()
    if seed_default_documents:
        documents.ensure_default_templates()

    def announce_terminal_run(run: dict[str, Any]) -> dict[str, Any] | None:
        if run.get("status") not in {"complete", "partial", "failed"}:
            return None
        link = database.get_chat_run_link(int(run["id"]))
        if not link or link.get("terminal_message_id"):
            return None
        company = database.get_company(int(run["company_id"])) or {"name": run.get("company_name", "This monitor")}
        name = company.get("name") or "This monitor"
        if run["status"] == "failed":
            content = f"{name} still needs attention — the {link['action']} failed: {run.get('message') or 'Unknown error'}"
        else:
            content = (
                f"{name} is ready — the {link['action']} completed and found "
                f"{int(run.get('raw_count') or 0)} open roles, with {int(run.get('matched_count') or 0)} matching your filters."
            )
        message = database.add_chat_message(
            int(link["thread_id"]), "assistant", content,
            {"run_update": {
                "run_id": int(run["id"]), "company_id": int(run["company_id"]), "company_name": name,
                "action": link["action"], "status": run["status"], "message": run.get("message"),
                "raw_count": int(run.get("raw_count") or 0), "matched_count": int(run.get("matched_count") or 0),
            }},
        )
        database.mark_chat_run_announced(int(run["id"]), int(message["id"]))
        return message

    def sync_terminal_chat_runs(thread_id: int) -> None:
        for linked in database.pending_chat_run_links(thread_id):
            run = dict(linked)
            run["id"] = run.pop("run_id")
            announce_terminal_run(run)

    async def publish_scheduler_event(event: dict[str, Any]) -> None:
        await events.publish(event)
        run = event.get("run") or {}
        try:
            message = announce_terminal_run(run) if isinstance(run, dict) else None
        except Exception:
            # Chat status delivery is best-effort and must never alter scraper run state.
            message = None
        if message:
            await events.publish({"type": "chat.message", "thread_id": message["thread_id"], "message": message})

    scheduler = Scheduler(database, ai_connections=connections, gateway=scheduler_gateway, event_callback=publish_scheduler_event)
    recaps = RecapService(database, connections, scheduler, events)
    presets = PresetService(database, scheduler)
    legacy_chat_agent = chat_provider
    chat_turn_tasks: dict[int, asyncio.Task[Any]] = {}
    chat_turn_cancellations: dict[int, Event] = {}

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        database.interrupt_active_chat_turns()
        recap_task = recaps.start(scheduled=start_scheduler)
        interviews.start()
        print(f"JobHound pairing code: {security.pairing_code}", flush=True)
        if start_scheduler:
            scheduler.start()
        yield
        await recaps.stop(recap_task)
        for cancellation in tuple(chat_turn_cancellations.values()):
            cancellation.set()
        for task in tuple(chat_turn_tasks.values()):
            task.cancel()
        contributions.close()
        artifacts.close()
        login_manager.close()
        interviews.close()
        if start_scheduler:
            await scheduler.stop()

    app = FastAPI(title="JobHound", version="0.1.0", lifespan=lifespan)
    app.state.db = database
    app.state.contributions = contributions
    mount_contributions(app, contributions)
    app.state.security = security
    app.state.scheduler = scheduler
    app.state.recaps = recaps
    mount_recaps(app, recaps)
    app.state.events = events
    app.state.ai_connections = connections
    app.state.ai_login_manager = login_manager
    app.state.artifacts = artifacts
    mount_artifacts(app, artifacts)
    app.state.documents = documents
    app.state.interviews = interviews
    mount_interviews(app, interviews, chat_attachments)
    mount_trackers(app, database, scheduler)
    from .public_board_routes import mount_public_board
    mount_public_board(app, database, app.state.trackers)
    library = LibraryService(database, documents, interviews)
    app.state.library = library
    mount_library(app, library)
    app.state.chat_attachments = chat_attachments
    app.state.platform_catalog = platform_catalog
    app.state.presets = presets
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[origin for origin in os.getenv("JOBHOUND_ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if origin],
        allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
    )

    @app.middleware("http")
    async def authorize_api(request: Request, call_next):
        public_paths = {"/api/v1/health", "/api/v1/auth/status", "/api/v1/auth/pair"}
        if request.url.path.startswith("/api/v1/") and request.url.path not in public_paths:
            try:
                security.authorize(request)
            except HTTPException as exc:
                return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
        response = await call_next(request)
        if "text/html" in response.headers.get("content-type", ""):
            # Native microphone capture must not be clickjacked by a remote website.
            policy = "frame-ancestors 'self' http://127.0.0.1:* http://localhost:*"
            existing = response.headers.get("content-security-policy", "")
            if "frame-ancestors" not in existing:
                response.headers["Content-Security-Policy"] = (existing + "; " if existing else "") + policy
        return response

    def get_db() -> Database:
        return database

    def require_loopback(request: Request) -> None:
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "Career documents are available only on the host computer")

    def company_or_404(company_id: int) -> dict[str, Any]:
        company = database.get_company(company_id)
        if not company or company.get("kind") == "public":
            raise HTTPException(404, "Company not found")
        return company

    def criteria_for_storage(value: dict[str, Any]) -> dict[str, Any]:
        if all(isinstance(value.get(key), list) for key in ("cities", "title_terms", "keywords")):
            return {key: {"mode": "replace" if value[key] else "any", "values": value[key]}
                    for key in ("cities", "title_terms", "keywords")}
        return value

    def cadence(company: dict[str, Any]) -> str:
        if company.get("schedule_kind") == "interval" and company.get("interval_hours") == 6:
            return "every_6_hours"
        return company.get("schedule_kind", "manual")

    def present_company(company: dict[str, Any] | None) -> dict[str, Any] | None:
        if not company:
            return None
        result = dict(company)
        result["schedule"] = cadence(company)
        result["failure_count"] = result.get("consecutive_failures", 0)
        criteria = result.get("criteria", {})
        result["criteria"] = {key: (criteria.get(key, {}).get("values", []) if criteria.get(key, {}).get("mode") == "replace" else [])
                              for key in ("cities", "title_terms", "keywords")}
        with database.connect() as connection:
            counts = connection.execute(
                """SELECT COUNT(*) raw_count, COALESCE(SUM(CASE WHEN m.is_match=1 THEN 1 ELSE 0 END),0) matching_count
                FROM jobs j LEFT JOIN job_matches m ON m.job_id=j.id WHERE j.company_id=? AND j.is_active=1""", (company["id"],)
            ).fetchone()
        result["raw_job_count"] = counts["raw_count"]
        result["matching_job_count"] = counts["matching_count"]
        memberships = database.list_company_preset_memberships(int(company["id"]))
        result["preset_memberships"] = memberships
        result["preset_ids"] = [item["preset_id"] for item in memberships]
        result["is_hidden"] = database.is_company_hidden(int(company["id"]))
        return result

    def present_activity(activity: dict[str, Any], *, include_job: bool = False) -> dict[str, Any]:
        result = dict(activity)
        if include_job:
            result["job"] = {
                "id": result.pop("job_id"), "title": result.pop("job_title", ""),
                "company": result.pop("company", ""),
            }
        else:
            result.pop("job_title", None)
            result.pop("company", None)
        return result

    _HOME_UNSET = object()

    def present_job(
        job: dict[str, Any], *, include_activities: bool = False,
        home_location: dict[str, Any] | None | object = _HOME_UNSET,
    ) -> dict[str, Any]:
        from .geography import add_geography
        home = database.get_settings().get("home_location") if home_location is _HOME_UNSET else home_location
        job = add_geography(job, home if isinstance(home, dict) else None)
        result = dict(job)
        description = " ".join(str(result.get("description") or "").split())
        snippet = description[:320]
        if len(description) > 320:
            snippet = snippet.rsplit(" ", 1)[0].rstrip(" ,.;:") + "…"
        result["description_available"] = bool(description)
        result["description_snippet"] = snippet
        result["company"] = result.get("company_name", "")
        result["source_url"] = result.get("url", "")
        result["is_read"] = not bool(result.get("unread", False))
        result["is_dismissed"] = bool(result.get("dismissed", False))
        result["is_saved"] = bool(result.get("is_saved", False))
        result["applied_at_inferred"] = bool(result.get("applied_at_inferred", False))
        result["origin"] = result.get("origin") or "scraped"
        result["activity_count"] = int(result.get("activity_count") or 0)
        if include_activities:
            result["activities"] = [present_activity(item) for item in database.list_job_activities(
                job_id=int(result["id"]), limit=8,
            )]
        return result

    job_queries = JobQueries(database, present_job)
    chat_jobs = ChatJobs(job_queries, app.state.public_board)

    async def recruiter_search_for_job(job_id: int, *, live_search: bool = True) -> dict[str, Any]:
        value = database.get_job(job_id)
        if not value:
            raise HTTPException(404, "Job not found")
        return await find_recruiters(
            present_job(value), connections, database.get_settings(), live_search=live_search,
        )

    async def interview_prep_for_job(
        job_id: int, payload: InterviewPrepRequest, *, request: Request | None = None,
    ) -> dict[str, Any]:
        value = database.get_job(job_id)
        if not value:
            raise HTTPException(404, "Job not found")
        company = database.get_company(int(value["company_id"]))
        if not company:
            raise HTTPException(409, "The company record for this job is unavailable")
        settings_value = database.get_settings()
        selected_connection = settings_value.get("ai_connection")
        selected_model = settings_value.get("ai_model")
        if not selected_connection or selected_connection == "none":
            raise HTTPException(409, "Choose an AI connection before preparing for an interview")

        resume_context = None
        if payload.resume_document_id is not None:
            if request is not None:
                require_loopback(request)
            if payload.document_consent_connection != selected_connection:
                raise HTTPException(
                    409,
                    f"Confirm that this resume may be sent to the configured {selected_connection} connection",
                )
            source = database.get_document(payload.resume_document_id)
            if not source or source.get("archived_at"):
                raise HTTPException(404, "Active resume not found")
            if source.get("kind") != "resume":
                raise HTTPException(422, "Interview preparation accepts only a resume document")
            try:
                resume_value = documents.read(payload.resume_document_id, max_chars=30_000)
            except KeyError as exc:
                raise HTTPException(404, "Resume not found") from exc
            if not resume_value.get("text", "").strip():
                raise HTTPException(409, "The selected resume has no extractable text")
            resume_context = {
                "id": payload.resume_document_id,
                "label": resume_value.get("label"),
                "text": resume_value.get("text", ""),
                "text_truncated": resume_value.get("text_truncated", False),
            }

        job_context = present_job(value)
        job_context["description"] = str(value.get("description") or "")[:50_000]
        company_context = {
            "id": int(company["id"]),
            "name": company.get("name"),
            "careers_url": company.get("careers_url"),
        }
        browsing = bool(settings_value.get("chat_web_browsing", True))
        prompt = compose_interview_prep_prompt(
            job_context, company_context, payload, resume=resume_context, browsing=browsing,
        )
        try:
            raw = await asyncio.to_thread(
                connections.run_structured, selected_connection, prompt, InterviewPrepAnswer,
                model=selected_model, browsing=browsing,
            )
            result = normalize_interview_prep_answer(raw, payload)
        except AIConnectionError as exc:
            raise HTTPException(409, exc.detail) from exc
        except ValueError as exc:
            raise HTTPException(502, f"The selected AI returned invalid interview preparation: {exc}") from exc
        result.update({
            "job_id": int(value["id"]),
            "job_title": value.get("title"),
            "company": company.get("name"),
            "source_url": value.get("url"),
            "provider": selected_connection,
            "model": selected_model,
        })
        return result

    async def discover_companies_for_request(
        payload: CompanyDiscoveryRequest, *, request: Request | None = None,
    ) -> dict[str, Any]:
        settings_value = database.get_settings()
        selected_connection = settings_value.get("ai_connection")
        selected_model = settings_value.get("ai_model")
        resume_context = None
        warnings: list[str] = []
        if payload.resume_document_id is not None:
            if request is not None:
                require_loopback(request)
            if not selected_connection or selected_connection == "none":
                raise HTTPException(409, "Choose an AI connection before using a resume for company discovery")
            if payload.document_consent_connection != selected_connection:
                raise HTTPException(
                    409,
                    f"Confirm that this resume may be sent to the configured {selected_connection} connection",
                )
            source = database.get_document(payload.resume_document_id)
            if not source or source.get("archived_at"):
                raise HTTPException(404, "Active resume not found")
            if source.get("kind") != "resume":
                raise HTTPException(422, "Company discovery accepts only a resume document")
            try:
                resume_value = documents.read(payload.resume_document_id, max_chars=30_000)
            except KeyError as exc:
                raise HTTPException(404, "Resume not found") from exc
            if not resume_value.get("text", "").strip():
                raise HTTPException(409, "The selected resume has no extractable text")
            resume_context = {
                "id": payload.resume_document_id,
                "label": resume_value.get("label"),
                "text": resume_value.get("text", ""),
                "text_truncated": resume_value.get("text_truncated", False),
            }

        signals = fallback_signals(settings_value, payload)
        profile_summary = "I matched your saved JobHound search profile against the preset catalog."
        if selected_connection and selected_connection != "none":
            try:
                raw_signals = await asyncio.to_thread(
                    connections.run_structured,
                    selected_connection,
                    compose_signal_prompt(settings_value, payload, resume=resume_context),
                    SignalExtractionAnswer,
                    model=selected_model,
                    browsing=False,
                )
                extracted = SignalExtractionAnswer.model_validate(raw_signals)
                signals = extracted.signals
                profile_summary = extracted.summary
            except (AIConnectionError, ValueError) as exc:
                detail = exc.detail if isinstance(exc, AIConnectionError) else str(exc)
                warnings.append(f"AI signal extraction was unavailable, so JobHound used saved criteria: {detail}")

        if not any((signals.industries, signals.specialties, signals.role_families,
                    signals.title_terms, signals.keywords, signals.locations)):
            return {
                "profile_summary": "Tell me a role, industry, specialty, or location to start company discovery.",
                "signals": signals.model_dump(mode="json"), "collections": [], "companies": [],
                "local_candidates": [], "warnings": warnings,
                "catalog_status": "not_loaded", "catalog_error": None, "source_commit": None,
                "provider": selected_connection, "model": selected_model,
                "resume_used": resume_context is not None, "needs_refinement": True,
            }

        try:
            snapshot = presets.discovery_catalog()
            ranked = rank_catalog(
                signals,
                snapshot["catalog"],
                snapshot["companies"],
                presets.discovery_company,
                presets.discovery_collection,
            )
        except PresetCatalogError as exc:
            return {
                "profile_summary": profile_summary,
                "signals": signals.model_dump(mode="json"), "collections": [], "companies": [],
                "local_candidates": [], "warnings": [*warnings, "The public preset catalog is offline."],
                "catalog_status": "unavailable", "catalog_error": str(exc), "source_commit": None,
                "provider": selected_connection, "model": selected_model,
                "resume_used": resume_context is not None, "needs_refinement": False,
            }

        local_candidates: list[dict[str, Any]] = []
        browsing = bool(settings_value.get("chat_web_browsing", True))
        if payload.include_local_fallback and len(ranked["companies"]) < 3 and browsing:
            home = settings_value.get("home_location") or {}
            local_area = " ".join(str(item) for item in (
                home.get("city"), home.get("region"), home.get("country")
            ) if item).strip()
            if not local_area:
                local_area = next(iter(criteria_values(settings_value.get("criteria") or {}, "cities")), "")
            if not local_area:
                warnings.append("Add a Home Location or saved search city before asking for local companies.")
            elif selected_connection and selected_connection != "none":
                catalog_names = [str(item.get("name") or "") for item in snapshot["companies"]]
                existing = database.list_companies(include_archived=True)
                try:
                    raw_local = await asyncio.to_thread(
                        connections.run_structured,
                        selected_connection,
                        compose_local_company_prompt(
                            signals, local_area,
                            [*catalog_names, *[str(item.get("name") or "") for item in existing]],
                        ),
                        LocalCompanyAnswer,
                        model=selected_model,
                        browsing=True,
                    )
                    local_candidates, local_warnings = normalize_local_candidates(
                        raw_local,
                        excluded_names=[*catalog_names, *[str(item.get("name") or "") for item in existing]],
                        existing_urls=[str(item.get("careers_url") or "") for item in existing],
                    )
                    warnings.extend(local_warnings)
                except (AIConnectionError, ValueError) as exc:
                    detail = exc.detail if isinstance(exc, AIConnectionError) else str(exc)
                    warnings.append(f"Local-company research was unavailable: {detail}")

        return {
            "profile_summary": profile_summary,
            "signals": signals.model_dump(mode="json"),
            **ranked,
            "local_candidates": local_candidates,
            "warnings": warnings,
            "catalog_status": snapshot["catalog"].get("catalog_status", "current"),
            "catalog_error": snapshot["catalog"].get("catalog_error"),
            "source_commit": snapshot["catalog"].get("source_commit"),
            "provider": selected_connection,
            "model": selected_model,
            "resume_used": resume_context is not None,
            "needs_refinement": False,
        }

    async def intro_letter_for_job(
        job_id: int, payload: IntroLetterRequest, *, request: Request,
        current_draft: dict[str, Any] | None = None,
        draft_id: int | None = None,
        source_document_id: int | None = None,
    ) -> dict[str, Any]:
        require_loopback(request)
        value = database.get_job(job_id)
        if not value:
            raise HTTPException(404, "Job not found")
        company = database.get_company(int(value["company_id"]))
        if not company:
            raise HTTPException(409, "The company record for this job is unavailable")
        settings_value = database.get_settings()
        selected_connection = settings_value.get("ai_connection")
        selected_model = settings_value.get("ai_model")
        if not selected_connection or selected_connection == "none":
            raise HTTPException(409, "Choose an AI connection before creating an intro letter")

        resume_context = None
        selected_source_id = source_document_id
        if payload.resume_document_id is not None:
            if payload.document_consent_connection != selected_connection:
                raise HTTPException(
                    409,
                    f"Confirm that this resume may be sent to the configured {selected_connection} connection",
                )
            source = database.get_document(payload.resume_document_id)
            if not source or source.get("archived_at"):
                raise HTTPException(404, "Active resume not found")
            if source.get("kind") != "resume":
                raise HTTPException(422, "Intro-letter drafting accepts only a resume document")
            try:
                resume_value = documents.read(payload.resume_document_id, max_chars=30_000)
            except KeyError as exc:
                raise HTTPException(404, "Resume not found") from exc
            if not resume_value.get("text", "").strip():
                raise HTTPException(409, "The selected resume has no extractable text")
            selected_source_id = payload.resume_document_id
            resume_context = {
                "id": payload.resume_document_id,
                "label": resume_value.get("label"),
                "text": resume_value.get("text", ""),
                "text_truncated": resume_value.get("text_truncated", False),
            }

        job_context = present_job(value)
        job_context["description"] = str(value.get("description") or "")[:50_000]
        prompt = compose_intro_letter_prompt(
            job_context, payload, resume=resume_context, current_draft=current_draft,
        )
        try:
            raw = await asyncio.to_thread(
                connections.run_structured, selected_connection, prompt, IntroLetterAnswer,
                model=selected_model, browsing=False,
            )
            normalized = normalize_intro_letter_answer(
                raw, job_title=str(value.get("title") or "Role"),
                company=str(company.get("name") or "Company"),
                candidate_source=bool(resume_context or selected_source_id),
            )
            draft = documents.create_draft(
                normalized["draft"], source_document_id=selected_source_id, draft_id=draft_id,
            )
        except AIConnectionError as exc:
            raise HTTPException(409, exc.detail) from exc
        except (DocumentError, ValueError) as exc:
            raise HTTPException(502, f"The selected AI returned an invalid intro letter: {exc}") from exc
        return {
            "job_id": int(value["id"]), "job_title": value.get("title"),
            "company": company.get("name"), "source_url": value.get("url"),
            "resume_used": bool(selected_source_id), "warnings": normalized["warnings"],
            "provider": selected_connection, "model": selected_model,
            "reply": normalized["reply"], "draft": draft,
        }

    def validate_chat_binding(
        command_id: str | None, context_type: str | None, context_id: int | None,
    ) -> dict[str, Any] | None:
        command = get_command(command_id)
        if command_id and not command:
            raise HTTPException(422, f"Unknown chat command: {command_id}")
        bound_value = None
        if context_type == "job" and context_id is not None:
            bound_value = database.get_job(context_id)
            if not bound_value:
                raise HTTPException(404, "Job context not found")
        elif context_type == "document" and context_id is not None:
            bound_value = database.get_document(context_id)
            if not bound_value:
                raise HTTPException(404, "Document context not found")
        elif context_type is not None or context_id is not None:
            raise HTTPException(422, "Chat context must include a supported type and id")
        if command and command.get("requires_context", True) and (
            not context_type or context_type not in command["supported_context_types"]
        ):
            raise HTTPException(422, f"/{command_id} requires a compatible attached context")
        if command and context_type and context_type not in command["supported_context_types"]:
            raise HTTPException(422, f"/{command_id} does not support that attached context")
        return bound_value

    def present_chat_thread(thread: dict[str, Any]) -> dict[str, Any]:
        result = dict(thread)
        command = public_command(result.get("command_id"))
        job_value = None
        document_value = None
        if result.get("context_type") == "job" and result.get("context_id") is not None:
            job_value = database.get_job(int(result["context_id"]))
        elif result.get("context_type") == "document" and result.get("context_id") is not None:
            value = database.get_document(int(result["context_id"]))
            document_value = documents.public(value) if value else None
        result["command"] = command
        result["context"] = resolved_context(
            result.get("context_type"), result.get("context_id"), job_value, document_value
        )
        result["suggested_prompt"] = command.get("suggested_prompt") if command else None
        if result.get("id") is not None:
            result["activity_summary"] = database.get_chat_activity_summary(int(result["id"]))
            active_turn = database.get_active_chat_turn(int(result["id"]))
            result["active_turn"] = present_progress(active_turn) if active_turn else None
            selected = "codex" if legacy_chat_agent is not None else database.get_settings().get("ai_connection")
            if selected and selected != "none":
                result["library_access"] = library.access(int(result["id"]), selected)
        return result

    def require_document_chat(request: Request, thread: dict[str, Any] | None) -> None:
        if thread and (thread.get("context_type") == "document" or thread.get("private_local")):
            require_loopback(request)

    def latest_document_draft_id(thread: dict[str, Any]) -> int | None:
        for message in reversed(thread.get("messages", [])):
            value = (message.get("metadata") or {}).get("document_draft")
            if value and value.get("id"):
                return int(value["id"])
        return None

    def skill_prompt(
        thread: dict[str, Any], command_id: str, prompt_message_id: int | None,
    ) -> dict[str, Any] | None:
        option_key = {
            "interview_prep": "interview_prep_options",
            "create_intro_letter": "intro_letter_options",
            "discover_companies": "company_discovery_options",
        }.get(command_id)
        if not option_key:
            return None
        prompts = [
            item for item in thread.get("messages", [])
            if item.get("role") == "assistant" and (item.get("metadata") or {}).get(option_key)
        ]
        if prompt_message_id is not None:
            prompt = next((item for item in prompts if int(item["id"]) == prompt_message_id), None)
            if not prompt:
                raise HTTPException(409, "That skill questionnaire is no longer available in this chat")
            return prompt
        return prompts[-1] if prompts else None

    def completed_skill_submission(
        thread: dict[str, Any], command_id: str, prompt_message_id: int,
    ) -> dict[str, Any] | None:
        result_key = {
            "interview_prep": "interview_prep_result",
            "create_intro_letter": "intro_letter_result",
            "discover_companies": "company_discovery_result",
        }[command_id]
        option_key = {
            "interview_prep": "interview_prep_options",
            "create_intro_letter": "intro_letter_options",
            "discover_companies": "company_discovery_options",
        }[command_id]
        for item in thread.get("messages", []):
            if int(item["id"]) <= prompt_message_id or item.get("role") != "assistant":
                continue
            metadata = item.get("metadata") or {}
            submission = metadata.get("skill_submission") or {}
            if submission.get("command_id") == command_id and int(
                submission.get("prompt_message_id") or 0
            ) == prompt_message_id:
                return submission
            # Compatibility for successful chats created before submission
            # snapshots existed. Stop at a newer questionnaire invocation.
            if metadata.get(option_key):
                break
            if metadata.get(result_key):
                return {"command_id": command_id, "prompt_message_id": prompt_message_id}
        return None

    def require_open_skill_prompt(
        thread: dict[str, Any], command_id: str, prompt_message_id: int | None,
    ) -> dict[str, Any]:
        prompt = skill_prompt(thread, command_id, prompt_message_id)
        if not prompt:
            raise HTTPException(409, f"Start /{command_id} to open a fresh questionnaire")
        if completed_skill_submission(thread, command_id, int(prompt["id"])):
            raise HTTPException(
                409,
                f"This /{command_id} questionnaire was already completed. Select the skill again for a new run.",
            )
        return prompt

    def resume_selection(resume_document_id: int | None) -> dict[str, Any]:
        if not resume_document_id:
            return {"resume_document_id": None, "resume_label": "No resume"}
        record = database.get_document(resume_document_id)
        return {
            "resume_document_id": resume_document_id,
            "resume_label": str((record or {}).get("label") or f"Resume #{resume_document_id}"),
        }

    def present_run(run: dict[str, Any]) -> dict[str, Any]:
        result = dict(run)
        result["state"] = result.get("status")
        company = database.get_company(result["company_id"])
        result["company_name"] = company.get("name") if company else None
        return result

    def connection_snapshot() -> dict[str, Any]:
        settings_value = database.get_settings()
        selected = settings_value.get("ai_connection")
        model = settings_value.get("ai_model")
        records = []
        for status in connections.statuses():
            item = status.model_dump(mode="json")
            item["selected"] = item["id"] == selected
            if item["selected"] and model:
                item["active_model"] = model
            records.append(item)
        return {
            "onboarding": {
                "completed": bool(settings_value.get("onboarding_completed_at")),
                "completed_at": settings_value.get("onboarding_completed_at"),
            },
            "selection": {"connection": selected, "model": model},
            "connections": records,
        }

    def present_settings(value: dict[str, Any]) -> dict[str, Any]:
        result = dict(value)
        home = value.get("home_location") or {}
        result["home_address"] = home.get("address")
        if value["default_schedule_kind"] == "interval" and value["default_interval_hours"] == 6:
            result["default_schedule"] = "every_6_hours"
        else:
            result["default_schedule"] = value["default_schedule_kind"]
        snapshot = connection_snapshot()
        codex = next((item for item in snapshot["connections"] if item["id"] == "codex"), None)
        result.update({
            "ai_connection": value.get("ai_connection"), "ai_model": value.get("ai_model"),
            "onboarding_completed": snapshot["onboarding"]["completed"],
            "codex_connected": bool(codex and codex["authenticated"]), "codex_model": None,
            "lan_url": None, "codex": codex, "chat_providers": snapshot["connections"],
            # Transitional aliases for existing locally served clients.
            "chat_provider": value.get("ai_connection") or "none",
            "chat_model": value.get("ai_model"),
        })
        return result

    def create_monitor_from_suggestion(name: str, careers_url: str, thread_id: int | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
        normalized_url = careers_url.rstrip("/").casefold()
        for existing in database.list_companies(include_archived=False):
            if str(existing.get("careers_url", "")).rstrip("/").casefold() == normalized_url:
                return existing, {"duplicate": True, "message": "This careers page is already monitored."}
        settings_value = database.get_settings()
        require_local_scrapers()
        company = database.create_company({
            "name": name, "careers_url": careers_url,
            "schedule_kind": settings_value["default_schedule_kind"],
            "interval_hours": settings_value["default_interval_hours"],
            "local_time": settings_value["default_local_time"], "weekday": settings_value["default_weekday"],
            "criteria": {key: {"mode": "inherit", "values": []} for key in ("cities", "title_terms", "keywords")},
            "build_now": False,
        })
        database.update_company(company["id"], {"state": "building"})
        run = scheduler.enqueue(company["id"], "build")
        if thread_id:
            database.link_chat_run(int(run["id"]), thread_id, "scraper build")
        return database.get_company(company["id"]) or company, present_run(run)

    def queue_chat_monitor_action(thread_id: int, company_id: int, requested_action: str) -> tuple[str, dict[str, Any]]:
        require_local_scrapers()
        if not database.get_chat_thread(thread_id):
            raise HTTPException(404, "Chat not found")
        company = company_or_404(company_id)
        action = requested_action
        if action == "repair" and not company.get("active_recipe_version"):
            action = "rebuild"
        if action == "repair":
            run = scheduler.enqueue(company_id, "repair")
            label = "scraper repair"
        else:
            database.update_company(company_id, {"state": "building"})
            run = scheduler.enqueue(company_id, "build")
            label = "scraper rebuild"
        database.link_chat_run(int(run["id"]), thread_id, label)
        return action, present_run(run)

    def chat_monitor_context(company: dict[str, Any]) -> dict[str, Any]:
        latest = database.list_runs(int(company["id"]), limit=1)
        run = latest[0] if latest else None
        return {
            "id": company["id"], "name": company["name"], "careers_url": company["careers_url"],
            "state": company.get("state"), "adapter": company.get("adapter"),
            "active_recipe_version": company.get("active_recipe_version"),
            "consecutive_failures": int(company.get("consecutive_failures") or 0),
            "available_actions": ["rebuild"] + (["repair"] if company.get("active_recipe_version") else []),
            "latest_run": ({
                "id": run["id"], "kind": run["kind"], "status": run["status"],
                "message": run.get("message"), "diagnostics": run.get("diagnostics", {}),
                "raw_count": int(run.get("raw_count") or 0), "matched_count": int(run.get("matched_count") or 0),
            } if run else None),
        }

    def present_build(run: dict[str, Any]) -> dict[str, Any]:
        status = run.get("status")
        event_type = "error" if status == "failed" else "complete" if status in {"complete", "partial"} else "progress"
        company = database.get_company(run["company_id"])
        payload = {
            "type": event_type, "stage": "complete" if event_type == "complete" else status,
            "message": run.get("message") or "Queued", "progress": run.get("progress", 0),
            "build_id": str(run["id"]), "company_id": str(run["company_id"]),
            "adapter": company.get("adapter") if company else None,
            "raw_count": run.get("raw_count", 0), "matched_count": run.get("matched_count", 0),
        }
        if event_type == "error":
            payload["error"] = run.get("message") or "Scraper build failed"
        if event_type == "complete":
            payload["preview_jobs"] = [present_job(item) for item in database.list_jobs(
                matching=None, company_id=run["company_id"], dismissed=None, active=True, limit=3)]
        return payload

    @app.get("/api/v1/health")
    def health():
        with database.connect() as connection:
            busy = bool(connection.execute("SELECT 1 FROM scraper_contributions WHERE state IN ('queued','running') LIMIT 1").fetchone()
                        or connection.execute("SELECT 1 FROM runs WHERE status='running' LIMIT 1").fetchone()
                        or connection.execute("SELECT 1 FROM recap_runs WHERE status IN ('queued','running') LIMIT 1").fetchone()
                        or connection.execute("SELECT 1 FROM chat_artifact_revisions WHERE state='pending' LIMIT 1").fetchone()
                        or connection.execute("SELECT 1 FROM interviews WHERE capture_state IN ('recording','saving') OR json_extract(metadata,'$.transcription_state') IN ('queued','processing') LIMIT 1").fetchone())
        busy = busy or any(not task.done() for task in chat_turn_tasks.values())
        return {"ok": True, "status": "ok", "service": "jobhound", "version": app.version,
                "instance_id": os.getenv("JOBHOUND_INSTANCE_ID"), "capabilities": capabilities(),
                "busy": busy, "release": os.getenv("JOBHOUND_RELEASE"),
                "owner_pid": int(os.getenv("JOBHOUND_OWNER_PID", "0")) or None}

    @app.get("/api/v1/auth/status")
    def auth_status(request: Request):
        local = is_loopback(request.client.host if request.client else None)
        paired = local
        if not local:
            try:
                security.authorize(request)
                paired = True
            except HTTPException:
                paired = False
        return {"local": local, "paired": paired, "requires_pairing": not local and not paired}

    @app.get("/api/v1/auth/pairing-code")
    def pairing_code(request: Request):
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "Pairing code is shown only on the host computer")
        return {"code": security.pairing_code, "expires_in_seconds": security.pairing_ttl_minutes * 60}

    @app.post("/api/v1/auth/pair")
    def pair(payload: PairRequest, response: Response):
        csrf = security.pair(payload.code, response)
        return {"paired": True, "csrf_token": csrf}

    @app.get("/api/v1/dashboard")
    def dashboard(request: Request, db: Database = Depends(get_db), activity_only: bool = False):
        activity = activity_summary(db, local=is_loopback(request.client.host if request.client else None))
        if activity_only:
            return {"activity": activity}
        counts = db.counts()
        local = is_loopback(request.client.host if request.client else None)
        if not local:
            counts.pop("documents", None)
        with db.connect() as connection:
            horizon = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
            due = connection.execute("SELECT COUNT(*) FROM companies WHERE state='active' AND next_run_at IS NOT NULL AND next_run_at<=?", (horizon,)).fetchone()[0]
        saved_jobs = [present_job(item) for item in db.list_dashboard_jobs(kind="saved", limit=5)]
        new_roles = [present_job(item) for item in db.list_dashboard_jobs(kind="new", limit=5)]
        # Dashboard chat rows deliberately expose navigation metadata, not message contents.
        recent_chats = [{
            "id": int(item["id"]), "title": item["title"],
            "command_id": item.get("command_id"), "message_count": int(item.get("message_count") or 0),
            "created_at": item.get("created_at"), "updated_at": item.get("updated_at"),
        } for item in db.list_dashboard_chat_threads(
            limit=3, include_document_context=local,
        )]
        ats_activity = [present_activity(item, include_job=True)
                        for item in db.list_dashboard_job_activities(limit=5)]
        alerts = []
        for item in db.list_dashboard_scraper_alerts(limit=5):
            alerts.append({
                "company_id": int(item["id"]), "company_name": item["name"],
                "careers_url": item["careers_url"], "state": item.get("state"),
                "adapter": item.get("adapter"),
                "consecutive_failures": int(item.get("consecutive_failures") or 0),
                "latest_run": ({
                    "id": int(item["latest_run_id"]), "kind": item.get("latest_run_kind"),
                    "status": item.get("latest_run_status"),
                    "message": item.get("latest_run_message"),
                    "diagnostics": item.get("diagnostics") or {},
                    "finished_at": item.get("latest_run_finished_at"),
                    "queued_at": item.get("latest_run_queued_at"),
                } if item.get("latest_run_id") is not None else None),
            })
        layout = db.get_dashboard_layout()
        card_guidance = {
            "daily_recap": ("The latest daily job briefing and its Chat conversation.", "matching jobs and saved-job updates", ["morning briefing", "daily recap"]),
            "saved_jobs": ("The five most recently saved roles.", "saved jobs", ["recent saved roles", "bookmarked jobs"]),
            "recent_chats": ("The user's three most recent JobHound discussions.", "chat thread metadata", ["recent discussions", "recent JobHound chats"]),
            "scraper_alerts": ("Monitors with current scraper failures or warnings.", "scraper health", ["scraper problems", "broken monitors"]),
            "recent_ats_activity": ("The five latest application-tracking events.", "ATS activity", ["recent application activity", "ATS updates"]),
            "new_roles": ("The five newest roles matching the user's criteria.", "matching jobs", ["new roles", "latest matching jobs"]),
            "profile_visibility": ("Visibility status for tracked recruiting profiles.", "platform profile visibility", ["profile visibility", "recruiter discoverability"]),
            "application_funnel": ("Current application counts by milestone and outcome.", "application tracker", ["application progress", "application funnel"]),
            "create_widget": ("Starts the dashboard widget builder.", "widget creation action", []),
        }
        catalog = []
        for key, title, size in (
            ("daily_recap", "Daily Recap", "tall"),
            ("saved_jobs", "Last Saved Jobs", "tall"),
            ("recent_chats", "Recent Chats", "standard"),
            ("scraper_alerts", "Scraper Alerts", "standard"),
            ("recent_ats_activity", "Recent ATS Activity", "tall"),
            ("new_roles", "5 New Roles", "tall"),
            ("profile_visibility", "Profile Visibility", "standard"),
            ("application_funnel", "Application Funnel", "standard"),
            ("create_widget", "Create Widget", "standard"),
        ):
            description, data_scope, suggested_uses = card_guidance[key]
            catalog.append({
                "key": key, "title": title, "default_size": size, "available": True,
                "kind": "built_in", "description": description, "data_scope": data_scope,
                "export_eligible": key != "create_widget", "suggested_uses": suggested_uses,
            })
        cards = {
            "daily_recap": recaps.store.state(),
            "saved_jobs": {"key": "saved_jobs", "title": "Last Saved Jobs",
                           "count": db.count_jobs(matching=None, dismissed=None, active=None, saved=True),
                           "items": saved_jobs},
            "recent_chats": {"key": "recent_chats", "title": "Recent Chats",
                             "count": len(recent_chats), "items": recent_chats},
            "scraper_alerts": {"key": "scraper_alerts", "title": "Scraper Alerts",
                               "count": int(counts.get("failing_monitors", len(alerts))), "items": alerts},
            "recent_ats_activity": {"key": "recent_ats_activity", "title": "Recent ATS Activity",
                                    "count": len(ats_activity), "items": ats_activity},
            "new_roles": {"key": "new_roles", "title": "5 New Roles",
                          "count": int(counts.get("matching_jobs", len(new_roles))), "items": new_roles},
            "profile_visibility": {"key": "profile_visibility", "title": "Profile Visibility",
                                   "count": len(db.list_platform_profiles()),
                                   "items": present_profiles(
                                       db.list_platform_profiles(), platform_catalog.load()[0]
                                   )["profiles"]},
            "application_funnel": {"key": "application_funnel", "title": "Application Funnel",
                                   **db.application_tracker()},
        }
        installed = list_widgets(db, include_drafts=False)["widgets"]
        for widget in installed:
            manifest = widget["manifest"]
            catalog.append({
                "key": widget["key"], "title": manifest.get("title", "Custom widget"),
                "default_size": manifest.get("default_size", "standard"), "available": True,
                "custom": True, "widget_id": widget["id"], "kind": "installed_widget",
                "description": manifest.get("description", "Installed custom dashboard widget."),
                "data_scope": "custom widget bindings", "export_eligible": True,
                "suggested_uses": [manifest.get("title", "custom widget")],
            })
        return {
            **counts, "due_monitors": due, "activity": activity,
            "recent_runs": [present_run(item) for item in db.list_runs(limit=8)],
            "recent_jobs": [present_job(item) for item in db.list_jobs(limit=8)],
            "saved_jobs": saved_jobs,
            "layout_revision": layout["revision"], "layout": layout,
            "catalog": catalog, "available_cards": catalog, "cards": cards,
            "widgets": installed, "widget_builder_available": True,
        }

    @app.get("/api/v1/dashboard/cards/{card_key:path}/image")
    async def export_dashboard_card_image(
        card_key: str, request: Request, theme: Literal["light", "dark"] = Query("light"),
        db: Database = Depends(get_db),
    ):
        require_loopback(request)
        if card_key == "create_widget":
            raise HTTPException(422, "The Create Widget action is not an exportable dashboard card")
        if card_key in BUILTIN_DASHBOARD_KEYS:
            pass
        elif card_key.startswith("widget:") and card_key[7:].isdigit():
            if not get_widget(db, int(card_key[7:]), include_source=False):
                raise HTTPException(404, "Installed dashboard widget not found")
        else:
            raise HTTPException(404, "Dashboard card not found")
        try:
            png = await card_exporter.render(
                base_url=str(request.base_url).rstrip("/"), card_key=card_key, theme=theme,
            )
        except DashboardCardExportTimeout as exc:
            raise HTTPException(504, str(exc)) from exc
        except DashboardCardExportUnavailable as exc:
            raise HTTPException(503, str(exc)) from exc
        return Response(
            content=png, media_type="image/png",
            headers={
                "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
                "X-JobHound-Card-Key": card_key, "X-JobHound-Theme": theme,
            },
        )

    @app.put("/api/v1/dashboard/layout")
    async def update_dashboard_layout(
        payload: DashboardLayoutUpdate, db: Database = Depends(get_db),
    ):
        installed_keys = {item["key"] for item in list_widgets(db, include_drafts=False)["widgets"]}
        unknown_widgets = [item.key for item in payload.items
                           if item.key.startswith("widget:") and item.key not in installed_keys]
        if unknown_widgets:
            raise HTTPException(422, f"Unknown installed dashboard widget: {unknown_widgets[0]}")
        try:
            result = db.update_dashboard_layout(
                expected_revision=payload.revision,
                items=[item.model_dump(mode="json") for item in payload.items],
            )
        except DashboardLayoutConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        await events.publish({"type": "dashboard.layout.updated", "layout": result})
        return result

    @app.get("/api/v1/dashboard/widget-sdk")
    def get_dashboard_widget_sdk():
        return widget_sdk()

    @app.get("/api/v1/dashboard/widgets")
    def get_dashboard_widgets(include_drafts: bool = True, db: Database = Depends(get_db)):
        return list_widgets(db, include_drafts=include_drafts)

    @app.post("/api/v1/dashboard/widget-drafts", status_code=201)
    def create_dashboard_widget_draft(payload: WidgetDraftCreate, db: Database = Depends(get_db)):
        try:
            return save_widget_draft(
                db, manifest=payload.manifest.model_dump(mode="json"),
                javascript=payload.javascript, css=payload.css, thread_id=payload.thread_id,
                request_id=payload.request_id,
            )
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/api/v1/dashboard/widget-drafts/{draft_id}")
    def read_dashboard_widget_draft(draft_id: int, db: Database = Depends(get_db)):
        result = get_widget_draft(db, draft_id)
        if not result:
            raise HTTPException(404, "Dashboard widget draft not found")
        return result

    @app.put("/api/v1/dashboard/widget-drafts/{draft_id}")
    def revise_dashboard_widget_draft(
        draft_id: int, payload: WidgetDraftUpdate, db: Database = Depends(get_db),
    ):
        try:
            return save_widget_draft(
                db, draft_id=draft_id, expected_revision=payload.revision,
                manifest=payload.manifest.model_dump(mode="json"),
                javascript=payload.javascript, css=payload.css,
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/v1/dashboard/widgets/install")
    async def install_dashboard_widget(payload: WidgetInstallRequest, db: Database = Depends(get_db)):
        try:
            result = install_widget(
                db, draft_id=payload.draft_id, size=payload.size,
                after_key=payload.after_key, at_top=payload.at_top,
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        await events.publish({"type": "dashboard.widget.installed", "widget": result})
        return result

    def widget_runtime_response(
        source: dict[str, Any], nonce: str | None, theme: Literal["dark", "light"] = "dark",
    ) -> HTMLResponse:
        runtime_nonce = nonce if nonce and re.fullmatch(r"[A-Za-z0-9_-]{8,80}", nonce) else secrets.token_urlsafe(18)
        return HTMLResponse(
            runtime_document(
                javascript=source["javascript"], css=source.get("css", ""),
                nonce=runtime_nonce, theme=theme,
                interactions=source.get("manifest", {}).get("interactions", []),
            ),
            headers={"Content-Security-Policy": RUNTIME_CSP, "Cache-Control": "no-store",
                     "X-Content-Type-Options": "nosniff"},
        )

    @app.get("/api/v1/dashboard/widget-drafts/{draft_id}/runtime", response_class=HTMLResponse)
    def dashboard_widget_draft_runtime(
        draft_id: int, nonce: str | None = None, theme: Literal["dark", "light"] = "dark",
        db: Database = Depends(get_db),
    ):
        source = get_widget_draft(db, draft_id)
        if not source:
            raise HTTPException(404, "Dashboard widget draft not found")
        return widget_runtime_response(source, nonce, theme)

    @app.get("/api/v1/dashboard/widget-drafts/{draft_id}/snapshot")
    def dashboard_widget_draft_snapshot(draft_id: int, db: Database = Depends(get_db)):
        source = get_widget_draft(db, draft_id)
        if not source:
            raise HTTPException(404, "Dashboard widget draft not found")
        return widget_snapshot(db, source["manifest"])

    @app.get("/api/v1/dashboard/widgets/{widget_id}/runtime", response_class=HTMLResponse)
    def dashboard_widget_runtime(
        widget_id: int, nonce: str | None = None, theme: Literal["dark", "light"] = "dark",
        db: Database = Depends(get_db),
    ):
        source = get_widget(db, widget_id)
        if not source:
            raise HTTPException(404, "Dashboard widget not found")
        return widget_runtime_response(source, nonce, theme)

    @app.get("/api/v1/dashboard/widgets/{widget_id}/snapshot")
    def dashboard_widget_snapshot(widget_id: int, db: Database = Depends(get_db)):
        source = get_widget(db, widget_id)
        if not source:
            raise HTTPException(404, "Dashboard widget not found")
        return widget_snapshot(db, source["manifest"])

    @app.get("/api/v1/settings")
    def settings(db: Database = Depends(get_db)):
        return present_settings(db.get_settings())

    @app.get("/api/v1/map/preferences")
    def map_preferences(db: Database = Depends(get_db)):
        return {"home": db.get_settings().get("home_location")}

    @app.put("/api/v1/map/home")
    async def update_home_location(payload: HomeLocationUpdate, db: Database = Depends(get_db)):
        try:
            resolved = await geocode_home_address(payload.address)
        except HomeAddressError as exc:
            raise HTTPException(422, str(exc)) from exc
        home = db.set_home_location(resolved)
        await events.publish({"type": "map.home_updated", "home": home})
        return {"home": home}

    @app.delete("/api/v1/map/home")
    async def clear_home_location(db: Database = Depends(get_db)):
        db.set_home_location(None)
        await events.publish({"type": "map.home_updated", "home": None})
        return {"home": None}

    @app.get("/api/v1/platforms")
    def platform_profiles(db: Database = Depends(get_db)):
        return present_profiles(db.list_platform_profiles(), platform_catalog.load()[0])

    @app.get("/api/v1/platform-catalog")
    def platform_catalog_entries(
        q: str = Query(default="", max_length=120),
        country: str = Query(default="", max_length=20),
        region: str = Query(default="", max_length=20),
        industry: str = Query(default="", max_length=80),
        db: Database = Depends(get_db),
    ):
        result = platform_catalog.search(
            query=q, country=country, region=region, industry=industry,
        )
        states = {item["platform"]: item for item in db.list_platform_profiles(tracked_only=False)}
        result["platforms"] = [
            {**item, "tracked": bool(states.get(item["id"], {}).get("tracked", False))}
            for item in result["platforms"]
        ]
        return result

    @app.post("/api/v1/platform-catalog/custom", status_code=201)
    def add_custom_platform(payload: PlatformCatalogCreate):
        try:
            return platform_catalog.add_custom(payload.model_dump(mode="json"))
        except ValueError as exc:
            status = 409 if "already exists" in str(exc) else 422
            raise HTTPException(status, str(exc)) from exc

    @app.post("/api/v1/platforms/{platform}", status_code=201)
    async def track_platform_profile(platform: str, db: Database = Depends(get_db)):
        definition = platform_catalog.get(platform)
        if not definition:
            raise HTTPException(404, "Platform is not in the catalog")
        result = present_profile(db.track_platform_profile(platform), definition)
        await events.publish({"type": "platform.profile.tracked", "profile": result})
        return result

    @app.delete("/api/v1/platforms/{platform}")
    async def untrack_platform_profile(platform: str, db: Database = Depends(get_db)):
        definition = platform_catalog.get(platform)
        if not definition:
            raise HTTPException(404, "Platform is not in the catalog")
        try:
            result = present_profile(db.untrack_platform_profile(platform), definition)
        except ValueError as exc:
            raise HTTPException(404, str(exc)) from exc
        await events.publish({"type": "platform.profile.untracked", "profile": result})
        return result

    @app.put("/api/v1/platforms/{platform}")
    async def update_platform_profile(
        platform: str, payload: PlatformProfileUpdate,
        db: Database = Depends(get_db),
    ):
        definition = platform_catalog.get(platform)
        if not definition:
            raise HTTPException(404, "Platform is not in the catalog")
        try:
            validate_visibility(definition, payload.visibility)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        try:
            value = db.update_platform_profile(
                platform=platform, visibility=payload.visibility,
                reminder_days=payload.reminder_days,
                confirmation_source=payload.confirmation_source,
            )
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        result = present_profile(value, definition)
        await events.publish({"type": "platform.profile.updated", "profile": result})
        return result

    @app.put("/api/v1/settings")
    async def update_settings(payload: SettingsUpdate, db: Database = Depends(get_db)):
        current = db.get_settings()
        home_changed = False
        resolved_home = current.get("home_location")
        if "home_address" in payload.model_fields_set and payload.home_address is not None:
            current_address = str((current.get("home_location") or {}).get("address") or "")
            if payload.home_address != current_address:
                home_changed = True
                if payload.home_address:
                    try:
                        resolved_home = await geocode_home_address(payload.home_address)
                    except HomeAddressError as exc:
                        raise HTTPException(422, str(exc)) from exc
                else:
                    resolved_home = None
        data = payload.model_dump(mode="json", exclude={
            "default_schedule", "codex_connected", "codex_model", "lan_url", "home_address"
        })
        result = db.update_settings(data)
        if home_changed:
            db.set_home_location(resolved_home)
            result = db.get_settings()
            await events.publish({"type": "map.home_updated", "home": resolved_home})
        await events.publish({"type": "settings.updated", "settings": result})
        return present_settings(result)

    def present_agent_instructions(overrides: dict[str, str] | None = None) -> dict[str, Any]:
        settings_value = database.get_settings()
        return instruction_snapshot(
            settings_value.get("agent_instruction_overrides", {}) if overrides is None else overrides,
            revision=int(settings_value.get("agent_instructions_revision") or 1),
            updated_at=settings_value.get("agent_instructions_updated_at"),
        )

    @app.get("/api/v1/settings/agent-instructions")
    def get_agent_instructions():
        return present_agent_instructions()

    @app.post("/api/v1/settings/agent-instructions/preview")
    def preview_agent_instructions(payload: AgentInstructionsUpdate):
        settings_value = database.get_settings()
        try:
            candidate = apply_instruction_patch(
                settings_value.get("agent_instruction_overrides", {}),
                payload.model_dump(exclude_unset=True),
            )
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        result = present_agent_instructions(candidate)
        result["preview_only"] = True
        return result

    @app.put("/api/v1/settings/agent-instructions")
    async def update_agent_instructions(payload: AgentInstructionsUpdate):
        settings_value = database.get_settings()
        try:
            candidate = apply_instruction_patch(
                settings_value.get("agent_instruction_overrides", {}),
                payload.model_dump(exclude_unset=True),
            )
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        updated = database.set_agent_instruction_overrides(candidate)
        result = instruction_snapshot(
            updated.get("agent_instruction_overrides", {}),
            revision=int(updated.get("agent_instructions_revision") or 1),
            updated_at=updated.get("agent_instructions_updated_at"),
        )
        await events.publish({"type": "agent_instructions.updated", "revision": result["revision"]})
        return result

    @app.get("/api/v1/ai/connections")
    def ai_connection_status():
        return connection_snapshot()

    @app.put("/api/v1/ai/selection")
    async def select_ai_connection(payload: AISelectionUpdate):
        if payload.openai_options is not None and payload.connection != "codex":
            raise HTTPException(422, "OpenAI options apply only to Codex")
        if payload.connection == "none":
            database.set_ai_selection("none", None)
        else:
            connection = connections.get(payload.connection)
            status = connection.status()
            if not status.ready:
                raise HTTPException(409, status.required_action or status.detail)
            if payload.connection == "openrouter":
                if not payload.model:
                    raise HTTPException(422, "Choose a compatible OpenRouter model")
                try:
                    models = connection.list_models(browsing=database.get_settings().get("chat_web_browsing", False))
                except AIConnectionError as exc:
                    raise HTTPException(409, exc.detail) from exc
                if payload.model not in {item.id for item in models}:
                    raise HTTPException(422, "The selected OpenRouter model is unavailable or incompatible")
            if payload.openai_options is not None and payload.connection != "codex":
                raise HTTPException(422, "OpenAI options apply only to Codex")
            options = payload.openai_options.model_dump(exclude_unset=True) if payload.openai_options is not None else None
            if payload.connection == "codex":
                effort = (options or {}).get("reasoning_effort", database.get_settings().get("openai_reasoning_effort"))
                if effort and not payload.model:
                    raise HTTPException(422, "Choose an explicit model for a reasoning override, or clear the override")
                if payload.model:
                    try:
                        catalog = await asyncio.to_thread(connection.list_models)
                    except AIConnectionError as exc:
                        raise HTTPException(409, exc.detail) from exc
                    chosen_model = next((item for item in catalog if item.id == payload.model), None)
                    if chosen_model is None or (effort and effort not in chosen_model.reasoning_efforts):
                        raise HTTPException(422, "The selected OpenAI model or reasoning effort is unavailable")
            database.set_ai_selection(payload.connection, payload.model, openai_options=options)
        await events.publish({"type": "ai.selection.updated", "selection": connection_snapshot()["selection"]})
        return connection_snapshot()

    @app.post("/api/v1/ai/connections/{connection_id}/test")
    def test_ai_connection(connection_id: str):
        try:
            status = connections.get(connection_id).status()
        except AIConnectionError as exc:
            raise HTTPException(404, exc.detail) from exc
        return status.model_dump(mode="json")

    @app.post("/api/v1/ai/connections/{connection_id}/auth/start")
    async def start_ai_connection_login(connection_id: str, request: Request):
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "AI sign-in can be started only on the host computer")
        try:
            current = connections.get(connection_id).status()
            if (database.get_settings().get("ai_connection") == connection_id
                    and not current.ready):
                database.set_ai_selection("none", None)
                await events.publish({"type": "ai.selection.updated", "selection": {"connection": None, "model": None}})
            return login_manager.start(connection_id)
        except AIConnectionError as exc:
            raise HTTPException(409, exc.detail) from exc

    @app.get("/api/v1/ai/connections/{connection_id}/auth/status")
    def ai_connection_login_status(connection_id: str, request: Request):
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "AI sign-in status is available only on the host computer")
        try:
            return login_manager.status(connection_id)
        except AIConnectionError as exc:
            raise HTTPException(404, exc.detail) from exc

    @app.get("/api/v1/ai/connections/codex/models")
    def codex_models(request: Request):
        from .ai_connections.codex_catalog import runtime_info
        connection = connections.get("codex")
        saved = database.get_settings()
        result = {"items": [], "state": "ready", "error": None,
                  "preferences": {"model": saved.get("openai_model"), "reasoning_effort": saved.get("openai_reasoning_effort")},
                  "runtime": runtime_info(getattr(connection, "executable", None),
                      host_local=is_loopback(request.client.host if request.client else None))}
        try:
            result["items"] = [item.model_dump(mode="json") for item in connection.list_models()]
        except AIConnectionError as exc:
            result.update(state="unavailable", error={"category": exc.category.value, "message": exc.detail})
        return result

    @app.get("/api/v1/ai/connections/openrouter/models")
    def openrouter_models(browsing: bool = Query(False)):
        try:
            values = connections.get("openrouter").list_models(browsing=browsing)
        except AIConnectionError as exc:
            raise HTTPException(409, exc.detail) from exc
        return {"items": [item.model_dump(mode="json") for item in values], "count": len(values)}

    @app.put("/api/v1/ai/connections/openrouter/credential")
    def set_openrouter_credential(payload: OpenRouterCredentialUpdate, request: Request):
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "OpenRouter credentials can be changed only on the host computer")
        connection = connections.get("openrouter")
        if not isinstance(connection, OpenRouterConnection):
            raise HTTPException(503, "OpenRouter credential management is unavailable")
        try:
            connection.set_credential(payload.api_key)
        except AIConnectionError as exc:
            raise HTTPException(409, exc.detail) from exc
        return connection.status().model_dump(mode="json")

    @app.delete("/api/v1/ai/connections/openrouter/credential")
    async def delete_openrouter_credential(request: Request):
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "OpenRouter credentials can be changed only on the host computer")
        connection = connections.get("openrouter")
        if not isinstance(connection, OpenRouterConnection):
            raise HTTPException(503, "OpenRouter credential management is unavailable")
        try:
            connection.delete_credential()
        except AIConnectionError as exc:
            raise HTTPException(409, exc.detail) from exc
        if database.get_settings().get("ai_connection") == "openrouter":
            database.set_ai_selection("none", None)
        await events.publish({"type": "ai.selection.updated", "selection": connection_snapshot()["selection"]})
        return connection_snapshot()

    @app.post("/api/v1/onboarding/complete")
    async def complete_onboarding():
        value = database.complete_onboarding()
        await events.publish({"type": "onboarding.completed"})
        return {"onboarding": {"completed": True, "completed_at": value["onboarding_completed_at"]}}

    @app.post("/api/v1/settings/codex/connect")
    def connect_codex():
        value = connections.get("codex").status()
        return {"status": "connected" if value.ready else "action_required",
                "message": value.detail if value.ready else "Run `codex login` on this computer, then try again."}

    @app.get("/api/v1/chat/providers")
    def chat_providers():
        return {"items": connection_snapshot()["connections"]}

    @app.get("/api/v1/chat/commands")
    def chat_commands():
        items = list_commands()
        return {"items": items, "count": len(items)}

    @app.get("/api/v1/interview-prep/options")
    def interview_prep_option_list():
        return interview_prep_options()

    @app.get("/api/v1/intro-letter/options")
    def intro_letter_option_list():
        return intro_letter_options()

    @app.get("/api/v1/company-discovery/options")
    def company_discovery_option_list():
        return company_discovery_options()

    @app.post("/api/v1/company-discovery")
    async def discover_companies(payload: CompanyDiscoveryRequest, request: Request):
        return await discover_companies_for_request(payload, request=request)

    @app.get("/api/v1/chat/threads")
    def chat_threads(request: Request, role_id: int | None = Query(default=None, ge=1),
                     company_id: int | None = Query(default=None, ge=1),
                     command_id: str | None = Query(default=None, max_length=80),
                     query: str | None = Query(default=None, max_length=120),
                     limit: int | None = Query(default=None, ge=1, le=200)):
        local = is_loopback(request.client.host if request.client else None)
        items = [present_chat_thread(item) for item in database.list_chat_threads(
            role_id=role_id, company_id=company_id, command_id=command_id,
            query=query, limit=limit,
        )
                 if local or (item.get("context_type") != "document" and not item.get("private_local"))]
        return {"items": items, "count": len(items)}

    @app.post("/api/v1/chat/threads", status_code=201)
    def create_chat_thread(payload: ChatThreadCreate, request: Request):
        context_type = payload.context.type if payload.context else None
        context_id = payload.context.id if payload.context else None
        bound_value = validate_chat_binding(payload.command_id, context_type, context_id)
        if context_type == "document":
            require_loopback(request)
        title = payload.title
        if title == "New chat" and bound_value:
            title = (f"Chat about {bound_value.get('title') or 'this role'}" if context_type == "job"
                     else f"Edit {bound_value.get('label') or 'career document'}")[:120]
        elif title == "New chat" and payload.command_id == "create_widget":
            title = "Create dashboard widget"
        return present_chat_thread(database.create_chat_thread(
            title, command_id=payload.command_id,
            context_type=context_type, context_id=context_id, request_id=payload.request_id,
        ))

    @app.get("/api/v1/chat/threads/{thread_id}")
    def get_chat_thread(thread_id: int, request: Request):
        sync_terminal_chat_runs(thread_id)
        value = database.get_chat_thread(thread_id)
        if not value:
            raise HTTPException(404, "Chat not found")
        require_document_chat(request, value)
        return present_chat_thread(value)

    @app.patch("/api/v1/chat/threads/{thread_id}")
    def rename_chat_thread(thread_id: int, payload: ChatThreadUpdate, request: Request):
        current = database.get_chat_thread(thread_id)
        if not current:
            raise HTTPException(404, "Chat not found")
        require_document_chat(request, current)
        supplied = payload.model_fields_set
        command_id = payload.command_id if "command_id" in supplied else current.get("command_id")
        if "context" in supplied:
            context_type = payload.context.type if payload.context else None
            context_id = payload.context.id if payload.context else None
            if payload.context is None and "command_id" not in supplied:
                active = get_command(command_id)
                if active and current.get("context_type") in active["supported_context_types"]:
                    command_id = None
        else:
            context_type = current.get("context_type")
            context_id = current.get("context_id")
        validate_chat_binding(command_id, context_type, context_id)
        changes: dict[str, Any] = {}
        if "title" in supplied:
            changes["title"] = payload.title
        if "command_id" in supplied or command_id != current.get("command_id"):
            changes["command_id"] = command_id
        if "context" in supplied:
            changes.update({"context_type": context_type, "context_id": context_id})
        value = database.update_chat_thread(thread_id, **changes)
        return present_chat_thread(value or current)

    @app.delete("/api/v1/chat/threads/{thread_id}")
    async def delete_chat_thread(thread_id: int, request: Request):
        current = database.get_chat_thread(thread_id)
        if not current:
            raise HTTPException(404, "Chat not found")
        require_document_chat(request, current)
        scoped_attachments = database.list_chat_attachments(thread_id)
        database.delete_chat_thread(thread_id)
        for attachment in scoped_attachments:
            stored = attachment.get("stored_filename")
            if stored:
                chat_attachments._path(str(stored)).unlink(missing_ok=True)
        await events.publish({"type": "chat.thread.deleted", "thread_id": thread_id})
        return {"deleted": True, "thread_id": thread_id}

    async def _process_chat_message(
        thread_id: int, payload: ChatMessageCreate, request: Request,
        *, precreated_user_message: dict[str, Any] | None = None,
        cancel_event: Event | None = None,
    ) -> dict[str, Any]:
        thread = database.get_chat_thread(thread_id)
        if not thread:
            raise HTTPException(404, "Chat not found")
        require_document_chat(request, thread)
        command = get_command(thread.get("command_id"))
        if payload.start_skill and (not command or command.get("kind") != "skill"):
            raise HTTPException(422, "start_skill requires an active skill command")
        selected_skill_prompt = None
        if payload.interview_prep is not None:
            if not command or command["id"] != "interview_prep":
                raise HTTPException(409, "Activate /interview_prep before submitting its questionnaire")
            selected_skill_prompt = require_open_skill_prompt(
                thread, command["id"], payload.skill_prompt_message_id,
            )
        elif payload.intro_letter is not None:
            if not command or command["id"] != "create_intro_letter":
                raise HTTPException(409, "Activate /create_intro_letter before submitting its questionnaire")
            selected_skill_prompt = require_open_skill_prompt(
                thread, command["id"], payload.skill_prompt_message_id,
            )
        elif payload.company_discovery is not None:
            if not command or command["id"] != "discover_companies":
                raise HTTPException(409, "Activate /discover_companies before submitting its questionnaire")
            selected_skill_prompt = require_open_skill_prompt(
                thread, command["id"], payload.skill_prompt_message_id,
            )
        if thread.get("context_type") == "document":
            selected = "codex" if legacy_chat_agent is not None else database.get_settings().get("ai_connection")
            if selected and payload.document_consent_connection == selected:
                pass
            else:
                label = selected or "selected AI"
                raise HTTPException(
                    409,
                    f"Confirm that this document may be sent to the configured {label} connection for this chat",
                )
        user_message = precreated_user_message or database.add_chat_message(
            thread_id, "user", payload.content,
            {"attachment_ids": payload.attachment_ids} if payload.attachment_ids else None,
        )
        first_message = len(thread.get("messages", [])) == (1 if precreated_user_message else 0)
        if first_message and thread.get("title") == "New chat":
            database.rename_chat_thread(thread_id, payload.content[:60])
        settings_value = database.get_settings()
        companies_value = [present_company(item) for item in database.list_companies(False)]
        if command and command["id"] == "daily_recap":
            try:
                result = await recaps.in_chat(thread_id, int(user_message["id"]))
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc
            await events.publish({"type": "chat.message", "thread_id": thread_id, "message": result["assistant_message"]})
            return {**result, "user_message": user_message, "thread": present_chat_thread(result["thread"])}
        context = {
            "criteria": settings_value["criteria"],
            "default_schedule": settings_value["default_schedule_kind"],
            "existing_monitors": [chat_monitor_context(item) for item in companies_value],
        }
        if payload.attachment_ids:
            require_loopback(request)
            selected_for_consent = "codex" if legacy_chat_agent is not None else settings_value.get("ai_connection")
            if not selected_for_consent or payload.document_consent_connection != selected_for_consent:
                raise HTTPException(
                    409,
                    f"Confirm that the selected attachments may be sent to the configured {selected_for_consent or 'AI'} connection",
                )
            try:
                context["untrusted_chat_attachments"] = chat_attachments.context(
                    thread_id, payload.attachment_ids,
                )
            except DocumentError as exc:
                raise HTTPException(422, str(exc)) from exc
            database.mark_chat_attachments_used(payload.attachment_ids)
        if thread.get("context_type") == "job" and thread.get("context_id") is not None:
            is_skill = bool(command and command.get("kind") == "skill")
            if first_message or is_skill:
                activity = database.record_job_chat_activity(
                    job_id=int(thread["context_id"]), thread_id=thread_id,
                    message_id=int(user_message["id"]), command_id=command["id"] if command else None,
                    label=command["label"] if command else "Chat about this role",
                    detail=payload.content[:500],
                    icon_key=command.get("icon_key", "chat") if command else "chat",
                )
                if activity:
                    await events.publish({"type": "job.activity_created",
                                          "job_id": int(thread["context_id"]),
                                          "activity": present_activity(activity)})
        if command:
            context["active_command"] = {
                "id": command["id"], "slash_name": command["slash_name"],
                "managed_instructions": command["managed_instructions"],
            }
            if command["id"] == "create_widget":
                context["current_widget_draft"] = latest_thread_draft(database, thread_id)
        if thread.get("context_type") == "job" and thread.get("context_id") is not None:
            job_value = validate_chat_binding(
                thread.get("command_id"), thread.get("context_type"), thread.get("context_id")
            )
            context["untrusted_attached_job"] = resolved_context(
                "job", int(thread["context_id"]), job_value
            )["job"]
        elif thread.get("context_type") == "document" and thread.get("context_id") is not None:
            source_id = int(thread["context_id"])
            try:
                source = documents.read(source_id, max_chars=30_000)
            except KeyError as exc:
                raise HTTPException(409, "The attached document was deleted. Start a new document chat") from exc
            attached: dict[str, Any] = {
                "id": source_id,
                "kind": source["kind"],
                "label": source["label"],
                "layout_key": source.get("layout_key") or (
                    "creative" if source.get("template_key") == "creative_resume" else
                    "intro_letter" if source["kind"] == "intro_letter" else "corporate"
                ),
                "extraction_status": source["extraction_status"],
                "text": source.get("text", ""),
                "text_truncated": source.get("text_truncated", False),
            }
            if source.get("is_default_template"):
                attached["built_in_example_style_reference"] = documents.read(
                    source_id, variant="example", max_chars=30_000,
                ).get("text", "")
            context["untrusted_attached_document"] = attached
            draft_id = latest_document_draft_id(thread)
            if draft_id:
                try:
                    context["current_document_draft"] = documents.read_draft(draft_id)["content"]
                except KeyError:
                    pass
        history = [{"role": item["role"], "content": item["content"]}
                   for item in thread.get("messages", []) if item["id"] != user_message["id"]]
        selected_connection = settings_value.get("ai_connection")
        selected_model = settings_value.get("ai_model")
        if command and command["id"] == "discover_companies":
            prior_discovery = next((
                (item.get("metadata") or {}).get("company_discovery_result")
                for item in reversed(thread.get("messages", []))
                if (item.get("metadata") or {}).get("company_discovery_result")
            ), None)
            if payload.company_discovery is None and (payload.start_skill or prior_discovery is None):
                assistant = database.add_chat_message(
                    thread_id, "assistant",
                    "Choose an optional resume, or continue with your saved search profile.",
                    {"provider": selected_connection, "model": selected_model,
                     "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                     "suggestions": [], "actions": [],
                     "company_discovery_options": company_discovery_options(),
                     "fresh_skill_invocation": bool(payload.start_skill),
                     "command_used": public_command(command["id"])},
                )
                await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
                return {"user_message": user_message, "assistant_message": assistant,
                        "thread": present_chat_thread(thread)}
            discovery_request = payload.company_discovery
            if discovery_request is None:
                discovery_request = CompanyDiscoveryRequest(
                    refinement=payload.content,
                    prior_signals=(prior_discovery or {}).get("signals"),
                )
            elif discovery_request.refinement is None:
                discovery_request = discovery_request.model_copy(update={"refinement": payload.content})
            result = await discover_companies_for_request(discovery_request, request=request)
            submission = None
            if selected_skill_prompt is not None:
                submission = {
                    "command_id": command["id"],
                    "prompt_message_id": int(selected_skill_prompt["id"]),
                    "selection": resume_selection(discovery_request.resume_document_id),
                }
            assistant = database.add_chat_message(
                thread_id, "assistant", render_company_discovery(result),
                {"provider": result.get("provider"), "model": result.get("model"),
                 "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                 "suggestions": [], "actions": [], "company_discovery_result": result,
                 "skill_submission": submission,
                 "command_used": public_command(command["id"])},
            )
            await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
            return {"user_message": user_message, "assistant_message": assistant,
                    "thread": present_chat_thread(thread)}
        if command and command["id"] == "interview_prep" and payload.interview_prep is None:
            has_report = any((item.get("metadata") or {}).get("interview_prep_result")
                             for item in thread.get("messages", []))
            if payload.start_skill or not has_report:
                assistant = database.add_chat_message(
                    thread_id, "assistant",
                    "Choose the interview-prep sections you want, then optionally select a resume for coaching cues.",
                    {"provider": selected_connection, "model": selected_model,
                     "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                     "suggestions": [], "actions": [],
                     "interview_prep_options": interview_prep_options(),
                     "command_used": public_command(command["id"])},
                )
                await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
                return {"user_message": user_message, "assistant_message": assistant,
                        "thread": present_chat_thread(thread)}
        if command and command["id"] == "interview_prep" and payload.interview_prep is not None:
            result = await interview_prep_for_job(
                int(thread["context_id"]), payload.interview_prep, request=request,
            )
            assistant = database.add_chat_message(
                thread_id, "assistant", render_interview_prep(result),
                {"provider": result.get("provider"), "model": result.get("model"),
                 "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                 "suggestions": [], "actions": [], "interview_prep_result": result,
                 "skill_submission": {
                     "command_id": command["id"],
                     "prompt_message_id": int(selected_skill_prompt["id"]),
                     "selection": {
                         "sections": list(payload.interview_prep.sections),
                         "question_count": payload.interview_prep.question_count,
                         **resume_selection(payload.interview_prep.resume_document_id),
                     },
                 },
                 "command_used": public_command(command["id"])},
            )
            await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
            return {"user_message": user_message, "assistant_message": assistant,
                    "thread": present_chat_thread(thread)}
        if command and command["id"] == "create_intro_letter":
            current_draft_id = latest_document_draft_id(thread)
            if payload.intro_letter is None and (payload.start_skill or current_draft_id is None):
                assistant = database.add_chat_message(
                    thread_id, "assistant",
                    "Choose an optional resume, or continue without one for a role-focused template with placeholders.",
                    {"provider": selected_connection, "model": selected_model,
                     "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                     "suggestions": [], "actions": [],
                     "intro_letter_options": intro_letter_options(),
                     "fresh_skill_invocation": bool(payload.start_skill),
                     "command_used": public_command(command["id"])},
                )
                await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
                return {"user_message": user_message, "assistant_message": assistant,
                        "thread": present_chat_thread(thread)}
            current_draft_record = None
            if current_draft_id is not None:
                try:
                    current_draft_record = documents.read_draft(current_draft_id)
                except KeyError:
                    current_draft_id = None
            if selected_skill_prompt and (selected_skill_prompt.get("metadata") or {}).get(
                "fresh_skill_invocation"
            ):
                current_draft_id = None
                current_draft_record = None
            intro_request = payload.intro_letter or IntroLetterRequest(follow_up=payload.content)
            result = await intro_letter_for_job(
                int(thread["context_id"]), intro_request, request=request,
                current_draft=current_draft_record.get("content") if current_draft_record else None,
                draft_id=current_draft_id,
                source_document_id=(current_draft_record or {}).get("source_document_id"),
            )
            assistant = database.add_chat_message(
                thread_id, "assistant", render_intro_letter(result),
                {"provider": result.get("provider"), "model": result.get("model"),
                 "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                 "suggestions": [], "actions": [], "document_draft": result["draft"],
                 "intro_letter_result": {key: value for key, value in result.items() if key != "draft"},
                 "skill_submission": ({
                     "command_id": command["id"],
                     "prompt_message_id": int(selected_skill_prompt["id"]),
                     "selection": resume_selection(payload.intro_letter.resume_document_id),
                 } if payload.intro_letter is not None else None),
                 "command_used": public_command(command["id"])},
            )
            await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
            return {"user_message": user_message, "assistant_message": assistant,
                    "thread": present_chat_thread(thread)}
        if command and command["id"] == "find_recruiters":
            search = await recruiter_search_for_job(int(thread["context_id"]))
            assistant = database.add_chat_message(
                thread_id, "assistant", recruiter_reply(search),
                {"provider": search.get("provider"), "model": selected_model,
                 "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
                 "suggestions": [], "actions": [], "recruiter_search": search,
                 "command_used": public_command(command["id"])},
            )
            completed_thread = database.update_chat_thread(thread_id, command_id=None)
            await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
            return {"user_message": user_message, "assistant_message": assistant,
                    "thread": present_chat_thread(completed_thread or thread)}
        if legacy_chat_agent is not None:
            selected_connection = "codex"
        library_sources = []
        event_loop = asyncio.get_running_loop()
        active_turn = database.get_active_chat_turn(thread_id)
        activity_turn_id = active_turn["id"] if active_turn else None
        last_activity = [None, 0.0]
        file_tools = (ArtifactTools(artifacts, thread_id, activity_turn_id,
                       f"chat-{user_message['id']}", can_read=False)
                      if is_loopback(request.client.host if request.client else None) else None)


        def record_activity(stage):
            if activity_turn_id is None:
                return
            def update():
                now = event_loop.time()
                if last_activity[0] == stage and now - last_activity[1] < 1:
                    return
                turn = database.update_running_chat_stage(activity_turn_id, stage)
                if turn:
                    last_activity[:] = [stage, now]
                    event_loop.create_task(publish_turn(turn))
            try:
                on_loop = asyncio.get_running_loop() is event_loop
            except RuntimeError:
                on_loop = False
            if on_loop:
                update()
            else:
                event_loop.call_soon_threadsafe(update)

        async def retrieve_chat_answer():
            return await retrieve_answer(library, thread_id, selected_connection, context,
                invoke_chat_provider, cancel_event, jobs=chat_jobs, activity=record_activity,
                allow_library=local_library)

        try:
            async def invoke_chat_provider():
                record_activity("contacting_provider" if selected_connection == "codex" and legacy_chat_agent is None
                                else "waiting_provider")
                if context.get("untrusted_chat_attachments") or context.get("untrusted_attached_document"):
                    library.mark_shared(thread_id, selected_connection)
                if legacy_chat_agent is not None:
                    answer = await asyncio.to_thread(
                        legacy_chat_agent.run, provider="codex", model=None,
                        browsing=settings_value.get("chat_web_browsing", True), message=payload.content,
                        history=history, context=context,
                        instructions=settings_value.get("agent_instruction_overrides", {}),
                    )
                else:
                    if not selected_connection or selected_connection == "none":
                        raise AIConnectionError(
                            ConnectionErrorCategory.CONFIGURATION,
                            "Choose an AI connection before using JobHound Chat",
                        )
                    prompt = LocalAgentProvider._prompt(
                        payload.content, history, context, settings_value.get("chat_web_browsing", True),
                        settings_value.get("agent_instruction_overrides", {}))
                    if file_tools is not None:
                        prompt += "\n\n" + FILE_GUIDANCE
                        file_tools.can_read = bool(library.access(thread_id, selected_connection)['allowed'])
                        file_items = artifacts.list(thread_id)['items'] if file_tools.can_read else []
                        if file_items:
                            prompt += "\nCurrent chat files (untrusted data): " + json.dumps(file_items)
                            # All file content enters prompts only after the named-provider consent gate below.
                            sources = []
                            for item in file_items[:5]:
                                source = artifacts.read(thread_id, item['artifact_id'], item['revision'], content=True)
                                if len(json.dumps(source)) <= 12000:
                                    sources.append(source)
                            prompt += "\nUntrusted file sources: " + json.dumps(sources)
                            library.mark_shared(thread_id, selected_connection)
                    answer_schema = (
                        widget_agent_provider_schema() if command and command["id"] == "create_widget" else
                        DocumentAgentAnswer if command and command["id"] == "edit_document" else AgentAnswer
                    )
                    answer = await asyncio.to_thread(
                        connections.run_structured, selected_connection, prompt, answer_schema,
                        model=selected_model, browsing=settings_value.get("chat_web_browsing", True),
                        cancel_event=cancel_event, activity=record_activity, tool_context=file_tools,
                    )
                if command and command["id"] == "create_widget":
                    answer = WidgetAgentAnswer.model_validate(answer).model_dump(mode="json")
                return answer
            local_library = is_loopback(request.client.host if request.client else None)
            access = library.access(thread_id, selected_connection) if local_library and selected_connection else None
            if access and (access['history_requires_consent'] or (artifacts.list(thread_id)['items'] and not access['allowed'])):
                if not await library_consent(library, thread_id, selected_connection, cancel_event, history=True):
                    answer = library_declined(history=True)
                else:
                    library.mark_used(thread_id, selected_connection)
                    answer, library_sources = await retrieve_chat_answer()
            elif selected_connection and (not command or command['id'] == 'edit_document'):
                answer, library_sources = await retrieve_chat_answer()
            else:
                answer = await invoke_chat_provider()
        except ProviderCancelled:
            raise asyncio.CancelledError()
        except Exception as exc:
            assistant = database.add_chat_message(thread_id, "assistant", f"I couldn't reach the selected agent: {exc}",
                                                  {"error": True, "provider": selected_connection, "model": selected_model,
                                                   "artifacts": file_tools.results if file_tools else [],
                                                   "connection_error": {"category": exc.category.value, "diagnostics": exc.diagnostics} if isinstance(exc, AIConnectionError) else None})
            return {"user_message": user_message, "assistant_message": assistant,
                    "thread": present_chat_thread(thread)}
        if answer.get('artifact_requests'):
            if file_tools is None:
                answer['reply'] += "\n\nLocal file creation is available only on the host computer."
            else:
                for proposal in answer['artifact_requests'][:5]:
                    try:
                        await asyncio.to_thread(file_tools.create, ArtifactProposal.model_validate(proposal), cancel_event or Event(), record_activity)
                    except ProviderCancelled:
                        raise asyncio.CancelledError()
                    except (ValueError, KeyError) as exc:
                        answer['reply'] += f"\n\nFile creation needs attention: {exc}"
        if file_tools and file_tools.results:
            library.mark_shared(thread_id, selected_connection)
            if any(item['state'] != 'complete' for item in file_tools.results):
                answer['reply'] += "\n\nSome files are not ready. Check each file card for its actual status."
        rendered_suggestions = []
        for suggestion in answer.get("suggestions", []):
            item = dict(suggestion)
            if suggestion.get("create_now") and settings_value.get("chat_auto_create_monitors", True):
                try:
                    company_value, run_value = create_monitor_from_suggestion(suggestion["name"], suggestion["careers_url"], thread_id)
                    item.update({"created": True, "company_id": company_value["id"], "run": run_value})
                except Exception as exc:
                    item.update({"created": False, "error": str(exc)})
            rendered_suggestions.append(item)
        rendered_actions = []
        for requested in answer.get("actions", []):
            item = dict(requested)
            company = database.get_company(int(requested["company_id"]))
            if not company:
                item.update({"queued": False, "error": "Monitor not found"})
            elif requested.get("execute_now") and settings_value.get("chat_auto_create_monitors", True):
                try:
                    effective_action, run_value = queue_chat_monitor_action(
                        thread_id, int(requested["company_id"]), requested["action"])
                    item.update({"queued": True, "effective_action": effective_action, "run": run_value,
                                 "company_name": company["name"]})
                except Exception as exc:
                    item.update({"queued": False, "error": str(exc), "company_name": company["name"]})
            else:
                item.update({"queued": False, "company_name": company["name"]})
            rendered_actions.append(item)
        draft_result = None
        widget_draft_result = None
        if command and command["id"] == "edit_document" and answer.get("draft"):
            try:
                draft_result = documents.create_draft(
                    answer["draft"], source_document_id=int(thread["context_id"]),
                    draft_id=latest_document_draft_id(thread),
                )
            except (DocumentError, ValueError) as exc:
                answer["reply"] += f"\n\nI could not format that revision yet: {exc}"
        if command and command["id"] == "create_widget":
            try:
                current_widget = latest_thread_draft(database, thread_id)
                widget_draft_result = save_widget_draft(
                    database, manifest=answer["manifest"], javascript=answer["javascript"],
                    css=answer.get("css", ""), thread_id=thread_id,
                    draft_id=current_widget["id"] if current_widget else None,
                    expected_revision=current_widget["revision"] if current_widget else None,
                )
            except (KeyError, RuntimeError, ValueError) as exc:
                answer["reply"] += f"\n\nI could not save that widget draft yet: {exc}"
        assistant = database.add_chat_message(
            thread_id, "assistant", answer["reply"],
            {"provider": selected_connection, "model": selected_model,
             "instruction_revision": int(settings_value.get("agent_instructions_revision") or 1),
             "suggestions": rendered_suggestions, "actions": rendered_actions,
             "sources": answer.get("sources", []),
             "library_sources": library_sources,
             "artifacts": file_tools.results if file_tools else [],
             "document_draft": draft_result,
             "widget_draft": widget_draft_result,
             "command_used": public_command(command["id"]) if command else None},
        )
        completed_thread = (
            database.update_chat_thread(thread_id, command_id=None)
            if command and not command.get("persistent") else thread
        )
        if thread.get("context_type") != "document":
            await events.publish({"type": "chat.message", "thread_id": thread_id, "message": assistant})
        return {"user_message": user_message, "assistant_message": assistant,
                "thread": present_chat_thread(completed_thread or thread)}

    @app.post("/api/v1/chat/threads/{thread_id}/messages", status_code=201)
    async def send_chat_message(thread_id: int, payload: ChatMessageCreate, request: Request):
        """Compatibility endpoint while bundled clients migrate to persisted turns."""
        return await _process_chat_message(thread_id, payload, request)

    def present_chat_turn(turn: dict[str, Any]) -> dict[str, Any]:
        result = present_progress(turn)
        thread = database.get_chat_thread(int(turn["thread_id"]))
        messages = {int(item["id"]): item for item in (thread or {}).get("messages", [])}
        result["user_message"] = messages.get(int(turn["user_message_id"])) if turn.get("user_message_id") else None
        result["assistant_message"] = messages.get(int(turn["assistant_message_id"])) if turn.get("assistant_message_id") else None
        return result

    async def publish_turn(turn: dict[str, Any]) -> None:
        await events.publish({"type": "chat.turn", "thread_id": turn["thread_id"],
                              "turn": present_chat_turn(turn)})

    async def run_chat_turn(turn_id: int, payload: ChatMessageCreate, request: Request,
                            user_message: dict[str, Any], cancel_event: Event) -> None:
        try:
            settings_value = database.get_settings()
            turn = database.update_chat_turn(
                turn_id, status="running", stage="preparing_context", progress=10,
                provider=settings_value.get("ai_connection") or ("codex" if legacy_chat_agent else None),
                model=settings_value.get("ai_model"),
                instruction_revision=int(settings_value.get("agent_instructions_revision") or 1),
                started_at=datetime.now(timezone.utc).isoformat(),
            )
            if turn:
                await publish_turn(turn)
            result = await _process_chat_message(
                int(turn["thread_id"]), payload, request, precreated_user_message=user_message,
                cancel_event=cancel_event,
            )
            current = database.get_chat_turn(turn_id)
            if not current or current.get("cancel_requested") or current.get("status") == "cancelled":
                return
            assistant = result.get("assistant_message") or {}
            failed = bool((assistant.get("metadata") or {}).get("error"))
            turn = database.update_chat_turn(
                turn_id, assistant_message_id=assistant.get("id"),
                status="failed" if failed else "complete", stage="failed" if failed else "complete",
                progress=100, error=assistant.get("content") if failed else None,
                finished_at=datetime.now(timezone.utc).isoformat(),
            )
            if turn:
                await publish_turn(turn)
        except asyncio.CancelledError:
            current = database.get_chat_turn(turn_id)
            if current and current["status"] in {"queued", "running"}:
                turn = database.update_chat_turn(
                    turn_id, status="cancelled", stage="cancelled", progress=100,
                    error="Cancelled by the user", cancel_requested=1,
                    finished_at=datetime.now(timezone.utc).isoformat(),
                )
                if turn:
                    await publish_turn(turn)
            raise
        except Exception as exc:
            turn = database.update_chat_turn(
                turn_id, status="failed", stage="failed", progress=100, error=str(exc),
                finished_at=datetime.now(timezone.utc).isoformat(),
            )
            if turn:
                await publish_turn(turn)
        finally:
            chat_turn_tasks.pop(turn_id, None)
            chat_turn_cancellations.pop(turn_id, None)

    @app.post("/api/v1/chat/threads/{thread_id}/turns", status_code=202)
    async def create_chat_turn(thread_id: int, payload: ChatMessageCreate, request: Request):
        thread = database.get_chat_thread(thread_id)
        if not thread:
            raise HTTPException(404, "Chat not found")
        require_document_chat(request, thread)
        request_id = payload.request_id or str(uuid.uuid4())
        try:
            turn, duplicate = database.create_chat_turn(
                thread_id, request_id, payload.model_dump(mode="json"),
            )
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        if duplicate:
            return {"turn": present_chat_turn(turn), "duplicate": True}
        user_message = database.add_chat_message(
            thread_id, "user", payload.content,
            {"attachment_ids": payload.attachment_ids, "turn_id": int(turn["id"])},
        )
        turn = database.update_chat_turn(int(turn["id"]), user_message_id=int(user_message["id"])) or turn
        cancel_event = Event()
        chat_turn_cancellations[int(turn["id"])] = cancel_event
        task = asyncio.create_task(run_chat_turn(int(turn["id"]), payload, request, user_message, cancel_event))
        chat_turn_tasks[int(turn["id"])] = task
        await publish_turn(turn)
        return {"turn": present_chat_turn(turn), "user_message": user_message, "duplicate": False}

    @app.get("/api/v1/chat/turns/{turn_id}")
    def get_chat_turn(turn_id: int, request: Request):
        turn = database.get_chat_turn(turn_id)
        if not turn:
            raise HTTPException(404, "Chat turn not found")
        require_document_chat(request, database.get_chat_thread(int(turn["thread_id"])))
        return present_chat_turn(turn)

    @app.post("/api/v1/chat/turns/{turn_id}/cancel")
    async def cancel_chat_turn(turn_id: int, request: Request):
        turn = database.get_chat_turn(turn_id)
        if not turn:
            raise HTTPException(404, "Chat turn not found")
        require_document_chat(request, database.get_chat_thread(int(turn["thread_id"])))
        if turn["status"] not in {"queued", "running"}:
            return present_chat_turn(turn)
        turn = database.update_chat_turn(
            turn_id, status="cancelled", stage="cancelled", progress=100,
            cancel_requested=1, error="Cancelled by the user",
            finished_at=datetime.now(timezone.utc).isoformat(),
        ) or turn
        task = chat_turn_tasks.get(turn_id)
        cancellation = chat_turn_cancellations.get(turn_id)
        if cancellation:
            cancellation.set()
        if task:
            task.cancel()
        await publish_turn(turn)
        return present_chat_turn(turn)

    @app.post("/api/v1/chat/turns/{turn_id}/retry", status_code=202)
    async def retry_chat_turn(turn_id: int, payload: ChatTurnRetry, request: Request):
        original = database.get_chat_turn(turn_id)
        if not original:
            raise HTTPException(404, "Chat turn not found")
        if original["status"] not in {"failed", "cancelled", "interrupted"}:
            raise HTTPException(409, "Only failed, cancelled, or interrupted turns can be retried")
        thread = database.get_chat_thread(int(original["thread_id"]))
        require_document_chat(request, thread)
        request_payload = dict(original["request"])
        request_payload["request_id"] = payload.request_id or str(uuid.uuid4())
        chat_payload = ChatMessageCreate.model_validate(request_payload)
        try:
            turn, duplicate = database.create_chat_turn(
                int(original["thread_id"]), str(chat_payload.request_id),
                chat_payload.model_dump(mode="json"), user_message_id=original.get("user_message_id"),
                retry_of_turn_id=turn_id,
            )
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        if not duplicate:
            user_message = next(
                item for item in (thread or {}).get("messages", [])
                if item["id"] == original.get("user_message_id")
            )
            cancel_event = Event()
            chat_turn_cancellations[int(turn["id"])] = cancel_event
            task = asyncio.create_task(run_chat_turn(
                int(turn["id"]), chat_payload, request, user_message, cancel_event,
            ))
            chat_turn_tasks[int(turn["id"])] = task
            await publish_turn(turn)
        return {"turn": present_chat_turn(turn), "duplicate": duplicate}

    @app.get("/api/v1/chat/turns/{turn_id}/events")
    async def chat_turn_events(turn_id: int, request: Request):
        turn = database.get_chat_turn(turn_id)
        if not turn:
            raise HTTPException(404, "Chat turn not found")
        require_document_chat(request, database.get_chat_thread(int(turn["thread_id"])))

        async def stream():
            queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=20)
            events.subscribers.add(queue)
            try:
                current = database.get_chat_turn(turn_id) or turn
                yield f"event: chat.turn\ndata: {json.dumps({'turn': present_chat_turn(current)}, default=str)}\n\n"
                if current["status"] not in {"queued", "running"}:
                    return
                while True:
                    item = await queue.get()
                    event_turn = item.get("turn") or {}
                    current_thread = database.get_chat_thread(int(turn["thread_id"]))
                    if current_thread and current_thread.get("private_local") and not is_loopback(request.client.host if request.client else None):
                        return
                    if item.get("type") == "chat.turn" and int(event_turn.get("id", -1)) == turn_id:
                        yield f"event: chat.turn\ndata: {json.dumps(item, default=str)}\n\n"
                        if event_turn.get("status") in {"complete", "failed", "cancelled", "interrupted"}:
                            return
            finally:
                events.subscribers.discard(queue)
        return StreamingResponse(stream(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @app.get("/api/v1/chat/threads/{thread_id}/attachments")
    def list_thread_attachments(thread_id: int, request: Request):
        require_loopback(request)
        if not database.get_chat_thread(thread_id):
            raise HTTPException(404, "Chat not found")
        items = [chat_attachments.public(item) for item in database.list_chat_attachments(thread_id)]
        return {"items": items, "count": len(items)}

    @app.post("/api/v1/chat/attachments", status_code=201)
    async def upload_chat_attachment(
        request: Request, thread_id: int = Form(..., ge=1), file: UploadFile = File(...),
    ):
        require_loopback(request)
        if not database.get_chat_thread(thread_id):
            raise HTTPException(404, "Chat not found")
        content = await file.read(MAX_FILE_BYTES + 1)
        try:
            attachment = chat_attachments.upload(
                thread_id=thread_id, original_filename=file.filename or "attachment", content=content,
            )
        except DocumentError as exc:
            raise HTTPException(422, str(exc)) from exc
        return {"attachment": attachment}

    @app.post("/api/v1/chat/attachments/from-document", status_code=201)
    def attach_library_document(payload: ChatDocumentAttachmentCreate, request: Request):
        require_loopback(request)
        if not database.get_chat_thread(payload.thread_id):
            raise HTTPException(404, "Chat not found")
        document = database.get_document(payload.document_id)
        if not document or document.get("archived_at"):
            raise HTTPException(404, "Active document not found")
        attachment = chat_attachments.from_document(thread_id=payload.thread_id, document=document)
        return {"attachment": attachment}

    @app.delete("/api/v1/chat/attachments/{attachment_id}")
    def remove_chat_attachment(attachment_id: int, request: Request):
        require_loopback(request)
        value = database.get_chat_attachment(attachment_id)
        if not value:
            raise HTTPException(404, "Chat attachment not found")
        if value.get("attached_at"):
            raise HTTPException(409, "An attachment already used by a turn remains part of chat history")
        chat_attachments.delete(attachment_id)
        return {"deleted": True, "attachment_id": attachment_id}

    @app.post("/api/v1/chat/suggestions", status_code=201)
    async def accept_chat_suggestion(payload: ChatSuggestionCreate):
        company_value, run_value = create_monitor_from_suggestion(payload.name, str(payload.careers_url), payload.thread_id)
        await events.publish({"type": "company.created", "company": company_value, "run": run_value})
        return {"company": present_company(company_value), "run": run_value}

    @app.post("/api/v1/chat/actions", status_code=202)
    async def accept_chat_monitor_action(payload: ChatMonitorActionCreate):
        effective_action, run_value = queue_chat_monitor_action(payload.thread_id, payload.company_id, payload.action)
        await events.publish({"type": "run.queued", "run": run_value})
        return {"action": effective_action, "run": run_value}

    @app.get("/api/v1/presets")
    def preset_catalog(q: str = "", collection_type: str = "", industry: str = "",
                       role_family: str = "", city: str = "", adapter: str = "",
                       refresh: bool = False):
        return presets.list_presets(
            query=q, collection_type=collection_type, industry=industry,
            role_family=role_family, city=city, adapter=adapter, force_refresh=refresh,
        )

    @app.get("/api/v1/presets/{preset_id}")
    def preset_detail(preset_id: str, limit: int = Query(default=50, ge=1, le=100),
                      cursor: str | None = None):
        try:
            return presets.get_preset_page(preset_id, limit=limit, cursor=cursor)
        except KeyError as exc:
            raise HTTPException(404, "Preset not found") from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/api/v1/preset-catalog/companies")
    def preset_catalog_companies(q: str = "", industry: str = "", specialty: str = "",
                                 tag: str = "", collection_id: str = "", adapter: str = "",
                                 verification: str = "", limit: int = Query(default=50, ge=1, le=100),
                                 cursor: str | None = None, refresh: bool = False):
        try:
            return presets.search_catalog_companies(
                query=q, industry=industry, specialty=specialty, tag=tag,
                collection_id=collection_id, adapter=adapter, verification=verification,
                limit=limit, cursor=cursor, force_refresh=refresh,
            )
        except PresetCatalogError as exc:
            raise HTTPException(503, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/v1/preset-catalog/selections/preview")
    def preview_preset_catalog_selection(payload: CatalogSelectionRequest):
        try:
            return presets.preview_catalog_selection(payload)
        except PresetCatalogError as exc:
            raise HTTPException(503, str(exc)) from exc
        except (KeyError, ValueError) as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/v1/preset-catalog/selections/install", status_code=202)
    async def install_preset_catalog_selection(payload: CatalogSelectionInstallRequest):
        require_local_scrapers()
        try:
            result = presets.install_catalog_selection(payload)
        except PresetCatalogError as exc:
            raise HTTPException(503, str(exc)) from exc
        except (KeyError, ValueError) as exc:
            raise HTTPException(422, str(exc)) from exc
        for run in result["runs"]:
            await events.publish({"type": "run.queued", "run": run})
        await events.publish({"type": "preset.installed", "installation": result})
        return result

    @app.get("/api/v1/preset-installations")
    def preset_installations():
        return presets.list_installations()

    @app.patch("/api/v1/presets/{preset_id}/visibility")
    async def set_preset_visibility(preset_id: str, payload: PresetVisibilityRequest):
        try:
            result = presets.set_hidden(preset_id, payload.hidden)
        except KeyError as exc:
            raise HTTPException(404, "Installed preset pack not found") from exc
        await events.publish({"type": "preset.visibility", "preset": result})
        return result

    @app.get("/api/v1/presets/{preset_id}/removal-preview")
    def preset_removal_preview(preset_id: str):
        try:
            return presets.removal_preview(preset_id)
        except KeyError as exc:
            raise HTTPException(404, "Installed preset pack not found") from exc

    @app.post("/api/v1/presets/{preset_id}/remove")
    async def remove_preset_pack(preset_id: str, payload: PresetRemovalRequest):
        try:
            result = presets.remove_pack(preset_id, payload)
        except KeyError as exc:
            raise HTTPException(404, "Installed preset pack not found") from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        await events.publish({"type": "preset.removed", "preset": result})
        return result

    @app.post("/api/v1/presets/import", status_code=201)
    def import_preset(payload: PresetManifest):
        try:
            return presets.import_manifest(payload.model_dump(mode="json"))
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/v1/presets/export")
    def export_preset(payload: PresetExportRequest):
        try:
            return presets.export_manifest(payload)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/v1/presets/{preset_id}/install", status_code=202)
    async def install_preset(preset_id: str, payload: PresetInstallRequest):
        require_local_scrapers()
        try:
            result = presets.install(preset_id, payload)
        except KeyError as exc:
            raise HTTPException(404, "Preset not found") from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        for run in result["runs"]:
            await events.publish({"type": "run.queued", "run": run})
        await events.publish({"type": "preset.installed", "installation": result})
        return result

    @app.post("/api/v1/companies/{company_id}/catalog-recipe-update", status_code=202)
    async def update_catalog_recipe(company_id: int, payload: CatalogRecipeUpdateRequest):
        require_local_scrapers()
        try:
            result = presets.queue_catalog_update(
                company_id, request_id=payload.request_id,
                expected_revision=payload.expected_revision,
            )
        except KeyError as exc:
            raise HTTPException(404, "Catalog-managed company not found") from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        await events.publish({"type": "run.queued", "run": result["run"]})
        return result

    @app.delete("/api/v1/preset-installations/{installation_id}")
    async def archive_preset_installation(installation_id: int):
        try:
            result = presets.archive_installation(installation_id)
        except KeyError as exc:
            raise HTTPException(404, "Preset installation not found") from exc
        await events.publish({"type": "preset.archived", "installation": result})
        return result

    @app.get("/api/v1/companies")
    def companies(include_archived: bool = False, db: Database = Depends(get_db)):
        items = [present_company(item) for item in db.list_companies(include_archived)]
        return {"items": items, "count": len(items)}

    @app.post("/api/v1/companies", status_code=201)
    async def add_company(payload: CompanyCreate, db: Database = Depends(get_db)):
        require_local_scrapers()
        data = payload.model_dump(mode="json", exclude={"schedule", "preset_ids"})
        data["criteria"] = criteria_for_storage(data["criteria"])
        require_local_scrapers()
        company = db.create_company(data)
        if payload.preset_ids:
            try:
                presets.set_company_memberships(int(company["id"]), payload.preset_ids)
            except ValueError as exc:
                db.delete_company(int(company["id"]))
                raise HTTPException(422, str(exc)) from exc
            company = db.get_company(int(company["id"])) or company
        run = scheduler.enqueue(company["id"], "build") if payload.build_now else None
        await events.publish({"type": "company.created", "company": company, "run": run})
        return present_company(company)

    @app.get("/api/v1/companies/{company_id}")
    def company(company_id: int, db: Database = Depends(get_db)):
        value = company_or_404(company_id)
        value["recipes"] = db.list_recipes(company_id)
        value["recent_runs"] = db.list_runs(company_id, 20)
        return present_company(value)

    @app.get("/api/v1/companies/{company_id}/branding")
    async def company_branding(company_id: int):
        value = company_or_404(company_id)
        try:
            branding = await asyncio.to_thread(discover_company_branding, value["careers_url"])
        except (httpx.HTTPError, ValueError):
            branding = None
        try:
            logo = await asyncio.to_thread(
                resolve_company_logo, value["careers_url"], value.get("logo_url")
            )
        except (httpx.HTTPError, ValueError):
            logo = None
        website_url = branding.website_url if branding else None
        return {
            "website_url": website_url,
            "configured_logo_url": value.get("logo_url"),
            "logo_url": f"/api/v1/companies/{company_id}/branding/logo" if logo else None,
            "favicon_url": f"{website_url}/favicon.ico" if website_url else None,
            "source": logo.source if logo else "initials",
            "warning": None if logo else "No supported company image is currently available",
        }

    @app.get("/api/v1/companies/{company_id}/branding/logo")
    async def company_branding_logo(company_id: int):
        value = company_or_404(company_id)
        try:
            logo = await asyncio.to_thread(
                resolve_company_logo, value["careers_url"], value.get("logo_url")
            )
        except (httpx.HTTPError, ValueError):
            raise HTTPException(status_code=404, detail="Company logo is unavailable") from None
        return Response(
            content=logo.content,
            media_type=logo.media_type,
            headers={"Cache-Control": "private, max-age=86400"},
        )

    @app.patch("/api/v1/companies/{company_id}")
    async def edit_company(company_id: int, payload: CompanyUpdate, db: Database = Depends(get_db)):
        company_or_404(company_id)
        if payload.schedule is not None or any(key in payload.model_fields_set for key in ("schedule_kind", "interval_hours", "run_time", "weekday")):
            require_local_scrapers()
        if payload.preset_ids is not None:
            try:
                for preset_id in payload.preset_ids:
                    presets.get_manifest(preset_id)
            except KeyError as exc:
                raise HTTPException(422, f"Unknown preset id: {exc.args[0]}") from exc
        if "logo_url" in payload.model_fields_set and payload.logo_url is not None:
            try:
                await asyncio.to_thread(fetch_company_logo, str(payload.logo_url))
            except (httpx.HTTPError, ValueError) as exc:
                raise HTTPException(422, f"Logo URL is not a supported public image: {exc}") from exc
        changes = payload.model_dump(mode="json", exclude_none=True, exclude={"preset_ids"})
        if "logo_url" in payload.model_fields_set and payload.logo_url is None:
            changes["logo_url"] = None
        schedule = changes.pop("schedule", None)
        if schedule == "every_6_hours":
            changes.update({"schedule_kind": "interval", "interval_hours": 6})
        elif schedule in {"daily", "weekly", "manual"}:
            changes["schedule_kind"] = schedule
        if "criteria" in changes:
            changes["criteria"] = criteria_for_storage(changes["criteria"])
        updated = db.update_company(company_id, changes)
        if payload.preset_ids is not None:
            presets.set_company_memberships(company_id, payload.preset_ids)
            updated = db.get_company(company_id)
        if updated and updated.get("state") == "active":
            settings_value = db.get_settings()
            db.update_company(company_id, {"next_run_at": next_occurrence(updated, default_timezone=settings_value["timezone"])})
            updated = db.get_company(company_id)
        await events.publish({"type": "company.updated", "company": updated})
        return present_company(updated)

    @app.post("/api/v1/companies/{company_id}/build", status_code=202)
    async def build_company(company_id: int, payload: BuildRequest | None = None):
        company_or_404(company_id)
        run = scheduler.enqueue(company_id, "build_ai" if payload and payload.force_ai else "build")
        if not run.get("reused"):
            database.update_company(company_id, {"state": "building"})
        await events.publish({"type": "run.queued", "run": run})
        return {"build_id": str(run["id"]), **present_run(run)}

    @app.post("/api/v1/companies/{company_id}/run", status_code=202)
    async def run_company(company_id: int):
        company = company_or_404(company_id)
        if company.get("archived_at"):
            raise HTTPException(409, "Restore this tracker before running it")
        if database.is_company_hidden(company_id):
            raise HTTPException(409, "Show one of this company's preset packs before running it")
        if not company.get("active_recipe_version"):
            raise HTTPException(409, "Build and activate a scraper first")
        run = scheduler.enqueue(company_id, "scrape")
        await events.publish({"type": "run.queued", "run": run})
        return present_run(run)

    @app.post("/api/v1/companies/{company_id}/repair", status_code=202)
    async def repair_company(company_id: int):
        company = company_or_404(company_id)
        if not company.get("active_recipe_version"):
            raise HTTPException(409, "No active recipe to repair")
        run = scheduler.enqueue(company_id, "repair")
        await events.publish({"type": "run.queued", "run": run})
        return present_run(run)

    @app.post("/api/v1/companies/{company_id}/recipes/activate")
    async def activate_recipe(company_id: int, payload: RecipeActivate):
        require_local_scrapers()
        company_or_404(company_id)
        if not database.activate_recipe(company_id, payload.recipe_version):
            raise HTTPException(404, "Recipe version not found")
        updated = database.get_company(company_id)
        await events.publish({"type": "company.updated", "company": updated})
        return present_company(updated)

    @app.post("/api/v1/companies/{company_id}/pause")
    async def pause_company(company_id: int):
        return present_company(app.state.trackers.set_state(company_id, "pause")["monitor"])

    @app.post("/api/v1/companies/{company_id}/resume")
    async def resume_company(company_id: int):
        return present_company(app.state.trackers.set_state(company_id, "resume")["monitor"])

    @app.delete("/api/v1/companies/{company_id}")
    async def archive_company(company_id: int):
        result = app.state.trackers.set_state(company_id, "archive")
        return {"archived": True, "company": present_company(result["monitor"])}

    @app.get("/api/v1/jobs")
    def jobs(matching: bool | None = True, company_id: int | None = None,
             company_ids: list[int] | None = Query(default=None), unread: bool | None = None,
             dismissed: bool | None = False, active: bool | None = True, query: str | None = None,
             remote_modes: list[Literal["remote", "hybrid", "onsite", "unknown"]] | None = Query(default=None),
             employment_types: list[str] | None = Query(default=None), salary_listed: bool | None = None,
             posted_within_days: int | None = Query(default=None, ge=1, le=30), saved: bool | None = None,
             sort: Literal["default", "newest", "oldest", "nearest", "farthest", "title", "company"] = "default",
             limit: int = Query(default=100, ge=1, le=500), offset: int = Query(default=0, ge=0),
             include_closed: bool = False, include_all: bool = False):
        if posted_within_days is not None and posted_within_days not in {1, 7, 30}:
            raise HTTPException(422, "posted_within_days must be 1, 7, or 30")
        if include_closed:
            active = None
        if include_all:
            matching = None
        if saved is True:
            matching, dismissed, active = None, None, None
        filters = {
            "matching": matching, "company_id": company_id, "company_ids": company_ids,
            "unread": unread, "dismissed": dismissed, "active": active, "query": query,
            "remote_modes": remote_modes, "employment_types": employment_types,
            "salary_listed": salary_listed, "posted_within_days": posted_within_days, "saved": saved,
        }
        return job_queries.search(**filters, limit=limit, offset=offset, sort=sort)

    @app.get("/api/v1/jobs/{job_id}")
    def job(job_id: int):
        try:
            return job_queries.read(job_id)
        except KeyError:
            raise HTTPException(404, "Job not found")

    @app.get("/api/v1/jobs/{job_id}/activities")
    def job_activities(job_id: int, limit: int = Query(default=8, ge=1, le=100),
                       before_id: int | None = Query(default=None, ge=1)):
        if not database.get_job(job_id):
            raise HTTPException(404, "Job not found")
        page = database.list_job_activities(job_id=job_id, limit=limit + 1, before_id=before_id)
        more = len(page) > limit
        items = page[:limit]
        cursor = items[-1]["id"] if more and items else None
        return {"items": [present_activity(item) for item in items], "count": len(items),
                "next_cursor": cursor, "next_before_id": cursor}

    @app.get("/api/v1/job-activities")
    def all_job_activities(limit: int = Query(default=20, ge=1, le=100),
                           before_id: int | None = Query(default=None, ge=1)):
        page = database.list_job_activities(limit=limit + 1, before_id=before_id)
        more = len(page) > limit
        items = page[:limit]
        cursor = items[-1]["id"] if more and items else None
        return {"items": [present_activity(item, include_job=True) for item in items],
                "count": len(items), "next_cursor": cursor, "next_before_id": cursor}

    @app.get("/api/v1/application-tracker")
    def application_tracker(
        from_date: date | None = Query(default=None, alias="from"),
        to_date: date | None = Query(default=None, alias="to"),
        include_closed: bool = False,
    ):
        if from_date and to_date and from_date > to_date:
            raise HTTPException(422, "from must be on or before to")
        return job_queries.tracker(
            from_date=from_date.isoformat() if from_date else None,
            to_date=to_date.isoformat() if to_date else None, include_closed=include_closed)

    @app.post("/api/v1/applications/manual", status_code=201)
    async def create_manual_application(payload: ManualApplicationCreate):
        data = payload.model_dump(mode="json")
        try:
            value = database.create_manual_application(
                company_name=data["company"], title=data["title"],
                applied_at=data["applied_at"], location=data["location"],
                url=data.get("source_url") or "", description=data["description"],
                note=data["note"], request_id=data["request_id"],
                actor_type=data["actor_type"],
            )
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        result = present_job(value, include_activities=True)
        await events.publish({"type": "application.created", "job": result})
        return result

    @app.patch("/api/v1/jobs/{job_id}/tracking")
    async def update_job_tracking(job_id: int, payload: JobTrackingUpdate):
        occurred_at = payload.occurred_at.isoformat() if payload.occurred_at else None
        try:
            value = database.update_job_tracking(
                job_id, saved=payload.saved, stage=payload.stage,
                stage_supplied="stage" in payload.model_fields_set,
                milestone=payload.milestone,
                milestone_supplied="milestone" in payload.model_fields_set,
                outcome=payload.outcome,
                outcome_supplied="outcome" in payload.model_fields_set,
                occurred_at=occurred_at, detail=payload.detail,
                request_id=payload.request_id, actor_type=payload.actor_type,
            )
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        if not value:
            raise HTTPException(404, "Job not found")
        result = present_job(value, include_activities=True)
        await events.publish({"type": "job.tracking_updated", "job": result})
        return result

    @app.post("/api/v1/jobs/{job_id}/activities", status_code=201)
    async def add_job_activity(job_id: int, payload: JobActivityCreate):
        value = database.add_job_activity(job_id, **payload.model_dump())
        if not value:
            raise HTTPException(404, "Job not found")
        result = present_activity(value)
        await events.publish({"type": "job.activity_created", "job_id": job_id, "activity": result})
        return result

    @app.post("/api/v1/jobs/{job_id}/recruiters")
    async def recruiters(job_id: int, payload: RecruiterSearchRequest, request: Request):
        result = await recruiter_search_for_job(job_id, live_search=payload.live_search)
        if request.headers.get("X-JobHound-Actor", "").casefold() == "agent":
            activity = database.record_job_skill_activity(
                job_id=job_id, command_id="find_recruiters", label="Find potential recruiters",
                detail=f"Found {len(result.get('candidates', []))} potential recruiter profiles.",
            )
            if activity:
                await events.publish({"type": "job.activity_created", "job_id": job_id,
                                      "activity": present_activity(activity)})
        return result

    @app.post("/api/v1/jobs/{job_id}/interview-prep")
    async def prepare_interview(job_id: int, payload: InterviewPrepRequest, request: Request):
        result = await interview_prep_for_job(job_id, payload, request=request)
        if request.headers.get("X-JobHound-Actor", "").casefold() == "agent":
            activity = database.record_job_skill_activity(
                job_id=job_id, command_id="interview_prep", label="Prepare for an interview",
                detail=result.get("summary") or "Generated an interview preparation pack.",
            )
            if activity:
                await events.publish({"type": "job.activity_created", "job_id": job_id,
                                      "activity": present_activity(activity)})
        return result

    @app.post("/api/v1/jobs/{job_id}/intro-letter")
    async def create_intro_letter(job_id: int, payload: IntroLetterRequest, request: Request):
        return await intro_letter_for_job(job_id, payload, request=request)

    @app.patch("/api/v1/jobs/{job_id}")
    async def update_job(job_id: int, payload: JobStateUpdate):
        changes = payload.model_dump(exclude_none=True)
        if "is_read" in changes:
            changes["unread"] = not changes.pop("is_read")
        if "is_dismissed" in changes:
            changes["dismissed"] = changes.pop("is_dismissed")
        value = database.update_job_state(job_id, **changes)
        if not value:
            raise HTTPException(404, "Job not found")
        await events.publish({"type": "job.updated", "job": value})
        return present_job(value)

    @app.get("/api/v1/runs")
    def runs(company_id: int | None = None, limit: int = Query(default=50, ge=1, le=200)):
        items = database.list_runs(company_id, limit)
        return {"items": [present_run(item) for item in items], "count": len(items)}

    @app.get("/api/v1/runs/{run_id}")
    def run(run_id: int):
        value = database.get_run(run_id)
        if not value:
            raise HTTPException(404, "Run not found")
        return present_run(value)

    @app.get("/api/v1/scrapers/builds/{build_id}")
    def build_result(build_id: int):
        value = database.get_run(build_id)
        if not value or value.get("kind") not in {"build", "build_ai"}:
            raise HTTPException(404, "Build not found")
        return present_build(value)

    @app.get("/api/v1/scrapers/builds/{build_id}/events")
    async def build_event_stream(build_id: int):
        if not database.get_run(build_id):
            raise HTTPException(404, "Build not found")

        async def stream():
            previous: tuple[Any, ...] | None = None
            while True:
                value = database.get_run(build_id)
                if not value:
                    return
                marker = (value.get("status"), value.get("progress"), value.get("message"))
                if marker != previous:
                    payload = present_build(value)
                    yield f"event: progress\ndata: {json.dumps(payload, default=str)}\n\n"
                    previous = marker
                if value.get("status") in {"complete", "partial", "failed"}:
                    return
                await asyncio.sleep(0.4)

        return StreamingResponse(stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @app.get("/api/v1/events")
    def stream_events(request: Request):
        def visible(event):
            thread_id = event.get("thread_id")
            thread = database.get_chat_thread(int(thread_id)) if thread_id else None
            return not thread or not thread.get("private_local") or is_loopback(request.client.host if request.client else None)
        return StreamingResponse(events.stream(visible), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @app.get("/api/v1/documents")
    def list_documents(
        request: Request, kind: str | None = Query(None),
        include_archived: bool = Query(False), include_drafts: bool = Query(False),
    ):
        require_loopback(request)
        if kind not in {None, "resume", "intro_letter"}:
            raise HTTPException(422, "Document type must be resume or intro_letter")
        items = database.list_documents(kind=kind, include_archived=include_archived)
        presented = [documents.public(item) for item in items]
        if include_drafts:
            presented.extend(documents.public_draft(item) for item in database.list_document_drafts(kind=kind))
        return {"count": len(presented), "items": presented}

    @app.post("/api/v1/document-drafts", status_code=201)
    def create_document_draft(payload: DocumentDraftCreate, request: Request):
        require_loopback(request)
        try:
            return documents.create_draft(
                payload.content.model_dump(mode="json"),
                source_document_id=payload.source_document_id,
            )
        except KeyError as exc:
            raise HTTPException(404, "Source document not found") from exc
        except (DocumentError, ValueError) as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/api/v1/document-drafts/{draft_id}")
    def get_document_draft(draft_id: int, request: Request):
        require_loopback(request)
        try:
            return documents.read_draft(draft_id)
        except KeyError as exc:
            raise HTTPException(404, "Document draft not found") from exc

    @app.patch("/api/v1/document-drafts/{draft_id}")
    def update_document_draft(draft_id: int, payload: DocumentDraftUpdate, request: Request):
        require_loopback(request)
        try:
            return documents.create_draft(payload.content.model_dump(mode="json"), draft_id=draft_id)
        except KeyError as exc:
            raise HTTPException(404, "Document draft not found") from exc
        except (DocumentError, ValueError) as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/api/v1/document-drafts/{draft_id}/preview.html", response_class=HTMLResponse)
    def preview_document_draft(draft_id: int, request: Request):
        require_loopback(request)
        try:
            return HTMLResponse(
                documents.draft_html(draft_id),
                headers={"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'", "X-Frame-Options": "SAMEORIGIN"},
            )
        except KeyError as exc:
            raise HTTPException(404, "Document draft not found") from exc

    @app.get("/api/v1/document-drafts/{draft_id}/download.docx")
    def download_document_draft(draft_id: int, request: Request):
        require_loopback(request)
        try:
            draft, content = documents.draft_docx(draft_id)
        except KeyError as exc:
            raise HTTPException(404, "Document draft not found") from exc
        filename = re.sub(r'[^A-Za-z0-9._ -]+', '_', draft["label"]).strip() or "career-document"
        return Response(
            content=content,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="{filename}.docx"', "X-Content-Type-Options": "nosniff"},
        )

    @app.post("/api/v1/document-drafts/{draft_id}/publish")
    async def publish_document_draft(draft_id: int, request: Request):
        require_loopback(request)
        try:
            document, duplicate = documents.publish_draft(draft_id)
        except KeyError as exc:
            raise HTTPException(404, "Document draft not found") from exc
        except DocumentError as exc:
            raise HTTPException(409, str(exc)) from exc
        await events.publish({"type": "document.uploaded", "document_id": document["id"]})
        return {"document": documents.public(document), "duplicate": duplicate, "draft": documents.read_draft(draft_id)}

    @app.post("/api/v1/documents", status_code=201)
    async def upload_document(
        request: Request,
        file: UploadFile = File(...),
        kind: str = Form(...),
        label: str | None = Form(None),
        replace_document_id: int | None = Form(None),
    ):
        require_loopback(request)
        content = await file.read(MAX_FILE_BYTES + 1)
        try:
            document, duplicate = documents.upload(
                kind=kind, original_filename=file.filename or "document", content=content,
                label=label, replace_document_id=replace_document_id,
            )
        except KeyError as exc:
            raise HTTPException(404, "Replacement document not found or already archived") from exc
        except DocumentError as exc:
            raise HTTPException(422, str(exc)) from exc
        await events.publish({"type": "document.uploaded", "document_id": document["id"]})
        return {"document": documents.public(document, include_text=True), "duplicate": duplicate}

    @app.get("/api/v1/documents/{document_id}")
    def get_document(
        document_id: int, request: Request,
        max_chars: int = Query(20_000, ge=500, le=50_000),
        variant: Literal["template", "example"] = Query("template"),
        offset: int = Query(0, ge=0),
    ):
        require_loopback(request)
        try:
            return documents.read(document_id, variant=variant, max_chars=max_chars, offset=offset)
        except KeyError as exc:
            raise HTTPException(404, "Document not found") from exc
        except DocumentError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/api/v1/documents/{document_id}/download")
    def download_document(
        document_id: int, request: Request,
        variant: Literal["template", "example"] = Query("template"),
    ):
        require_loopback(request)
        try:
            document, path = documents.download_path(document_id, variant=variant)
        except KeyError as exc:
            raise HTTPException(404, "Document not found") from exc
        except DocumentError as exc:
            raise HTTPException(422, str(exc)) from exc
        return FileResponse(
            path, media_type=document["mime_type"], filename=document["original_filename"],
            headers={"X-Content-Type-Options": "nosniff"},
        )

    @app.get("/api/v1/documents/{document_id}/preview.pdf")
    def preview_document(
        document_id: int, request: Request,
        variant: Literal["template", "example"] = Query("template"),
    ):
        require_loopback(request)
        try:
            filename, path = documents.preview_path(document_id, variant=variant)
        except KeyError as exc:
            raise HTTPException(404, "Document not found") from exc
        except DocumentError as exc:
            raise HTTPException(422, str(exc)) from exc
        return FileResponse(
            path, media_type="application/pdf",
            headers={
                "Content-Disposition": f'inline; filename="{filename}"',
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.get("/api/v1/documents/{document_id}/preview.html", response_class=HTMLResponse)
    def preview_generated_document(document_id: int, request: Request):
        require_loopback(request)
        try:
            return HTMLResponse(
                documents.generated_html(document_id),
                headers={"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'", "X-Frame-Options": "SAMEORIGIN"},
            )
        except KeyError as exc:
            raise HTTPException(404, "Document not found") from exc
        except DocumentError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.patch("/api/v1/documents/{document_id}")
    async def update_document(document_id: int, payload: DocumentUpdate, request: Request):
        require_loopback(request)
        try:
            document = database.update_document(document_id, label=payload.label, archived=payload.archived)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        if not document:
            raise HTTPException(404, "Document not found")
        await events.publish({"type": "document.updated", "document_id": document_id})
        return documents.public(document)

    @app.delete("/api/v1/documents/{document_id}")
    async def purge_document(document_id: int, request: Request, confirm: bool = Query(False)):
        require_loopback(request)
        if not confirm:
            raise HTTPException(422, "Permanent deletion requires confirm=true")
        try:
            documents.purge(document_id)
        except KeyError as exc:
            raise HTTPException(404, "Document not found") from exc
        except DocumentError as exc:
            raise HTTPException(409, str(exc)) from exc
        await events.publish({"type": "document.purged", "document_id": document_id})
        return {"purged": True, "document_id": document_id}

    @app.get("/api/v1/documents-export.zip")
    def export_documents(request: Request):
        require_loopback(request)
        path = documents.export_zip()
        interviews.backup(path)
        return FileResponse(
            path, media_type="application/zip", filename="jobhound-documents.zip",
            background=BackgroundTask(path.unlink, missing_ok=True),
            headers={"X-Content-Type-Options": "nosniff"},
        )

    @app.get("/api/v1/export")
    def export_data(request: Request):
        result = {"settings": database.get_settings(), "companies": database.list_companies(True),
                  "jobs": database.list_jobs(matching=None, dismissed=None, active=None, limit=500, offset=0),
                  "runs": database.list_runs(limit=200),
                  "chat_threads": [database.get_chat_thread(item["id"]) for item in database.list_chat_threads() if is_loopback(request.client.host if request.client else None) or not item.get("private_local")],
                  "job_tracking": database.list_job_tracking(),
                  "job_activities": database.list_job_activities(limit=5000),
                  "dashboard_layout": database.get_dashboard_layout(),
                  "dashboard_widgets": list_widgets(database, include_drafts=True),
                  "preset_installations": presets.list_installations()["items"],
                  "presets": [item for item in presets.list_presets()["items"] if item["source"] == "imported"]}
        if is_loopback(request.client.host if request.client else None):
            result["documents"] = [documents.public(item) for item in database.list_documents(include_archived=True)]
        return result

    # Production builds are copied to web/dist by the frontend toolchain. API routes retain precedence.
    web_dist = Path(__file__).resolve().parents[1] / "web" / "dist"
    if web_dist.exists():
        from starlette.responses import FileResponse
        from starlette.exceptions import HTTPException as StarletteHTTPException
        from fastapi.staticfiles import StaticFiles

        class SPAStaticFiles(StaticFiles):
            async def get_response(self, path: str, scope: dict[str, Any]):
                try:
                    response = await super().get_response(path, scope)
                except StarletteHTTPException as exc:
                    if exc.status_code == 404 and "." not in Path(path).name:
                        return FileResponse(web_dist / "index.html")
                    raise
                if response.status_code == 404 and "." not in Path(path).name:
                    return FileResponse(web_dist / "index.html")
                return response

        app.mount("/", SPAStaticFiles(directory=web_dist, html=True), name="web")

    return app


app = create_app()
