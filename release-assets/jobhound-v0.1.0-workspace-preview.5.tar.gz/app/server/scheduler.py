"""Durable run queue worker and schedule calculations."""

from __future__ import annotations

import asyncio
import inspect
import json
import socket
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .external_http import external_trust_env, external_client_kwargs
from .ai_connections import AIConnection, AIConnectionError, AIConnectionRegistry, create_default_registry
from .agent_instructions import compose_recipe_prompt
from .db import Database, iso_now
from .models import ClaimedRun
from .scrapers.progress import progress_callback, report_progress


class SharedSourceClient:
    """Short-lived, bounded response reuse for monitors that declare one exact source key."""

    def __init__(self, source_key: str, *, ttl_seconds: float = 45.0, max_bytes: int = 50_000_000,
                 transport=None) -> None:
        import httpx
        self.source_key = source_key
        self.ttl_seconds = ttl_seconds
        self.max_bytes = max_bytes
        self._client = httpx.Client(follow_redirects=False, **external_client_kwargs(transport=transport))
        self._cache: dict[tuple, tuple[float, int, dict[str, str], bytes, str]] = {}
        self._bytes = 0
        self._lock = threading.Lock()
        self._jobhound_resolve_dns = transport is None

    def request(self, method: str, url: str, **kwargs):
        import httpx
        request = self._client.build_request(method, url, headers=kwargs.get("headers"),
                                             params=kwargs.get("params"), json=kwargs.get("json"),
                                             timeout=kwargs.get("timeout"))
        key = (self.source_key, request.method, str(request.url), bytes(request.content),
               tuple(sorted(request.headers.multi_items())))
        now = time.monotonic()
        with self._lock:
            self._prune(now)
            cached = self._cache.get(key)
        if cached:
            _, status, headers, content, response_url = cached
            cached_request = httpx.Request(request.method, response_url, headers=request.headers, content=request.content)
            return httpx.Response(status, headers=headers, content=content, request=cached_request)
        response = self._client.send(request, follow_redirects=kwargs.get("follow_redirects", False))
        content = response.read()
        if 200 <= response.status_code < 300 and len(content) <= self.max_bytes:
            with self._lock:
                self._prune(now)
                while self._cache and self._bytes + len(content) > self.max_bytes:
                    _, removed = self._cache.popitem()
                    self._bytes -= len(removed[3])
                if self._bytes + len(content) <= self.max_bytes:
                    self._cache[key] = (now + self.ttl_seconds, response.status_code,
                                        dict(response.headers), content, str(response.url))
                    self._bytes += len(content)
        return response

    def _prune(self, now: float) -> None:
        for key, value in list(self._cache.items()):
            if value[0] <= now:
                self._bytes -= len(value[3])
                del self._cache[key]

    def close(self) -> None:
        self._client.close()


ProgressCallback = Callable[[dict[str, Any]], Awaitable[None] | None]


def next_occurrence(company: dict[str, Any], *, after: datetime | None = None, default_timezone: str = "UTC") -> str | None:
    kind = company.get("schedule_kind", "manual")
    if kind == "manual":
        return None
    after = after or datetime.now(timezone.utc)
    try:
        zone = ZoneInfo(company.get("timezone") or default_timezone)
    except ZoneInfoNotFoundError:
        zone = timezone.utc
    local = after.astimezone(zone)
    if kind == "interval":
        return (after + timedelta(hours=max(1, int(company.get("interval_hours") or 24)))).isoformat()
    hour, minute = (int(part) for part in (company.get("local_time") or "09:00").split(":", 1))
    candidate = local.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if kind == "weekly":
        candidate += timedelta(days=(int(company.get("weekday") or 0) - candidate.weekday()) % 7)
    if candidate <= local:
        candidate += timedelta(days=7 if kind == "weekly" else 1)
    return candidate.astimezone(timezone.utc).isoformat()


def _dump(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    return value


def _job_payload(job: Any) -> dict[str, Any]:
    data = _dump(job)
    return {
        "source_job_id": data.get("source_job_id") or data.get("source_id"),
        "title": data.get("title", ""),
        "location": data.get("location", ""),
        "location_city": data.get("location_city"),
        "remote_mode": getattr(data.get("remote_mode"), "value", data.get("remote_mode", "unknown")),
        "employment_type": data.get("employment_type"),
        "posted_date": data.get("posted_date"),
        "description": data.get("description", ""),
        "salary_min": data.get("salary_min"), "salary_max": data.get("salary_max"),
        "salary_currency": data.get("salary_currency"),
        "salary_period": data.get("salary_period"),
        "url": data.get("url") or data.get("source_url") or data.get("canonical_url", ""),
        "canonical_url": data.get("canonical_url"), "source": data.get("source"),
    }


class ScraperGateway:
    """Adapter over the deterministic scraper package; all blocking I/O runs in a worker thread."""

    def __init__(self) -> None:
        self._shared_clients: dict[str, SharedSourceClient] = {}

    def _client_for(self, recipe: dict[str, Any]):
        source_key = str(recipe.get("source_key") or "")
        if not source_key:
            return None
        if source_key not in self._shared_clients:
            self._shared_clients[source_key] = SharedSourceClient(source_key)
        return self._shared_clients[source_key]

    def close(self) -> None:
        for client in self._shared_clients.values():
            client.close()
        self._shared_clients.clear()

    async def build(self, company: dict[str, Any], ai: AIConnection | None, model: str | None,
                    force_ai: bool = False, instruction_overrides: dict[str, str] | None = None,
                    instruction_revision: int = 1) -> tuple[dict[str, Any], list[dict[str, Any]], str, dict[str, Any] | None]:
        from .scrapers import build_scraper, run_scraper, validate_recipe
        from .scrapers.ai_contract import ScraperRecipeProposal, compile_recipe_proposal
        from .ai_connections.recipe_tools import RecipeTools

        report_progress("detecting", "Detecting careers platform")
        built = await asyncio.to_thread(build_scraper, company)
        recipe = built["recipe"]
        strategy = built.get("source") or recipe.get("strategy")
        used_ai = force_ai or strategy in {"generic_html", "playwright"}
        provenance = None
        if used_ai:
            if ai is None:
                raise RuntimeError("An AI connection is required to build this scraper. Configure one in Connections.")
            evidence = built.get("evidence") or f"Detector produced {strategy} for {company['careers_url']}."
            prompt = _recipe_prompt(company, evidence=evidence, overrides=instruction_overrides)
            report_progress("agent", f"{ai.id} is building a tracker", provider=ai.id)
            proposal = await asyncio.to_thread(
                ai.run_structured, prompt, ScraperRecipeProposal, model=model, browsing=False,
                **({"tool_context": RecipeTools(recipe)} if ai.id == "openrouter" else {}),
            )
            recipe = compile_recipe_proposal(proposal)
            provenance = {"ai_connection": ai.id, "ai_model": model, "operation": "compile",
                          "instruction_revision": instruction_revision}
            strategy = recipe.get("strategy") or strategy
        if used_ai:
            report_progress("validating", "Validating the proposed tracker")
            report = await asyncio.to_thread(validate_recipe, recipe)
            report_data = _dump(report)
            if not report_data.get("valid"):
                raise RuntimeError("; ".join(report_data.get("errors", [])) or "Recipe validation failed")
        else:
            report_data = built.get("validation", {})
            if not report_data.get("valid"):
                raise RuntimeError("; ".join(report_data.get("errors", [])) or "Recipe validation failed")
        provenance = provenance or {"operation": "detection"}
        provenance["validation"] = {
            "coverage": report_data.get("coverage", {}),
            "warnings": report_data.get("warnings", []),
        }
        result = await asyncio.to_thread(run_scraper, recipe)
        return recipe, [_job_payload(job) for job in result.jobs], strategy, provenance

    async def run(self, recipe: dict[str, Any]) -> tuple[list[dict[str, Any]], bool, str | None]:
        from .scrapers import run_scraper
        from .scrapers.runtime import rich_field_coverage, rich_field_warnings
        client = self._client_for(recipe)
        result = await asyncio.to_thread(run_scraper, recipe, client=client)
        result_data = _dump(result)
        diagnostics = [*result_data.get("warnings", []),
                       *rich_field_warnings(rich_field_coverage(result.jobs))]
        return [_job_payload(job) for job in result.jobs], bool(result_data.get("complete", True)), "; ".join(diagnostics) or None

    async def repair(self, company: dict[str, Any], recipe: dict[str, Any], diagnostics: str,
                     ai: AIConnection | None, model: str | None,
                     instruction_overrides: dict[str, str] | None = None,
                     instruction_revision: int = 1) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
        from .scrapers import build_scraper, run_scraper, validate_recipe
        from .scrapers.ai_contract import ScraperRecipeProposal, compile_recipe_proposal
        from .ai_connections.recipe_tools import RecipeTools
        if ai is None:
            raise RuntimeError("An AI connection is required to repair this scraper. Configure one in Connections.")
        report_progress("detecting", "Inspecting the careers source for repair")
        detected = await asyncio.to_thread(build_scraper, company)
        evidence = detected.get("evidence") or f"Current URL: {company['careers_url']}"
        prompt = _recipe_prompt(company, evidence=evidence, previous_recipe=recipe,
                                diagnostics=diagnostics, overrides=instruction_overrides)
        report_progress("agent", f"{ai.id} is repairing a tracker", provider=ai.id)
        proposal = await asyncio.to_thread(
            ai.run_structured, prompt, ScraperRecipeProposal, model=model, browsing=False,
                **({"tool_context": RecipeTools(recipe)} if ai.id == "openrouter" else {}),
        )
        repaired = compile_recipe_proposal(proposal)
        report_progress("validating", "Validating the repaired tracker")
        report = _dump(await asyncio.to_thread(validate_recipe, repaired))
        if not report.get("valid"):
            raise RuntimeError("; ".join(report.get("errors", [])) or "Repaired recipe failed validation")
        result = await asyncio.to_thread(run_scraper, repaired)
        provenance = {"ai_connection": ai.id, "ai_model": model, "operation": "repair",
                      "instruction_revision": instruction_revision,
                      "validation": {"coverage": report.get("coverage", {}),
                                     "warnings": report.get("warnings", [])}}
        return repaired, [_job_payload(job) for job in result.jobs], provenance


def _recipe_prompt(company: dict[str, Any], *, evidence: str, previous_recipe: dict[str, Any] | None = None,
                   diagnostics: str | None = None,
                   overrides: dict[str, str] | None = None) -> str:
    return compose_recipe_prompt(
        company, evidence=evidence, previous_recipe=previous_recipe,
        diagnostics=diagnostics, overrides=overrides,
    )


class Scheduler:
    def __init__(self, db: Database, ai_connections: AIConnectionRegistry | None = None, gateway: ScraperGateway | None = None,
                 event_callback: ProgressCallback | None = None, poll_seconds: float = 5.0) -> None:
        self.db = db
        self.ai_connections = ai_connections or create_default_registry()
        self.ai_connections.settings_reader = db.get_settings
        self.gateway = gateway or ScraperGateway()
        self.event_callback = event_callback
        self.poll_seconds = poll_seconds
        self.owner = f"{socket.gethostname()}-{uuid.uuid4().hex[:8]}"
        self._task: asyncio.Task[None] | None = None
        self._wake = asyncio.Event()
        self._stopping = False

    async def emit(self, event: dict[str, Any]) -> None:
        if self.event_callback:
            outcome = self.event_callback(event)
            if inspect.isawaitable(outcome):
                await outcome

    def start(self) -> None:
        if not self._task or self._task.done():
            self._stopping = False
            self._task = asyncio.create_task(self.loop(), name="jobhound-scheduler")

    async def stop(self) -> None:
        self._stopping = True
        self._wake.set()
        if self._task:
            await self._task
        close = getattr(self.gateway, "close", None)
        if close:
            close()

    def wake(self) -> None:
        self._wake.set()

    def enqueue(self, company_id: int, kind: str = "scrape") -> dict[str, Any]:
        from .capabilities import require_local_scrapers
        require_local_scrapers()
        run = self.db.enqueue_run(company_id, kind, reuse_active=True)
        self.wake()
        return run

    def enqueue_due(self) -> int:
        from .capabilities import local_scrapers_available
        if not local_scrapers_available():
            return 0
        now = iso_now()
        count = 0
        with self.db.connect() as connection:
            due = connection.execute(
                """SELECT c.id FROM companies c WHERE c.state='active' AND c.archived_at IS NULL
                AND c.next_run_at IS NOT NULL AND c.next_run_at<=?
                AND (NOT EXISTS(SELECT 1 FROM company_preset_memberships pm WHERE pm.company_id=c.id)
                  OR EXISTS(SELECT 1 FROM company_preset_memberships pm
                    JOIN preset_pack_state ps ON ps.preset_id=pm.preset_id
                    WHERE pm.company_id=c.id AND ps.hidden_at IS NULL))
                AND NOT EXISTS(SELECT 1 FROM runs r WHERE r.company_id=c.id AND r.status IN ('queued','running'))""", (now,)
            ).fetchall()
        for row in due:
            self.db.enqueue_run(row["id"], "scrape", reuse_active=True)
            count += 1
        return count

    async def loop(self) -> None:
        while not self._stopping:
            self.enqueue_due()
            from .capabilities import local_scrapers_available
            claimed = self.db.claim_run(self.owner) if local_scrapers_available() else None
            if claimed:
                await self.process(claimed)
                continue
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=self.poll_seconds)
            except TimeoutError:
                pass

    async def _progress(self, run: ClaimedRun, progress: int, message: str) -> None:
        payload = self.db.update_run(run.id, progress=progress, message=message) or {}
        await self.emit({"type": "run.progress", "run": payload})

    async def process(self, run: ClaimedRun) -> None:
        company = self.db.get_company(run.company_id)
        if not company:
            self.db.update_run(run.id, status="failed", finished_at=iso_now(), message="Company no longer exists")
            return
        if company.get("archived_at") or self.db.is_company_hidden(run.company_id):
            self.db.update_run(
                run.id, status="cancelled", progress=100, finished_at=iso_now(),
                message="Cancelled because the tracker is archived or hidden",
                lease_owner=None, lease_until=None,
            )
            return
        loop = asyncio.get_running_loop()
        detail = dict((self.db.get_run(run.id) or {}).get("progress_detail") or {})
        def telemetry(event):
            nonlocal detail
            if event.get("stage") != detail.get("stage"):
                detail = {key: value for key, value in detail.items() if key not in {"completed", "total", "unit"}}
            detail = {**detail, **event, "updated_at": iso_now()}
            payload = self.db.update_run(run.id, progress_detail_json=detail, message=event["message"],
                                         lease_until=(datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat())
            loop.call_soon_threadsafe(lambda: asyncio.create_task(self.emit({"type": "run.progress", "run": payload})))
        token = progress_callback.set(telemetry)
        preserved_state = None
        try:
            await self._progress(run, 10, f"Starting {run.kind}")
            report_progress("starting", f"Starting {run.kind}")
            settings = self.db.get_settings()
            selected_id = settings.get("ai_connection")
            ai = self.ai_connections.configured(selected_id) if selected_id and selected_id != "none" else None
            ai_model = settings.get("ai_model")
            if run.kind in {"build", "build_ai"}:
                recipe, jobs, adapter, provenance = await self.gateway.build(
                    company, ai, ai_model, force_ai=run.kind == "build_ai",
                    instruction_overrides=settings.get("agent_instruction_overrides", {}),
                    instruction_revision=int(settings.get("agent_instructions_revision") or 1))
                preserved_state = (self.db.get_company(company["id"]) or {}).get("state")
                saved = self.db.save_recipe(company["id"], recipe, "Validated successfully", activate=True)
                counts = self.db.upsert_jobs(company["id"], jobs, run.id, full_run=True)
                self.db.update_run(run.id, recipe_version=saved["version"],
                                   diagnostics_json=provenance or {}, **counts)
                self.db.update_company(company["id"], {"adapter": adapter, "state": "active"})
            elif run.kind == "repair":
                current = self.db.get_recipe(company["id"])
                if not current:
                    raise RuntimeError("No active recipe to repair")
                recent = self.db.list_runs(company["id"], limit=5)
                diagnostic_lines = [
                    str(item.get("message") or "")
                    for item in recent if item.get("status") == "failed"
                ]
                diagnostic_lines.append(
                    "Current stored rich-field coverage: "
                    + json.dumps(self.db.job_rich_field_coverage(company["id"]), sort_keys=True)
                )
                diagnostics = "\n".join(filter(None, diagnostic_lines))
                recipe, jobs, provenance = await self.gateway.repair(
                    company, current["recipe"], diagnostics, ai, ai_model,
                    instruction_overrides=settings.get("agent_instruction_overrides", {}),
                    instruction_revision=int(settings.get("agent_instructions_revision") or 1))
                preserved_state = (self.db.get_company(company["id"]) or {}).get("state")
                saved = self.db.save_recipe(company["id"], recipe, "Repair validated successfully", activate=True)
                counts = self.db.upsert_jobs(company["id"], jobs, run.id, full_run=True)
                self.db.update_run(run.id, recipe_version=saved["version"],
                                   diagnostics_json=provenance, **counts)
            elif run.kind == "catalog_update":
                update = self.db.get_catalog_update(run.id)
                if not update:
                    raise RuntimeError("Catalog update metadata is missing")
                candidate = self.db.get_recipe(company["id"], int(update["recipe_version"]))
                if not candidate or candidate.get("status") != "candidate":
                    raise RuntimeError("Catalog recipe candidate is unavailable")
                jobs, full_run, diagnostics = await self.gateway.run(candidate["recipe"])
                if not jobs:
                    raise RuntimeError("Catalog recipe returned zero valid jobs")
                preserved_state = (self.db.get_company(company["id"]) or {}).get("state")
                if not self.db.activate_recipe(company["id"], int(update["recipe_version"])):
                    raise RuntimeError("Catalog recipe could not be activated")
                counts = self.db.upsert_jobs(company["id"], jobs, run.id, full_run=full_run)
                self.db.set_catalog_source(
                    company["id"], company_key=update["catalog_company_id"],
                    monitor_id=update["catalog_monitor_id"], revision=int(update["catalog_revision"]),
                    sha256=update.get("catalog_sha256"), source_commit=update.get("source_commit"),
                )
                self.db.update_run(
                    run.id, recipe_version=int(update["recipe_version"]), full_run=int(full_run),
                    diagnostics_json={"message": diagnostics, "catalog_revision": update["catalog_revision"]},
                    **counts,
                )
            else:
                current = self.db.get_recipe(company["id"])
                if not current:
                    raise RuntimeError("No active scraper recipe")
                jobs, full_run, diagnostics = await self.gateway.run(current["recipe"])
                counts = self.db.upsert_jobs(company["id"], jobs, run.id, full_run=full_run)
                self.db.update_run(run.id, full_run=int(full_run), diagnostics_json={"message": diagnostics} if diagnostics else {}, **counts)
            fresh = self.db.get_company(company["id"]) or company
            preserve_pause = fresh.get("state") == "paused" or preserved_state == "paused"
            preserve_archive = bool(fresh.get("archived_at"))
            self.db.update_company(company["id"], {
                "last_run_at": iso_now(),
                "next_run_at": (
                    None if preserve_pause or preserve_archive
                    else next_occurrence(fresh, default_timezone=settings["timezone"])
                ),
                "consecutive_failures": 0,
                "state": "archived" if preserve_archive else "paused" if preserve_pause else "active",
            })
            final_status = "complete" if (self.db.get_run(run.id) or {}).get("full_run", True) else "partial"
            result = self.db.update_run(run.id, status=final_status, progress=100, message="Completed" if final_status == "complete" else "Completed with partial source coverage", finished_at=iso_now(), lease_owner=None, lease_until=None)
            await self.emit({"type": "run.completed", "run": result})
        except Exception as exc:
            failures = int(company.get("consecutive_failures") or 0) + 1
            build_failed = run.kind in {"build", "build_ai"} and company.get("state") == "building"
            state = "needs_attention" if build_failed or failures >= 2 else company.get("state", "active")
            fresh = self.db.get_company(company["id"]) or company
            if fresh.get("state") in {"paused", "archived"}:
                state = fresh["state"]
            self.db.update_company(company["id"], {"consecutive_failures": failures, "state": state, "last_run_at": iso_now()})
            result = self.db.update_run(run.id, status="failed", progress=100, message=str(exc)[:2000],
                                        diagnostics_json={"error_type": type(exc).__name__,
                                                          **({"category": exc.category.value, "detail": exc.diagnostics} if isinstance(exc, AIConnectionError) else {})}, finished_at=iso_now(), lease_owner=None, lease_until=None)
            await self.emit({"type": "run.failed", "run": result})
        finally:
            progress_callback.reset(token)
