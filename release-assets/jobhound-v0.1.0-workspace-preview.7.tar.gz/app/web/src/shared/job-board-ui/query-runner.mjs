import { queryJobs } from './query.mjs';
// The public feed supports 200 MB. Allow bounded room for saved/local overlays
// and query metadata; count raw bytes before decoding, including UTF-8 text.
const maxInputBytes = 256 * 1024 * 1024;
try {
  const chunks = [];
  let bytes = 0;
  for await (const chunk of process.stdin) {
    bytes += chunk.length;
    if (bytes > maxInputBytes) {
      process.stderr.write('JOBHOUND_QUERY_INPUT_LIMIT');
      process.exitCode = 2;
      break;
    }
    chunks.push(chunk);
  }
  if (!process.exitCode) {
    const payload = JSON.parse(Buffer.concat(chunks, bytes).toString('utf8'));
    process.stdout.write(JSON.stringify(queryJobs(payload)));
  }
} catch (error) {
  process.stderr.write(String(error.message));
  process.exitCode = 1;
}
