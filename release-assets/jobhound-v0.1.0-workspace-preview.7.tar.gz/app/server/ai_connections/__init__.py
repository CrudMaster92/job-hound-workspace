"""Unified outbound AI connection boundary for JobHound."""

from .cli import ClaudeConnection, CodexConnection, HermesConnection, OpenClawConnection
from .models import (
    AIConnectionError,
    AIModel,
    ConnectionCapabilities,
    ConnectionErrorCategory,
    ConnectionStatus,
)
from .login import AILoginManager, LoginRun
from .openrouter import OpenRouterConnection
from .registry import AIConnection, AIConnectionRegistry, create_default_registry
from .secret_store import KeyringSecretStore, SecretStore, default_secret_store

__all__ = [
    "AIConnection",
    "AIConnectionError",
    "AIConnectionRegistry",
    "AILoginManager",
    "AIModel",
    "ClaudeConnection",
    "CodexConnection",
    "ConnectionCapabilities",
    "ConnectionErrorCategory",
    "ConnectionStatus",
    "HermesConnection",
    "KeyringSecretStore",
    "LoginRun",
    "OpenClawConnection",
    "OpenRouterConnection",
    "SecretStore",
    "create_default_registry",
    "default_secret_store",
]
