"""Cancellable execution for bounded local AI subprocesses."""

from __future__ import annotations

import subprocess
import time
from threading import Event
from typing import Any, Callable


class ProviderCancelled(RuntimeError):
    pass


def run_cancellable(
    command: list[str], *, cancel_event: Event, timeout: float,
    popen: Callable[..., Any] = subprocess.Popen, input: str | None = None,
) -> subprocess.CompletedProcess[str]:
    process = popen(
        command, stdin=subprocess.PIPE if input is not None else None,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        encoding="utf-8", errors="replace",
    )
    deadline = time.monotonic() + timeout
    while True:
        if cancel_event.is_set():
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)
            raise ProviderCancelled("AI provider request was cancelled")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            process.kill()
            process.wait(timeout=2)
            raise subprocess.TimeoutExpired(command, timeout)
        try:
            stdout, stderr = process.communicate(input=input, timeout=min(0.1, remaining))
            return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
        except subprocess.TimeoutExpired:
            # communicate() buffers partial output internally; input must only be supplied once.
            input = None

