"""Read-only recipe trials confined to the detector's existing host allowlist."""
import json
import sys
from urllib.parse import urlsplit
from pydantic import BaseModel, ConfigDict
from ..scrapers.ai_contract import ScraperRecipeProposal, compile_recipe_proposal
from .validation import json_schema
from .cancellation import run_cancellable


class Trial(BaseModel):
    model_config=ConfigDict(extra='forbid')
    proposal: ScraperRecipeProposal


class RecipeTools:
    def __init__(self, recipe):
        self.hosts=set(recipe.get('allowed_hosts',[]))
        self.careers_url=recipe.get('careers_url')
        self.schemas=[{'type':'function','function':{'name':'validate_scraper_candidate',
            'description':'Run a bounded validation trial on the existing company source hosts. Does not install or activate a recipe. Interactive browser control is unavailable.',
            'parameters':json_schema(Trial)}}]

    def call(self,name,args,cancellation,activity=None):
        if name!='validate_scraper_candidate': raise ValueError('Unsupported recipe tool')
        trial=Trial.model_validate(args)
        recipe=compile_recipe_proposal(trial.proposal.model_dump(mode='json'))
        if not set(recipe['allowed_hosts']).issubset(self.hosts):
            raise ValueError('Validation cannot add hosts beyond the detected company source')
        if urlsplit(recipe['careers_url']).hostname != urlsplit(self.careers_url or '').hostname:
            raise ValueError('Validation must remain on the selected company')
        if recipe['strategy']=='playwright':
            return {'valid':False,'errors':['Browser validation is deferred to the normal recipe validator; interactive browser use is coming soon.']}
        if activity: activity('validating_recipe')
        result=run_cancellable([sys.executable,'-m','server.ai_connections.recipe_trial'],input=json.dumps(recipe),cancel_event=cancellation,timeout=45)
        if result.returncode: raise ValueError('Recipe trial failed; check the source and recipe')
        return json.loads(result.stdout)
