"""Structured-response helpers shared by CLI and HTTP connections."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

from pydantic import BaseModel, TypeAdapter, ValidationError

from .models import AIConnectionError, ConnectionErrorCategory


Schema = type[BaseModel] | TypeAdapter[Any] | dict[str, Any]


def json_schema(schema: Schema) -> dict[str, Any]:
    if isinstance(schema, dict):
        value = deepcopy(schema)
    elif isinstance(schema, TypeAdapter):
        value = schema.json_schema()
    else:
        value = schema.model_json_schema()
    value = _strict_provider_schema(value)
    _validate_provider_schema(value)
    return value


def _strict_provider_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Normalize Pydantic output for strict structured-output providers.

    Codex requires every declared object property in ``required`` even when
    the application model supplies a default. Provider schemas also reject
    some annotation-only keywords such as Pydantic URL formats. JobHound still
    validates the returned payload against the original Pydantic model.
    """

    def visit(node: Any) -> None:
        if isinstance(node, dict):
            node.pop("default", None)
            node.pop("format", None)
            # Strict Structured Outputs accepts only a subset of JSON Schema.
            # The application model still enforces collection uniqueness after
            # the provider returns its response.
            node.pop("uniqueItems", None)
            properties = node.get("properties")
            if node.get("type") == "object" and isinstance(properties, dict):
                node["required"] = list(properties)
                node["additionalProperties"] = False
            for key, value in node.items():
                # Property/definition names are user fields, not schema keywords.
                # In particular a field named "format" must not be stripped.
                if key in {"properties", "$defs", "definitions", "patternProperties"} and isinstance(value, dict):
                    for child in value.values():
                        visit(child)
                else:
                    visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    visit(schema)
    return schema


def _validate_provider_schema(schema: dict[str, Any]) -> None:
    """Fail locally when a strict provider would reject an object schema."""

    errors: list[str] = []

    def visit(node: Any, path: str, *, root: bool = False) -> None:
        if isinstance(node, dict):
            if root and node.get("type") != "object":
                errors.append(f"{path} must be an object")
            if node.get("type") == "object":
                if node.get("additionalProperties") is not False:
                    errors.append(f"{path}.additionalProperties must be false")
                properties = node.get("properties")
                if isinstance(properties, dict):
                    required = node.get("required")
                    if not isinstance(required, list) or set(required) != set(properties):
                        errors.append(f"{path}.required must contain every property")
            for key, value in node.items():
                visit(value, f"{path}/{key}")
        elif isinstance(node, list):
            for index, value in enumerate(node):
                visit(value, f"{path}/{index}")

    visit(schema, "$", root=True)
    if errors:
        raise AIConnectionError(
            ConnectionErrorCategory.CONFIGURATION,
            "JobHound generated an incompatible strict response schema: " + "; ".join(errors[:5]),
        )


def validate_payload(payload: Any, schema: Schema) -> dict[str, Any]:
    try:
        if isinstance(schema, dict):
            _validate_json_schema(payload, schema)
            return payload
        adapter = schema if isinstance(schema, TypeAdapter) else TypeAdapter(schema)
        value = adapter.validate_python(payload)
        if isinstance(value, BaseModel):
            return value.model_dump(mode="json")
        if not isinstance(value, dict):
            raise ValueError("the root value must be an object")
        return value
    except (ValidationError, ValueError, TypeError) as exc:
        raise AIConnectionError(
            ConnectionErrorCategory.INVALID_RESPONSE,
            f"AI connection returned an invalid structured response: {exc}",
        ) from exc


def _validate_json_schema(value: Any, schema: dict[str, Any], path: str = "response") -> None:
    """Validate the bounded JSON-Schema subset emitted by Pydantic contracts.

    Application callers should normally pass their Pydantic model. Supporting
    raw schemas keeps the adapter contract useful without adding a second JSON
    Schema dependency merely for provider-boundary validation.
    """

    expected = schema.get("type")
    matches = {
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "number": isinstance(value, (int, float)) and not isinstance(value, bool),
        "boolean": isinstance(value, bool),
        "null": value is None,
    }
    if isinstance(expected, str) and expected in matches and not matches[expected]:
        raise ValueError(f"{path} must be {expected}")
    if isinstance(expected, list) and not any(matches.get(item, False) for item in expected):
        raise ValueError(f"{path} has an invalid type")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(f"{path} is not an allowed value")
    if isinstance(value, dict):
        required = schema.get("required", [])
        missing = [key for key in required if key not in value]
        if missing:
            raise ValueError(f"{path} is missing required fields: {', '.join(missing)}")
        properties = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            extras = set(value).difference(properties)
            if extras:
                raise ValueError(f"{path} has unexpected fields: {', '.join(sorted(extras))}")
        for key, child in properties.items():
            if key in value and isinstance(child, dict):
                _validate_json_schema(value[key], child, f"{path}.{key}")
    if isinstance(value, list) and isinstance(schema.get("items"), dict):
        for index, item in enumerate(value):
            _validate_json_schema(item, schema["items"], f"{path}[{index}]")


def extract_json(raw: str) -> dict[str, Any]:
    """Extract an object from plain, fenced, or common CLI envelope output."""

    candidate = raw.strip()
    if candidate.startswith("```"):
        first_newline = candidate.find("\n")
        if first_newline >= 0:
            candidate = candidate[first_newline + 1 :]
        if candidate.endswith("```"):
            candidate = candidate[:-3].rstrip()
    try:
        value = json.loads(candidate)
    except json.JSONDecodeError:
        start, end = candidate.find("{"), candidate.rfind("}")
        if start < 0 or end <= start:
            raise AIConnectionError(
                ConnectionErrorCategory.INVALID_RESPONSE,
                "AI connection did not return a JSON object",
            )
        try:
            value = json.loads(candidate[start : end + 1])
        except json.JSONDecodeError as exc:
            raise AIConnectionError(
                ConnectionErrorCategory.INVALID_RESPONSE,
                "AI connection returned malformed JSON",
            ) from exc

    for key in ("result", "response", "content"):
        if isinstance(value, dict) and isinstance(value.get(key), str):
            return extract_json(value[key])
    if not isinstance(value, dict):
        raise AIConnectionError(
            ConnectionErrorCategory.INVALID_RESPONSE,
            "AI connection returned JSON with a non-object root",
        )
    return value
