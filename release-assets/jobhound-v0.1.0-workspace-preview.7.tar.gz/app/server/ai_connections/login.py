"""Bounded host-only browser login processes for local subscription CLIs."""

from __future__ import annotations

import subprocess
import threading
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Callable

from .models import AIConnectionError, ConnectionErrorCategory
from .registry import AIConnectionRegistry


PopenFactory = Callable[..., Any]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class LoginRun:
    id: str
    connection: str
    state: str
    started_at: str
    finished_at: str | None = None
    message: str = "Complete the sign-in in the browser opened on this computer."

    def snapshot(self) -> dict[str, Any]:
        return asdict(self)


class AILoginManager:
    """Runs one interactive provider login per connection without reading credentials."""

    COMMANDS = {"codex": ("login",), "claude": ("auth", "login")}

    def __init__(
        self,
        connections: AIConnectionRegistry,
        *,
        popen: PopenFactory = subprocess.Popen,
        timeout_seconds: int = 600,
    ) -> None:
        self.connections = connections
        self.popen = popen
        self.timeout_seconds = timeout_seconds
        self._lock = threading.Lock()
        self._runs: dict[str, LoginRun] = {}
        self._processes: dict[str, Any] = {}

    def start(self, connection_id: str) -> dict[str, Any]:
        if connection_id not in self.COMMANDS:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                "Browser sign-in is available only for Codex and Claude",
            )
        connection = self.connections.get(connection_id)
        status = connection.status()
        executable = getattr(connection, "executable", None)
        if not status.available or not executable:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                status.required_action or f"Install {status.label} before signing in",
            )
        if status.ready:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                f"{status.label} is already signed in",
            )
        with self._lock:
            existing = self._runs.get(connection_id)
            if existing and existing.state == "running":
                return existing.snapshot()
            run = LoginRun(
                id=uuid.uuid4().hex,
                connection=connection_id,
                state="running",
                started_at=_now(),
            )
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            try:
                process = self.popen(
                    [executable, *self.COMMANDS[connection_id]],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=flags,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                raise AIConnectionError(
                    ConnectionErrorCategory.UNAVAILABLE,
                    f"Could not start {status.label} sign-in: {str(exc)[:300]}",
                ) from exc
            self._runs[connection_id] = run
            self._processes[connection_id] = process
            threading.Thread(
                target=self._wait,
                args=(connection_id, process),
                name=f"jobhound-{connection_id}-login",
                daemon=True,
            ).start()
            return run.snapshot()

    def status(self, connection_id: str) -> dict[str, Any]:
        if connection_id not in self.COMMANDS:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                "Browser sign-in is available only for Codex and Claude",
            )
        with self._lock:
            run = self._runs.get(connection_id)
            if run:
                return run.snapshot()
        connection = self.connections.get(connection_id).status()
        return LoginRun(
            id="",
            connection=connection_id,
            state="succeeded" if connection.ready else "idle",
            started_at="",
            finished_at=None,
            message=f"{connection.label} is ready" if connection.ready else "No sign-in is running.",
        ).snapshot()

    def _wait(self, connection_id: str, process: Any) -> None:
        state = "failed"
        message = "Sign-in did not complete. Try again or run the provider login command manually."
        try:
            return_code = process.wait(timeout=self.timeout_seconds)
            status = self.connections.get(connection_id).status()
            if return_code == 0 and status.ready:
                state, message = "succeeded", f"{status.label} sign-in completed."
            elif status.required_action:
                message = status.required_action
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            state = "timed_out"
            message = "Sign-in timed out. Start it again when you are ready to complete the browser flow."
        except (OSError, subprocess.SubprocessError):
            message = "The sign-in process ended unexpectedly. Try again."
        finally:
            with self._lock:
                run = self._runs.get(connection_id)
                if run:
                    run.state = state
                    run.finished_at = _now()
                    run.message = message
                self._processes.pop(connection_id, None)

    def close(self) -> None:
        with self._lock:
            processes = list(self._processes.values())
            self._processes.clear()
        for process in processes:
            try:
                if process.poll() is None:
                    process.kill()
            except (OSError, subprocess.SubprocessError):
                pass
