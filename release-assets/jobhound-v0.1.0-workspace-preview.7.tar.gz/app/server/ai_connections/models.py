"""Stable public types for outbound AI connections."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ConnectionErrorCategory(str, Enum):
    AUTHENTICATION = "authentication"
    BILLING = "billing"
    POLICY = "policy"
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    UNAVAILABLE = "unavailable"
    INVALID_RESPONSE = "invalid_response"
    CONFIGURATION = "configuration"
    COMPATIBILITY = "compatibility"


class AIConnectionError(RuntimeError):
    """A safe, categorized error suitable for returning through application APIs."""

    def __init__(self, category: ConnectionErrorCategory, detail: str) -> None:
        self.category = category
        self.detail = detail
        self.diagnostics = detail[:1000]
        super().__init__(detail)


class ConnectionCapabilities(BaseModel):
    model_config = ConfigDict(extra="forbid")

    structured_output: bool = True
    model_selection: bool = False
    model_catalog: bool = False
    web_browsing: bool = False
    tool_use: bool = False
    web_search: bool = False
    page_reading: bool = False
    file_creation: bool = True
    curated_skills: bool = True
    browser_interaction: bool = False


class ConnectionStatus(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    available: bool
    authenticated: bool
    ready: bool
    authentication_method: str
    detail: str
    active_model: str | None = None
    capabilities: ConnectionCapabilities = Field(default_factory=ConnectionCapabilities)
    required_action: str | None = None


class AIModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    context_length: int | None = None
    supports_browsing: bool = False
    supported_parameters: list[str] = Field(default_factory=list)
    pricing: dict[str, Any] = Field(default_factory=dict)
    reasoning_efforts: list[str] = Field(default_factory=list)
    default_reasoning_effort: str | None = None
    is_default: bool = False
