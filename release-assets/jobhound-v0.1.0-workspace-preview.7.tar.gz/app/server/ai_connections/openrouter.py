"""Direct, fixed-endpoint OpenRouter connection."""

from __future__ import annotations

from threading import Event, Thread
from typing import Any

import httpx

from .models import (
    AIConnectionError,
    AIModel,
    ConnectionCapabilities,
    ConnectionErrorCategory,
    ConnectionStatus,
)
from .secret_store import SecretStore, default_secret_store
from .validation import Schema, extract_json, json_schema, validate_payload
from .cancellation import ProviderCancelled


class OpenRouterConnection:
    id = "openrouter"
    label = "OpenRouter"
    API_ROOT = "https://openrouter.ai/api/v1"
    SECRET_NAME = "openrouter-api-key"
    capabilities = ConnectionCapabilities(
        structured_output=True,
        model_selection=True,
        model_catalog=True,
        web_browsing=True, tool_use=True, web_search=True, page_reading=True,
        file_creation=True, curated_skills=True,
    )

    def __init__(
        self,
        *,
        secret_store: SecretStore | None = None,
        client: httpx.Client | None = None,
        timeout_seconds: float = 60,
    ) -> None:
        self.secret_store = secret_store or default_secret_store()
        self.timeout_seconds = timeout_seconds
        self._owns_client = client is None
        self.client = client or httpx.Client(
            timeout=timeout_seconds, follow_redirects=False, trust_env=False,
        )

    def _key(self) -> str | None:
        try:
            return self.secret_store.get(self.SECRET_NAME)
        except Exception:
            return None

    @staticmethod
    def _headers(key: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://127.0.0.1",
            "X-Title": "JobHound",
        }

    def status(self) -> ConnectionStatus:
        key = self._key()
        if not key:
            return ConnectionStatus(
                id=self.id,
                label=self.label,
                available=True,
                authenticated=False,
                ready=False,
                authentication_method="OpenRouter API key in OS credential store",
                detail="No OpenRouter credential is configured",
                capabilities=self.capabilities,
                required_action="Add and validate an OpenRouter API key on the host computer",
            )
        failure: AIConnectionError | None = None
        try:
            response = self.client.get(f"{self.API_ROOT}/models/user", headers=self._headers(key))
            self._raise_for_response(response)
        except httpx.TimeoutException:
            failure = AIConnectionError(ConnectionErrorCategory.TIMEOUT, "OpenRouter timed out")
        except httpx.HTTPError:
            failure = AIConnectionError(ConnectionErrorCategory.UNAVAILABLE, "OpenRouter is unavailable")
        except AIConnectionError as exc:
            failure = exc
        if failure is None:
            return ConnectionStatus(
                id=self.id,
                label=self.label,
                available=True,
                authenticated=True,
                ready=True,
                authentication_method="OpenRouter API key in OS credential store",
                detail="OpenRouter credential validated",
                capabilities=self.capabilities,
            )
        return ConnectionStatus(
            id=self.id,
            label=self.label,
            available=failure.category not in {ConnectionErrorCategory.UNAVAILABLE, ConnectionErrorCategory.TIMEOUT},
            authenticated=failure.category not in {ConnectionErrorCategory.AUTHENTICATION},
            ready=False,
            authentication_method="OpenRouter API key in OS credential store",
            detail=failure.detail,
            capabilities=self.capabilities,
            required_action="Check the OpenRouter credential or service status",
        )

    def set_credential(self, value: str) -> None:
        key = value.strip()
        if not key:
            raise AIConnectionError(ConnectionErrorCategory.CONFIGURATION, "OpenRouter API key is required")
        try:
            response = self.client.get(f"{self.API_ROOT}/models/user", headers=self._headers(key))
            self._raise_for_response(response)
            self.secret_store.set(self.SECRET_NAME, key)
        except httpx.TimeoutException as exc:
            raise AIConnectionError(ConnectionErrorCategory.TIMEOUT, "OpenRouter timed out") from exc
        except httpx.HTTPError as exc:
            raise AIConnectionError(ConnectionErrorCategory.UNAVAILABLE, "OpenRouter is unavailable") from exc
        except AIConnectionError:
            raise
        except Exception as exc:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                "The OpenRouter credential could not be stored in the OS credential store",
            ) from exc

    def delete_credential(self) -> None:
        try:
            self.secret_store.delete(self.SECRET_NAME)
        except Exception as exc:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                "The OpenRouter credential could not be removed from the OS credential store",
            ) from exc

    def list_models(self, *, browsing: bool = False) -> list[AIModel]:
        key = self._require_key()
        try:
            response = self.client.get(f"{self.API_ROOT}/models/user", headers=self._headers(key))
        except httpx.TimeoutException as exc:
            raise AIConnectionError(ConnectionErrorCategory.TIMEOUT, "OpenRouter timed out") from exc
        except httpx.HTTPError as exc:
            raise AIConnectionError(ConnectionErrorCategory.UNAVAILABLE, "OpenRouter is unavailable") from exc
        self._raise_for_response(response)
        try:
            items = response.json().get("data", [])
        except (ValueError, AttributeError) as exc:
            raise AIConnectionError(ConnectionErrorCategory.INVALID_RESPONSE, "OpenRouter returned an invalid model catalog") from exc
        models: list[AIModel] = []
        for item in items:
            if not isinstance(item, dict) or not item.get("id"):
                continue
            parameters = [str(value) for value in item.get("supported_parameters", [])]
            supports_structured = bool({"structured_outputs", "response_format"}.intersection(parameters))
            supports_tools = bool({"tools", "tool_choice"}.intersection(parameters))
            if not supports_structured or not supports_tools:
                continue
            models.append(AIModel(
                id=item["id"],
                name=item.get("name") or item["id"],
                context_length=item.get("context_length"),
                supports_browsing=supports_tools,
                supported_parameters=parameters,
                pricing=item.get("pricing") if isinstance(item.get("pricing"), dict) else {},
            ))
        return models

    def run_structured(
        self,
        prompt: str,
        schema: Schema,
        *,
        model: str | None = None,
        browsing: bool = False,
        cancel_event: Event | None = None,
        activity=None,
        tool_context=None,
    ) -> dict[str, Any]:
        from .agent_loop import run
        return run(self, prompt, schema, model=model, browsing=browsing,
                   cancel_event=cancel_event, activity=activity, tool_context=tool_context)

    def _post_chat(self, body: dict[str, Any], key: str,
                   cancel_event: Event | None) -> httpx.Response:
        url = f"{self.API_ROOT}/chat/completions"
        if cancel_event is None or not self._owns_client:
            return self.client.post(url, headers=self._headers(key), json=body)
        if cancel_event.is_set():
            raise ProviderCancelled("AI provider request was cancelled")
        client = httpx.Client(
            timeout=self.timeout_seconds, follow_redirects=False, trust_env=False,
        )
        complete = Event()

        def interrupt() -> None:
            while not complete.wait(0.1):
                if cancel_event.is_set():
                    # This per-turn client owns only this request, so closing it cannot affect
                    # settings checks, model catalogs, or another chat turn.
                    client.close()
                    return

        Thread(target=interrupt, name="jobhound-openrouter-cancel", daemon=True).start()
        try:
            response = client.post(url, headers=self._headers(key), json=body)
            if cancel_event.is_set():
                raise ProviderCancelled("AI provider request was cancelled")
            return response
        except httpx.HTTPError as exc:
            if cancel_event.is_set():
                raise ProviderCancelled("AI provider request was cancelled") from exc
            raise
        finally:
            complete.set()
            client.close()

    def _require_key(self) -> str:
        key = self._key()
        if not key:
            raise AIConnectionError(ConnectionErrorCategory.AUTHENTICATION, "No OpenRouter credential is configured")
        return key

    @staticmethod
    def _raise_for_response(response: httpx.Response) -> None:
        if response.is_success:
            return
        status = response.status_code
        if status in {401, 403}:
            category, detail = ConnectionErrorCategory.AUTHENTICATION, "OpenRouter rejected the credential"
        elif status == 402:
            category, detail = ConnectionErrorCategory.BILLING, "OpenRouter billing or credits require attention"
        elif status == 429:
            category, detail = ConnectionErrorCategory.RATE_LIMIT, "OpenRouter rate limit reached"
        elif status in {408, 504}:
            category, detail = ConnectionErrorCategory.TIMEOUT, "OpenRouter timed out"
        elif status in {400, 404, 409, 422}:
            category, detail = ConnectionErrorCategory.POLICY, "OpenRouter rejected the requested model or parameters"
        else:
            category, detail = ConnectionErrorCategory.UNAVAILABLE, "OpenRouter is unavailable"
        raise AIConnectionError(category, detail)
