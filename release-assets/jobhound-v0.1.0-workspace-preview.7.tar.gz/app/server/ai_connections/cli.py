"""Fresh, bounded CLI-backed AI connections."""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from threading import Event
from typing import Any, Callable

from .models import (
    AIConnectionError,
    ConnectionCapabilities,
    ConnectionErrorCategory,
    ConnectionStatus,
)
from .validation import Schema, extract_json, json_schema, validate_payload
from .cancellation import ProviderCancelled, run_cancellable
from .progress import run_with_activity


Runner = Callable[..., subprocess.CompletedProcess[str]]
Resolver = Callable[[str], str | None]


class CLIConnection:
    """Base class for a single isolated invocation of a local agent command."""

    id = ""
    label = ""
    executable_name = ""
    authentication_method = "local subscription/configuration"
    capabilities = ConnectionCapabilities(model_selection=True)
    timeout_seconds = 240

    def __init__(
        self,
        *,
        runner: Runner = subprocess.run,
        resolver: Resolver = shutil.which,
        executable: str | None = None,
    ) -> None:
        self.runner = runner
        self.executable = executable or resolver(self.executable_name)

    def _auth_command(self) -> list[str] | None:
        return None

    def _is_authenticated(self, result: subprocess.CompletedProcess[str]) -> bool:
        return result.returncode == 0

    def status(self) -> ConnectionStatus:
        if not self.executable:
            return ConnectionStatus(
                id=self.id,
                label=self.label,
                available=False,
                authenticated=False,
                ready=False,
                authentication_method=self.authentication_method,
                detail=f"{self.executable_name} is not installed or is not on PATH",
                capabilities=self.capabilities,
                required_action=f"Install and sign in to {self.label}",
            )
        command = self._auth_command()
        if command is None:
            return ConnectionStatus(
                id=self.id,
                label=self.label,
                available=True,
                authenticated=True,
                ready=True,
                authentication_method=self.authentication_method,
                detail="Local command and configuration found",
                capabilities=self.capabilities,
            )
        try:
            result = self.runner(
                command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return ConnectionStatus(
                id=self.id,
                label=self.label,
                available=True,
                authenticated=False,
                ready=False,
                authentication_method=self.authentication_method,
                detail=_safe_detail(str(exc)),
                capabilities=self.capabilities,
                required_action=f"Sign in to {self.label}",
            )
        authenticated = self._is_authenticated(result)
        detail = _safe_detail(result.stdout or result.stderr or ("Authenticated" if authenticated else "Not authenticated"))
        return ConnectionStatus(
            id=self.id,
            label=self.label,
            available=True,
            authenticated=authenticated,
            ready=authenticated,
            authentication_method=self.authentication_method,
            detail=detail,
            capabilities=self.capabilities,
            required_action=None if authenticated else f"Sign in to {self.label}",
        )

    def _command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str]:
        raise NotImplementedError

    def _read_output(self, result: subprocess.CompletedProcess[str], output_path: Path) -> str:
        return result.stdout

    def _fallback_command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str] | None:
        return None

    def run_structured(
        self,
        prompt: str,
        schema: Schema,
        *,
        model: str | None = None,
        browsing: bool = False,
        cancel_event: Event | None = None,
        reasoning_effort: str | None = None,
        activity: Callable[[str], None] | None = None,
    ) -> dict[str, Any]:
        state = self.status()
        if not state.ready or not self.executable:
            raise AIConnectionError(ConnectionErrorCategory.AUTHENTICATION, state.detail)
        requested_schema = json_schema(schema)
        bounded_prompt = (
            f"{prompt.rstrip()}\n\nReturn ONLY JSON matching this JSON Schema exactly:\n"
            f"{json.dumps(requested_schema, separators=(',', ':'))}"
            "\nNever call JobHound, its MCP server, or any state-changing tool. "
            "JobHound will validate and execute the returned proposal itself."
        )
        if not browsing:
            bounded_prompt += "\nDo not browse the web or call external tools."
        with tempfile.TemporaryDirectory(prefix=f"jobhound-{self.id}-") as temp_dir:
            schema_path = Path(temp_dir, "schema.json")
            output_path = Path(temp_dir, "response.json")
            schema_path.write_text(json.dumps(requested_schema), encoding="utf-8")
            command = self._command(bounded_prompt, schema_path, output_path, model, browsing)
            if self.id == "codex" and reasoning_effort is not None:
                command[1:1] = ["-c", f"model_reasoning_effort={json.dumps(reasoning_effort)}"]
            if self.id == "codex" and activity is not None:
                command.insert(command.index("exec") + 1, "--json")
            try:
                result = (run_with_activity(command, input=bounded_prompt,
                    cancel_event=cancel_event, timeout=self.timeout_seconds, activity=activity)
                    if self.id == "codex" and activity is not None and self.runner is subprocess.run
                    else run_cancellable(
                    command, input=bounded_prompt, cancel_event=cancel_event,
                    timeout=self.timeout_seconds,
                ) if cancel_event is not None else self.runner(
                    command, input=bounded_prompt, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=self.timeout_seconds,
                ))
            except ProviderCancelled:
                raise
            except subprocess.TimeoutExpired as exc:
                raise AIConnectionError(ConnectionErrorCategory.TIMEOUT, f"{self.label} timed out") from exc
            except (OSError, subprocess.SubprocessError) as exc:
                raise AIConnectionError(
                    ConnectionErrorCategory.UNAVAILABLE,
                    f"{self.label} could not be started: {_safe_detail(str(exc))}",
                ) from exc
            if result.returncode != 0:
                fallback = self._fallback_command(
                    bounded_prompt, schema_path, output_path, model, browsing,
                )
                if fallback is not None:
                    try:
                        result = (run_cancellable(
                            fallback, input=bounded_prompt, cancel_event=cancel_event,
                            timeout=self.timeout_seconds,
                        ) if cancel_event is not None else self.runner(
                            fallback, input=bounded_prompt, capture_output=True, text=True,
                            encoding="utf-8", errors="replace", timeout=self.timeout_seconds,
                        ))
                    except ProviderCancelled:
                        raise
                    except subprocess.TimeoutExpired as exc:
                        raise AIConnectionError(ConnectionErrorCategory.TIMEOUT, f"{self.label} timed out") from exc
                    except (OSError, subprocess.SubprocessError) as exc:
                        raise AIConnectionError(
                            ConnectionErrorCategory.UNAVAILABLE,
                            f"{self.label} could not be started: {_safe_detail(str(exc))}",
                        ) from exc
            if result.returncode != 0:
                detail = _safe_detail(result.stderr or result.stdout or "Agent command failed")
                category = ConnectionErrorCategory.UNAVAILABLE
                message = f"{self.label} failed: {detail}"
                if self.id == "codex":
                    if "requires a newer version" in detail.lower():
                        category = ConnectionErrorCategory.COMPATIBILITY
                        message = "The selected model requires a newer Codex CLI. Update the standalone CLI in Connections â†’ OpenAI, then retry."
                    elif "503" in detail or "service unavailable" in detail.lower():
                        message = "OpenAI is temporarily unavailable (503). Please retry shortly."
                    elif "401" in detail or "not logged in" in detail.lower():
                        category = ConnectionErrorCategory.AUTHENTICATION
                        message = "Sign in to Codex on the host computer, then retry."
                error = AIConnectionError(category, message)
                error.diagnostics = detail
                raise error
            if activity:
                activity("checking_answer")
            return validate_payload(extract_json(self._read_output(result, output_path)), schema)

    def list_models(self, *, browsing: bool = False) -> list[Any]:
        return []


class CodexConnection(CLIConnection):
    id = "codex"
    label = "Codex"
    executable_name = "codex"
    authentication_method = "Codex subscription login"
    capabilities = ConnectionCapabilities(model_selection=True, model_catalog=True, web_browsing=True)

    def list_models(self, *, browsing: bool = False):
        from .codex_catalog import discover
        return discover(self.executable)


    def _auth_command(self) -> list[str]:
        return [self.executable, "login", "status"]  # type: ignore[list-item]

    def _is_authenticated(self, result: subprocess.CompletedProcess[str]) -> bool:
        # Current Codex releases return exit code 0 for the status command even
        # when no cached ChatGPT/API login exists, so the text is authoritative.
        detail = (result.stdout or result.stderr or "").strip().lower()
        return result.returncode == 0 and "not logged in" not in detail

    def _command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str]:
        command = [
            self.executable, "exec", "-", "--ephemeral", "--sandbox", "read-only",
            "--skip-git-repo-check", "--output-schema", str(schema_path),
            "--output-last-message", str(output_path),
        ]
        if model:
            command[2:2] = ["--model", model]
        if browsing:
            command.insert(1, "--search")
        return command

    def _read_output(self, result: subprocess.CompletedProcess[str], output_path: Path) -> str:
        return output_path.read_text(encoding="utf-8") if output_path.exists() else result.stdout


class ClaudeConnection(CLIConnection):
    id = "claude"
    label = "Claude"
    executable_name = "claude"
    authentication_method = "Claude subscription login"
    capabilities = ConnectionCapabilities(model_selection=True, web_browsing=True)

    def _auth_command(self) -> list[str]:
        return [self.executable, "auth", "status"]  # type: ignore[list-item]

    def _command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str]:
        command = [
            self.executable, "-p", prompt, "--output-format", "text", "--permission-mode", "plan",
        ]
        if model:
            command.extend(["--model", model])
        return command


class HermesConnection(CLIConnection):
    id = "hermes"
    label = "Hermes"
    executable_name = "hermes"
    authentication_method = "Hermes active provider configuration"
    capabilities = ConnectionCapabilities(model_selection=True, web_browsing=True)

    def _command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str]:
        # Current Hermes exposes programmatic one-shot execution through
        # ``chat -q``. Safe mode prevents project rules, plugins, memory, and
        # MCP servers from leaking into or recursively invoking this turn.
        command = [self.executable, "chat", "--safe-mode", "-q", prompt, "--quiet"]
        if model:
            command.extend(["--model", model])
        return command

    def _fallback_command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str]:
        # Compatibility with Hermes releases predating the chat subcommand.
        command = [self.executable, "--safe-mode", "--oneshot", prompt]
        if model:
            command.extend(["--model", model])
        return command


class OpenClawConnection(CLIConnection):
    id = "openclaw"
    label = "OpenClaw"
    executable_name = "openclaw"
    authentication_method = "OpenClaw default agent configuration"
    capabilities = ConnectionCapabilities(web_browsing=True)

    def _command(
        self, prompt: str, schema_path: Path, output_path: Path,
        model: str | None, browsing: bool,
    ) -> list[str]:
        return [self.executable, "agent", "--message", prompt, "--json"]


def _safe_detail(value: str) -> str:
    import re
    decoder = json.JSONDecoder()
    messages = []
    for match in re.finditer(r"\{", value):
        try:
            payload, _ = decoder.raw_decode(value[match.start():])
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, dict):
            continue
        error = payload.get("error")
        detail = payload.get("detail")
        if isinstance(error, dict) and isinstance(error.get("message"), str):
            detail = error["message"]
            if isinstance(error.get("code"), str):
                detail += f" ({error['code']})"
        if isinstance(detail, str) and detail not in messages:
            messages.append(detail)
    upgrade = next((m for m in messages if "requires a newer version" in m.lower()), None)
    # Unstructured logs may contain prompts: retain only error lines where possible.
    lines = [line.split("ERROR:", 1)[-1] for line in value.splitlines() if "ERROR:" in line]
    clean = " ".join((upgrade or (messages[-1] if messages else " ".join(lines) or value)).split())
    clean = re.sub(r"(?i)(bearer\s+|sk-)[a-z0-9_\-]+", "[redacted]", clean)
    return clean[-1000:] or "No detail was provided"
