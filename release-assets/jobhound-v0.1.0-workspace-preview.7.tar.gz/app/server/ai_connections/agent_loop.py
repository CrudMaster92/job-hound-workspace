"""Bounded OpenRouter tool loop. Application tools are explicitly supplied per task."""
import json
from threading import Event, Timer
import httpx
from .cancellation import ProviderCancelled
from .models import AIConnectionError, ConnectionErrorCategory
from .validation import extract_json, json_schema, validate_payload


def run(connection, prompt, schema, *, model, browsing=False, cancel_event=None, activity=None, tool_context=None):
    if not model:
        raise AIConnectionError(ConnectionErrorCategory.CONFIGURATION,'An OpenRouter model must be selected')
    requested=json_schema(schema)
    key=connection._require_key()
    expired=Event()
    stop=Event()
    def expire():
        expired.set()
        stop.set()
    timer=Timer(300,expire)
    timer.daemon=True
    timer.start()
    # The transport watches both user cancellation and the invocation deadline.
    class Cancellation:
        def set(self):
            stop.set()
        def is_set(self):
            return stop.is_set() or bool(cancel_event and cancel_event.is_set())
    cancellation=Cancellation()
    messages=[{'role':'user','content':prompt}]
    tools=tool_context.schemas if tool_context else []
    local_calls=0
    failures={}
    final=not (tools or browsing)
    corrected=False
    web_rounds=0
    try:
        for step in range(16):
            if cancellation.is_set():
                raise ProviderCancelled('Agent run cancelled')
            if activity: activity('checking_answer' if final else 'working')
            if len(json.dumps(messages).encode()) > 600_000:
                raise AIConnectionError(ConnectionErrorCategory.POLICY,'Agent context limit reached; narrow the task')
            body={'model':model,'messages':messages,'provider':{'require_parameters':True}}
            if final:
                body['response_format']={'type':'json_schema','json_schema':{'name':'jobhound_response','strict':True,'schema':requested}}
            else:
                active=list(tools)
                if browsing and web_rounds < 8:
                    # Reserve one search/fetch per server request, at most eight
                    # rounds. Unobservable unused capacity is not recycled.
                    active += [{'type':'openrouter:web_search','parameters':{'max_uses':1}},
                               {'type':'openrouter:web_fetch','parameters':{'engine':'openrouter','max_uses':1,'max_content_tokens':16000}}]
                    web_rounds+=1
                if active:
                    body['tools']=active
            try:
                response=connection._post_chat(body,key,cancellation)
            except httpx.TimeoutException as exc:
                raise AIConnectionError(ConnectionErrorCategory.TIMEOUT,'OpenRouter timed out') from exc
            except httpx.HTTPError as exc:
                raise AIConnectionError(ConnectionErrorCategory.UNAVAILABLE,'OpenRouter is unavailable') from exc
            connection._raise_for_response(response)
            if cancellation.is_set(): raise ProviderCancelled('Agent run cancelled')
            try:
                message=response.json()['choices'][0]['message']
                if not isinstance(message,dict): raise ValueError()
            except (KeyError,IndexError,TypeError,ValueError) as exc:
                raise AIConnectionError(ConnectionErrorCategory.INVALID_RESPONSE,'OpenRouter returned an invalid response envelope') from exc
            # Preserve reasoning_details and reasoning_content required by some providers.
            assistant={k:v for k,v in message.items() if k in {'content','tool_calls','reasoning','reasoning_content','reasoning_details'}}
            assistant['role']='assistant'
            messages.append(assistant)
            calls=message.get('tool_calls') or []
            if calls:
                if final or not tool_context:
                    raise AIConnectionError(ConnectionErrorCategory.INVALID_RESPONSE,'Unexpected tool call')
                for call in calls:
                    local_calls+=1
                    if local_calls>24: raise AIConnectionError(ConnectionErrorCategory.POLICY,'Agent tool limit reached')
                    if cancellation.is_set(): raise ProviderCancelled('Agent run cancelled')
                    try:
                        name=call['function']['name']
                        raw=call['function']['arguments']
                        call_id=call['id']
                        if not isinstance(call_id,str) or not isinstance(raw,str): raise ValueError()
                    except (KeyError,TypeError,ValueError) as exc:
                        raise AIConnectionError(ConnectionErrorCategory.INVALID_RESPONSE,'Invalid tool call envelope') from exc
                    signature=(name,raw)
                    if failures.get(signature,0)>=2:
                        raise AIConnectionError(ConnectionErrorCategory.POLICY,'Repeated identical failed tool call; revise the request')
                    try:
                        if len(raw)>1_100_000: raise ValueError('Tool arguments too large')
                        args=json.loads(raw)
                        result=tool_context.call(name,args,cancellation,activity)
                    except ProviderCancelled:
                        raise
                    except (ValueError,KeyError) as exc:
                        failures[signature]=failures.get(signature,0)+1
                        result={'error':str(exc)[:500]}
                    messages.append({'role':'tool','tool_call_id':call_id,'content':json.dumps(result,ensure_ascii=False)})
                continue
            if not final:
                final=True
                messages.append({'role':'user','content':'Now return only the final JSON response matching the required schema. Describe files using only actual tool results; never invent a file link. Do not repeat file operations already completed.'})
                continue
            try:
                content=message.get('content')
                return validate_payload(extract_json(content) if isinstance(content,str) else content,schema)
            except (AIConnectionError,ValueError,TypeError):
                if corrected: raise AIConnectionError(ConnectionErrorCategory.INVALID_RESPONSE,'Agent returned invalid structured output after correction')
                corrected=True
                messages.append({'role':'user','content':'The response did not match the required JSON schema. Return valid JSON matching it exactly; do not call tools.'})
        raise AIConnectionError(ConnectionErrorCategory.POLICY,'Agent request limit reached')
    except ProviderCancelled:
        if expired.is_set():
            raise AIConnectionError(ConnectionErrorCategory.TIMEOUT,'Agent exceeded the five-minute limit')
        raise
    finally:
        timer.cancel()
