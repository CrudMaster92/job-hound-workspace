"""Small registry used by chat, recipe building, API, and MCP surfaces."""

from __future__ import annotations

from inspect import signature
from threading import Event
from typing import Any, Callable, Iterable, Protocol

from .cli import ClaudeConnection, CodexConnection, HermesConnection, OpenClawConnection
from .models import AIConnectionError, AIModel, ConnectionErrorCategory, ConnectionStatus
from .openrouter import OpenRouterConnection
from .validation import Schema


class AIConnection(Protocol):
    id: str
    label: str

    def status(self) -> ConnectionStatus: ...
    def list_models(self, *, browsing: bool = False) -> list[AIModel]: ...
    def run_structured(
        self,
        prompt: str,
        schema: Schema,
        *,
        model: str | None = None,
        browsing: bool = False,
        activity: Callable[[str], None] | None = None,
    ) -> dict[str, Any]: ...


class AIConnectionRegistry:
    IDS = ("codex", "claude", "openrouter", "hermes", "openclaw")

    def __init__(self, connections: Iterable[AIConnection] | None = None) -> None:
        selected = list(connections) if connections is not None else [
            CodexConnection(),
            ClaudeConnection(),
            OpenRouterConnection(),
            HermesConnection(),
            OpenClawConnection(),
        ]
        self._connections = {connection.id: connection for connection in selected}
        self.settings_reader = None

    def get(self, connection_id: str) -> AIConnection:
        try:
            return self._connections[connection_id]
        except KeyError as exc:
            raise AIConnectionError(
                ConnectionErrorCategory.CONFIGURATION,
                f"Unsupported AI connection: {connection_id}",
            ) from exc

    def configured(self, connection_id: str):
        """Expose the shared invocation path to scheduler gateways."""
        from types import SimpleNamespace
        from functools import partial
        connection = self.get(connection_id)
        return SimpleNamespace(id=connection.id, status=connection.status,
                               run_structured=partial(self.run_structured, connection_id))

    def statuses(self) -> list[ConnectionStatus]:
        return [self._connections[item].status() for item in self.IDS if item in self._connections]

    def run_structured(
        self,
        connection_id: str,
        prompt: str,
        schema: Schema,
        *,
        model: str | None = None,
        browsing: bool = False,
        cancel_event: Event | None = None,
        activity: Callable[[str], None] | None = None,
        tool_context=None,
        model_override: str | None = None,
    ) -> dict[str, Any]:
        method = self.get(connection_id).run_structured
        options: dict[str, Any] = {"model": model, "browsing": browsing}
        if connection_id == "codex" and self.settings_reader is not None:
            saved = self.settings_reader()
            options["model"] = model_override or saved.get("openai_model")
            if "reasoning_effort" in signature(method).parameters:
                options["reasoning_effort"] = saved.get("openai_reasoning_effort")
        if cancel_event is not None and "cancel_event" in signature(method).parameters:
            options["cancel_event"] = cancel_event
        if activity is not None and "activity" in signature(method).parameters:
            options["activity"] = activity
        if tool_context is not None and "tool_context" in signature(method).parameters:
            options["tool_context"] = tool_context
        return method(prompt, schema, **options)


def create_default_registry() -> AIConnectionRegistry:
    return AIConnectionRegistry()
