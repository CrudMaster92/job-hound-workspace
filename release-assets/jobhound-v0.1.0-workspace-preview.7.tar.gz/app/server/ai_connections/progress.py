"""Bounded Codex JSONL activity reader; never exposes model text or tool arguments."""
import json
import os
import subprocess
import time
from collections import deque
from queue import Queue, Empty, Full
from threading import Event, Thread
from .cancellation import ProviderCancelled


def event_stage(line):
    try:
        event = json.loads(line)
    except (ValueError, TypeError):
        return None
    if not isinstance(event, dict):
        return None
    kind = event.get("type")
    if kind == "turn.started":
        return "working"
    item = event.get("item")
    if kind in ("item.started", "item.updated", "item.completed") and isinstance(item, dict):
        if item.get("type") == "web_search":
            return "working" if kind == "item.completed" else "searching_web"
        if item.get("type") in ("reasoning", "agent_message"):
            return "working"
    return None


def run_with_activity(command, *, input, timeout, cancel_event, activity,
                      popen=subprocess.Popen):
    process = popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    pending = Queue(maxsize=32)
    errors = deque(maxlen=16)
    done = Event()

    def read_output():
        # Discard oversized lines rather than accumulating provider content.
        oversized = False
        for line in iter(lambda: process.stdout.readline(65537), ""):
            if len(line) > 65536 or oversized:
                oversized = not line.endswith("\n")
                continue
            stage = event_stage(line)
            if stage:
                try:
                    pending.put_nowait(stage)
                except Full:
                    pass
        done.set()

    def read_errors():
        for chunk in iter(lambda: process.stderr.read(1024), ""):
            errors.append(chunk)

    def write_input():
        try:
            process.stdin.write(input)
            process.stdin.close()
        except (BrokenPipeError, OSError, ValueError):
            pass

    workers = [Thread(target=target, daemon=True) for target in (read_output, read_errors, write_input)]
    for worker in workers:
        worker.start()
    deadline = time.monotonic() + timeout
    try:
        while True:
            if cancel_event and cancel_event.is_set():
                raise ProviderCancelled("AI provider request was cancelled")
            if time.monotonic() >= deadline:
                raise subprocess.TimeoutExpired(command, timeout)
            try:
                activity(pending.get(timeout=.05))
            except Empty:
                pass
            if process.poll() is not None and done.is_set() and pending.empty():
                break
        workers[1].join(timeout=1)
        return subprocess.CompletedProcess(command, process.returncode, "", "".join(errors))
    finally:
        if process.poll() is None:
            # Windows CLI shims spawn a child executable. Stop only this invocation's tree.
            if os.name == "nt":
                try:
                    subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3,
                        creationflags=subprocess.CREATE_NO_WINDOW)
                except (OSError, subprocess.TimeoutExpired):
                    pass
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
        for worker in workers:
            worker.join(timeout=1)
        for stream in (process.stdin, process.stdout, process.stderr):
            stream.close()
