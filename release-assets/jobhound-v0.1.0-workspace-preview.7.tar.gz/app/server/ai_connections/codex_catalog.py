"""Bounded, read-only Codex app-server model discovery."""
from __future__ import annotations

import json
import os
import queue
import subprocess
import threading
import time

from .models import AIConnectionError, AIModel, ConnectionErrorCategory

UPDATE_COMMAND = "npm install -g @openai/codex@latest"


def runtime_info(executable, *, host_local=False):
    result = {"version": None, "source": "not found", "update_command": UPDATE_COMMAND}
    if not executable:
        return result
    lowered = str(executable).lower().replace("\\", "/")
    result["source"] = "npm" if "/npm/" in lowered else "desktop app" if "/openai/codex/" in lowered else "PATH"
    if host_local:
        result["executable_path"] = str(executable)
    try:
        run = subprocess.run([executable, "--version"], capture_output=True, text=True, timeout=5)
        if run.returncode == 0:
            result["version"] = run.stdout.strip()[:100]
    except (OSError, subprocess.SubprocessError):
        pass
    return result


def discover(executable, *, timeout=20, popen=subprocess.Popen):
    if not executable:
        raise AIConnectionError(ConnectionErrorCategory.UNAVAILABLE, "Install Codex CLI, then refresh models.")
    process = None
    worker = None
    stopped = threading.Event()
    try:
        process = popen([executable, "app-server"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                        stderr=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace")
        messages = queue.Queue(maxsize=100)
        stopped = threading.Event()
        def reader():
            while not stopped.is_set():
                line = process.stdout.readline(1024 * 1024 + 1)
                if not line or len(line) > 1024 * 1024:
                    break
                try:
                    messages.put(line, timeout=0.1)
                except queue.Full:
                    break
            try:
                messages.put_nowait(None)
            except queue.Full:
                pass
        worker = threading.Thread(target=reader, daemon=True)
        worker.start()
        deadline = time.monotonic() + timeout
        def send(payload):
            process.stdin.write(json.dumps(payload) + "\n")
            process.stdin.flush()
        def request(identifier, method, params):
            send({"id": identifier, "method": method, "params": params})
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError()
                line = messages.get(timeout=remaining)
                if line is None:
                    raise ValueError("Codex closed model discovery")
                message = json.loads(line)
                if message.get("id") != identifier:
                    continue
                if "error" in message:
                    raise ValueError("Codex rejected model discovery; update the CLI and retry")
                return message["result"]
        request(1, "initialize", {"clientInfo": {"name": "jobhound", "version": "1.0"}})
        send({"method": "initialized", "params": {}})
        models, cursor, seen = [], None, set()
        for page in range(50):
            result = request(page + 2, "model/list", {"limit": 100, "includeHidden": False, "cursor": cursor})
            for item in result["data"]:
                models.append(AIModel(id=item["model"], name=item["displayName"],
                    reasoning_efforts=[e["reasoningEffort"] for e in item.get("supportedReasoningEfforts", [])],
                    default_reasoning_effort=item.get("defaultReasoningEffort"), is_default=item.get("isDefault", False)))
            cursor = result.get("nextCursor")
            if not cursor:
                return models
            if cursor in seen:
                raise ValueError("Repeated catalog cursor")
            seen.add(cursor)
        raise ValueError("Model catalog exceeded page limit")
    except (TimeoutError, queue.Empty) as exc:
        raise AIConnectionError(ConnectionErrorCategory.TIMEOUT, "Codex model discovery timed out. Refresh to retry.") from exc
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
        raise AIConnectionError(ConnectionErrorCategory.UNAVAILABLE, "Could not discover Codex models. Check the CLI installation and refresh.") from exc
    finally:
        if process is not None:
            stopped.set()
            # npm launches a child executable on Windows: stop the entire discovery tree.
            if process.poll() is None:
                if os.name == "nt":
                    try:
                        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
                    except (OSError, subprocess.SubprocessError):
                        process.kill()
                else:
                    process.kill()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            if worker is not None:
                worker.join(timeout=1)
            for stream in (process.stdin, process.stdout):
                if stream:
                    stream.close()
