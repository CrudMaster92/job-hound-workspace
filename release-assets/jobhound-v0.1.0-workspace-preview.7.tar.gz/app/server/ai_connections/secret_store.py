"""Narrow OS credential-store boundary; deliberately has no plaintext fallback."""

from __future__ import annotations

from typing import Protocol


class SecretStore(Protocol):
    def get(self, name: str) -> str | None: ...
    def set(self, name: str, value: str) -> None: ...
    def delete(self, name: str) -> None: ...


class KeyringSecretStore:
    SERVICE = "JobHound"

    def __init__(self, backend=None) -> None:
        if backend is None:
            try:
                import keyring as backend
            except ImportError as exc:
                raise RuntimeError("OS credential storage is unavailable; install keyring") from exc
        self._backend = backend

    def get(self, name: str) -> str | None:
        return self._backend.get_password(self.SERVICE, name)

    def set(self, name: str, value: str) -> None:
        self._backend.set_password(self.SERVICE, name, value)

    def delete(self, name: str) -> None:
        try:
            self._backend.delete_password(self.SERVICE, name)
        except Exception as exc:
            # keyring uses backend-specific exception types, and delete should be
            # idempotent for the application-facing credential contract.
            if "not found" not in str(exc).casefold():
                raise


class UnavailableSecretStore:
    def get(self, name: str) -> str | None:
        return None

    def set(self, name: str, value: str) -> None:
        raise RuntimeError("OS credential storage is unavailable")

    def delete(self, name: str) -> None:
        raise RuntimeError("OS credential storage is unavailable")


def default_secret_store() -> SecretStore:
    try:
        return KeyringSecretStore()
    except RuntimeError:
        return UnavailableSecretStore()
