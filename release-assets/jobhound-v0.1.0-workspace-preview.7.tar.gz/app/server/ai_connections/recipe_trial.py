"""Cancellable deterministic trial, never mutates a monitor or its active recipe."""
import json
import sys
from ..scrapers.models import ScraperRecipe
from ..scrapers.runtime import validate_recipe

if __name__=='__main__':
    try:
        recipe=ScraperRecipe.model_validate_json(sys.stdin.read(1_100_000))
        report=validate_recipe(recipe)
        sys.stdout.write(report.model_dump_json())
    except Exception:
        sys.stderr.write('Recipe trial failed')
        sys.exit(1)
