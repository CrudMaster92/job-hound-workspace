"""Resolve an employer website from a hosted careers page."""

from __future__ import annotations

import html as html_module
import ipaddress
import re
import socket
from dataclasses import dataclass
from functools import lru_cache
from urllib.parse import urljoin, urlsplit, urlunsplit

import httpx
from bs4 import BeautifulSoup


PROVIDER_HOSTS = (
    "ashbyhq.com",
    "greenhouse.io",
    "jobvite.com",
    "lever.co",
    "myworkdayjobs.com",
    "smartrecruiters.com",
)
IGNORED_HOSTS = PROVIDER_HOSTS + (
    "googleapis.com",
    "greenhouse.com",
    "gstatic.com",
    "myworkday.com",
    "recaptcha.net",
    "w3.org",
    "workday.com",
)
STATIC_SUFFIXES = (
    ".css", ".eot", ".gif", ".ico", ".jpeg", ".jpg", ".js", ".json",
    ".otf", ".png", ".svg", ".ttf", ".webp", ".woff", ".woff2",
)
URL_PATTERN = re.compile(r"https?://[^\s\"'<>\\]+", re.IGNORECASE)


@dataclass(frozen=True)
class CompanyBranding:
    website_url: str | None
    logo_url: str | None


@dataclass(frozen=True)
class CompanyLogo:
    content: bytes
    media_type: str
    source: str = "automatic"
    source_url: str | None = None


def _host_matches(host: str, suffixes: tuple[str, ...]) -> bool:
    return any(host == suffix or host.endswith(f".{suffix}") for suffix in suffixes)


def _origin(value: str) -> str | None:
    try:
        parsed = urlsplit(value)
    except ValueError:
        return None
    host = (parsed.hostname or "").casefold().rstrip(".")
    if parsed.scheme not in {"http", "https"} or not host or parsed.username or parsed.password:
        return None
    if host == "localhost" or host.endswith(".localhost"):
        return None
    try:
        if not ipaddress.ip_address(host).is_global:
            return None
    except ValueError:
        pass
    return urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))


def _public_url(value: str, *, base_url: str) -> str | None:
    absolute = urljoin(base_url, value)
    if not _origin(absolute):
        return None
    try:
        parsed = urlsplit(absolute)
    except ValueError:
        return None
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, parsed.query, ""))


def _assert_public_network_url(value: str) -> None:
    parsed = urlsplit(value)
    host = parsed.hostname or ""
    if not _origin(value):
        raise ValueError("Logo URL must be a public HTTP(S) URL")
    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(host, parsed.port or 443)}
    except OSError as exc:
        raise ValueError("Logo host could not be resolved") from exc
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise ValueError("Logo URL must resolve only to public addresses")


def _get_public(client: httpx.Client, value: str) -> httpx.Response:
    current = value
    for _ in range(5):
        _assert_public_network_url(current)
        response = client.get(current)
        if response.is_redirect:
            location = response.headers.get("location")
            if not location:
                break
            current = urljoin(current, location)
            continue
        return response
    raise ValueError("Logo URL redirected too many times")


def detect_image_media_type(content: bytes) -> str | None:
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if content.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if content.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if content.startswith(b"\x00\x00\x01\x00"):
        return "image/x-icon"
    if content.startswith(b"RIFF") and content[8:12] == b"WEBP":
        return "image/webp"
    return None


def is_hosted_job_board(url: str) -> bool:
    host = (urlsplit(url).hostname or "").casefold().rstrip(".")
    return _host_matches(host, PROVIDER_HOSTS)


def extract_company_website(careers_url: str, page_html: str) -> str | None:
    """Choose the employer origin advertised by a hosted job board."""
    source_host = (urlsplit(careers_url).hostname or "").casefold().rstrip(".")
    soup = BeautifulSoup(page_html, "html.parser")

    logo = soup.select_one("a.logo[href]")
    if logo:
        value = _origin(str(logo.get("href", "")))
        if value:
            return value

    candidates: list[tuple[int, int, str]] = []
    seen: set[str] = set()
    values = [str(node.get("href", "")) for node in soup.select("a[href]")]
    decoded = html_module.unescape(page_html).replace(r"\/", "/")
    values.extend(match.group(0).rstrip("),;]}") for match in URL_PATTERN.finditer(decoded))
    for index, value in enumerate(values):
        origin = _origin(value)
        if not origin or origin in seen:
            continue
        parsed = urlsplit(value)
        host = (parsed.hostname or "").casefold().rstrip(".")
        path = parsed.path.casefold()
        if host == source_host or _host_matches(host, IGNORED_HOSTS) or path.endswith(STATIC_SUFFIXES):
            continue
        seen.add(origin)
        score = 20 if re.search(r"(?:^|/)(?:career|careers|job|jobs)(?:/|$)", path) else 0
        candidates.append((-score, index, origin))
    return min(candidates)[2] if candidates else None


def extract_company_logo(careers_url: str, page_html: str) -> str | None:
    """Return tenant-provided company artwork from a hosted careers page."""
    soup = BeautifulSoup(page_html, "html.parser")
    selectors = (
        ('meta[property="og:image"]', "content"),
        ('meta[name="twitter:image"]', "content"),
        ('meta[name="image"]', "content"),
        ("img.logo", "src"),
        ('img[class*="logo"]', "src"),
    )
    for selector, attribute in selectors:
        node = soup.select_one(selector)
        if not node:
            continue
        value = _public_url(str(node.get(attribute, "")), base_url=careers_url)
        if value:
            return value
    return None


def extract_site_icons(website_url: str, page_html: str) -> list[str]:
    """Return public icon links in document order, preferring declared favicons."""
    soup = BeautifulSoup(page_html, "html.parser")
    values: list[str] = []
    for node in soup.select('link[rel][href]'):
        rel = " ".join(node.get("rel") or []).casefold()
        if "icon" not in rel:
            continue
        value = _public_url(str(node.get("href", "")), base_url=website_url)
        if value and value not in values:
            values.append(value)
    fallback = _public_url("/favicon.ico", base_url=website_url)
    if fallback and fallback not in values:
        values.append(fallback)
    return values


@lru_cache(maxsize=256)
def discover_company_branding(careers_url: str) -> CompanyBranding:
    """Resolve employer branding without mistaking an ATS vendor for the employer."""
    direct_origin = _origin(careers_url)
    if not direct_origin:
        return CompanyBranding(None, None)
    if not is_hosted_job_board(careers_url):
        return CompanyBranding(direct_origin, None)
    with httpx.Client(
        follow_redirects=True,
        timeout=httpx.Timeout(8.0),
        headers={"User-Agent": "JobHound/0.1 company-branding"},
    ) as client:
        response = client.get(careers_url)
        response.raise_for_status()
        if len(response.content) > 5 * 1024 * 1024:
            return CompanyBranding(None, None)
        return CompanyBranding(
            extract_company_website(careers_url, response.text),
            extract_company_logo(careers_url, response.text),
        )


@lru_cache(maxsize=256)
def discover_company_website(careers_url: str) -> str | None:
    """Backward-compatible website-only branding lookup."""
    return discover_company_branding(careers_url).website_url


@lru_cache(maxsize=256)
def fetch_company_logo(logo_url: str) -> CompanyLogo:
    """Fetch a discovered public raster logo and correct unreliable media types."""
    if not _public_url(logo_url, base_url=logo_url):
        raise ValueError("Logo URL must be a public HTTP(S) URL")
    with httpx.Client(
        follow_redirects=False,
        timeout=httpx.Timeout(8.0),
        headers={"User-Agent": "JobHound/0.1 company-branding"},
    ) as client:
        response = _get_public(client, logo_url)
        response.raise_for_status()
        if len(response.content) > 2 * 1024 * 1024:
            raise ValueError("Company logo is too large")
        media_type = detect_image_media_type(response.content)
        if not media_type:
            raise ValueError("Company logo is not a supported raster image")
        return CompanyLogo(response.content, media_type, source_url=str(response.url))


@lru_cache(maxsize=64)
def resolve_company_logo(careers_url: str, manual_url: str | None = None) -> CompanyLogo:
    """Resolve one display-safe image, falling through every broken candidate."""
    branding = discover_company_branding(careers_url)
    candidates: list[tuple[str, str]] = []
    if manual_url:
        candidates.append(("manual", manual_url))
    if branding.website_url:
        try:
            with httpx.Client(
                follow_redirects=True,
                timeout=httpx.Timeout(8.0),
                headers={"User-Agent": "JobHound/0.1 company-branding"},
            ) as client:
                response = client.get(branding.website_url)
                response.raise_for_status()
                if len(response.content) <= 5 * 1024 * 1024:
                    candidates.extend(
                        ("official_favicon", value)
                        for value in extract_site_icons(branding.website_url, response.text)
                    )
        except httpx.HTTPError:
            fallback = _public_url("/favicon.ico", base_url=branding.website_url)
            if fallback:
                candidates.append(("official_favicon", fallback))
    if branding.logo_url:
        candidates.append(("careers_artwork", branding.logo_url))
    seen: set[str] = set()
    for source, value in candidates:
        if value in seen:
            continue
        seen.add(value)
        try:
            logo = fetch_company_logo(value)
            return CompanyLogo(logo.content, logo.media_type, source=source,
                               source_url=logo.source_url or value)
        except (httpx.HTTPError, ValueError):
            continue
    raise ValueError("No supported company image is available")
