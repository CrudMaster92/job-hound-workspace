"""Public activity presentation shared by HTTP, SSE, and MCP."""
from datetime import datetime, timezone

STAGES = {
    "queued": "Queued", "preparing_context": "Preparing context",
    "contacting_provider": "Connecting", "working": "Working on your request",
    "searching_web": "Searching the web", "reading_jobs": "Reading your jobs",
    "rendering_file": "Creating your file", "validating_recipe": "Validating scraper recipe",
    "checking_answer": "Checking the answer", "awaiting_library_access": "Waiting for Documents access",
    "complete": "Complete", "failed": "Failed", "cancelled": "Cancelled", "interrupted": "Interrupted",
}


def present_progress(turn):
    value = dict(turn)
    value["terminal"] = value.get("status") in {"complete", "failed", "cancelled", "interrupted"}
    stage = value.get("stage", "queued")
    value["message"] = (f"Waiting for {value.get('provider') or 'provider'}" if stage == "waiting_provider"
                        else STAGES.get(stage, "Working on your request"))
    start = value.get("started_at") or value.get("created_at")
    end = value.get("finished_at")
    try:
        beginning = datetime.fromisoformat(start.replace("Z", "+00:00"))
        ending = datetime.fromisoformat(end.replace("Z", "+00:00")) if end else datetime.now(timezone.utc)
        value["elapsed_seconds"] = max(0, int((ending - beginning).total_seconds()))
    except (AttributeError, TypeError, ValueError):
        value["elapsed_seconds"] = 0
    value["last_activity_at"] = value.get("updated_at")
    return value
