"""Small domain models shared by the database, scheduler, and API layers."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class CriteriaMode(StrEnum):
    INHERIT = "inherit"
    REPLACE = "replace"
    ANY = "any"


class MonitorState(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"
    BUILDING = "building"
    NEEDS_ATTENTION = "needs_attention"
    ARCHIVED = "archived"


class RunStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"


class RunKind(StrEnum):
    SCRAPE = "scrape"
    BUILD = "build"
    REPAIR = "repair"


@dataclass(slots=True)
class ScrapeResult:
    jobs: list[dict[str, Any]] = field(default_factory=list)
    full_run: bool = True
    source: str | None = None
    diagnostics: str | None = None
    recipe: dict[str, Any] | None = None


@dataclass(slots=True)
class ClaimedRun:
    id: int
    company_id: int
    kind: str
    recipe_version: int | None
