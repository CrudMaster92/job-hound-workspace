"""JSON command transport over JobHound's existing typed MCP contracts."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from typing import Any

from mcp import Client
from .mcp_api import normalize_api_url


async def invoke(action: str, tool: str | None = None, arguments: dict[str, Any] | None = None):
    # Importing the tool server does not start the application or a scheduler.
    from .mcp_server import mcp
    async with Client(mcp) as client:
        registered = (await client.list_tools()).tools
        if action == "tools":
            return {"ok": True, "tool_count": len(registered),
                    "tools": [item.model_dump(mode="json", by_alias=True) for item in registered]}
        if tool not in {item.name for item in registered}:
            return {"ok": False, "error": {"code": "unknown_tool", "message": "Use tools to discover a registered JobHound operation."}}
        result = await client.call_tool(tool, arguments or {})
        return {"ok": not result.is_error, "tool": tool,
                "result": result.model_dump(mode="json", by_alias=True)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--api-url", default=os.getenv("JOBHOUND_API_URL"))
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("tools")
    commands.add_parser("status")
    call = commands.add_parser("call")
    call.add_argument("tool")
    call.add_argument("--arguments", default="{}", help="JSON object matching the discovered MCP input schema.")
    call.add_argument("--arguments-file", help="Read a bounded JSON file instead of shell-quoting a public proposal.")
    args = parser.parse_args()
    try:
        os.environ["JOBHOUND_API_URL"] = normalize_api_url(args.api_url)
        raw = getattr(args, "arguments", "{}")
        if getattr(args, "arguments_file", None):
            from pathlib import Path
            path = Path(args.arguments_file)
            if path.stat().st_size > 600_000:
                raise ValueError("arguments exceed 600 KB")
            raw = path.read_text(encoding="utf-8")
        arguments = json.loads(raw)
        if not isinstance(arguments, dict):
            raise ValueError("arguments must be a JSON object")
        if len(raw.encode("utf-8")) > 600_000:
            raise ValueError("arguments exceed 600 KB")
        action = "tools" if args.action == "tools" else "call"
        tool = "get_jobhound_status" if args.action == "status" else getattr(args, "tool", None)
        result = asyncio.run(invoke(action, tool, arguments))
    except Exception as exc:
        result = {"ok": False, "error": {"code": "invocation_failed", "message": str(exc)}}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())

