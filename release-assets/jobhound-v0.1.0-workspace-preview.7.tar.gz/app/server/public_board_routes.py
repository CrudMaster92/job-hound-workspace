"""Public board HTTP contracts; normal local app authorization applies."""
from typing import Literal
from fastapi import APIRouter, Query, HTTPException
from pydantic import ValidationError
from .public_board import PublicBoard
from .public_board_contracts import BoardQuery, FavouritesImport, FavouritesTransfer, SavedUpdate


def mount_public_board(app, db, trackers):
    service = PublicBoard(db, trackers)
    app.state.public_board = service
    router = APIRouter(prefix="/api/v1/public-board", tags=["public-board"])

    @router.get("/status")
    def status():
        return service.status()

    @router.get("/jobs")
    def jobs(query: str = Query(default="", max_length=500), location: str = Query(default="", max_length=500), company_ids: list[str] = Query(default=[]),
             collection_ids: list[str] = Query(default=[]), work_modes: list[str] = Query(default=[]),
             employment_types: list[str] = Query(default=[]), salary_listed: bool = False,
             posted_within_days: Literal[1, 7, 30] | None = None,
             sort: Literal["newest", "oldest", "title", "company"] = "newest",
             view: Literal["all", "saved", "favourite_companies"] = "all",
             limit: int = Query(default=25, ge=1, le=100), offset: int = Query(default=0, ge=0)):
        try:
            filters = BoardQuery(query=query, location=location, company_ids=company_ids, collection_ids=collection_ids,
                                 work_modes=work_modes, employment_types=employment_types, salary_listed=salary_listed,
                                 posted_within_days=posted_within_days, sort=sort, view=view, limit=limit, offset=offset)
        except ValidationError as exc:
            raise HTTPException(422, "Invalid public board filters") from exc
        return service.search(filters)

    @router.get("/jobs/{job_id}")
    def detail(job_id: str):
        return service.detail(job_id)

    @router.patch("/jobs/{job_id}/saved")
    def saved(job_id: str, payload: SavedUpdate):
        return service.save(job_id, payload.saved, actor_type=payload.actor_type)

    @router.get("/favourites/export")
    def export():
        return service.export()

    @router.post("/favourites/preview")
    def preview(payload: FavouritesTransfer):
        return service.preview(payload)

    @router.post("/favourites/import")
    def import_favourites(payload: FavouritesImport):
        return service.import_favourites(payload.transfer, payload.preview_token, actor_type=payload.actor_type)

    app.include_router(router)
