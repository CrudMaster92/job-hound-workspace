"""Local interview capture and transcription."""
