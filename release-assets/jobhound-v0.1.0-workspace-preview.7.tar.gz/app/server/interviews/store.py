"""SQLite metadata and revisioned transcripts; generated paths never leave the API."""
import json
import shutil
import stat
import time
from pathlib import Path
from .contracts import InterviewError, UpdateInterview

SCHEMA = """
CREATE TABLE IF NOT EXISTS interviews (
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL UNIQUE,
 capture_state TEXT NOT NULL, archived INTEGER NOT NULL DEFAULT 0,
 revision INTEGER NOT NULL DEFAULT 1, metadata TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS one_active_interview ON interviews((1))
 WHERE capture_state IN ('recording','saving');
CREATE TABLE IF NOT EXISTS interview_segments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 interview_id INTEGER NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
 source TEXT NOT NULL, start REAL NOT NULL, end REAL NOT NULL,
 text TEXT NOT NULL, original_text TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS interview_segments_order ON interview_segments(interview_id,start,id);
CREATE TABLE IF NOT EXISTS interview_requests (
 request_id TEXT PRIMARY KEY, interview_id INTEGER NOT NULL,
 run_id TEXT NOT NULL
);
"""

class InterviewStore:
    def __init__(self, database):
        self.db = database
        self.root = (Path(database.path).resolve().parent / "interviews").resolve()
        self.root.mkdir(exist_ok=True, parents=True)
        with database.connect() as c:
            c.executescript(SCHEMA)

    def directory(self, interview_id):
        if not isinstance(interview_id, int) or interview_id < 1:
            raise InterviewError("invalid_id", "Invalid interview ID", 422)
        candidate = self.root / str(interview_id)
        reparse = candidate.exists() and bool(getattr(candidate.lstat(), "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 1024))
        path = candidate.resolve()
        if path.parent != self.root or candidate.is_symlink() or reparse:
            raise InterviewError("invalid_path", "Invalid managed audio path", 422)
        return path

    @staticmethod
    def present(row):
        return {**json.loads(row["metadata"]), "id": row["id"], "revision": row["revision"],
                "capture_state": row["capture_state"], "archived": bool(row["archived"])}

    def get(self, interview_id):
        with self.db.connect() as c:
            row = c.execute("SELECT * FROM interviews WHERE id=?", (interview_id,)).fetchone()
        if row is None:
            raise InterviewError("not_found", "Interview not found", 404)
        return self.present(row)

    def by_request(self, key):
        with self.db.connect() as c:
            row = c.execute("SELECT * FROM interviews WHERE request_id=?", (key,)).fetchone()
        return self.present(row) if row else None

    def active(self):
        with self.db.connect() as c:
            row = c.execute("SELECT * FROM interviews WHERE capture_state IN ('recording','saving')").fetchone()
        return self.present(row) if row else None

    def create(self, payload):
        now = time.time()
        data = {"title": payload.title.strip() or time.strftime("Interview · %Y-%m-%d %H:%M"),
                "started_at": now, "created_at": now, "duration": 0, "language": payload.language,
                "transcription_state": "pending", "run_id": None, "error": None,
                "microphone_label": "You", "output_label": "Call audio", "audio_ready": False,
                "microphone_id": payload.microphone_id, "output_id": payload.output_id}
        with self.db.connect() as c:
            cursor = c.execute("INSERT INTO interviews(request_id,capture_state,metadata) VALUES(?,?,?)",
                               (payload.request_id, "recording", json.dumps(data)))
            interview_id = cursor.lastrowid
            # A directory failure rolls back the row and the one-active constraint.
            self.directory(interview_id).mkdir(exist_ok=True)
        return self.get(interview_id)

    def change(self, interview_id, **changes):
        with self.db.connect() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT * FROM interviews WHERE id=?", (interview_id,)).fetchone()
            if row is None:
                raise InterviewError("not_found", "Interview not found", 404)
            data = json.loads(row["metadata"])
            state = changes.pop("capture_state", row["capture_state"])
            data.update(changes)
            c.execute("UPDATE interviews SET capture_state=?,metadata=? WHERE id=?",
                      (state, json.dumps(data), interview_id))
        return self.get(interview_id)

    def list(self, archived=False, offset=0, limit=50, query=""):
        with self.db.connect() as c:
            where = "archived=? AND (?='' OR json_extract(metadata,'$.title') LIKE ? OR EXISTS (SELECT 1 FROM interview_segments s WHERE s.interview_id=interviews.id AND s.text LIKE ?))"
            args = (int(archived), query, f"%{query}%", f"%{query}%")
            count = c.execute("SELECT count(*) FROM interviews WHERE " + where, args).fetchone()[0]
            rows = c.execute("SELECT * FROM interviews WHERE " + where + " ORDER BY id DESC LIMIT ? OFFSET ?", (*args, limit, offset)).fetchall()
        return {"items": [self.present(r) for r in rows], "count": count, "next_offset": offset + limit if offset + limit < count else None}

    def segments(self, interview_id, offset=0, limit=100, query=""):
        self.get(interview_id)
        with self.db.connect() as c:
            args = (interview_id, f"%{query}%")
            count = c.execute("SELECT count(*) FROM interview_segments WHERE interview_id=? AND text LIKE ?", args).fetchone()[0]
            rows = c.execute("SELECT id,source,start,end,text,original_text FROM interview_segments WHERE interview_id=? AND text LIKE ? ORDER BY start,id LIMIT ? OFFSET ?", (*args, limit, offset)).fetchall()
        return {"items": [dict(r) for r in rows], "count": count, "next_offset": offset + limit if offset + limit < count else None}

    def install_segments(self, interview_id, segments, languages=None):
        # Install atomically only on successful worker completion; retries retain prior corrections.
        with self.db.connect() as c:
            existing = c.execute("SELECT count(*) FROM interview_segments WHERE interview_id=?", (interview_id,)).fetchone()[0]
            if existing:
                raise InterviewError("transcript_exists", "A completed transcript already exists")
            c.executemany("INSERT INTO interview_segments(interview_id,source,start,end,text,original_text) VALUES(?,?,?,?,?,?)",
                          ((interview_id, s["source"], s["start"], s["end"], s["text"], s["text"]) for s in segments))
            if languages is not None:
                row = c.execute("SELECT metadata FROM interviews WHERE id=?", (interview_id,)).fetchone()
                data = json.loads(row["metadata"])
                data.update(transcription_state="ready", detected_languages=languages, error=None)
                c.execute("UPDATE interviews SET metadata=? WHERE id=?", (json.dumps(data), interview_id))

    def update(self, interview_id, payload: UpdateInterview):
        with self.db.connect() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT * FROM interviews WHERE id=?", (interview_id,)).fetchone()
            if row is None:
                raise InterviewError("not_found", "Interview not found", 404)
            if row["revision"] != payload.revision:
                raise InterviewError("revision_conflict", "Interview changed; reload before saving")
            data = json.loads(row["metadata"])
            if row["capture_state"] in ("recording", "saving") and payload.archived:
                raise InterviewError("recording_active", "Stop recording before archiving")
            if data["transcription_state"] in ("queued", "processing") and payload.segments:
                raise InterviewError("processing", "Wait for transcription before editing")
            for name in ("title", "microphone_label", "output_label"):
                value = getattr(payload, name)
                if value is not None:
                    if not value.strip():
                        raise InterviewError("empty_label", "Labels cannot be blank", 422)
                    data[name] = value.strip()
            for segment in payload.segments:
                result = c.execute("UPDATE interview_segments SET text=? WHERE id=? AND interview_id=?", (segment.text, segment.id, interview_id))
                if result.rowcount != 1:
                    raise InterviewError("segment_not_found", "Transcript segment not found", 404)
            archived = row["archived"] if payload.archived is None else int(payload.archived)
            c.execute("UPDATE interviews SET metadata=?,archived=?,revision=revision+1 WHERE id=?", (json.dumps(data), archived, interview_id))
        return self.get(interview_id)

    def purge(self, interview_id):
        item = self.get(interview_id)
        if not item["archived"] or item["capture_state"] in ("recording", "saving") or item["transcription_state"] in ("queued", "processing"):
            raise InterviewError("not_archived", "Archive a stopped interview and wait for processing before permanently deleting")
        folder = self.directory(interview_id)
        if folder.exists():
            try:
                shutil.rmtree(folder)
            except OSError as exc:
                raise InterviewError("audio_in_use", "Close audio playback or downloads, then retry permanent deletion") from exc
        with self.db.connect() as c:
            c.execute("DELETE FROM interview_requests WHERE interview_id=?", (interview_id,))
            c.execute("DELETE FROM interview_segments WHERE interview_id=?", (interview_id,))
            c.execute("DELETE FROM interviews WHERE id=?", (interview_id,))
        return {"purged": True, "interview_id": interview_id}
