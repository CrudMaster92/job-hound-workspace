"""Bounded audio finalization: align each timestamped chunk onto a common clock."""
import json
import os
from pathlib import Path
import re
import wave

RATE = 16000

def chunks(folder):
    manifest = folder / "chunks.jsonl"
    if not manifest.exists():
        return []
    result = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        try:
            item = json.loads(line)
            if re.fullmatch(r"(microphone|output)-[0-9]{7}\.wav", item["file"]) and item["source"] in ("microphone", "output"):
                result.append(item)
        except (ValueError, KeyError, TypeError):
            continue  # An incomplete final manifest line must not discard earlier audio.
    return result


def finalize(folder):
    import av
    import numpy as np
    manifest = chunks(folder)
    if not manifest:
        raise ValueError("No recoverable audio chunks were captured")
    duration = max(float(c["start"]) + c["frames"] / c["rate"] for c in manifest)
    frames_total = int(duration * RATE) + 1
    for source in ("microphone", "output"):
        position = 0
        temporary = folder / (source + ".wav.tmp")
        with wave.open(str(temporary), "wb") as output:
            output.setnchannels(1); output.setsampwidth(2); output.setframerate(RATE)
            for item in sorted((c for c in manifest if c["source"] == source), key=lambda c: c["start"]):
                start = max(0, round(item["start"] * RATE))
                while position < start:
                    count = min(RATE, start - position)
                    output.writeframesraw(b"\x00\x00" * count); position += count
                skip = max(0, position - start)
                resampler = av.AudioResampler(format="s16", layout="mono", rate=RATE)
                with av.open(str(folder / item["file"])) as container:
                    for frame in container.decode(audio=0):
                        for normalized in resampler.resample(frame):
                            samples = normalized.to_ndarray().reshape(-1)
                            cut = min(skip, len(samples)); samples = samples[cut:]; skip -= cut
                            output.writeframesraw(samples.astype("<i2").tobytes()); position += len(samples)
                    for normalized in resampler.resample(None):
                        samples = normalized.to_ndarray().reshape(-1)
                        cut = min(skip, len(samples)); samples = samples[cut:]; skip -= cut
                        output.writeframesraw(samples.astype("<i2").tobytes()); position += len(samples)
            while position < frames_total:
                count = min(RATE, frames_total - position)
                output.writeframesraw(b"\x00\x00" * count); position += count
        os.replace(temporary, folder / (source + ".wav"))
    temporary = folder / "audio.wav.tmp"
    with wave.open(str(folder / "microphone.wav"), "rb") as mic, wave.open(str(folder / "output.wav"), "rb") as system, wave.open(str(temporary), "wb") as mixed:
        mixed.setnchannels(1); mixed.setsampwidth(2); mixed.setframerate(RATE)
        while True:
            a, b = mic.readframes(RATE), system.readframes(RATE)
            if not a and not b:
                break
            size = max(len(a), len(b))
            x = np.frombuffer(a.ljust(size, b"\x00"), dtype="<i2").astype(np.int32)
            y = np.frombuffer(b.ljust(size, b"\x00"), dtype="<i2").astype(np.int32)
            mixed.writeframesraw(np.clip((x + y) // 2, -32768, 32767).astype("<i2").tobytes())
    os.replace(temporary, folder / "audio.wav")
    return duration
