"""Typed, bounded interview contracts shared by API and MCP."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator

class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")

class StartRecording(Strict):
    request_id: str = Field(min_length=1, max_length=160)
    title: str = Field(default="", max_length=120)
    microphone_id: str = Field(min_length=1, max_length=200)
    output_id: str = Field(min_length=1, max_length=200)
    language: str | None = Field(default=None, pattern=r"^[a-z]{2,3}$")

class PrepareModel(Strict):
    confirm_download: bool = False

class Transcribe(Strict):
    request_id: str = Field(min_length=1, max_length=160)
    language: str | None = Field(default=None, pattern=r"^[a-z]{2,3}$")

class SegmentEdit(Strict):
    id: int = Field(ge=1)
    text: str = Field(max_length=8000)

class UpdateInterview(Strict):
    revision: int = Field(ge=1)
    title: str | None = Field(default=None, min_length=1, max_length=120)
    archived: bool | None = None
    microphone_label: str | None = Field(default=None, min_length=1, max_length=80)
    output_label: str | None = Field(default=None, min_length=1, max_length=80)
    segments: list[SegmentEdit] = Field(default_factory=list, max_length=200)

    @field_validator("segments")
    @classmethod
    def unique_segments(cls, values):
        if len({v.id for v in values}) != len(values):
            raise ValueError("Segment IDs must be unique")
        return values

class InterviewError(ValueError):
    def __init__(self, code: str, message: str, status: int = 409):
        super().__init__(message)
        self.code, self.status = code, status

ExportFormat = Literal["audio", "microphone", "output", "txt", "json"]
