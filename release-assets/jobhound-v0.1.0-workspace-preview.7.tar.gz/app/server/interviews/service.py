"""Application-owned capture lifecycle and isolated local transcription jobs."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from .audio import finalize, chunks
from .contracts import InterviewError
from .store import InterviewStore

class InterviewService:
    def __init__(self, database):
        self.store = InterviewStore(database)
        self.models = self.store.root / "models"
        self.lock = threading.RLock()
        self.clients = set()
        self.disconnected_at = None
        self.capture = None
        self.probe = None
        self.devices_cache = (0, [])
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="interview-transcription")
        self.finalizers = ThreadPoolExecutor(max_workers=1, thread_name_prefix="interview-audio-save")
        self.jobs = set()
        self.shutdown = threading.Event()
        self.monitor = None
        self.model_run = {"state": "ready" if (self.models / "ready.json").exists() else "missing", "run_id": None}

    @staticmethod
    def read_json(path, default=None):
        try:
            return json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            return default

    @staticmethod
    def terminate_worker(process):
        if process.poll() is not None:
            return
        if sys.platform == "win32":
            # The Windows venv launcher may own a child Python interpreter.
            # Kill only the tree rooted at the subprocess created by this service.
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            process.kill()
        process.wait(timeout=10)

    def spawn(self, operation, folder, models=False):
        folder.mkdir(parents=True, exist_ok=True)
        command = [sys.executable, "-m", "server.interviews.worker", operation, "--directory", str(folder)]
        if models:
            command.extend(["--models", str(self.models)])
        with (folder / "worker.log").open("wb") as log:
            process = subprocess.Popen(command, cwd=str(Path(__file__).resolve().parents[2]),
                                       stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) | (getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0) if operation in ("prepare", "transcribe") else 0))
        return process

    def start(self):
        # Recover metadata without opening any device. Audio rebuilding stays off the API thread.
        with self.store.db.connect() as c:
            rows = c.execute("SELECT id FROM interviews").fetchall()
        for row in rows:
            item = self.store.get(row["id"])
            if item["capture_state"] in ("recording", "saving"):
                self.store.change(item["id"], capture_state="saving", error="JobHound restarted; recovering saved chunks")
                self.finalizers.submit(self.recover, item["id"])
            elif item["transcription_state"] in ("queued", "processing"):
                self.store.change(item["id"], transcription_state="failed", error="Transcription interrupted by restart; retry from saved audio")
        self.monitor = threading.Thread(target=self.watch, daemon=True)
        self.monitor.start()

    def recover(self, interview_id):
        # An orphaned worker can still be flushing its last chunks after a server crash.
        # Let its six-second lease and bounded joins expire before finalizing audio.
        lease = self.store.directory(interview_id) / "lease"
        try:
            remaining = max(0, min(13, lease.stat().st_mtime + 13 - time.time()))
        except OSError:
            remaining = 0
        if remaining:
            self.shutdown.wait(remaining)
        if not self.shutdown.is_set():
            self.finish(interview_id, "JobHound restarted; partial audio recovered")

    def close(self):
        self.shutdown.set()
        with self.lock:
            if self.capture:
                (self.capture[1] / "stop").touch()
            if self.probe:
                (self.probe[1] / "stop").touch()
            for job in tuple(self.jobs):
                self.terminate_worker(job)
        if self.monitor:
            self.monitor.join(timeout=12)
        self.pool.shutdown(wait=False, cancel_futures=True)
        self.finalizers.shutdown(wait=False)

    def connected(self, client_id):
        with self.lock:
            self.clients.add(client_id)
            self.disconnected_at = None

    def disconnected(self, client_id):
        with self.lock:
            self.clients.discard(client_id)
            if not self.clients:
                self.disconnected_at = time.monotonic()

    def devices(self):
        if time.monotonic() - self.devices_cache[0] < 30:
            return self.devices_cache[1]
        if sys.platform != "win32" or importlib.util.find_spec("pyaudiowpatch") is None:
            return []
        try:
            value = subprocess.run([sys.executable, "-m", "server.interviews.worker", "devices"],
                                   cwd=str(Path(__file__).resolve().parents[2]), capture_output=True, text=True,
                                   timeout=12, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            result = json.loads(value.stdout) if value.returncode == 0 else []
        except (ValueError, OSError, subprocess.TimeoutExpired):
            result = []
        self.devices_cache = (time.monotonic(), result)
        return result

    def capabilities(self):
        return {"supported": sys.platform == "win32", "capture_installed": importlib.util.find_spec("pyaudiowpatch") is not None,
                "transcription_installed": importlib.util.find_spec("faster_whisper") is not None,
                "model": self.model_run, "devices": self.devices(), "interface_connected": bool(self.clients),
                "active": self.store.active(), "meter": self.status()["meter"], "probe_active": self.probe is not None, "engine": "faster-whisper", "model_name": "small",
                "language_default": "automatic", "setup_instruction": "Restart with Start JobHound.bat to install recording dependencies."}

    def status(self):
        active = self.store.active()
        target = self.capture or self.probe
        meter = self.read_json(target[1] / "meter.json", {}) if target else {}
        return {"active": active, "meter": meter, "model": self.model_run, "probe_active": self.probe is not None}

    def prepare(self, confirmed):
        if not confirmed:
            raise InterviewError("download_confirmation_required", "Confirm the one-time local speech model download", 422)
        if importlib.util.find_spec("faster_whisper") is None:
            raise InterviewError("dependency_missing", "Restart JobHound using its launcher to install transcription dependencies", 503)
        with self.lock:
            if self.model_run["state"] in ("queued", "processing", "ready"):
                return self.model_run.copy()
            self.model_run = {"run_id": uuid.uuid4().hex, "state": "queued"}
            self.pool.submit(self.prepare_job)
            return self.model_run.copy()

    def prepare_job(self):
        self.model_run["state"] = "processing"
        try:
            with self.lock:
                if self.shutdown.is_set():
                    raise RuntimeError("JobHound is shutting down")
                process = self.spawn("prepare", self.models)
                self.jobs.add(process)
            try:
                code = process.wait(timeout=3600)
            finally:
                if process.poll() is None:
                    self.terminate_worker(process)
                with self.lock:
                    self.jobs.discard(process)
            if code:
                raise RuntimeError("Model download failed; check connectivity and available disk space, then retry")
            self.model_run.update(state="ready", error=None)
        except Exception as exc:
            self.model_run.update(state="failed", error=str(exc))

    def validate_devices(self, payload):
        if not self.clients:
            raise InterviewError("interface_required", "Open JobHound on this computer before starting audio capture")
        devices = {d["id"]: d["source"] for d in self.devices()}
        if devices.get(payload.microphone_id) != "microphone" or devices.get(payload.output_id) != "output":
            raise InterviewError("device_unavailable", "Select an available microphone and Windows output device", 422)
        if shutil.disk_usage(self.store.root).free < 256 * 1024 * 1024:
            raise InterviewError("disk_full", "Free at least 256 MiB before recording", 507)
        if payload.language is not None:
            from faster_whisper.tokenizer import _LANGUAGE_CODES
            if payload.language not in _LANGUAGE_CODES:
                raise InterviewError("invalid_language", "Unsupported transcription language", 422)

    def start_recording(self, payload):
        with self.lock:
            previous = self.store.by_request(payload.request_id)
            if previous:
                return {"interview": previous, "duplicate": True}
            if self.store.active():
                raise InterviewError("recording_active", "An interview is already recording; inspect or stop it first")
            self.validate_devices(payload)
            self.end_probe()
            try:
                item = self.store.create(payload)
            except OSError as exc:
                raise InterviewError("storage_unavailable", "Could not create audio storage; check free space and folder permissions", 507) from exc
            folder = self.store.directory(item["id"])
            try:
                (folder / "settings.json").write_text(json.dumps(payload.model_dump()), encoding="utf-8")
                (folder / "lease").touch()
                self.capture = (self.spawn("record", folder), folder, item["id"], None)
            except OSError:
                self.store.change(item["id"], capture_state="failed", error="Could not start the audio worker")
                raise InterviewError("worker_unavailable", "Could not start the audio worker", 503)
            return {"interview": self.store.get(item["id"]), "duplicate": False}

    def start_probe(self, payload):
        with self.lock:
            if self.store.active():
                raise InterviewError("recording_active", "Recording already has live audio meters")
            self.validate_devices(payload)
            self.end_probe()
            folder = self.store.root / "probe"
            folder.mkdir(exist_ok=True)
            for name in ("stop", "meter.json", "result.json"):
                (folder / name).unlink(missing_ok=True)
            (folder / "settings.json").write_text(json.dumps(payload.model_dump()), encoding="utf-8")
            (folder / "lease").touch()
            self.probe = (self.spawn("probe", folder), folder, time.monotonic())
            return {"probe_active": True, "saved_audio": False}

    def end_probe(self):
        if self.probe:
            process, folder, _ = self.probe
            (folder / "stop").touch()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.terminate_worker(process)
            self.probe = None

    def stop_recording(self, interview_id):
        with self.lock:
            item = self.store.get(interview_id)
            if not self.capture or self.capture[2] != interview_id:
                return item
            process, folder, _, stopped = self.capture
            if stopped is None:
                try:
                    (folder / "stop").touch()
                except OSError:
                    self.terminate_worker(process)
                self.capture = (process, folder, interview_id, time.monotonic())
                self.store.change(interview_id, capture_state="saving")
            return self.store.get(interview_id)

    def watch(self):
        while True:
            with self.lock:
                if self.probe:
                    process, folder, began = self.probe
                    if process.poll() is not None or self.shutdown.is_set() or time.monotonic() - began > 60 or not self.clients:
                        self.end_probe()
                    else:
                        (folder / "lease").touch()
                if self.capture:
                    process, folder, interview_id, stopped = self.capture
                    if stopped is None:
                        try:
                            (folder / "lease").touch()
                            disk_full = shutil.disk_usage(folder).free < 64 * 1024 * 1024
                        except OSError:
                            disk_full = True
                        lost = not self.clients and self.disconnected_at is not None and time.monotonic() - self.disconnected_at >= 10
                        if self.shutdown.is_set() or lost or disk_full:
                            reason = "Low disk space; partial audio saved" if disk_full else None
                            if reason:
                                self.store.change(interview_id, error=reason)
                            self.stop_recording(interview_id)
                    elif time.monotonic() - stopped > 8 and process.poll() is None:
                        self.terminate_worker(process)
                    if process.poll() is not None:
                        result = self.read_json(folder / "result.json", {"error": "Audio worker stopped unexpectedly; partial audio saved"})
                        error = self.store.get(interview_id).get("error") or result.get("error")
                        self.store.change(interview_id, capture_state="saving")
                        self.capture = None
                        self.finalizers.submit(self.finish, interview_id, error)
                if self.shutdown.is_set() and not self.capture:
                    break
            time.sleep(.25)

    def finish(self, interview_id, error=None):
        try:
            duration = finalize(self.store.directory(interview_id))
            self.store.change(interview_id, duration=duration, audio_ready=True,
                              capture_state="interrupted" if error else "stopped", capture_error=error, error=error)
            if not self.shutdown.is_set():
                self.transcribe(interview_id, "auto-" + str(interview_id))
        except Exception as exc:
            self.store.change(interview_id, capture_state="interrupted", transcription_state="failed", capture_error=error,
                              error="Saved chunks could not be finalized: " + str(exc))

    def transcribe(self, interview_id, request_id, language=None):
        with self.lock:
            item = self.store.get(interview_id)
            with self.store.db.connect() as c:
                previous = c.execute("SELECT * FROM interview_requests WHERE request_id=?", (request_id,)).fetchone()
            if previous:
                if previous["interview_id"] != interview_id:
                    raise InterviewError("request_conflict", "This request ID belongs to another interview")
                return self.store.get(interview_id)
            if item["capture_state"] in ("recording", "saving"):
                raise InterviewError("recording_active", "Stop and save the recording before transcription")
            if item["transcription_state"] in ("ready", "queued", "processing"):
                return item
            if not item["audio_ready"]:
                if chunks(self.store.directory(interview_id)):
                    self.store.change(interview_id, capture_state="saving", error=None)
                    self.finalizers.submit(self.finish, interview_id, item.get("capture_error"))
                    return self.store.get(interview_id)
                raise InterviewError("audio_unavailable", "No recoverable audio is available")
            if self.model_run["state"] != "ready":
                return self.store.change(interview_id, transcription_state="failed", error="Audio saved. Prepare the local speech model, then retry transcription")
            if language is not None:
                from faster_whisper.tokenizer import _LANGUAGE_CODES
                if language not in _LANGUAGE_CODES:
                    raise InterviewError("invalid_language", "Unsupported transcription language", 422)
            run_id = uuid.uuid4().hex
            with self.store.db.connect() as c:
                c.execute("INSERT INTO interview_requests VALUES(?,?,?)", (request_id, interview_id, run_id))
            self.store.change(interview_id, run_id=run_id, transcription_state="queued", error=None,
                              language=language if language is not None else item.get("language"))
            self.pool.submit(self.transcription_job, interview_id)
            return self.store.get(interview_id)

    def transcription_job(self, interview_id):
        folder = self.store.directory(interview_id)
        self.store.change(interview_id, transcription_state="processing")
        try:
            settings = self.read_json(folder / "settings.json", {})
            settings["language"] = self.store.get(interview_id).get("language")
            (folder / "settings.json").write_text(json.dumps(settings), encoding="utf-8")
            (folder / "transcript-result.json").unlink(missing_ok=True)
            with self.lock:
                if self.shutdown.is_set():
                    raise RuntimeError("JobHound is shutting down")
                process = self.spawn("transcribe", folder, models=True)
                self.jobs.add(process)
            try:
                code = process.wait(timeout=24 * 3600)
            finally:
                if process.poll() is None:
                    self.terminate_worker(process)
                with self.lock:
                    self.jobs.discard(process)
            result = self.read_json(folder / "transcript-result.json")
            if result and result.get("error") == "model_unavailable":
                self.model_run.update(state="failed", error="The local speech model could not load. Download it again from recording setup, then retry.")
                (self.models / "ready.json").unlink(missing_ok=True)
                raise RuntimeError(self.model_run["error"])
            if code or result is None:
                raise RuntimeError("Local transcription failed; audio is safe. Check model availability and memory, then retry")
            self.store.install_segments(interview_id, result["segments"], languages=result["languages"])
        except Exception as exc:
            self.store.change(interview_id, transcription_state="failed", error=str(exc))

    def export_info(self, interview_id, format):
        item = self.store.get(interview_id)
        if format in ("audio", "microphone", "output"):
            if not item["audio_ready"] or not (self.store.directory(interview_id) / (format + ".wav")).is_file():
                raise InterviewError("audio_unavailable", "Audio is still saving or unavailable")
        elif item["transcription_state"] != "ready":
            raise InterviewError("transcript_unavailable", "The transcript is not ready; wait for processing or retry a failed transcription")
        return {"interview_id": interview_id, "format": format, "audio_ready": item["audio_ready"],
                "transcription_state": item["transcription_state"], "capture_state": item["capture_state"]}

    def export(self, interview_id, format):
        self.export_info(interview_id, format)
        item = self.store.get(interview_id)
        folder = self.store.directory(interview_id)
        if format in ("audio", "microphone", "output"):
            path = folder / (format + ".wav")
            return path, "audio/wav"
        # This export is intentionally complete; ordinary reads remain paginated.
        with self.store.db.connect() as c:
            rows = [dict(r) for r in c.execute("SELECT id,source,start,end,text,original_text FROM interview_segments WHERE interview_id=? ORDER BY start,id", (interview_id,))]
        path = folder / ("transcript." + format)
        if format == "json":
            content = json.dumps({"interview": item, "segments": rows}, ensure_ascii=False, indent=2)
        else:
            content = "\n\n".join(f"[{s['start']:.1f}s] {item[s['source'] + '_label']}: {s['text']}" for s in rows)
        path.write_text(content, encoding="utf-8")
        return path, "application/json" if format == "json" else "text/plain"

    def backup(self, archive):
        with self.lock, zipfile.ZipFile(archive, "a", compression=zipfile.ZIP_DEFLATED) as output:
            with self.store.db.connect() as c:
                items = [self.store.present(row) for row in c.execute("SELECT * FROM interviews ORDER BY id")]
                segments = [dict(row) for row in c.execute("SELECT * FROM interview_segments ORDER BY interview_id,start,id")]
            output.writestr("interviews/manifest.json", json.dumps({"version": 1, "interviews": items, "segments": segments}, ensure_ascii=False))
            for item in items:
                folder = self.store.directory(item["id"])
                for path in folder.glob("*"):
                    if path.is_file() and not path.is_symlink() and (path.suffix == ".wav" or path.name == "chunks.jsonl"):
                        output.write(path, f"interviews/{item['id']}/{path.name}")
