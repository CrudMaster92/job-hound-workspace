"""Native Windows capture worker. Only fixed capture/model operations are accepted."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import queue
import threading
import time
import wave


def atomic_json(path, value):
    temp = path.with_suffix(".tmp")
    try:
        temp.write_text(json.dumps(value), encoding="utf-8")
    except OSError:
        if path.name in ("meter.json", "progress.json"):
            return
        raise
    # Windows readers/antivirus can briefly deny replacement of an open file.
    for attempt in range(10):
        try:
            os.replace(temp, path)
            return
        except PermissionError:
            time.sleep(.01 * (attempt + 1))
    if path.name in ("meter.json", "progress.json"):
        return  # Advisory telemetry must never end a recording.
    os.replace(temp, path)


def device_key(info):
    value = f"{info['index']}:{info['name']}:{info.get('isLoopbackDevice', False)}"
    return hashlib.sha256(value.encode()).hexdigest()[:24]


def devices():
    import pyaudiowpatch as pa
    with pa.PyAudio() as audio:
        infos = list(audio.get_device_info_generator())
        host = audio.get_host_api_info_by_type(pa.paWASAPI)
        wasapi = host["index"]
        default_input = host["defaultInputDevice"]
        default_output = audio.get_device_info_by_index(host["defaultOutputDevice"])["name"]
        return [{"id": device_key(i), "name": i["name"], "source": "output" if i.get("isLoopbackDevice") else "microphone",
                 "is_default": i["index"] == default_input or (bool(i.get("isLoopbackDevice")) and i["name"].removesuffix(" [Loopback]") == default_output)}
                for i in infos if i["hostApi"] == wasapi and i["maxInputChannels"] > 0]


def record(folder, probe=False):
    import numpy as np
    import pyaudiowpatch as pa
    settings = json.loads((folder / "settings.json").read_text(encoding="utf-8"))
    stop = threading.Event()
    errors = queue.Queue()
    levels = {"microphone": 0, "output": 0}
    started = time.monotonic()
    ready = set()
    manifest_lock = threading.Lock()
    with pa.PyAudio() as audio:
        infos = {device_key(i): i for i in audio.get_device_info_generator()}
        def source_thread(source):
            stream = None
            try:
                info = infos.get(settings[source + "_id"])
                if info is None:
                    raise RuntimeError(f"Selected {source} is no longer available")
                if bool(info.get("isLoopbackDevice")) != (source == "output"):
                    raise RuntimeError("Selected audio source has changed; select devices again")
                rate = int(info["defaultSampleRate"])
                channels = min(int(info["maxInputChannels"]), 2)
                frames = max(1, rate // 10)
                stream = audio.open(format=pa.paInt16, channels=channels, rate=rate, input=True,
                                    input_device_index=int(info["index"]), frames_per_buffer=frames)
                ready.add(source)
                pieces, length, sequence, chunk_start = [], 0, 0, None
                last_read = time.monotonic()
                def flush():
                    nonlocal pieces, length, sequence, chunk_start
                    if not pieces or probe:
                        pieces, length, chunk_start = [], 0, None
                        return
                    name = f"{source}-{sequence:07d}.wav"
                    temporary = folder / (name + ".tmp")
                    with wave.open(str(temporary), "wb") as out:
                        out.setnchannels(1); out.setsampwidth(2); out.setframerate(rate)
                        out.writeframes(b"".join(pieces))
                    with temporary.open("r+b") as handle:
                        os.fsync(handle.fileno())
                    os.replace(temporary, folder / name)
                    with manifest_lock, (folder / "chunks.jsonl").open("a", encoding="utf-8") as handle:
                        handle.write(json.dumps({"file": name, "source": source, "start": chunk_start,
                                                "frames": length, "rate": rate}) + "\n")
                        handle.flush(); os.fsync(handle.fileno())
                    sequence += 1
                    pieces, length, chunk_start = [], 0, None
                try:
                    last_loop = time.monotonic()
                    while not stop.is_set():
                        now = time.monotonic()
                        if now - last_loop > 5:
                            raise RuntimeError("Audio capture interrupted by sleep")
                        last_loop = now
                        if not stream.is_active():
                            raise RuntimeError("Audio device disconnected")
                        available = stream.get_read_available()
                        if available < frames:
                            if now - last_read > .25:
                                levels[source] = 0
                                # WASAPI loopback supplies no frames while an output is idle.
                                # End the current chunk so the next sound keeps its real timestamp.
                                flush()
                            if source == "microphone" and now - last_read > 5:
                                raise RuntimeError("Microphone stopped delivering audio")
                            stop.wait(.02)
                            continue
                        data = stream.read(frames, exception_on_overflow=True)
                        now = time.monotonic()
                        last_read = now
                        samples = np.frombuffer(data, dtype=np.int16).reshape(-1, channels).astype(np.float32).mean(axis=1)
                        levels[source] = min(1.0, float(np.sqrt(np.mean(samples ** 2))) / 12000)
                        if chunk_start is None:
                            chunk_start = max(0, now - started - available / rate)
                        pieces.append(samples.astype(np.int16).tobytes()); length += len(samples)
                        if length >= rate * 2:
                            flush()
                finally:
                    flush()
            except Exception as exc:
                errors.put(f"{source}: {exc}"); stop.set()
            finally:
                if stream is not None:
                    try:
                        stream.stop_stream(); stream.close()
                    except Exception:
                        pass
        threads = [threading.Thread(target=source_thread, args=(s,), daemon=True) for s in levels]
        for thread in threads:
            thread.start()
        last = time.monotonic()
        while not stop.wait(.25):
            now = time.monotonic()
            if (folder / "stop").exists():
                break
            lease = folder / "lease"
            if not lease.exists() or time.time() - lease.stat().st_mtime > 6 or now - last > 5:
                errors.put("JobHound stopped responding or the computer slept; partial audio saved")
                break
            last = now
            if now - started > 10 and len(ready) < 2:
                errors.put("The selected audio devices did not start")
                break
            atomic_json(folder / "meter.json", {"levels": levels, "ready": len(ready) == 2, "duration": now - started})
        stop.set()
        for thread in threads:
            thread.join(timeout=3)
        error = errors.get() if not errors.empty() else None
        atomic_json(folder / "result.json", {"error": error, "duration": time.monotonic() - started})


def prepare(folder):
    from faster_whisper import WhisperModel
    folder.mkdir(exist_ok=True, parents=True)
    WhisperModel("small", device="cpu", compute_type="int8", download_root=str(folder))
    atomic_json(folder / "ready.json", {"model": "small", "device": "cpu", "compute_type": "int8"})


def transcribe(folder, model_folder):
    from faster_whisper import WhisperModel
    settings = json.loads((folder / "settings.json").read_text(encoding="utf-8"))
    try:
        model = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=4,
                             download_root=str(model_folder), local_files_only=True)
    except Exception:
        atomic_json(folder / "transcript-result.json", {"error": "model_unavailable"})
        raise
    results, languages = [], {}
    for source in ("microphone", "output"):
        segments, info = model.transcribe(str(folder / (source + ".wav")), language=settings.get("language"),
                                         vad_filter=True, beam_size=5, condition_on_previous_text=False)
        languages[source] = info.language
        for segment in segments:
            text = segment.text.strip()
            if text:
                results.append({"source": source, "start": segment.start, "end": segment.end, "text": text})
            atomic_json(folder / "progress.json", {"source": source, "seconds": segment.end})
    results.sort(key=lambda s: s["start"])
    atomic_json(folder / "transcript-result.json", {"segments": results, "languages": languages})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["devices", "record", "probe", "prepare", "transcribe"])
    parser.add_argument("--directory", type=Path)
    parser.add_argument("--models", type=Path)
    args = parser.parse_args()
    if args.operation == "devices":
        print(json.dumps(devices()))
    elif args.operation in ("record", "probe"):
        record(args.directory, args.operation == "probe")
    elif args.operation == "prepare":
        prepare(args.directory)
    else:
        transcribe(args.directory, args.models)

if __name__ == "__main__":
    main()
