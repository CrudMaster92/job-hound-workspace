"""Host-only interview routes and a browser-lifetime control connection."""
import asyncio
import hashlib
import json
import os
import uuid
from urllib.parse import urlsplit
from fastapi import APIRouter, Depends, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from pydantic import Field
from .contracts import ExportFormat, InterviewError, PrepareModel, StartRecording, Strict, Transcribe, UpdateInterview
from ..security import is_loopback

class AttachInterview(Strict):
    thread_id: int = Field(ge=1)
    interview_id: int = Field(ge=1)


def local_connection(connection, websocket=False):
    if not is_loopback(connection.client.host if connection.client else None):
        raise HTTPException(403, "Interviews are available only on the host computer")
    host = urlsplit("http://" + connection.headers.get("host", "")).hostname
    if not is_loopback(host):
        raise HTTPException(403, "A loopback host is required")
    origin = connection.headers.get("origin")
    allowed = {f"http://{connection.headers.get('host')}", f"https://{connection.headers.get('host')}"}
    allowed.update(v.strip() for v in os.getenv("JOBHOUND_ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(","))
    if (origin and origin not in allowed) or (websocket and not origin) or connection.headers.get("sec-fetch-site") == "cross-site":
        raise HTTPException(403, "Untrusted interview control origin")


def mount_interviews(app, service, attachments):
    def local(request: Request):
        local_connection(request)
    router = APIRouter(prefix="/api/v1/interviews", dependencies=[Depends(local)])

    @app.exception_handler(InterviewError)
    async def interview_error(request, exc):
        from fastapi.responses import JSONResponse
        return JSONResponse({"detail": {"code": exc.code, "message": str(exc)}}, status_code=exc.status)

    @router.get("/capabilities")
    def capabilities():
        return service.capabilities()

    @router.post("/prepare", status_code=202)
    def prepare(payload: PrepareModel):
        return service.prepare(payload.confirm_download)

    @router.get("")
    def listing(archived: bool = False, offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=100), query: str = Query("", max_length=200)):
        return service.store.list(archived, offset, limit, query)

    @router.post("/recordings", status_code=202)
    def start(payload: StartRecording):
        return service.start_recording(payload)

    @router.post("/probe", status_code=202)
    def probe(payload: StartRecording):
        return service.start_probe(payload)

    @router.delete("/probe")
    def stop_probe():
        with service.lock:
            service.end_probe()
        return {"probe_active": False}

    @router.get("/{interview_id}")
    def get(interview_id: int, offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=200), query: str = Query("", max_length=200)):
        return {"interview": service.store.get(interview_id), "segments": service.store.segments(interview_id, offset, limit, query),
                "progress": service.read_json(service.store.directory(interview_id) / "progress.json")}

    @router.post("/{interview_id}/stop", status_code=202)
    def stop(interview_id: int):
        return service.stop_recording(interview_id)

    @router.post("/{interview_id}/transcribe", status_code=202)
    def transcribe(interview_id: int, payload: Transcribe):
        return service.transcribe(interview_id, payload.request_id, payload.language)

    @router.patch("/{interview_id}")
    def update(interview_id: int, payload: UpdateInterview):
        with service.lock:
            return service.store.update(interview_id, payload)

    @router.delete("/{interview_id}")
    def purge(interview_id: int, confirm: bool = False):
        if not confirm:
            raise InterviewError("confirmation_required", "Confirm permanent deletion of this archived interview", 422)
        with service.lock:
            return service.store.purge(interview_id)

    @router.get("/{interview_id}/export-info")
    def export_info(request: Request, interview_id: int, format: ExportFormat = "txt"):
        with service.lock:
            value = service.export_info(interview_id, format)
        return {**value, "download_url": f"{str(request.base_url).rstrip('/')}/api/v1/interviews/{interview_id}/export?format={format}"}

    @router.get("/{interview_id}/export")
    def export(interview_id: int, format: ExportFormat = "audio"):
        with service.lock:
            path, mime = service.export(interview_id, format)
        return FileResponse(path, media_type=mime, filename=f"interview-{interview_id}-{path.name}",
                            headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})

    @router.post("/attachments", status_code=201)
    def attach(payload: AttachInterview):
        if not service.store.db.get_chat_thread(payload.thread_id):
            raise InterviewError("chat_not_found", "Chat not found", 404)
        item = service.store.get(payload.interview_id)
        if item["archived"] or item["transcription_state"] != "ready":
            raise InterviewError("transcript_unavailable", "Choose an active interview with a completed transcript")
        path, _ = service.export(payload.interview_id, "txt")
        text = path.read_text(encoding="utf-8")
        digest = hashlib.sha256(text.encode()).hexdigest()
        with service.store.db.connect() as connection:
            connection.execute("UPDATE chat_threads SET private_local=1 WHERE id=?", (payload.thread_id,))
            existing = connection.execute("SELECT * FROM chat_attachments WHERE thread_id=? AND source_interview_id=? AND sha256=? AND attached_at IS NULL", (payload.thread_id, payload.interview_id, digest)).fetchone()
        if existing:
            return {"attachment": attachments.public(dict(existing))}
        value = service.store.db.create_chat_attachment({
            "thread_id": payload.thread_id, "source_interview_id": payload.interview_id,
            "original_filename": item["title"] + ".txt", "mime_type": "text/plain", "extension": ".txt",
            "size_bytes": len(text.encode()), "sha256": hashlib.sha256(text.encode()).hexdigest(),
            "extracted_text": text, "extraction_status": "complete" if text else "empty"})
        return {"attachment": attachments.public(value)}

    app.include_router(router)

    @app.websocket("/api/v1/interviews/control")
    async def control(socket: WebSocket):
        try:
            local_connection(socket, websocket=True)
        except HTTPException:
            await socket.close(code=1008)
            return
        await socket.accept()
        client_id = uuid.uuid4().hex
        service.connected(client_id)
        async def receive():
            while True:
                # The connection is a presence lease, never an arbitrary command transport.
                await socket.receive_text()
        receiver = asyncio.create_task(receive())
        try:
            while not receiver.done():
                await socket.send_json(service.status())
                await asyncio.sleep(.5)
        except (WebSocketDisconnect, RuntimeError, OSError):
            pass
        finally:
            service.disconnected(client_id)
            receiver.cancel()
            await asyncio.gather(receiver, return_exceptions=True)
