"""The ten focused interview MCP tools; all call the same loopback API as humans."""
from typing import Annotated, Any
from pydantic import Field
from .contracts import ExportFormat, StartRecording, UpdateInterview


def register_tools(mcp, client, read, write, destructive):
    @mcp.tool(annotations=read)
    async def get_interview_capabilities() -> dict[str, Any]:
        """Inspect local audio devices, open interface, model download status/run ID, and active recording."""
        return await client().request("GET", "interviews/capabilities")

    @mcp.tool(annotations=write)
    async def prepare_interview_transcription(confirm_download: bool = False) -> dict[str, Any]:
        """Explicitly download the free local speech model; poll capabilities until ready or failed."""
        return await client().request("POST", "interviews/prepare", json={"confirm_download": confirm_download})

    @mcp.tool(annotations=read)
    async def list_interviews(archived: bool = False, offset: Annotated[int, Field(ge=0)] = 0,
                              limit: Annotated[int, Field(ge=1, le=100)] = 50,
                              query: Annotated[str, Field(max_length=200)] = "") -> dict[str, Any]:
        """Search local interview titles and transcripts, with bounded pagination."""
        return await client().request("GET", "interviews", params={"archived": archived, "offset": offset, "limit": limit, "query": query})

    @mcp.tool(annotations=read)
    async def get_interview(interview_id: Annotated[int, Field(ge=1)], offset: Annotated[int, Field(ge=0)] = 0,
                            limit: Annotated[int, Field(ge=1, le=200)] = 100,
                            query: Annotated[str, Field(max_length=200)] = "") -> dict[str, Any]:
        """Read capture/transcription run state and paginated timestamped original and corrected text."""
        return await client().request("GET", f"interviews/{interview_id}", params={"offset": offset, "limit": limit, "query": query})

    @mcp.tool(annotations=write)
    async def start_interview_recording(request: StartRecording, test_audio: bool = False) -> dict[str, Any]:
        """Start explicitly requested mic and output capture while a local JobHound interface is open. test_audio meters for up to 60 seconds without saving."""
        return await client().request("POST", "interviews/probe" if test_audio else "interviews/recordings", json=request.model_dump())

    @mcp.tool(annotations=write)
    async def stop_interview_recording(interview_id: Annotated[int | None, Field(ge=1)] = None) -> dict[str, Any]:
        """Stop and save an interview asynchronously. Omit ID only to stop the unsaved audio test."""
        if interview_id is None:
            return await client().request("DELETE", "interviews/probe")
        return await client().request("POST", f"interviews/{interview_id}/stop")

    @mcp.tool(annotations=write)
    async def transcribe_interview(interview_id: Annotated[int, Field(ge=1)], request_id: Annotated[str, Field(min_length=1, max_length=160)],
                                    language: Annotated[str | None, Field(pattern=r"^[a-z]{2,3}$")] = None) -> dict[str, Any]:
        """Queue/retry local transcription of saved audio; inspect get_interview for terminal state. Reuse request_id only for retries of the same request."""
        return await client().request("POST", f"interviews/{interview_id}/transcribe", json={"request_id": request_id, "language": language})

    @mcp.tool(annotations=write)
    async def update_interview(interview_id: Annotated[int, Field(ge=1)], changes: UpdateInterview) -> dict[str, Any]:
        """Rename, archive/restore, label sources, or correct transcript segments using the revision last read."""
        return await client().request("PATCH", f"interviews/{interview_id}", json=changes.model_dump(exclude_none=True))

    @mcp.tool(annotations=read)
    async def export_interview(interview_id: Annotated[int, Field(ge=1)], format: ExportFormat = "txt") -> dict[str, Any]:
        """Inspect the interview and return a host-only download URL for WAV audio, TXT, or complete JSON."""
        return await client().request("GET", f"interviews/{interview_id}/export-info", params={"format": format})

    @mcp.tool(annotations=destructive)
    async def purge_interview(interview_id: Annotated[int, Field(ge=1)], confirm_permanent_delete: bool = False) -> dict[str, Any]:
        """Explicitly and permanently delete an archived, stopped interview and all its audio and transcript files."""
        return await client().request("DELETE", f"interviews/{interview_id}", params={"confirm": confirm_permanent_delete})
