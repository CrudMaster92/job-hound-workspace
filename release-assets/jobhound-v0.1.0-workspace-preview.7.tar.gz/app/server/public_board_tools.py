"""Seven focused tools using the same public-board contracts as the human UI."""
from typing import Annotated
from pydantic import Field
from .public_board_contracts import BoardQuery, FavouritesImport, FavouritesTransfer


def register_tools(mcp, client, read, write):
    @mcp.tool(annotations=read)
    async def get_public_board_status() -> dict:
        """Inspect public feed freshness, source failures, collections and local favourite identifiers."""
        return await client().request("GET", "public-board/status")

    @mcp.tool(annotations=read)
    async def search_public_jobs(query: BoardQuery) -> dict:
        """Search shared public jobs or local favourites with the same filters, ordering and pagination as the board."""
        return await client().search_public_jobs(query.model_dump(exclude_none=True))

    @mcp.tool(annotations=read)
    async def get_public_job(job_id: Annotated[str, Field(min_length=1, max_length=300, pattern=r"^[A-Za-z0-9_.:-]+$")]) -> dict:
        """Read a public posting or durable local saved snapshot and its source URL."""
        return await client().request("GET", f"public-board/jobs/{job_id}")

    @mcp.tool(annotations=write)
    async def set_public_job_saved(job_id: Annotated[str, Field(min_length=1, max_length=300, pattern=r"^[A-Za-z0-9_.:-]+$")], saved: bool) -> dict:
        """Save or unsave a posting locally. Saving neither installs a tracker nor marks an application as submitted."""
        return await client().request("PATCH", f"public-board/jobs/{job_id}/saved", json={"saved": saved, "actor_type": "agent"})

    @mcp.tool(annotations=read)
    async def export_board_favourites() -> dict:
        """Export an explicit portable favourites file; contains no recipes, preferences, documents or application history."""
        return await client().request("GET", "public-board/favourites/export")

    @mcp.tool(annotations=read)
    async def preview_board_favourites(transfer: FavouritesTransfer) -> dict:
        """Validate and preview an additive favourites transfer before importing. Does not change saved roles."""
        return await client().request("POST", "public-board/favourites/preview", json=transfer.model_dump(exclude_none=True))

    @mcp.tool(annotations=write)
    async def import_board_favourites(request: FavouritesImport) -> dict:
        """Add the exact favourites transfer previously previewed. Retries never duplicate jobs or company favourites."""
        return await client().request("POST", "public-board/favourites/import", json={**request.model_dump(exclude_none=True), "actor_type": "agent"})
