"""Public contracts for the scheduled daily recap skill."""
from datetime import datetime
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, Field, field_validator

DEFAULT_PROMPT = (
    "Write a warm, concise morning briefing of 200–350 words. Highlight up to five new "
    "matching roles, relevant saved-job changes, and tracker health. Explain why the roles "
    "are worth a look using only the supplied facts. Be candid when there is nothing new."
)


class RecapSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool = True
    schedule_kind: Literal["manual", "interval", "daily", "weekly"] = "daily"
    interval_hours: int = Field(default=24, ge=1, le=168)
    local_time: str = "09:00"
    weekday: int = Field(default=0, ge=0, le=6)
    timezone: str = "America/Toronto"
    prompt: str = Field(default=DEFAULT_PROMPT, min_length=1, max_length=6000)
    provider: Literal["inherit", "codex", "claude", "hermes", "openclaw", "openrouter", "none"] = "inherit"
    model: str | None = Field(default=None, max_length=120)
    allow_repairs: bool = False

    @field_validator("local_time")
    @classmethod
    def valid_time(cls, value):
        if len(value) != 5:
            raise ValueError("Use HH:MM")
        datetime.strptime(value, "%H:%M")
        return value

    @field_validator("timezone")
    @classmethod
    def valid_timezone(cls, value):
        try:
            ZoneInfo(value)
        except (KeyError, ValueError) as exc:
            raise ValueError("Use a valid IANA timezone") from exc
        return value


class RecapRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    request_id: str = Field(min_length=1, max_length=160)


class RecapNarrative(BaseModel):
    model_config = ConfigDict(extra="forbid")
    overview: str = Field(min_length=1, max_length=2400)


class RecapJob(BaseModel):
    id: int
    company_id: int
    company_name: str
    title: str
    url: str
    reason: str
    location: str | None = None
    remote_mode: str | None = None
    salary_min: float | None = None
    salary_max: float | None = None
    salary_currency: str | None = None
    salary_period: str | None = None
    first_seen_at: str
    is_active: bool
    milestone: str | None = None
    outcome: str | None = None
    current_stage: str | None = None


class RecapSavedUpdate(BaseModel):
    id: int
    title: str
    url: str
    detail: str


class RecapRepair(BaseModel):
    company_id: int
    company_name: str
    run_id: int
    status: str


class RecapReport(BaseModel):
    run_id: int
    generated_at: str
    window_start: str
    window_end: str
    provider: str | None
    model: str | None
    fallback: bool
    fallback_reason: str | None = None
    overview: str
    new_count: int
    update_count: int
    jobs: list[RecapJob]
    updates: list[RecapSavedUpdate]
    health_note: str
    repairs: list[RecapRepair]


class RecapRun(BaseModel):
    """Stable run envelope. Report rows contain canonical job facts, not parsed prose."""
    id: int
    status: Literal["queued", "running", "complete", "failed"]
    terminal: bool
    created_at: str
    finished_at: str | None = None
    window_start: str
    window_end: str
    thread_id: int | None = None
    message_id: int | None = None
    chat_url: str | None = None
    error: str | None = None
    report: RecapReport | None = None


class RecapSettingsView(RecapSettings):
    next_run_at: str | None
    default_prompt: str


class RecapState(BaseModel):
    latest: RecapRun | None
    last_run: RecapRun | None
    settings: RecapSettingsView
