"""Shared read contracts for HTTP, MCP (through HTTP), and embedded Chat."""
from datetime import date


class JobQueries:
    def __init__(self, db, present):
        self.db, self.present = db, present

    def search(self, *, limit=100, offset=0, sort="default", **filters):
        if filters.get("posted_within_days") not in (None, 1, 7, 30):
            raise ValueError("posted_within_days must be 1, 7, or 30")
        if filters.get("saved") is True:
            filters.update(matching=None, dismissed=None, active=None)
        home = self.db.get_settings().get("home_location")
        items = self.db.list_jobs(**filters, limit=limit, offset=offset, sort_by=sort,
                                  home_location=home if isinstance(home, dict) else None)
        return {"items": [self.present(item, home_location=home) for item in items],
                "count": len(items), "total": self.db.count_jobs(**filters), "offset": offset}

    def read(self, job_id):
        value = self.db.get_job(job_id)
        if not value:
            raise KeyError("Job not found")
        return self.present(value, include_activities=True)

    def tracker(self, *, from_date=None, to_date=None, include_closed=False):
        if from_date and to_date and date.fromisoformat(from_date) > date.fromisoformat(to_date):
            raise ValueError("from must be on or before to")
        value = self.db.application_tracker(from_date=from_date, to_date=to_date,
                                           include_closed=include_closed)
        value["applications"] = [self.present(item) for item in value["applications"]]
        return value
