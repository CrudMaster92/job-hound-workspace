"""Read-only, hash-verified release catalog fallback. Contains public data only."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re

MAX_SNAPSHOT_BYTES = 80 * 1024 * 1024


def canonical_hash(value: dict) -> str:
    raw = (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()
    return hashlib.sha256(raw).hexdigest()


def read_object(path: Path, limit: int) -> dict:
    if path.is_symlink() or path.stat().st_size > limit:
        raise ValueError("Invalid or oversized packaged preset file")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Packaged preset file must contain an object")
    return value


def catalog(directory: Path, catalog_url: str) -> tuple[dict, dict]:
    meta = read_object(directory / "snapshot.json", 65536)
    if meta.get("format") != "jobhound-preset-snapshot" or meta.get("version") != 1 or meta.get("catalog_url") != catalog_url:
        raise ValueError("Packaged preset snapshot does not match the configured catalog")
    value = read_object(directory / "catalog.json", 2_000_000)
    if canonical_hash(value) != meta.get("catalog_sha256"):
        raise ValueError("Packaged preset catalog failed its hash check")
    if value.get("format") != "jobhound-preset-catalog" or value.get("catalog_version") != 3:
        raise ValueError("Unsupported packaged preset catalog")
    if not isinstance(value.get("collections"), list) or not isinstance(value.get("search_pages"), list):
        raise ValueError("Incomplete packaged preset catalog")
    return value, meta


def references(value):
    if isinstance(value, dict):
        for path_key, hash_key in (("path", "sha256"), ("bundle_path", "bundle_sha256")):
            if path_key in value and hash_key in value:
                yield {"path": value[path_key], "sha256": value[hash_key]}
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def artifact(directory: Path, relative: str, expected: str) -> dict:
    if not re.fullmatch(r"[a-f0-9]{64}", expected):
        raise ValueError("Invalid packaged preset artifact hash")
    filename = hashlib.sha256(relative.encode()).hexdigest() + ".json"
    value = read_object(directory / "artifacts" / filename, 5_000_000)
    if canonical_hash(value) != expected:
        raise ValueError("Packaged preset artifact failed its catalog hash check")
    return value


def verified_files(directory: Path, catalog_url: str):
    value, meta = catalog(directory, catalog_url)
    files = [directory / "catalog.json", directory / "snapshot.json"]
    seen, pending = {}, list(references(value))
    while pending:
        reference = pending.pop()
        relative, expected = reference["path"], reference["sha256"]
        if relative in seen:
            if seen[relative] != expected:
                raise ValueError("Conflicting snapshot artifact revisions")
            continue
        if not relative or relative.startswith(("/", "\\")) or ".." in relative.split("/"):
            raise ValueError("Unsafe snapshot reference")
        seen[relative] = expected
        if len(seen) > 5000:
            raise ValueError("Too many snapshot artifacts")
        child = artifact(directory, relative, expected)
        files.append(directory / "artifacts" / (hashlib.sha256(relative.encode()).hexdigest() + ".json"))
        pending.extend(references(child))
    if len(seen) != meta.get("artifact_count") or sum(path.stat().st_size for path in files) > MAX_SNAPSHOT_BYTES:
        raise ValueError("Snapshot completeness/size check failed")
    return files
