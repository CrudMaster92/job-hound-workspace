"""Deployment limits, not a second product or domain implementation."""
import os
import sys


def agent_profile() -> bool:
    return os.getenv("JOBHOUND_PROFILE", "desktop") == "agent"


def local_scrapers_available() -> bool:
    return not agent_profile() or os.getenv("JOBHOUND_AGENT_LOCAL_SCRAPERS") == "1"


def capabilities() -> dict:
    local = local_scrapers_available()
    def state(available, reason=""):
        return {"state": "available" if available else "unsupported", "reason": reason,
                "handoff": None if available else "Use the desktop app on a supported host."}
    return {"profile": "agent" if agent_profile() else "desktop",
            "public_board": state(True), "application_tracking": state(True),
            "documents_and_drafts": state(True), "dashboard": state(True),
            "public_contributions": state(True), "preset_browsing": state(True),
            "local_scrapers": state(local, "This agent profile consumes the shared feed and proposes public recipes; local scraper execution is disabled."),
            "native_audio_capture": state(sys.platform == "win32", "Capturing your computer's audio requires the Windows desktop host."),
            "continuous_schedules": {"state": "unverified" if agent_profile() else "available",
                                     "reason": "On-demand service lifetime is not continuous host uptime." if agent_profile() else ""},
            "github_submission": {"state": "external_setup", "reason": "Use your host's supported human GitHub OAuth connection. JobHound never stores GitHub credentials."},
            "private_web_mount": {"state": "unverified" if agent_profile() else "available"}}


def require_local_scrapers():
    if not local_scrapers_available():
        from fastapi import HTTPException
        raise HTTPException(409, detail={"code": "scraper_execution_unavailable",
            "message": "Use the shared board or prepare a public contribution. This host cannot create or run local scrapers.",
            "capability": capabilities()["local_scrapers"]})
