"""Read-only activity counts shared by the dashboard and its MCP tool."""
from typing import TypedDict
from .db import Database


class ActivitySummary(TypedDict):
    chat: int
    scrapers: int
    transcriptions: int | None


def activity_summary(db: Database, *, local: bool) -> ActivitySummary:
    with db.connect() as connection:
        privacy = "" if local else "AND t.private_local=0 AND (t.context_type IS NULL OR t.context_type!='document')"
        chat = connection.execute(f"""SELECT COUNT(*) FROM chat_turns c
            JOIN chat_threads t ON t.id=c.thread_id
            WHERE c.status IN ('queued','running') {privacy}""").fetchone()[0]
        scrapers = connection.execute("SELECT COUNT(*) FROM runs WHERE status IN ('queued','running')").fetchone()[0]
        transcriptions = None
        if local:
            transcriptions = connection.execute("""SELECT COUNT(*) FROM interviews
                WHERE capture_state IN ('recording','saving')
                OR json_extract(metadata,'$.transcription_state') IN ('queued','processing')""").fetchone()[0]
    return {"chat": chat, "scrapers": scrapers, "transcriptions": transcriptions}
