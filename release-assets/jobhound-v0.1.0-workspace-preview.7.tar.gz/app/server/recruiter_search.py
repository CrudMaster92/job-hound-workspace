"""Deterministic recruiter X-ray queries with optional validated live discovery."""

from __future__ import annotations

import asyncio
import re
from typing import Any, Literal
from urllib.parse import urlencode, urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .ai_connections import AIConnectionRegistry


RECRUITER_TITLES = (
    "Recruiter",
    "Technical Recruiter",
    "Talent Acquisition",
    "Talent Partner",
    "Talent Acquisition Partner",
    "Sourcer",
)

FUNCTION_SIGNALS = (
    (("machine learning", "ai/ml", "artificial intelligence"), "Machine Learning"),
    (("research", "scientist"), "Research"),
    (("software", "engineering", "engineer", "infrastructure"), "Engineering"),
    (("product",), "Product"),
    (("marketing", "growth", "brand"), "Marketing"),
    (("sales", "revenue", "account executive"), "Sales"),
    (("design", "designer"), "Design"),
    (("finance", "accounting"), "Finance"),
    (("legal", "counsel", "compliance"), "Legal"),
)


class RecruiterCandidateProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=160)
    headline: str = Field(min_length=1, max_length=300)
    location: str = Field(max_length=200)
    profile_url: str = Field(min_length=1, max_length=1000)
    matched_signals: list[str] = Field(max_length=8)
    confidence: Literal["strong", "possible"]


class RecruiterSearchProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")

    candidates: list[RecruiterCandidateProposal] = Field(max_length=3)


class RecruiterCandidate(RecruiterCandidateProposal):
    @field_validator("profile_url")
    @classmethod
    def public_linkedin_profile(cls, value: str) -> str:
        parsed = urlsplit(value.strip())
        host = (parsed.hostname or "").casefold()
        if parsed.scheme.casefold() != "https" or not (host == "linkedin.com" or host.endswith(".linkedin.com")):
            raise ValueError("profile_url must be a public HTTPS LinkedIn URL")
        if not parsed.path.casefold().startswith("/in/"):
            raise ValueError("profile_url must identify a LinkedIn /in/ profile")
        return value.strip()


def _dedupe(values: list[str], limit: int) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        cleaned = " ".join(value.split()).strip(" ,;|-/")
        key = cleaned.casefold()
        if cleaned and key not in seen:
            seen.add(key)
            result.append(cleaned)
        if len(result) >= limit:
            break
    return result


def _location_terms(job: dict[str, Any]) -> list[str]:
    raw = str(job.get("location") or job.get("location_city") or "")
    values: list[str] = []
    city = str(job.get("location_city") or "").strip()
    if city:
        values.append(city)
    values.extend(re.split(r"[,;/|]", raw))
    return [value for value in _dedupe(values, 4) if value.casefold() not in {"remote", "hybrid"}]


def _function_terms(job: dict[str, Any]) -> list[str]:
    evidence = " ".join((str(job.get("title") or ""), str(job.get("description") or "")[:5000])).casefold()
    terms = [label for needles, label in FUNCTION_SIGNALS if any(needle in evidence for needle in needles)]
    return _dedupe(terms, 3)


def _or_clause(values: list[str] | tuple[str, ...]) -> str:
    return "(" + " OR ".join(f'"{value}"' for value in values) + ")"


def build_recruiter_search(job: dict[str, Any]) -> dict[str, Any]:
    company = " ".join(str(job.get("company_name") or job.get("company") or "").split()).strip()
    if not company:
        raise ValueError("The job must include a company before recruiters can be searched")
    locations = _location_terms(job)
    functions = _function_terms(job)
    parts = ["site:linkedin.com/in/", _or_clause(RECRUITER_TITLES), f'"{company}"']
    if locations:
        parts.append(_or_clause(locations))
    if functions:
        parts.append(_or_clause(functions))
    query = " ".join(parts)
    return {
        "job_id": int(job["id"]),
        "company": company,
        "locations_used": locations,
        "title_terms_used": list(RECRUITER_TITLES),
        "functional_terms_used": functions,
        "boolean_query": query,
        "search_url": "https://www.google.com/search?" + urlencode({"q": query}),
    }


def _search_prompt(context: dict[str, Any]) -> str:
    return f"""Find up to three potential recruiters for a job at {context['company']} using public web search.
Run or closely follow this Google X-ray query:
{context['boolean_query']}

Return only public LinkedIn profile URLs whose path begins with /in/. Rank people whose public search result
headline or snippet supports the company, a recruiting/talent/sourcing role, and the supplied location or
functional terms. These are potential contacts, not confirmed owners of the requisition. Do not sign in,
open private pages, collect email addresses or phone numbers, or claim anyone posted the job. If fewer than
three supported profiles are visible, return fewer; do not invent candidates. matched_signals must briefly
name the public signals supporting each result."""


async def find_recruiters(
    job: dict[str, Any],
    connections: AIConnectionRegistry,
    settings: dict[str, Any],
    *,
    live_search: bool = True,
) -> dict[str, Any]:
    result = {
        **build_recruiter_search(job),
        "candidates": [],
        "live_search_attempted": False,
        "provider": None,
        "warning": None,
    }
    if not live_search or not settings.get("chat_web_browsing", True):
        result["warning"] = "Live web search is disabled; use the generated Google X-ray link."
        return result
    connection = settings.get("ai_connection") or settings.get("chat_provider")
    if not connection or connection == "none":
        result["warning"] = "No outbound AI connection is selected; use the generated Google X-ray link."
        return result
    result["live_search_attempted"] = True
    result["provider"] = connection
    try:
        proposal = await asyncio.to_thread(
            connections.run_structured,
            connection,
            _search_prompt(result),
            RecruiterSearchProposal,
            model=settings.get("ai_model") or settings.get("chat_model"),
            browsing=True,
        )
        candidates: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in proposal.get("candidates", []):
            try:
                candidate = RecruiterCandidate.model_validate(item).model_dump(mode="json")
            except ValueError:
                continue
            key = candidate["profile_url"].rstrip("/").casefold()
            if key not in seen:
                seen.add(key)
                candidates.append(candidate)
            if len(candidates) == 3:
                break
        result["candidates"] = candidates
        if not candidates:
            result["warning"] = "No supported public LinkedIn profiles were verified; use the generated Google X-ray link."
    except Exception as exc:
        result["warning"] = f"Live recruiter search was unavailable: {str(exc)[:500]}. Use the generated Google X-ray link."
    return result


def recruiter_reply(result: dict[str, Any]) -> str:
    count = len(result.get("candidates", []))
    if count:
        return (
            f"I found {count} potential recruiter profile{'s' if count != 1 else ''} for "
            f"{result['company']}. These are public matches, not confirmed owners of this requisition."
        )
    return (
        f"I couldn't verify a public recruiter profile for {result['company']}, but I built a Google "
        "X-ray search you can open and refine."
    )
