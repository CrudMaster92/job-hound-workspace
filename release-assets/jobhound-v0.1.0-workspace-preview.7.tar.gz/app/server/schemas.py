"""Pydantic request/response contracts for the JobHound API."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator, model_validator

from .career_document_drafts import CareerDocumentDraftContent
from .company_discovery import CompanyDiscoveryRequest
from .interview_prep import InterviewPrepRequest
from .intro_letter import IntroLetterRequest


class APIModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


BUILTIN_DASHBOARD_KEYS = {
    "daily_recap",
    "saved_jobs", "recent_chats", "scraper_alerts", "recent_ats_activity",
    "new_roles", "profile_visibility", "application_funnel", "create_widget",
}
DashboardCardKey = str


class DashboardLayoutItem(APIModel):
    key: DashboardCardKey
    visible: bool = True
    size: Literal["standard", "tall"] = "standard"
    width: Literal["standard", "wide"] = "standard"

    @field_validator("key")
    @classmethod
    def valid_key(cls, value: str) -> str:
        if value in BUILTIN_DASHBOARD_KEYS:
            return value
        if value.startswith("widget:") and value[7:].isdigit() and int(value[7:]) > 0:
            return value
        raise ValueError("unknown dashboard card key")


class DashboardLayout(APIModel):
    revision: int = Field(ge=1)
    items: list[DashboardLayoutItem]
    updated_at: str | None = None


class DashboardLayoutUpdate(APIModel):
    revision: int = Field(ge=1)
    items: list[DashboardLayoutItem] = Field(min_length=8, max_length=100)

    @model_validator(mode="after")
    def complete_unique_catalog(self):
        keys = [item.key for item in self.items]
        if len(set(keys)) != len(keys):
            raise ValueError("dashboard layout items must have unique keys")
        if not BUILTIN_DASHBOARD_KEYS.issubset(keys):
            raise ValueError("dashboard layout must contain every dashboard card exactly once")
        return self


class DashboardCard(APIModel):
    key: DashboardCardKey
    title: str
    count: int = Field(ge=0)
    items: list[dict[str, Any]] = Field(default_factory=list)


class CriteriaValues(APIModel):
    cities: list[str] = Field(default_factory=list)
    title_terms: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)

    @field_validator("cities", "title_terms", "keywords")
    @classmethod
    def clean_terms(cls, values: list[str]) -> list[str]:
        seen: set[str] = set()
        cleaned: list[str] = []
        for value in values:
            value = " ".join(value.split()).strip()
            key = value.casefold()
            if value and key not in seen:
                seen.add(key)
                cleaned.append(value)
        return cleaned


class CriteriaOverride(APIModel):
    mode: Literal["inherit", "replace", "any"] = "inherit"
    values: list[str] = Field(default_factory=list)

    @field_validator("values")
    @classmethod
    def clean_values(cls, values: list[str]) -> list[str]:
        return CriteriaValues.clean_terms(values)


class CompanyCriteria(APIModel):
    cities: CriteriaOverride = Field(default_factory=CriteriaOverride)
    title_terms: CriteriaOverride = Field(default_factory=CriteriaOverride)
    keywords: CriteriaOverride = Field(default_factory=CriteriaOverride)


class OptionalFeaturesUpdate(APIModel):
    profile_visibility_enabled: bool


class SettingsUpdate(APIModel):
    criteria: CriteriaValues = Field(default_factory=CriteriaValues)
    timezone: str = "America/Toronto"
    default_schedule_kind: Literal["manual", "interval", "daily", "weekly"] = "daily"
    default_interval_hours: int = Field(default=24, ge=1, le=168)
    default_local_time: str = "09:00"
    default_weekday: int = Field(default=0, ge=0, le=6)
    # Compact frontend aliases. Connection fields are read-only hints and ignored on write.
    default_schedule: str | None = None
    codex_connected: bool | None = None
    codex_model: str | None = None
    lan_url: str | None = None
    chat_provider: Literal["codex", "hermes", "claude", "openclaw", "openrouter", "none"] = "codex"
    chat_model: str | None = Field(default=None, max_length=120)
    chat_web_browsing: bool = True
    chat_auto_create_monitors: bool = True
    profile_visibility_enabled: bool | None = None
    home_address: str | None = Field(default=None, max_length=500)


    @field_validator("default_local_time")
    @classmethod
    def valid_time(cls, value: str) -> str:
        try:
            datetime.strptime(value, "%H:%M")
        except ValueError as exc:
            raise ValueError("time must be HH:MM") from exc
        return value

    @model_validator(mode="after")
    def apply_schedule_alias(self):
        if self.default_schedule:
            if self.default_schedule == "every_6_hours":
                self.default_schedule_kind, self.default_interval_hours = "interval", 6
            elif self.default_schedule in {"daily", "weekly", "manual"}:
                self.default_schedule_kind = self.default_schedule
        return self

    @field_validator("home_address")
    @classmethod
    def clean_home_address(cls, value: str | None) -> str | None:
        return " ".join(value.split()) if value is not None else None


class HomeLocationUpdate(APIModel):
    address: str = Field(min_length=1, max_length=500)

    @field_validator("address")
    @classmethod
    def clean_address(cls, value: str) -> str:
        return " ".join(value.split())


class PlatformProfileUpdate(APIModel):
    visibility: Literal[
        "unknown", "not_visible", "recruiters_only", "all_members", "visible"
    ]
    reminder_days: int = Field(default=30, ge=0, le=365)
    confirmation_source: Literal["human", "agent"] = "human"


class PlatformCatalogCreate(APIModel):
    id: str | None = Field(default=None, max_length=64)
    name: str = Field(min_length=1, max_length=100)
    home_url: str = Field(min_length=8, max_length=2048)
    profile_url: str | None = Field(default=None, max_length=2048)
    description: str = Field(default="", max_length=500)
    industry_keywords: list[str] = Field(default_factory=list, max_length=30)
    location_keywords: list[str] = Field(default_factory=list, max_length=30)
    countries: list[str] = Field(default_factory=lambda: ["GLOBAL"], max_length=30)
    regions: list[str] = Field(default_factory=list, max_length=100)
    work_types: list[str] = Field(default_factory=list, max_length=20)
    discovery_type: str = Field(default="recruiter database", max_length=80)
    visibility_scheme: Literal["binary", "linkedin"] = "binary"
    source_url: str | None = Field(default=None, max_length=2048)


class AgentInstructionsUpdate(APIModel):
    user_context: str | None = Field(default=None, max_length=6000)
    chat_guidance: str | None = Field(default=None, max_length=6000)
    scraper_build_guidance: str | None = Field(default=None, max_length=6000)
    scraper_repair_guidance: str | None = Field(default=None, max_length=6000)

    @field_validator(
        "user_context", "chat_guidance", "scraper_build_guidance", "scraper_repair_guidance"
    )
    @classmethod
    def valid_instruction_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if any(ord(char) < 32 and char not in "\r\n\t" for char in value):
            raise ValueError("agent instructions cannot contain control characters")
        return value

    @model_validator(mode="after")
    def valid_combined_length(self):
        if sum(len(value or "") for value in (
            self.user_context, self.chat_guidance, self.scraper_build_guidance,
            self.scraper_repair_guidance,
        )) > 16000:
            raise ValueError("combined agent instructions are limited to 16000 characters")
        return self


class OpenAIOptions(APIModel):
    reasoning_effort: str | None = Field(default=None, max_length=30)


class AISelectionUpdate(APIModel):
    openai_options: OpenAIOptions | None = None
    connection: Literal["codex", "claude", "openrouter", "hermes", "openclaw", "none"]
    model: str | None = Field(default=None, max_length=200)

    @field_validator("model")
    @classmethod
    def clean_model(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


class OpenRouterCredentialUpdate(APIModel):
    api_key: str = Field(min_length=12, max_length=512)

    @field_validator("api_key")
    @classmethod
    def clean_key(cls, value: str) -> str:
        return value.strip()


class DocumentUpdate(APIModel):
    label: str | None = Field(default=None, min_length=1, max_length=120)
    archived: bool | None = None

    @field_validator("label")
    @classmethod
    def clean_label(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = " ".join(value.split()).strip()
        if not cleaned:
            raise ValueError("document label cannot be empty")
        return cleaned

    @model_validator(mode="after")
    def has_change(self):
        if self.label is None and self.archived is None:
            raise ValueError("provide a label or archived state")
        return self


class DocumentDraftCreate(APIModel):
    source_document_id: int | None = Field(default=None, ge=1)
    content: CareerDocumentDraftContent


class DocumentDraftUpdate(APIModel):
    content: CareerDocumentDraftContent


class CompanyCreate(APIModel):
    name: str = Field(min_length=1, max_length=160)
    careers_url: HttpUrl
    logo_url: HttpUrl | None = None
    preset_ids: list[str] = Field(default_factory=list, max_length=20)
    schedule_kind: Literal["manual", "interval", "daily", "weekly"] = "daily"
    interval_hours: int = Field(default=24, ge=1, le=168)
    local_time: str = "09:00"
    weekday: int = Field(default=0, ge=0, le=6)
    criteria: CompanyCriteria | CriteriaValues = Field(default_factory=CompanyCriteria)
    schedule: str | None = None
    build_now: bool = False

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        return " ".join(value.split()).strip()

    @field_validator("local_time")
    @classmethod
    def valid_time(cls, value: str) -> str:
        return SettingsUpdate.valid_time(value)

    @model_validator(mode="after")
    def apply_schedule_alias(self):
        if self.schedule == "every_6_hours":
            self.schedule_kind, self.interval_hours = "interval", 6
        elif self.schedule in {"daily", "weekly", "manual"}:
            self.schedule_kind = self.schedule
        return self


class CompanyUpdate(APIModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    careers_url: HttpUrl | None = None
    logo_url: HttpUrl | None = None
    preset_ids: list[str] | None = Field(default=None, max_length=20)
    schedule_kind: Literal["manual", "interval", "daily", "weekly"] | None = None
    interval_hours: int | None = Field(default=None, ge=1, le=168)
    local_time: str | None = None
    weekday: int | None = Field(default=None, ge=0, le=6)
    criteria: CompanyCriteria | CriteriaValues | None = None
    schedule: str | None = None


class RecipeActivate(APIModel):
    recipe_version: int = Field(ge=1)


class JobIn(APIModel):
    source_job_id: str | None = None
    title: str = Field(min_length=1)
    location: str = ""
    location_city: str | None = None
    remote_mode: Literal["remote", "hybrid", "onsite", "unknown"] = "unknown"
    employment_type: str | None = None
    posted_date: date | None = None
    description: str = ""
    salary_min: float | None = None
    salary_max: float | None = None
    salary_currency: str | None = None
    salary_period: Literal["hour", "day", "week", "month", "year"] | None = None
    url: str = Field(min_length=1)
    canonical_url: str | None = None
    source: str | None = None


class JobStateUpdate(APIModel):
    unread: bool | None = None
    dismissed: bool | None = None
    is_read: bool | None = None
    is_dismissed: bool | None = None


class JobTrackingUpdate(APIModel):
    saved: bool | None = None
    stage: str | None = Field(default=None, max_length=80)
    milestone: Literal[
        "applied", "recruiter_screen", "interview", "later_stage_interview", "offer"
    ] | None = None
    outcome: Literal["accepted", "declined", "rejected", "withdrawn"] | None = None
    occurred_at: date | datetime | None = None
    detail: str = Field(default="", max_length=6000)
    request_id: str | None = Field(default=None, min_length=1, max_length=160)
    actor_type: Literal["human", "agent"] = "human"

    @field_validator("stage")
    @classmethod
    def clean_stage(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = " ".join(value.split())
        if not value:
            raise ValueError("stage cannot be blank")
        return value

    @model_validator(mode="after")
    def has_change(self):
        if not self.model_fields_set.intersection({"saved", "stage", "milestone", "outcome"}):
            raise ValueError("Provide saved, stage, milestone, or outcome")
        if self.outcome in {"accepted", "declined"} and self.milestone not in {None, "offer"}:
            raise ValueError("accepted or declined requires the offer milestone")
        return self


class ManualApplicationCreate(APIModel):
    company: str = Field(min_length=1, max_length=160)
    title: str = Field(min_length=1, max_length=240)
    applied_at: date | datetime
    location: str = Field(default="", max_length=240)
    source_url: HttpUrl | None = None
    description: str = Field(default="", max_length=20_000)
    note: str = Field(default="", max_length=6000)
    request_id: str = Field(min_length=1, max_length=160)
    actor_type: Literal["human", "agent"] = "human"

    @field_validator("company", "title", "location", "description", "note", "request_id")
    @classmethod
    def clean_manual_text(cls, value: str) -> str:
        return value.strip()


class JobActivityCreate(APIModel):
    kind: Literal["note", "custom"] = "note"
    label: str | None = Field(default=None, max_length=120)
    detail: str = Field(min_length=1, max_length=6000)
    request_id: str | None = Field(default=None, min_length=1, max_length=160)
    actor_type: Literal["human", "agent"] = "human"

    @field_validator("label", "detail", "request_id")
    @classmethod
    def clean_activity_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        if not value:
            raise ValueError("value cannot be blank")
        return value


class PairRequest(APIModel):
    code: str = Field(min_length=6, max_length=12)


class BuildRequest(APIModel):
    force_ai: bool = False


class ChatContext(APIModel):
    type: Literal["job", "document"]
    id: int = Field(ge=1)


class ChatThreadCreate(APIModel):
    title: str = Field(default="New chat", min_length=1, max_length=120)
    request_id: str | None = Field(default=None, min_length=8, max_length=120)
    command_id: str | None = Field(default=None, min_length=1, max_length=80)
    context: ChatContext | None = None

    @field_validator("title")
    @classmethod
    def non_blank_title(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("title cannot be blank")
        return value


class ChatThreadUpdate(APIModel):
    title: str | None = Field(default=None, min_length=1, max_length=120)
    command_id: str | None = Field(default=None, min_length=1, max_length=80)
    context: ChatContext | None = None

    @field_validator("title")
    @classmethod
    def non_blank_title(cls, value: str | None) -> str | None:
        if value is None:
            return value
        value = value.strip()
        if not value:
            raise ValueError("title cannot be blank")
        return value

    @model_validator(mode="after")
    def has_change(self):
        if not self.model_fields_set:
            raise ValueError("Provide a title, command_id, or context change")
        if "title" in self.model_fields_set and self.title is None:
            raise ValueError("title cannot be null")
        return self


class ChatMessageCreate(APIModel):
    content: str = Field(min_length=1, max_length=20000)
    request_id: str | None = Field(default=None, min_length=8, max_length=120)
    attachment_ids: list[int] = Field(default_factory=list, max_length=5)
    document_consent_connection: Literal["codex", "claude", "openrouter", "hermes", "openclaw"] | None = None
    interview_prep: InterviewPrepRequest | None = None
    intro_letter: IntroLetterRequest | None = None
    company_discovery: CompanyDiscoveryRequest | None = None
    skill_prompt_message_id: int | None = Field(default=None, ge=1)
    start_skill: bool = False


class ChatTurnRetry(APIModel):
    request_id: str | None = Field(default=None, min_length=8, max_length=120)


class ChatDocumentAttachmentCreate(APIModel):
    thread_id: int = Field(ge=1)
    document_id: int = Field(ge=1)


class RecruiterSearchRequest(APIModel):
    live_search: bool = True


class ChatSuggestionCreate(APIModel):
    name: str = Field(min_length=1, max_length=160)
    careers_url: HttpUrl
    reason: str | None = Field(default=None, max_length=1000)
    thread_id: int | None = Field(default=None, ge=1)


class ChatMonitorActionCreate(APIModel):
    thread_id: int = Field(ge=1)
    company_id: int = Field(ge=1)
    action: Literal["rebuild", "repair"]
    reason: str | None = Field(default=None, max_length=1000)


class RunResponse(APIModel):
    id: int
    company_id: int
    kind: str
    status: str
    progress: int
    message: str | None = None


class CatalogRecipeUpdateRequest(APIModel):
    request_id: str = Field(min_length=8, max_length=120)
    expected_revision: int = Field(ge=1)


class RecipeDocument(APIModel):
    version: int = 1
    strategy: Literal["ashby", "greenhouse", "lever", "smartrecruiters", "workday", "jobvite", "json_ld", "json", "html", "browser"]
    allowed_hosts: list[str]
    configuration: dict[str, Any] = Field(default_factory=dict)
