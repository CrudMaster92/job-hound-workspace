"""JobHound's local stdio MCP server for coding and desktop agents."""

from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Annotated, Any, Literal

from mcp.server import MCPServer
from mcp.types import CallToolResult, ImageContent, TextContent, ToolAnnotations
from pydantic import Field

from .mcp_api import JobHoundApiClient
from .schemas import OpenAIOptions
from .recap_contracts import RecapSettings
from .presets import CatalogSelectionRequest
from .artifacts.contracts import CreateArtifact


INSTRUCTIONS = (
    "JobHound monitors public company career pages with deterministic scrapers. Use read tools to "
    "inspect matching or saved jobs, role activity, monitors, and run status. Write tools may save roles, "
    "set structured application milestones and outcomes, create retry-safe manual applications, "
    "add role notes, create monitors, change search criteria, constrained schedules, "
    "install or share validated company presets, or the configured AI connection, and queue scraper work. Build, "
    "run, and repair are asynchronous: return the run_id to the user and poll get_run_status until "
    "terminal=true. "
    "Read the application tracker and resolve a stable job ID before changing a role; never guess an "
    "email match. Career documents are a general library, not application tracking. Document uploads accept one "
    "explicit local PDF, DOCX, or TXT path and permanent deletion requires prior archive plus confirmation. "
    "Chat is local, inspectable, and asynchronous: use concise Markdown in messages, preserve source "
    "links, list chats and commands before changing context, and poll get_chat_turn_status until terminal. "
    "Never report a queued chat turn as complete. Attachments require explicit local files or resolved "
    "Documents-library IDs plus the exact outbound connection consent returned by JobHound. "
    "Structured document drafts remain outside the library until explicitly published; never invent candidate facts. "
    "Role-specific intro letters use the shared job drafting contract and remain unpublished until approval. "
    "This server exposes no job dismissal, credential, arbitrary-code, or unrestricted cron tool. "
    "AI credentials must be "
    "configured by a human on the host computer. Expert instruction tools may refine Chat and scraper "
    "guidance but cannot change JobHound's locked safety contract, schemas, credentials, or tool policies. "
    "When a JobHound answer maps cleanly to a current dashboard card, usually include one relevant "
    "card image alongside the text by calling export_dashboard_card, even when the user did not explicitly "
    "request an image. Use at most one by default (two for a requested comparison), never use a mismatched "
    "card, and keep the complete text answer. Explicit image requests take priority."
    " Public scraper contributions require an explicit human request to publish a proposal. Use preview and prepare; "
    "preparation never creates a monitor or submits a PR. Submit through the human GitHub connector, then record exact PR content. "
    "Never merge contributions or present provisional findings as curated feed results. "
    " Recruiter research uses public LinkedIn profile search results only, returns potential rather "
    "than confirmed contacts, and always includes a user-controlled Google X-ray link."
)

mcp = MCPServer("JobHound", version="0.1.0", instructions=INSTRUCTIONS)

READ = ToolAnnotations(read_only_hint=True, open_world_hint=False)
WEB_READ = ToolAnnotations(read_only_hint=True, open_world_hint=True)
WRITE = ToolAnnotations(
    read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=False
)
IDEMPOTENT_WRITE = ToolAnnotations(
    read_only_hint=False, destructive_hint=False, idempotent_hint=True, open_world_hint=False
)
WEB_WRITE = ToolAnnotations(
    read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=True
)
DESTRUCTIVE_WRITE = ToolAnnotations(
    read_only_hint=False, destructive_hint=True, idempotent_hint=True, open_world_hint=False
)


def _client() -> JobHoundApiClient:
    return JobHoundApiClient()


@mcp.tool(annotations=READ)
async def list_chat_artifacts(
    thread_id: Annotated[int, Field(ge=1)],
    offset: Annotated[int, Field(ge=0)] = 0,
) -> dict[str, Any]:
    """List host-only generated files and revisions in one chat, including partial results."""
    return await _client().request('GET', f'chat/threads/{thread_id}/artifacts', params={'offset': offset})


@mcp.tool(annotations=READ)
async def get_chat_artifact(
    thread_id: Annotated[int, Field(ge=1)],
    artifact_id: Annotated[int, Field(ge=1)],
    revision: Annotated[int | None, Field(ge=1)] = None,
    include_content: bool = False,
) -> dict[str, Any]:
    """Read/poll a file revision and its download URL. Read before revising; terminal means rendering ended."""
    params = {'include_content': include_content}
    if revision is not None:
        params['revision'] = revision
    return await _client().request('GET', f'chat/threads/{thread_id}/artifacts/{artifact_id}', params=params)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def create_chat_artifact(
    thread_id: Annotated[int, Field(ge=1)],
    payload: CreateArtifact,
) -> dict[str, Any]:
    """Queue a requested TXT/MD/JSON/CSV/DOCX/PDF/XLSX file. Reuse request_id on retry; poll get_chat_artifact. Revisions require artifact_id and expected_revision. No scripts or arbitrary paths."""
    return await _client().request('POST', f'chat/threads/{thread_id}/artifacts', json=payload.model_dump(mode='json'))


def _job_summary(job: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "id", "company_id", "company", "title", "location", "location_city", "remote_mode",
        "employment_type", "posted_date", "salary_min", "salary_max", "salary_currency", "salary_period", "url",
        "description_available", "description_snippet",
        "source", "unread", "is_match", "match_reasons", "first_seen_at", "last_seen_at",
        "is_saved", "saved_at", "current_stage", "milestone", "outcome", "applied_at",
        "applied_at_inferred", "origin", "activity_count",
        "latitude", "longitude", "distance_from_home_km",
    )
    return {key: job.get(key) for key in keys if key in job}


@mcp.tool(annotations=READ)
async def get_jobhound_status() -> dict[str, Any]:
    """Check JobHound, including concise counts and safe AI connection status."""
    api = _client()
    health = await api.health()
    dashboard = await api.dashboard()
    ai = await api.ai_connections()
    map_preferences = await api.map_preferences()
    selection = ai.get("selection") or {}
    selected_id = selection.get("connection")
    selected = next(
        (item for item in ai.get("connections", []) if item.get("id") == selected_id), None
    )
    return {
        "ok": health.get("ok", False),
        "version": health.get("version"),
        "capabilities": health.get("capabilities"),
        "counts": {key: dashboard.get(key) for key in (
            "active_companies", "matching_jobs", "new_jobs", "due_monitors", "failed_monitors", "documents"
        ) if key in dashboard},
        "map": map_preferences,
        "ai": {
            "onboarding": ai.get("onboarding"),
            "selection": selection,
            "selected_connection": {
                key: selected.get(key) for key in (
                    "id", "label", "available", "authenticated", "ready",
                    "authentication_method", "detail", "active_model", "capabilities",
                    "required_action",
                ) if key in selected
            } if selected else None,
        },
    }


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def set_home_location(
    address: Annotated[
        str | None,
        Field(
            min_length=1,
            max_length=500,
            description="Full street address including city, region, postal or ZIP code, and country.",
        ),
    ] = None,
    clear: Annotated[bool, Field(description="True to remove the current Home pin.")] = False,
) -> dict[str, Any]:
    """Set a verified Home address for role distances, or clear it; inspect it first with get_jobhound_status."""
    if not clear and address is None:
        raise ValueError("Provide a full address, or clear=true")
    return await _client().set_home_location(address, clear)


@mcp.tool(annotations=READ)
async def get_recap_settings() -> dict[str, Any]:
    """Inspect daily recap cadence, prompt, provider and explicit repair permission."""
    return await _client().get_recap_settings()


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_recap_settings(settings: RecapSettings) -> dict[str, Any]:
    """Replace recap settings after reading them. Enable repairs only on the user's explicit request."""
    return await _client().update_recap_settings(settings.model_dump())


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def run_daily_recap(request_id: Annotated[str, Field(min_length=1, max_length=160)]) -> dict[str, Any]:
    """Queue a recap and dated Chat from existing results. Reuse request_id on retries; poll get_daily_recap."""
    return await _client().run_daily_recap(request_id)


@mcp.tool(annotations=READ)
async def get_daily_recap(run_id: Annotated[int | None, Field(ge=1)] = None) -> dict[str, Any]:
    """Read a run's terminal status and report, or latest report, last run and schedule when ID is omitted."""
    return await _client().get_daily_recap(run_id)


@mcp.tool(annotations=READ)
async def get_dashboard() -> dict[str, Any]:
    """Inspect active work counts, dashboard cards, custom widgets, and the shared revisioned layout before changing it."""
    return await _client().dashboard()


@mcp.tool(annotations=READ)
async def export_dashboard_card(
    card_key: Annotated[
        str,
        Field(
            min_length=1, max_length=80,
            description=(
                "Stable export-eligible key from get_dashboard.catalog, such as new_roles, "
                "saved_jobs, scraper_alerts, or widget:<id>."
            ),
        ),
    ],
    theme: Literal["light", "dark"] = "light",
) -> CallToolResult:
    """Export one relevant current card as PNG; proactively include it with a matching text answer."""
    api = _client()
    dashboard = await api.dashboard()
    card = next((item for item in dashboard.get("catalog", []) if item.get("key") == card_key), None)
    if not card:
        raise ValueError("Unknown dashboard card key; call get_dashboard and use a catalog key")
    if not card.get("export_eligible", card_key != "create_widget"):
        raise ValueError(f"Dashboard card '{card_key}' is not exportable")
    png = await api.export_dashboard_card(card_key, theme)
    metadata = {
        "card_key": card_key,
        "title": card.get("title") or card_key,
        "theme": theme,
        "mime_type": "image/png",
        "byte_count": len(png),
        "data_scope": card.get("data_scope"),
    }
    return CallToolResult(
        content=[
            TextContent(type="text", text=json.dumps(metadata, ensure_ascii=False)),
            ImageContent(type="image", data=base64.b64encode(png).decode("ascii"), mimeType="image/png"),
        ],
        structuredContent=metadata,
    )


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_dashboard_layout(
    revision: Annotated[int, Field(ge=1)],
    items: Annotated[list[dict[str, Any]], Field(min_length=7, max_length=100)],
) -> dict[str, Any]:
    """Reorder, show/hide, or resize dashboard cards using the revision returned by get_dashboard."""
    return await _client().update_dashboard_layout(revision, items)


@mcp.tool(annotations=READ)
async def get_platform_profiles() -> dict[str, Any]:
    """Inspect whether profile visibility reminders are enabled, saved confirmations, and reminder dates. Disabled reminders are suppressed; saved data remains readable."""
    return await _client().platform_profiles()


@mcp.tool(annotations=READ)
async def list_platform_catalog(
    query: Annotated[str, Field(max_length=120)] = "",
    country: Annotated[str, Field(max_length=20)] = "",
    region: Annotated[str, Field(max_length=20)] = "",
    industry: Annotated[str, Field(max_length=80)] = "",
) -> dict[str, Any]:
    """Search profile-sharing platforms by text, country, state/province, or industry."""
    return await _client().platform_catalog(query, country, region, industry)


@mcp.tool(annotations=WRITE)
async def add_custom_platform(
    name: Annotated[str, Field(min_length=1, max_length=100)],
    home_url: Annotated[str, Field(min_length=8, max_length=2048)],
    profile_url: Annotated[str, Field(max_length=2048)] = "",
    countries: list[str] = ["GLOBAL"],
    industry_keywords: list[str] = [],
    description: Annotated[str, Field(max_length=500)] = "",
) -> dict[str, Any]:
    """Add a platform to the local catalog only; use track_platform_profile separately to track it."""
    return await _client().add_custom_platform({
        "name": name, "home_url": home_url, "profile_url": profile_url or None,
        "countries": countries, "industry_keywords": industry_keywords,
        "description": description,
    })


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def track_platform_profile(platform: Annotated[str, Field(min_length=1, max_length=64)]) -> dict[str, Any]:
    """Add a catalog platform to the user's visibility tracker, preserving prior confirmations."""
    return await _client().track_platform_profile(platform)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def untrack_platform_profile(platform: Annotated[str, Field(min_length=1, max_length=64)]) -> dict[str, Any]:
    """Remove a platform from the tracker while preserving its confirmation history."""
    return await _client().untrack_platform_profile(platform)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_platform_profile(
    platform: Annotated[str | None, Field(min_length=1, max_length=64)] = None,
    visibility: Literal[
        "unknown", "not_visible", "recruiters_only", "all_members", "visible"
    ] | None = None,
    reminder_days: Annotated[int, Field(ge=0, le=365)] = 30,
    profile_visibility_enabled: bool | None = None,
) -> dict[str, Any]:
    """Read get_platform_profiles first. Pass profile_visibility_enabled alone to enable/disable the optional Platforms page, card and reminders without deleting data. Otherwise supply platform and visibility to record a confirmation."""
    if profile_visibility_enabled is not None:
        if platform is not None or visibility is not None:
            raise ValueError("Change the optional feature separately from a profile confirmation")
        return await _client().set_profile_visibility_enabled(profile_visibility_enabled)
    if platform is None or visibility is None:
        raise ValueError("Supply platform and visibility, or profile_visibility_enabled alone")
    return await _client().update_platform_profile(platform, visibility, reminder_days)


@mcp.tool(annotations=READ)
async def get_dashboard_widget_sdk() -> dict[str, Any]:
    """Read the live safe widget SDK, approved data bindings, limits, and UI-node contract."""
    return await _client().get_dashboard_widget_sdk()


@mcp.tool(annotations=READ)
async def list_dashboard_widgets(include_drafts: bool = True) -> dict[str, Any]:
    """List installed dashboard widgets and reviewable drafts, including their stable identifiers."""
    return await _client().list_dashboard_widgets(include_drafts)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def create_dashboard_widget_draft(
    manifest: dict[str, Any],
    javascript: Annotated[str, Field(min_length=1, max_length=96_000)],
    css: Annotated[str, Field(max_length=48_000)] = "",
    draft_id: Annotated[int | None, Field(ge=1)] = None,
    request_id: Annotated[str | None, Field(min_length=1, max_length=120)] = None,
) -> dict[str, Any]:
    """Create or revise a preview-only dashboard widget draft; this never installs the widget."""
    return await _client().create_dashboard_widget_draft(
        manifest, javascript, css, draft_id=draft_id, request_id=request_id,
    )


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def install_dashboard_widget(
    draft_id: Annotated[int, Field(ge=1)],
    size: Literal["standard", "tall"] | None = None,
    after_key: Annotated[str | None, Field(max_length=80)] = None,
    at_top: bool = False,
) -> dict[str, Any]:
    """Install an approved draft, or update its linked widget while preserving omitted layout choices."""
    return await _client().install_dashboard_widget(draft_id, size, after_key, at_top)


@mcp.tool(annotations=READ)
async def get_openai_models() -> dict[str, Any]:
    """Inspect Codex models, supported reasoning efforts, saved preferences, and CLI diagnostics before selecting."""
    return await _client().openai_models()


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def select_ai_connection(
    connection: Literal["codex", "claude", "openrouter", "hermes", "openclaw", "none"],
    model: Annotated[
        str | None,
        Field(
            min_length=1,
            max_length=200,
            description="Optional configured model ID. Omit to use the connection's default.",
        ),
    ] = None,
    openai_options: OpenAIOptions | None = None,
) -> dict[str, Any]:
    """Select a connection. Inspect get_openai_models first; omitted reasoning is preserved, null clears it."""
    if openai_options is None:
        return await _client().select_ai_connection(connection, model)
    return await _client().select_ai_connection(connection, model, openai_options.model_dump(exclude_unset=True))


INSTRUCTION_FIELD = Annotated[
    str | None,
    Field(
        max_length=6000,
        description="Optional replacement text. Omit to leave this field unchanged.",
    ),
]
InstructionKey = Literal[
    "user_context", "chat_guidance", "scraper_build_guidance", "scraper_repair_guidance"
]


def _instruction_patch(
    user_context: str | None,
    chat_guidance: str | None,
    scraper_build_guidance: str | None,
    scraper_repair_guidance: str | None,
) -> dict[str, str]:
    values = {
        "user_context": user_context,
        "chat_guidance": chat_guidance,
        "scraper_build_guidance": scraper_build_guidance,
        "scraper_repair_guidance": scraper_repair_guidance,
    }
    return {key: value for key, value in values.items() if value is not None}


@mcp.tool(annotations=READ)
async def get_agent_instructions() -> dict[str, Any]:
    """Inspect active/default guidance, locked contracts, revision, and composed prompt previews."""
    return await _client().get_agent_instructions()


@mcp.tool(annotations=READ)
async def preview_agent_instructions(
    user_context: INSTRUCTION_FIELD = None,
    chat_guidance: INSTRUCTION_FIELD = None,
    scraper_build_guidance: INSTRUCTION_FIELD = None,
    scraper_repair_guidance: INSTRUCTION_FIELD = None,
) -> dict[str, Any]:
    """Compose unsaved Chat, scraper-build, and scraper-repair previews for candidate guidance."""
    patch = _instruction_patch(
        user_context, chat_guidance, scraper_build_guidance, scraper_repair_guidance
    )
    return await _client().preview_agent_instructions(patch)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_agent_instructions(
    user_context: INSTRUCTION_FIELD = None,
    chat_guidance: INSTRUCTION_FIELD = None,
    scraper_build_guidance: INSTRUCTION_FIELD = None,
    scraper_repair_guidance: INSTRUCTION_FIELD = None,
    reset_fields: Annotated[
        list[InstructionKey],
        Field(
            description="Fields to restore to JobHound's managed defaults.",
        ),
    ] = [],
) -> dict[str, Any]:
    """Update editable guidance or reset named fields; locked JobHound rules cannot be changed."""
    patch: dict[str, Any] = _instruction_patch(
        user_context, chat_guidance, scraper_build_guidance, scraper_repair_guidance
    )
    patch.update({key: None for key in reset_fields})
    return await _client().update_agent_instructions(patch)


@mcp.tool(annotations=READ)
async def list_chat_threads(
    role_id: Annotated[int | None, Field(ge=1)] = None,
    company_id: Annotated[int | None, Field(ge=1)] = None,
    command_id: Annotated[str | None, Field(min_length=1, max_length=80)] = None,
    query: Annotated[str | None, Field(min_length=1, max_length=120)] = None,
    limit: Annotated[int, Field(ge=1, le=100)] = 50,
) -> dict[str, Any]:
    """List chats, optionally filtered by company, role, skill/command, or keyword."""
    data = await _client().list_chat_threads(
        role_id=role_id, company_id=company_id, command_id=command_id,
        query=query, limit=limit,
    )
    items = data.get("items", [])
    return {"count": len(items), "total": data.get("count", len(items)), "chats": items}


@mcp.tool(annotations=READ)
async def list_chat_commands() -> dict[str, Any]:
    """List stable JobHound Chat command/skill IDs before creating or contextualizing a chat."""
    return await _client().list_chat_commands()


@mcp.tool(annotations=READ)
async def get_chat_thread(
    thread_id: Annotated[int, Field(ge=1)],
) -> dict[str, Any]:
    """Read one chat's messages, Markdown, sources, attachments, roles, skills, and active turn."""
    return await _client().get_chat_thread(thread_id)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def create_chat_thread(
    request_id: Annotated[str, Field(min_length=8, max_length=120)],
    title: Annotated[str, Field(min_length=1, max_length=120)] = "New chat",
    command_id: Annotated[str | None, Field(min_length=1, max_length=80)] = None,
    context_type: Literal["job", "document"] | None = None,
    context_id: Annotated[int | None, Field(ge=1)] = None,
) -> dict[str, Any]:
    """Create one retry-safe Chat thread, optionally with a resolved role/document and command."""
    if (context_type is None) != (context_id is None):
        raise ValueError("context_type and context_id must be provided together")
    payload: dict[str, Any] = {"title": title, "request_id": request_id}
    if command_id is not None:
        payload["command_id"] = command_id
    if context_type is not None:
        payload["context"] = {"type": context_type, "id": context_id}
    return await _client().create_chat_thread(payload)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def set_chat_thread_context(
    thread_id: Annotated[int, Field(ge=1)],
    command_id: Annotated[str | None, Field(min_length=1, max_length=80)] = None,
    context_type: Literal["job", "document"] | None = None,
    context_id: Annotated[int | None, Field(ge=1)] = None,
    clear: bool = False,
) -> dict[str, Any]:
    """Set or explicitly clear a chat's resolved role/document context and active command."""
    if clear and (context_type is not None or context_id is not None):
        raise ValueError("clear=true cannot be combined with context_type or context_id")
    if not clear and (context_type is None) != (context_id is None):
        raise ValueError("context_type and context_id must be provided together")
    if not clear and context_type is None and command_id is None:
        raise ValueError("Provide command_id, a context pair, or clear=true")
    payload: dict[str, Any] = {}
    if clear:
        payload.update({"context": None, "command_id": None})
    else:
        if command_id is not None:
            payload["command_id"] = command_id
        if context_type is not None:
            payload["context"] = {"type": context_type, "id": context_id}
    return await _client().set_chat_thread_context(thread_id, payload)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def upload_chat_attachment(
    thread_id: Annotated[int, Field(ge=1)],
    file_path: Annotated[str | None, Field(min_length=1, max_length=2048)] = None,
    document_id: Annotated[int | None, Field(ge=1)] = None,
    interview_id: Annotated[int | None, Field(ge=1)] = None,
) -> dict[str, Any]:
    """Stage one explicit file, career document, or interview transcript; outbound consent is required on send."""
    if sum(value is not None for value in (file_path, document_id, interview_id)) != 1:
        raise ValueError("Provide exactly one of file_path, document_id, or interview_id")
    if interview_id is not None:
        return await _client().request("POST", "interviews/attachments", json={"thread_id": thread_id, "interview_id": interview_id})
    if document_id is not None:
        return await _client().attach_chat_document(thread_id, document_id)
    assert file_path is not None
    if any(character in file_path for character in "*?[]"):
        raise ValueError("file_path must name one file and cannot contain wildcards")
    candidate = Path(file_path).expanduser()
    if candidate.is_symlink():
        raise ValueError("file_path cannot be a symbolic link")
    path = candidate.resolve()
    if not path.is_file():
        raise ValueError("file_path must be an existing regular file")
    if path.suffix.casefold() not in {".pdf", ".docx", ".txt"}:
        raise ValueError("Supported chat attachment formats are PDF, DOCX, and TXT")
    if path.stat().st_size > 10 * 1024 * 1024:
        raise ValueError("Chat attachments are limited to 10 MiB")
    return await _client().upload_chat_attachment(thread_id, path)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def send_chat_message(
    thread_id: Annotated[int, Field(ge=1)],
    content: Annotated[str, Field(min_length=1, max_length=20_000)],
    request_id: Annotated[str, Field(min_length=8, max_length=120)],
    attachment_ids: Annotated[list[int], Field(max_length=5)] = [],
    document_consent_connection: Literal["codex", "claude", "openrouter", "hermes", "openclaw"] | None = None,
) -> dict[str, Any]:
    """Queue a retry-safe Chat turn; write useful Markdown and poll its returned turn ID."""
    if any(value < 1 for value in attachment_ids):
        raise ValueError("attachment_ids must contain positive stable IDs")
    return await _client().send_chat_message(thread_id, {
        "content": content,
        "request_id": request_id,
        "attachment_ids": attachment_ids,
        "document_consent_connection": document_consent_connection,
    })


@mcp.tool(annotations=READ)
async def get_chat_turn_status(
    turn_id: Annotated[int, Field(ge=1)],
) -> dict[str, Any]:
    """Poll a Chat turn: stage/message report observed activity, elapsed_seconds reports duration; wait for terminal=true."""
    return await _client().get_chat_turn_status(turn_id)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def cancel_chat_turn(
    turn_id: Annotated[int, Field(ge=1)],
) -> dict[str, Any]:
    """Request idempotent cancellation of one queued or running Chat turn."""
    return await _client().cancel_chat_turn(turn_id)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def retry_chat_turn(
    turn_id: Annotated[int, Field(ge=1)],
    request_id: Annotated[str, Field(min_length=8, max_length=120)],
) -> dict[str, Any]:
    """Retry one failed, cancelled, or interrupted turn without duplicating its user message."""
    return await _client().retry_chat_turn(turn_id, request_id)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def rename_chat_thread(
    thread_id: Annotated[int, Field(ge=1)],
    title: Annotated[str, Field(min_length=1, max_length=120)],
) -> dict[str, Any]:
    """Rename one embedded JobHound chat after resolving its ID with list_chat_threads."""
    return await _client().rename_chat_thread(thread_id, title)


@mcp.tool(annotations=DESTRUCTIVE_WRITE)
async def delete_chat_thread(
    thread_id: Annotated[int, Field(ge=1)],
    confirm_permanent_delete: bool = False,
) -> dict[str, Any]:
    """Permanently delete one chat and its messages after explicit confirmation."""
    if not confirm_permanent_delete:
        raise ValueError("Chat deletion requires confirm_permanent_delete=true")
    return await _client().delete_chat_thread(thread_id)


DocumentKind = Literal["resume", "intro_letter"]
DocumentVariant = Literal["template", "example"]
DocumentRecordType = Literal["document", "draft"]


@mcp.tool(annotations=READ)
async def search_library(
    query: Annotated[str, Field(max_length=200)] = "",
    source: Literal["all", "document", "interview"] = "all",
    include_archived: bool = False,
    offset: Annotated[int, Field(ge=0)] = 0,
    limit: Annotated[int, Field(ge=1, le=50)] = 20,
) -> dict[str, Any]:
    """Search saved resumes, intro letters and transcripts. Read results with get_document/get_interview; titles and snippets are private host-only data."""
    return await _client().request("GET", "library/search", params={"query":query,"source":source,"include_archived":include_archived,"offset":offset,"limit":limit})


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def set_chat_library_access(
    thread_id: Annotated[int, Field(ge=1)],
    connection: Literal["codex", "claude", "openrouter", "hermes", "openclaw"],
    allowed: bool,
    turn_id: Annotated[int | None, Field(ge=1)] = None,
) -> dict[str, Any]:
    """Only after explicit user approval, allow this named AI connection to search/read Documents in this chat. False revokes future lookup. Supply a waiting turn ID to approve/decline and resume it without duplication."""
    return await _client().request("PUT", f"chat/threads/{thread_id}/library-access", json={"connection":connection,"allowed":allowed,"turn_id":turn_id})


@mcp.tool(annotations=READ)
async def list_documents(
    kind: DocumentKind | None = None,
    include_archived: bool = False,
    include_drafts: bool = False,
) -> dict[str, Any]:
    """List resume and intro-letter metadata, optionally including unsaved local drafts."""
    return await _client().list_documents(kind, include_archived, include_drafts)


@mcp.tool(annotations=READ)
async def get_document(
    document_id: Annotated[int, Field(ge=1)],
    max_chars: Annotated[int, Field(ge=500, le=50_000)] = 20_000,
    variant: DocumentVariant = "template",
    record_type: DocumentRecordType = "document",
    offset: Annotated[int, Field(ge=0)] = 0,
) -> dict[str, Any]:
    """Read a saved document/example with character pagination, or inspect an unsaved draft."""
    return await _client().get_document(document_id, max_chars, variant, record_type, offset)


@mcp.tool(annotations=WRITE)
async def create_document_draft(
    content: Annotated[dict[str, Any], Field(description="Validated corporate/creative resume or intro-letter draft content.")],
    source_document_id: Annotated[int | None, Field(ge=1)] = None,
) -> dict[str, Any]:
    """Create a local previewable career-document draft without adding it to the Documents library."""
    return await _client().create_document_draft(content, source_document_id)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def upload_document(
    file_path: Annotated[str, Field(min_length=1, max_length=2048)],
    kind: DocumentKind,
    label: Annotated[str | None, Field(min_length=1, max_length=120)] = None,
    replace_document_id: Annotated[int | None, Field(ge=1)] = None,
) -> dict[str, Any]:
    """Upload one explicit local PDF, DOCX, or TXT file; replacement archives the previous document."""
    if any(character in file_path for character in "*?[]"):
        raise ValueError("file_path must name one file and cannot contain wildcards")
    candidate = Path(file_path).expanduser()
    if candidate.is_symlink():
        raise ValueError("file_path cannot be a symbolic link")
    path = candidate.resolve()
    if not path.is_file():
        raise ValueError("file_path must be an existing regular file")
    if path.suffix.casefold() not in {".pdf", ".docx", ".txt"}:
        raise ValueError("Supported document formats are PDF, DOCX, and TXT")
    if path.stat().st_size > 10 * 1024 * 1024:
        raise ValueError("Documents are limited to 10 MiB")
    return await _client().upload_document(
        path, kind=kind, label=label, replace_document_id=replace_document_id,
    )


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_document(
    document_id: Annotated[int, Field(ge=1)],
    label: Annotated[str | None, Field(min_length=1, max_length=120)] = None,
    archived: bool | None = None,
    record_type: DocumentRecordType = "document",
    draft_content: Annotated[dict[str, Any] | None, Field(description="Complete replacement content for a draft.")] = None,
    publish: bool = False,
) -> dict[str, Any]:
    """Rename/archive a saved document, or revise/publish a local document draft."""
    if record_type == "draft":
        if label is not None or archived is not None:
            raise ValueError("Draft updates use draft_content or publish, not label or archived")
        if draft_content is not None:
            result = await _client().update_document_draft(document_id, draft_content)
            if not publish:
                return result
        if publish:
            return await _client().publish_document_draft(document_id)
        raise ValueError("Provide draft_content or publish=true for a draft")
    patch = {key: value for key, value in {"label": label, "archived": archived}.items() if value is not None}
    if not patch:
        raise ValueError("Provide a label or archived state")
    return await _client().update_document(document_id, patch)


@mcp.tool(annotations=DESTRUCTIVE_WRITE)
async def purge_document(
    document_id: Annotated[int, Field(ge=1)],
    confirm_permanent_delete: bool = False,
) -> dict[str, Any]:
    """Permanently delete an archived document and original file after explicit confirmation."""
    if not confirm_permanent_delete:
        raise ValueError("Permanent deletion requires confirm_permanent_delete=true")
    return await _client().purge_document(document_id)


@mcp.tool(annotations=READ)
async def search_jobs(
    query: Annotated[str | None, Field(description="Text to match in title, company, location, or description.")] = None,
    company_id: Annotated[int | None, Field(ge=1)] = None,
    company_ids: Annotated[list[int] | None, Field(description="Company IDs to match (OR).", min_length=1)] = None,
    matching: bool = True,
    unread: bool | None = None,
    remote_mode: Literal["remote", "hybrid", "onsite", "unknown"] | None = None,
    remote_modes: Annotated[list[Literal["remote", "hybrid", "onsite", "unknown"]] | None,
                            Field(description="Work modes to match (OR).", min_length=1)] = None,
    employment_types: Annotated[list[str] | None,
                                Field(description="Employment labels/components to match (OR).", min_length=1)] = None,
    salary_listed: Annotated[bool | None, Field(description="True for roles with a published salary; false for roles without one.")] = None,
    posted_within_days: Literal[1, 7, 30] | None = None,
    sort: Annotated[
        Literal["newest", "oldest", "nearest", "farthest", "title", "company"],
        Field(description="Order roles by posting date, Home distance, title, or company."),
    ] = "newest",
    saved: Annotated[
        bool | None,
        Field(
            description=(
                "True to search all saved roles, including closed, dismissed, and no-longer-matching "
                "roles; false to exclude saved roles; omit for the normal current-job feed."
            )
        ),
    ] = None,
    limit: Annotated[int, Field(ge=1, le=100)] = 25,
    offset: Annotated[int, Field(ge=0)] = 0,
    include_closed: bool = False,
    include_all: bool = False,
) -> dict[str, Any]:
    """Search current jobs or the durable saved-role collection; use get_job for full detail."""
    selected_companies = list(dict.fromkeys([
        *([company_id] if company_id is not None else []), *(company_ids or [])
    ]))
    selected_modes = list(dict.fromkeys([
        *([remote_mode] if remote_mode is not None else []), *(remote_modes or [])
    ]))
    params: dict[str, Any] = {"limit": limit, "sort": sort, "offset": offset}
    if saved is True:
        # Saved roles intentionally survive normal feed visibility constraints.
        params["saved"] = True
    else:
        params.update({"matching": matching, "dismissed": False, "active": True})
        if saved is False:
            params["saved"] = False
    if include_closed:
        params["include_closed"] = True
    if include_all:
        params["include_all"] = True
    if query:
        params["query"] = query
    if selected_companies:
        params["company_ids"] = selected_companies
    if unread is not None:
        params["unread"] = unread
    if selected_modes:
        params["remote_modes"] = selected_modes
    if employment_types:
        params["employment_types"] = employment_types
    if salary_listed is not None:
        params["salary_listed"] = salary_listed
    if posted_within_days is not None:
        params["posted_within_days"] = posted_within_days
    data = await _client().list_jobs(**params)
    items = data.get("items", [])
    # Keep compatibility with older JobHound servers that accepted the request but did not yet
    # implement text/work-mode filtering. Current servers already return this exact subset.
    if query:
        needle = query.casefold().strip()
        items = [item for item in items if needle in " ".join(str(item.get(key) or "") for key in (
            "title", "company", "location", "description"
        )).casefold()]
    if selected_modes:
        items = [item for item in items if item.get("remote_mode") in selected_modes]
    items = items[:limit]
    return {"count": len(items), "total": data.get("total", len(items)),
            "jobs": [_job_summary(item) for item in items], "offset": data.get("offset", offset),
            "next_offset": offset + len(items) if offset + len(items) < data.get("total", len(items)) else None}


@mcp.tool(annotations=READ)
async def get_job(
    job_id: Annotated[int, Field(ge=1)],
    description_max_chars: Annotated[int, Field(ge=500, le=50000)] = 12000,
) -> dict[str, Any]:
    """Get one job, including tracking state, recent ATS activity, description, and source URL."""
    job = await _client().get_job(job_id)
    description = str(job.get("description") or "")
    if len(description) > description_max_chars:
        job["description"] = description[:description_max_chars] + "\n\n[Description truncated by MCP]"
        job["description_truncated"] = True
    else:
        job["description_truncated"] = False
    return job


@mcp.tool(annotations=READ)
async def get_application_tracker(
    from_date: Annotated[
        str | None, Field(pattern=r"^\d{4}-\d{2}-\d{2}$", description="Optional applied-date cohort start.")
    ] = None,
    to_date: Annotated[
        str | None, Field(pattern=r"^\d{4}-\d{2}-\d{2}$", description="Optional applied-date cohort end.")
    ] = None,
    include_closed: bool = False,
) -> dict[str, Any]:
    """Inspect application funnel metrics and stable job IDs before updating a role."""
    return await _client().application_tracker(from_date, to_date, include_closed)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def create_manual_application(
    company: Annotated[str, Field(min_length=1, max_length=160)],
    title: Annotated[str, Field(min_length=1, max_length=240)],
    applied_at: Annotated[
        str, Field(description="Application date or timestamp in ISO 8601 format.")
    ],
    request_id: Annotated[
        str, Field(min_length=1, max_length=160, description="Stable retry key for this application.")
    ],
    location: Annotated[str, Field(max_length=240)] = "",
    source_url: Annotated[str | None, Field(max_length=2000)] = None,
    description: Annotated[str, Field(max_length=20000)] = "",
    note: Annotated[str, Field(max_length=6000)] = "",
) -> dict[str, Any]:
    """Create a saved manual role at Applied when no matching JobHound job exists."""
    return await _client().create_manual_application({
        "company": company, "title": title, "applied_at": applied_at,
        "request_id": request_id, "location": location, "source_url": source_url,
        "description": description, "note": note, "actor_type": "agent",
    })


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_job_tracking(
    job_id: Annotated[int, Field(ge=1)],
    saved: Annotated[
        bool | None,
        Field(description="Set true to save/pin the role or false to unpin it; omit to keep unchanged."),
    ] = None,
    stage: Annotated[
        str | None,
        Field(
            min_length=1,
            max_length=80,
            description=(
                "Set a standard stage (Interested, Applied, Interviewing, Offer, Rejected, Withdrawn) "
                "or a concise custom stage; omit to keep unchanged."
            ),
        ),
    ] = None,
    clear_stage: Annotated[
        bool,
        Field(description="Set true to clear the current stage; cannot be combined with stage."),
    ] = False,
    milestone: Literal[
        "applied", "recruiter_screen", "interview", "later_stage_interview", "offer"
    ] | None = None,
    outcome: Literal["accepted", "declined", "rejected", "withdrawn"] | None = None,
    clear_outcome: Annotated[
        bool, Field(description="Set true to reopen an ended application; cannot be combined with outcome.")
    ] = False,
    occurred_at: Annotated[
        str | None, Field(description="Optional ISO 8601 time when the stage change actually occurred.")
    ] = None,
    detail: Annotated[str, Field(max_length=6000)] = "",
    request_id: Annotated[str | None, Field(min_length=1, max_length=160)] = None,
) -> dict[str, Any]:
    """Save a role or update its structured application milestone/outcome with attribution."""
    if saved is None and stage is None and not clear_stage and milestone is None and outcome is None and not clear_outcome:
        raise ValueError("Provide saved, stage, milestone, outcome, clear_stage, or clear_outcome")
    if stage is not None and clear_stage:
        raise ValueError("stage and clear_stage=true cannot be combined")
    if outcome is not None and clear_outcome:
        raise ValueError("outcome and clear_outcome=true cannot be combined")
    patch: dict[str, Any] = {"actor_type": "agent"}
    if saved is not None:
        patch["saved"] = saved
    if stage is not None or clear_stage:
        patch["stage"] = stage
    if milestone is not None:
        patch["milestone"] = milestone
    if outcome is not None or clear_outcome:
        patch["outcome"] = outcome
    if occurred_at is not None:
        patch["occurred_at"] = occurred_at
    if detail:
        patch["detail"] = detail
    if request_id:
        patch["request_id"] = request_id
    return await _client().update_job_tracking(job_id, patch)


@mcp.tool(annotations=WRITE)
async def add_job_activity(
    job_id: Annotated[int, Field(ge=1)],
    detail: Annotated[
        str,
        Field(min_length=1, max_length=6000, description="The note or custom activity text."),
    ],
    kind: Literal["note", "custom"] = "note",
    label: Annotated[
        str | None,
        Field(min_length=1, max_length=120, description="Optional concise card label."),
    ] = None,
    request_id: Annotated[
        str | None,
        Field(
            min_length=1,
            max_length=160,
            description="Stable caller-generated retry key. Reuse it when retrying the same activity.",
        ),
    ] = None,
) -> dict[str, Any]:
    """Append an agent-attributed note or custom event to a job's mini-ATS history."""
    return await _client().add_job_activity(job_id, {
        "kind": kind,
        "label": label,
        "detail": detail,
        "request_id": request_id,
        "actor_type": "agent",
    })


@mcp.tool(annotations=WEB_READ)
async def find_recruiters(
    job_id: Annotated[int, Field(ge=1)],
    live_search: Annotated[
        bool,
        Field(description="Attempt public web discovery; the Google X-ray URL is returned either way."),
    ] = True,
) -> dict[str, Any]:
    """Find up to three potential public recruiter profiles for a stored job and return the X-ray query."""
    return await _client().find_recruiters(job_id, live_search)


@mcp.tool(annotations=WEB_READ)
async def discover_companies(
    refinement: Annotated[
        str | None,
        Field(max_length=4000, description="Optional role, industry, location, or follow-up refinement."),
    ] = None,
    resume_document_id: Annotated[
        int | None,
        Field(ge=1, description="Optional active JobHound resume used to derive bounded career signals."),
    ] = None,
    document_consent_connection: Literal[
        "codex", "claude", "openrouter", "hermes", "openclaw"
    ] | None = None,
    prior_signals: Annotated[
        dict[str, list[str]] | None,
        Field(description="Signals returned by a prior discovery call when refining its results."),
    ] = None,
    include_local_fallback: bool = True,
) -> dict[str, Any]:
    """Recommend preset collections and companies from a resume, saved criteria, and refinements.

    Every returned monitor starts unselected. Present the choices and wait before calling
    install_preset_monitors. Before passing a resume, name JobHound's selected AI connection and
    obtain explicit permission. Researched local candidates are separate suggestions; create one
    only after the user explicitly selects it.
    """
    return await _client().discover_companies({
        "refinement": refinement,
        "resume_document_id": resume_document_id,
        "document_consent_connection": document_consent_connection,
        "prior_signals": prior_signals,
        "include_local_fallback": include_local_fallback,
    })


@mcp.tool(annotations=WEB_READ)
async def prepare_interview(
    job_id: Annotated[int, Field(ge=1)],
    sections: Annotated[
        list[Literal[
            "company_overview", "interview_questions", "industry_terminology",
            "role_tools", "follow_up_questions", "job_description_priorities",
            "compensation_benefits",
        ]] | None,
        Field(description="Preparation sections to generate. Omit to retrieve the selectable menu."),
    ] = None,
    resume_document_id: Annotated[
        int | None,
        Field(ge=1, description="Optional active JobHound resume to use only for coaching cues."),
    ] = None,
    question_count: Annotated[
        int, Field(ge=1, le=10, description="Role-specific interview questions; defaults to three."),
    ] = 3,
    document_consent_connection: Literal[
        "codex", "claude", "openrouter", "hermes", "openclaw"
    ] | None = None,
    follow_up: Annotated[str | None, Field(max_length=4000)] = None,
) -> dict[str, Any]:
    """Get interview-prep choices or generate a sourced coaching pack for one stored job.

    Read the job first. If sections are omitted, present the returned choices and wait for the
    user's selection. Before passing resume_document_id, name JobHound's selected AI connection
    and obtain explicit permission; then pass that connection as document_consent_connection.
    """
    if not sections:
        options = await _client().interview_prep_options()
        return {"status": "needs_selection", **options}
    return await _client().prepare_interview(job_id, {
        "sections": sections,
        "resume_document_id": resume_document_id,
        "question_count": question_count,
        "document_consent_connection": document_consent_connection,
        "follow_up": follow_up,
    })


@mcp.tool(annotations=WRITE)
async def create_intro_letter_for_job(
    job_id: Annotated[int, Field(ge=1, description="Stored JobHound job identifier.")],
    resume_document_id: Annotated[
        int | None,
        Field(ge=1, description="Optional active JobHound resume used for supported candidate facts."),
    ] = None,
    document_consent_connection: Literal[
        "codex", "claude", "openrouter", "hermes", "openclaw"
    ] | None = None,
    follow_up: Annotated[str | None, Field(max_length=4000)] = None,
) -> dict[str, Any]:
    """Create a local, unpublished three-paragraph intro-letter draft for one stored job.

    Read the job first. Before passing resume_document_id, name JobHound's selected AI connection
    and obtain explicit permission; pass that connection as document_consent_connection. With no
    resume, the draft contains visible placeholders that the user must replace before use.
    """
    return await _client().create_intro_letter(job_id, {
        "resume_document_id": resume_document_id,
        "document_consent_connection": document_consent_connection,
        "follow_up": follow_up,
    })


@mcp.tool(annotations=READ)
async def list_company_presets(
    query: str = "",
    collection_type: str = "",
    industry: str = "",
    role_family: str = "",
    city: str = "",
    adapter: str = "",
    refresh_catalog: bool = False,
) -> dict[str, Any]:
    """Search curated, bundled, and imported presets with structured facets and install/update state."""
    return await _client().list_presets({
        "q": query, "collection_type": collection_type, "industry": industry,
        "role_family": role_family, "city": city, "adapter": adapter,
        "refresh": refresh_catalog,
    })


@mcp.tool(annotations=READ)
async def get_company_preset(
    preset_id: Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")],
    limit: Annotated[int, Field(ge=1, le=100)] = 50,
    cursor: str | None = None,
) -> dict[str, Any]:
    """Read one preset's paginated company/monitor summaries before selecting monitors to install."""
    return await _client().get_preset(preset_id, limit=limit, cursor=cursor)


@mcp.tool(annotations=READ)
async def search_preset_companies(
    query: str = "",
    industry: str = "",
    specialty: str = "",
    tag: str = "",
    collection_id: str = "",
    adapter: str = "",
    verification: str = "",
    limit: Annotated[int, Field(ge=1, le=100)] = 50,
    cursor: str | None = None,
    refresh_catalog: bool = False,
) -> dict[str, Any]:
    """Search the public catalog's companies and inspect their monitor choices and local status."""
    return await _client().search_preset_companies({
        "q": query, "industry": industry, "specialty": specialty, "tag": tag,
        "collection_id": collection_id, "adapter": adapter, "verification": verification,
        "limit": limit, "cursor": cursor, "refresh": refresh_catalog,
    })


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def install_company_preset(
    preset_id: Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")],
    company_keys: Annotated[list[str], Field(min_length=1, max_length=200)],
    request_id: Annotated[str, Field(min_length=8, max_length=120)],
    reviewed_selection: CatalogSelectionRequest | None = None,
) -> dict[str, Any]:
    """Install selected companies and validated recipes; monitors inherit the user's search profile.

    Read list_company_presets, then get_company_preset for monitor selection. Reuse the same request_id for a retry. Each installed monitor
    queues a deterministic scrape; poll every returned run ID until terminal.
    For public catalog installs after preview_preset_selection, pass reviewed_selection
    with the current reviewed revisions and source_commit. This uses the same
    revision-checked install contract as the local UI. Omit only for legacy packs.
    """
    if reviewed_selection is not None:
        if reviewed_selection.mode != "collection" or reviewed_selection.collection_id != preset_id:
            raise ValueError("reviewed_selection must name this collection")
        if set(company_keys) != {item.monitor_id for item in reviewed_selection.selections}:
            raise ValueError("company_keys must match the reviewed selection")
        return await _client().install_preset_monitors({
            **reviewed_selection.model_dump(mode="json"), "request_id": request_id,
        })
    return await _client().install_preset(preset_id, {
        "company_keys": company_keys, "request_id": request_id,
    })


@mcp.tool(annotations=WEB_READ)
async def preview_preset_selection(selection: CatalogSelectionRequest) -> dict[str, Any]:
    """Review a website or .jobhound-selection.json selection without installing anything.

    Accept the exact bounded jobhound-catalog-install version-1 payload. The shared backend
    resolves trusted catalog references and reports changed revisions, unavailable monitors,
    verification warnings, and local installed state. Show this review before an explicit
    install_company_preset (collection mode) or install_preset_monitors (monitors mode) action.
    A preview never creates monitors, packs, or scraper runs and never changes user settings.
    """
    return await _client().preview_preset_selection(selection.model_dump(mode="json"))


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def install_preset_monitors(
    selections: Annotated[list[dict[str, Any]], Field(min_length=1, max_length=200)],
    request_id: Annotated[str, Field(min_length=8, max_length=120)],
    source_commit: Annotated[str | None, Field(max_length=100)] = None,
) -> dict[str, Any]:
    """Install an explicitly selected batch of public catalog monitors without creating a named pack.

    Read search_preset_companies first and pass each selected company_id, monitor_id, and revision.
    Reuse request_id on retries and poll every returned run ID until terminal.
    """
    return await _client().install_preset_monitors({
        "format": "jobhound-catalog-install", "version": 1, "catalog_version": 3,
        "source_commit": source_commit, "mode": "monitors",
        "selections": selections, "request_id": request_id,
    })


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_company_from_preset_catalog(
    company_id: Annotated[int, Field(ge=1)],
    expected_revision: Annotated[int, Field(ge=1)],
    request_id: Annotated[str, Field(min_length=8, max_length=120)],
) -> dict[str, Any]:
    """Queue an explicitly approved catalog recipe update after reviewing get_company_preset.

    The candidate is validated before activation and the previous recipe remains available for rollback.
    Reuse request_id on retries and poll the returned run until terminal.
    """
    return await _client().update_catalog_recipe(company_id, {
        "expected_revision": expected_revision, "request_id": request_id,
    })


@mcp.tool(annotations=READ)
async def export_company_preset(
    preset_id: Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")],
    name: Annotated[str, Field(min_length=1, max_length=120)],
    company_ids: Annotated[list[int], Field(min_length=1, max_length=200)],
    description: Annotated[str, Field(max_length=600)] = "",
    tags: Annotated[list[str] | None, Field(max_length=20)] = None,
) -> dict[str, Any]:
    """Export selected active monitors and recipes as portable preset JSON; personal filters and jobs are excluded."""
    return await _client().export_preset({
        "id": preset_id, "name": name, "description": description,
        "tags": tags or [], "company_ids": company_ids,
    })


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def import_company_preset(manifest: dict[str, Any]) -> dict[str, Any]:
    """Validate and save one JobHound preset manifest locally without installing its companies."""
    return await _client().import_preset(manifest)


@mcp.tool(annotations=DESTRUCTIVE_WRITE)
async def archive_preset_installation(
    installation_id: Annotated[int, Field(ge=1)],
) -> dict[str, Any]:
    """Archive every still-active monitor created or restored by one preset installation."""
    return await _client().archive_preset_installation(installation_id)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def set_preset_pack_visibility(
    preset_id: Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")],
    hidden: bool,
) -> dict[str, Any]:
    """Hide or show one locally installed preset pack. Read list_company_presets first."""
    return await _client().set_preset_visibility(preset_id, hidden)


@mcp.tool(annotations=READ)
async def preview_preset_pack_removal(
    preset_id: Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")],
) -> dict[str, Any]:
    """Preview companies, jobs, applications, and active runs affected by permanent pack removal."""
    return await _client().preview_preset_removal(preset_id)


@mcp.tool(annotations=DESTRUCTIVE_WRITE)
async def remove_preset_pack(
    preset_id: Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")],
    confirm_name: Annotated[str, Field(min_length=1, max_length=120)],
    delete_applications: bool = False,
) -> dict[str, Any]:
    """Permanently remove a local pack after previewing it and obtaining explicit confirmation.

    Only pack-created, pack-exclusive monitors are deleted. Shared, restored, pre-existing, and
    manually assigned monitors are detached and preserved. Pass the exact returned preset_name as
    confirm_name; set delete_applications only after the user accepts the previewed loss.
    """
    return await _client().remove_preset(preset_id, {
        "confirm_name": confirm_name, "delete_applications": delete_applications,
    })


@mcp.tool(annotations=READ)
async def list_monitors(include_archived: bool = False) -> dict[str, Any]:
    """List company career-page monitors, criteria, schedules, and counts."""
    data = await _client().list_companies(include_archived)
    return {"count": data.get("count", 0), "monitors": data.get("items", [])}


@mcp.tool(annotations=READ)
async def get_monitor(company_id: Annotated[int, Field(ge=1)]) -> dict[str, Any]:
    """Get one monitor, including its scraper recipe and recent runs."""
    return await _client().get_company(company_id)


@mcp.tool(annotations=WEB_WRITE)
async def create_monitor(
    name: Annotated[str, Field(min_length=1, max_length=160)],
    careers_url: Annotated[str, Field(pattern=r"^https?://")],
    cities: list[str] | None = None,
    title_terms: list[str] | None = None,
    keywords: list[str] | None = None,
    schedule_kind: Literal["manual", "interval", "daily", "weekly"] = "daily",
    interval_hours: Annotated[int, Field(ge=1, le=168)] = 24,
    local_time: Annotated[str, Field(pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")] = "09:00",
    weekday: Annotated[int, Field(ge=0, le=6)] = 0,
    logo_url: Annotated[str | None, Field(pattern=r"^https?://")] = None,
    preset_ids: Annotated[list[str] | None, Field(max_length=20)] = None,
    build_now: bool = True,
) -> dict[str, Any]:
    """Create a career-page monitor and optionally queue its first scraper build."""
    api = _client()
    company = await api.create_company({
        "name": name,
        "careers_url": careers_url,
        "criteria": {"cities": cities or [], "title_terms": title_terms or [], "keywords": keywords or []},
        "schedule_kind": schedule_kind,
        "interval_hours": interval_hours,
        "local_time": local_time,
        "weekday": weekday,
        "logo_url": logo_url,
        "preset_ids": preset_ids or [],
        "build_now": False,
    })
    result: dict[str, Any] = {"monitor": company, "build": None}
    if build_now:
        run = await api.action(company["id"], "build", {"force_ai": False})
        result["build"] = run
        result["next_step"] = f"Poll get_run_status with run_id={run['id']}."
    return result


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_monitor_details(
    company_id: Annotated[int, Field(ge=1)],
    name: Annotated[str | None, Field(min_length=1, max_length=160)] = None,
    careers_url: Annotated[str | None, Field(pattern=r"^https?://")] = None,
    logo_url: Annotated[str | None, Field(pattern=r"^https?://")] = None,
    clear_logo_url: bool = False,
    preset_ids: Annotated[list[str] | None, Field(max_length=20)] = None,
) -> dict[str, Any]:
    """Update monitor identity, optional logo override, and local preset memberships.

    Use clear_logo_url=true to return to automatic branding. Preset membership changes organize
    this local monitor only and never rewrite a portable or external preset manifest.
    """
    if clear_logo_url and logo_url is not None:
        raise ValueError("clear_logo_url cannot be combined with logo_url")
    patch: dict[str, Any] = {}
    if name is not None:
        patch["name"] = name
    if careers_url is not None:
        patch["careers_url"] = careers_url
    if logo_url is not None or clear_logo_url:
        patch["logo_url"] = None if clear_logo_url else logo_url
    if preset_ids is not None:
        patch["preset_ids"] = preset_ids
    if not patch:
        raise ValueError("Provide name, careers_url, logo_url, clear_logo_url, or preset_ids")
    return await _client().patch_company(company_id, patch)


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def update_monitor_criteria(
    company_id: Annotated[int, Field(ge=1)],
    cities: list[str] | None = None,
    title_terms: list[str] | None = None,
    keywords: list[str] | None = None,
) -> dict[str, Any]:
    """Replace a monitor's city, job-title, and keyword criteria. Empty lists mean any value."""
    return await _client().patch_company(company_id, {"criteria": {
        "cities": cities or [], "title_terms": title_terms or [], "keywords": keywords or []
    }})


@mcp.tool(annotations=IDEMPOTENT_WRITE)
async def set_monitor_schedule(
    company_id: Annotated[int, Field(ge=1)],
    schedule_kind: Literal["manual", "interval", "daily", "weekly"],
    interval_hours: Annotated[int, Field(ge=1, le=168)] = 24,
    local_time: Annotated[str, Field(pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")] = "09:00",
    weekday: Annotated[int, Field(ge=0, le=6)] = 0,
) -> dict[str, Any]:
    """Set a constrained manual, hourly-interval, daily, or weekly monitor schedule."""
    return await _client().patch_company(company_id, {
        "schedule_kind": schedule_kind, "interval_hours": interval_hours,
        "local_time": local_time, "weekday": weekday,
    })


async def _queue_action(company_id: int, action: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    run = await _client().action(company_id, action, payload)
    return {"queued": run.get("status") == "queued", "reused": bool(run.get("reused")), "run": run, "run_id": run["id"], "terminal": False,
            "next_step": f"Poll get_run_status with run_id={run['id']}."}


@mcp.tool(annotations=WEB_WRITE)
async def build_scraper(company_id: Annotated[int, Field(ge=1)], force_ai: bool = False) -> dict[str, Any]:
    """Queue scraper detection/build. Use force_ai only to regenerate a known or generic recipe."""
    return await _queue_action(company_id, "build", {"force_ai": force_ai})


@mcp.tool(annotations=WEB_WRITE)
async def run_scraper(company_id: Annotated[int, Field(ge=1)]) -> dict[str, Any]:
    """Queue a deterministic scraper run for a monitor with an active recipe."""
    return await _queue_action(company_id, "run")


@mcp.tool(annotations=WEB_WRITE)
async def repair_scraper(company_id: Annotated[int, Field(ge=1)]) -> dict[str, Any]:
    """Queue validation and repair of a monitor's active scraper recipe."""
    return await _queue_action(company_id, "repair")


@mcp.tool(annotations=READ)
async def list_runs(
    company_id: Annotated[int | None, Field(ge=1)] = None,
    limit: Annotated[int, Field(ge=1, le=100)] = 25,
) -> dict[str, Any]:
    """List recent scraper build, run, and repair activity."""
    data = await _client().list_runs(company_id, limit)
    return {"count": data.get("count", 0), "runs": data.get("items", [])}


@mcp.tool(annotations=READ)
async def get_run_status(run_id: Annotated[int, Field(ge=1)]) -> dict[str, Any]:
    """Get run status; follow continuation_run_id until all-role work finishes."""
    run = await _client().get_run(run_id)
    run["terminal"] = run.get("status") in {"complete", "partial", "failed", "cancelled", "interrupted"}
    following = (run.get('progress_detail') or {}).get('continuation_run_id')
    if following:
        run['continuation_run_id'] = following
        run['next_step'] = f'Poll get_run_status with run_id={following} to follow the remaining all-role work.'
    return run


from .tracker_tools import register_tools as register_tracker_tools
register_tracker_tools(mcp, lambda: _client(), READ, IDEMPOTENT_WRITE, WEB_WRITE, DESTRUCTIVE_WRITE)

from .public_board_tools import register_tools as register_public_board_tools
register_public_board_tools(mcp, lambda: _client(), READ, IDEMPOTENT_WRITE)

from .interviews.mcp import register_tools as register_interview_tools
register_interview_tools(mcp, _client, READ, IDEMPOTENT_WRITE, DESTRUCTIVE_WRITE)


from .contributions.mcp import register_tools as register_contribution_tools
register_contribution_tools(mcp, lambda: _client(), READ, WEB_READ, IDEMPOTENT_WRITE)


if __name__ == "__main__":
    mcp.run()
