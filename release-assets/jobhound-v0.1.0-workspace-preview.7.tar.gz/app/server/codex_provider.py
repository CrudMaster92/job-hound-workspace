"""Narrow, mock-friendly boundary for Codex recipe generation and repair."""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Callable

from .agent_instructions import compose_recipe_prompt


class CodexProviderError(RuntimeError):
    pass


Runner = Callable[..., subprocess.CompletedProcess[str]]


class CodexProvider:
    """Uses the local Codex login without reading or copying credential files."""

    def __init__(self, runner: Runner = subprocess.run, executable: str | None = None) -> None:
        self.runner = runner
        self.executable = executable or shutil.which("codex")

    def status(self) -> dict[str, Any]:
        if not self.executable:
            return {"available": False, "authenticated": False, "detail": "Codex CLI is not installed"}
        try:
            result = self.runner(
                [self.executable, "login", "status"], capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=10,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return {"available": True, "authenticated": False, "detail": str(exc)}
        detail = (result.stdout or result.stderr).strip()
        authenticated = result.returncode == 0 and "not logged in" not in detail.lower()
        return {"available": True, "authenticated": authenticated, "detail": detail}

    def generate_recipe(self, *, company: str, careers_url: str, evidence: str, previous_recipe: dict[str, Any] | None = None,
                        diagnostics: str | None = None,
                        instructions: dict[str, str] | None = None) -> dict[str, Any]:
        status = self.status()
        if not status["authenticated"]:
            raise CodexProviderError(status["detail"])
        try:
            from .ai_connections.validation import json_schema
            from .scrapers.ai_contract import ScraperRecipeProposal, compile_recipe_proposal
        except ImportError as exc:
            raise CodexProviderError("Scraper recipe contract is unavailable") from exc
        prompt = compose_recipe_prompt(
            {"name": company, "careers_url": careers_url}, evidence=evidence,
            previous_recipe=previous_recipe, diagnostics=diagnostics,
            overrides=instructions,
        )
        schema = json_schema(ScraperRecipeProposal)
        if self.runner is subprocess.run:
            try:
                from openai_codex import Codex, Sandbox

                with Codex() as codex:
                    thread = codex.thread_start(ephemeral=True, sandbox=Sandbox.read_only)
                    result = thread.run(prompt, output_schema=schema)
                payload = json.loads(result.final_response)
                return compile_recipe_proposal(payload)
            except Exception as exc:
                # Keep the CLI path as a compatibility fallback for older local SDK runtimes.
                sdk_error = exc
        else:
            sdk_error = None
        with tempfile.TemporaryDirectory(prefix="jobhound-codex-") as temp_dir:
            schema_path = Path(temp_dir, "recipe-schema.json")
            output_path = Path(temp_dir, "recipe.json")
            schema_path.write_text(json.dumps(schema), encoding="utf-8")
            command = [self.executable, "exec", "-", "--ephemeral", "--sandbox", "read-only", "--skip-git-repo-check",
                       "--output-schema", str(schema_path), "--output-last-message", str(output_path)]
            try:
                result = self.runner(
                    command, input=prompt, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=180,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                raise CodexProviderError(f"Codex execution failed: {exc}") from exc
            if result.returncode != 0 or not output_path.exists():
                detail = (result.stderr or result.stdout)[-2000:]
                if sdk_error:
                    detail = f"SDK fallback reason: {sdk_error}; CLI: {detail}"
                raise CodexProviderError(f"Codex did not produce a recipe: {detail}")
            try:
                payload = json.loads(output_path.read_text(encoding="utf-8"))
                return compile_recipe_proposal(payload)
            except (json.JSONDecodeError, ValueError) as exc:
                raise CodexProviderError(f"Codex returned an invalid recipe: {exc}") from exc

    def repair_recipe(self, *, company: str, careers_url: str, evidence: str, previous_recipe: dict[str, Any], diagnostics: str,
                      instructions: dict[str, str] | None = None) -> dict[str, Any]:
        return self.generate_recipe(company=company, careers_url=careers_url, evidence=evidence,
                                    previous_recipe=previous_recipe, diagnostics=diagnostics,
                                    instructions=instructions)
