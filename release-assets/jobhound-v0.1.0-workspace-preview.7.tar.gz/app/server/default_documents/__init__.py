"""Packaged default career documents."""
