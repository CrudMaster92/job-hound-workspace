"""Host-only saved-library search and per-chat, named-connection access."""
import json
from typing import Literal
from fastapi import APIRouter, Depends, Request, Query
from pydantic import BaseModel, ConfigDict, Field
from .interviews.contracts import InterviewError
from .interviews.routes import local_connection

Connection = Literal['codex', 'claude', 'openrouter', 'hermes', 'openclaw']
class LibraryRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    action: Literal['search', 'read']
    query: str = Field(default='', max_length=200)
    source: Literal['all', 'document', 'interview'] = 'all'
    id: int | None = Field(default=None, ge=1)
    offset: int = Field(default=0, ge=0)
    include_archived: bool = False

class LibraryAccess(BaseModel):
    model_config = ConfigDict(extra='forbid')
    connection: Connection
    allowed: bool
    turn_id: int | None = Field(default=None, ge=1)

class LibraryService:
    def __init__(self, database, documents, interviews):
        self.db, self.documents, self.interviews = database, documents, interviews
        with database.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS chat_library_access (
              thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
              connection TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0,
              used INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(thread_id,connection));
            CREATE TABLE IF NOT EXISTS chat_library_decisions (
              turn_id INTEGER PRIMARY KEY REFERENCES chat_turns(id) ON DELETE CASCADE,
              connection TEXT NOT NULL, allowed INTEGER NOT NULL);
            ''')
            # Older private chats retain which provider already received their history,
            # without granting that provider automatic library lookup.
            c.execute("""INSERT OR IGNORE INTO chat_library_access(thread_id,connection,allowed,used)
              SELECT DISTINCT t.id,json_extract(m.metadata_json,'$.provider'),0,1
              FROM chat_threads t JOIN chat_messages m ON m.thread_id=t.id
              WHERE t.private_local=1 AND m.role='assistant'
              AND json_extract(m.metadata_json,'$.provider') IN ('codex','claude','hermes','openrouter','openclaw')""")

    def access(self, thread_id, connection):
        if not self.db.get_chat_thread(thread_id):
            raise InterviewError('chat_not_found', 'Chat not found', 404)
        with self.db.connect() as c:
            row = c.execute('SELECT * FROM chat_library_access WHERE thread_id=? AND connection=?', (thread_id, connection)).fetchone()
            any_used = bool(c.execute('SELECT 1 FROM chat_library_access WHERE thread_id=? AND used=1 LIMIT 1', (thread_id,)).fetchone())
        return {'thread_id': thread_id, 'connection': connection, 'allowed': bool(row and row['allowed']),
                'history_requires_consent': any_used and not bool(row and row['used'])}

    def set_access(self, thread_id, payload):
        self.access(thread_id, payload.connection)
        with self.db.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if payload.turn_id is not None:
                turn = c.execute('SELECT * FROM chat_turns WHERE id=? AND thread_id=?', (payload.turn_id, thread_id)).fetchone()
                if not turn or turn['status'] != 'running' or turn['stage'] != 'awaiting_library_access' or turn['provider'] != payload.connection:
                    # Repeated submissions for the same resolved decision are harmless.
                    old = c.execute('SELECT * FROM chat_library_decisions WHERE turn_id=?', (payload.turn_id,)).fetchone()
                    if old and old['connection'] == payload.connection and bool(old['allowed']) == payload.allowed:
                        return self.access(thread_id, payload.connection)
                    raise InterviewError('stale_consent', 'This request is no longer waiting for library access')
                c.execute('INSERT OR REPLACE INTO chat_library_decisions VALUES(?,?,?)', (payload.turn_id, payload.connection, int(payload.allowed)))
            c.execute('INSERT INTO chat_library_access(thread_id,connection,allowed) VALUES(?,?,?) ON CONFLICT(thread_id,connection) DO UPDATE SET allowed=excluded.allowed', (thread_id, payload.connection, int(payload.allowed)))
            if payload.allowed:
                c.execute('UPDATE chat_threads SET private_local=1 WHERE id=?', (thread_id,))
        return self.access(thread_id, payload.connection)

    def mark_shared(self, thread_id, connection):
        """Record explicitly attached text sharing without granting library-wide access."""
        with self.db.connect() as c:
            c.execute('UPDATE chat_threads SET private_local=1 WHERE id=?',(thread_id,))
            c.execute('INSERT INTO chat_library_access(thread_id,connection,used) VALUES(?,?,1) ON CONFLICT(thread_id,connection) DO UPDATE SET used=1',(thread_id,connection))

    def mark_used(self, thread_id, connection):
        with self.db.connect() as c:
            c.execute('UPDATE chat_threads SET private_local=1 WHERE id=?', (thread_id,))
            c.execute('UPDATE chat_library_access SET used=1 WHERE thread_id=? AND connection=? AND allowed=1', (thread_id, connection))

    def search(self, query='', source='all', include_archived=False, offset=0, limit=20):
        # SQL selects only bounded snippets, never whole library contents.
        sql = '''WITH library AS (
          SELECT 'document' AS source,id,label AS title,kind,extraction_status AS state,
            archived_at IS NOT NULL AS archived,updated_at AS date,extracted_text AS body
          FROM documents
          UNION ALL
          SELECT 'interview',id,json_extract(metadata,'$.title'),'transcript',
            json_extract(metadata,'$.transcription_state'),archived,
            CAST(json_extract(metadata,'$.started_at') AS TEXT),
            COALESCE((SELECT group_concat(text,' ') FROM interview_segments WHERE interview_id=interviews.id),'')
          FROM interviews
        ) SELECT source,id,title,kind,state,archived,date,
          substr(body,max(1,instr(lower(body),lower(?))-100),400) AS snippet
          FROM library WHERE (?='all' OR source=?) AND (? OR NOT archived)
            AND (?='' OR instr(lower(title),lower(?))>0 OR instr(lower(body),lower(?))>0)
          ORDER BY CASE WHEN lower(title)=lower(?) THEN 0 ELSE 1 END,title COLLATE NOCASE,source,id
          LIMIT ? OFFSET ?'''
        args=(query,source,source,include_archived,query,query,query,query,limit+1,offset)
        with self.db.connect() as c:
            rows=[dict(r) for r in c.execute(sql,args)]
        more=len(rows)>limit
        return {'items': rows[:limit], 'next_offset': offset+limit if more else None}

    def read(self, request):
        if request.source == 'document':
            value=self.documents.read(request.id, offset=request.offset, max_chars=12000)
            if value.get('archived') and not request.include_archived:
                raise InterviewError('archived', 'The document is archived; request archived items explicitly')
            if value['extraction_status'] != 'complete':
                raise InterviewError('text_unavailable', 'Document text is not ready')
            return {'source':'document','id':request.id,'title':value['label'], 'text':value['text'],
                    'offset':request.offset,'next_offset':value['next_offset'], 'sha256':value.get('sha256'),
                    'url':f'/documents?document={request.id}'}
        if request.source != 'interview' or not request.id:
            raise InterviewError('invalid_source', 'Read requires a document or interview ID',422)
        item=self.interviews.store.get(request.id)
        if item['archived'] and not request.include_archived:
            raise InterviewError('archived', 'The interview is archived; request archived items explicitly')
        if item['transcription_state'] != 'ready':
            raise InterviewError('text_unavailable', f"Transcript is {item['transcription_state']}; wait or retry transcription")
        page=self.interviews.store.segments(request.id,request.offset,8,request.query)
        return {'source':'interview','id':request.id,'title':item['title'],'revision':item['revision'],
                'microphone_label':item['microphone_label'],'output_label':item['output_label'],
                'segments':[{k:s[k] for k in ('id','source','start','end','text')} for s in page['items']],
                'next_offset':page['next_offset'],'url':f'/documents?interview={request.id}'}

    def execute(self, value):
        if value.action=='search':
            return self.search(value.query,value.source,value.include_archived,value.offset,10)
        return self.read(value)


def mount_library(app, library):
    def local(request: Request): local_connection(request)
    router=APIRouter(prefix='/api/v1',dependencies=[Depends(local)])
    @router.get('/library/search')
    def search(query: str=Query('',max_length=200), source: Literal['all','document','interview']='all',
               include_archived: bool=False, offset: int=Query(0,ge=0),limit: int=Query(20,ge=1,le=50)):
        return library.search(query,source,include_archived,offset,limit)
    @router.get('/chat/threads/{thread_id}/library-access')
    def access(thread_id: int, connection: Connection): return library.access(thread_id,connection)
    @router.put('/chat/threads/{thread_id}/library-access')
    def change(thread_id: int,payload: LibraryAccess): return library.set_access(thread_id,payload)
    app.include_router(router)
