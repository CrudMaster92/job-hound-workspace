"""Loopback-only HTTP client used by the JobHound MCP bridge."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx


DEFAULT_API_URL = "http://127.0.0.1:4175/api/v1"
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}


class JobHoundApiError(RuntimeError):
    """An actionable error safe to return to an MCP client."""


def normalize_api_url(value: str | None = None) -> str:
    raw = (value or os.getenv("JOBHOUND_API_URL") or DEFAULT_API_URL).strip().rstrip("/")
    parsed = urlparse(raw)
    if parsed.scheme != "http" or (parsed.hostname or "").casefold() not in LOOPBACK_HOSTS:
        raise ValueError(
            "JOBHOUND_API_URL must be an HTTP loopback URL using localhost, 127.0.0.1, or ::1."
        )
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("JOBHOUND_API_URL cannot contain credentials, a query, or a fragment.")
    if not parsed.path or parsed.path == "/":
        raw += "/api/v1"
    elif not parsed.path.rstrip("/").endswith("/api/v1"):
        raise ValueError("JOBHOUND_API_URL must end in /api/v1.")
    return raw


class JobHoundApiClient:
    def __init__(
        self,
        base_url: str | None = None,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        timeout: float = 45.0,
    ) -> None:
        self.base_url = normalize_api_url(base_url)
        self.transport = transport
        self.timeout = timeout

    async def request(self, method: str, path: str, **kwargs: Any) -> Any:
        try:
            async with httpx.AsyncClient(
                base_url=self.base_url,
                transport=self.transport,
                timeout=self.timeout,
                trust_env=False,
            ) as client:
                response = await client.request(method, path.lstrip("/"), **kwargs)
        except httpx.TimeoutException as exc:
            raise JobHoundApiError(
                "JobHound did not respond before the request deadline. Inspect service/run status and retry; queued work may still be running."
            ) from exc
        except httpx.RequestError as exc:
            raise JobHoundApiError(
                "Cannot reach JobHound's loopback service. Start JobHound or inspect the workspace launcher status, then retry."
            ) from exc
        if response.is_error:
            try:
                detail = response.json().get("detail")
            except (ValueError, AttributeError):
                detail = None
            message = detail or response.text.strip() or response.reason_phrase
            raise JobHoundApiError(f"JobHound returned HTTP {response.status_code}: {message}")
        if response.status_code == 204:
            return None
        return response.json()

    async def request_bytes(self, method: str, path: str, **kwargs: Any) -> tuple[bytes, dict[str, str]]:
        try:
            async with httpx.AsyncClient(
                base_url=self.base_url,
                transport=self.transport,
                timeout=self.timeout,
                trust_env=False,
            ) as client:
                response = await client.request(method, path.lstrip("/"), **kwargs)
        except httpx.TimeoutException as exc:
            raise JobHoundApiError(
                "JobHound did not respond before the request deadline. Inspect service/run status and retry; queued work may still be running."
            ) from exc
        except httpx.RequestError as exc:
            raise JobHoundApiError(
                "Cannot reach JobHound's loopback service. Start JobHound or inspect the workspace launcher status, then retry."
            ) from exc
        if response.is_error:
            try:
                detail = response.json().get("detail")
            except (ValueError, AttributeError):
                detail = None
            message = detail or response.text.strip() or response.reason_phrase
            raise JobHoundApiError(f"JobHound returned HTTP {response.status_code}: {message}")
        return response.content, dict(response.headers)

    async def health(self) -> dict[str, Any]:
        return await self.request("GET", "health")

    async def get_recap_settings(self):
        return await self.request("GET", "recap/settings")

    async def update_recap_settings(self, settings):
        return await self.request("PUT", "recap/settings", json=settings)

    async def run_daily_recap(self, request_id):
        return await self.request("POST", "recap/runs", json={"request_id": request_id})

    async def get_daily_recap(self, run_id=None):
        return await self.request("GET", "recap", params={"run_id": run_id} if run_id else {})

    async def search_public_jobs(self, query: dict[str, Any]) -> dict[str, Any]:
        params = []
        for key, value in query.items():
            if value is None:
                continue
            values = value if isinstance(value, list) else [value]
            params.extend((key, str(item).lower() if isinstance(item, bool) else str(item)) for item in values)
        return await self.request("GET", "public-board/jobs", params=params)

    async def dashboard(self) -> dict[str, Any]:
        return await self.request("GET", "dashboard")

    async def export_dashboard_card(self, card_key: str, theme: str = "light") -> bytes:
        content, _ = await self.request_bytes(
            "GET", f"dashboard/cards/{card_key}/image", params={"theme": theme},
        )
        return content

    async def application_tracker(
        self, from_date: str | None = None, to_date: str | None = None,
        include_closed: bool = False,
    ) -> dict[str, Any]:
        return await self.request("GET", "application-tracker", params={
            "from": from_date, "to": to_date, "include_closed": include_closed,
        })

    async def create_manual_application(self, value: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "applications/manual", json=value)

    async def map_preferences(self) -> dict[str, Any]:
        return await self.request("GET", "map/preferences")

    async def set_home_location(
        self, address: str | None = None, clear: bool = False,
    ) -> dict[str, Any]:
        if clear:
            return await self.request("DELETE", "map/home")
        return await self.request("PUT", "map/home", json={"address": address})

    async def update_dashboard_layout(self, revision: int, items: list[dict[str, Any]]) -> dict[str, Any]:
        return await self.request("PUT", "dashboard/layout", json={"revision": revision, "items": items})

    async def platform_profiles(self) -> dict[str, Any]:
        return await self.request("GET", "platforms")

    async def platform_catalog(
        self, query: str = "", country: str = "", region: str = "", industry: str = "",
    ) -> dict[str, Any]:
        return await self.request("GET", "platform-catalog", params={
            "q": query, "country": country, "region": region, "industry": industry,
        })

    async def add_custom_platform(self, value: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "platform-catalog/custom", json=value)

    async def track_platform_profile(self, platform: str) -> dict[str, Any]:
        return await self.request("POST", f"platforms/{platform}")

    async def untrack_platform_profile(self, platform: str) -> dict[str, Any]:
        return await self.request("DELETE", f"platforms/{platform}")

    async def set_profile_visibility_enabled(self, enabled: bool) -> dict[str, Any]:
        return await self.request("PUT", "settings/optional-features", json={
            "profile_visibility_enabled": enabled,
        })

    async def update_platform_profile(
        self, platform: str, visibility: str, reminder_days: int,
    ) -> dict[str, Any]:
        return await self.request("PUT", f"platforms/{platform}", json={
            "visibility": visibility,
            "reminder_days": reminder_days,
            "confirmation_source": "agent",
        })

    async def get_dashboard_widget_sdk(self) -> dict[str, Any]:
        return await self.request("GET", "dashboard/widget-sdk")

    async def list_dashboard_widgets(self, include_drafts: bool = True) -> dict[str, Any]:
        return await self.request("GET", "dashboard/widgets", params={"include_drafts": include_drafts})

    async def create_dashboard_widget_draft(
        self, manifest: dict[str, Any], javascript: str, css: str = "",
        draft_id: int | None = None, request_id: str | None = None,
    ) -> dict[str, Any]:
        payload = {"manifest": manifest, "javascript": javascript, "css": css}
        if draft_id is None:
            if request_id:
                payload["request_id"] = request_id
            return await self.request("POST", "dashboard/widget-drafts", json=payload)
        current = await self.request("GET", f"dashboard/widget-drafts/{draft_id}")
        payload["revision"] = current["revision"]
        return await self.request("PUT", f"dashboard/widget-drafts/{draft_id}", json=payload)

    async def install_dashboard_widget(
        self, draft_id: int, size: str | None = None,
        after_key: str | None = None, at_top: bool = False,
    ) -> dict[str, Any]:
        return await self.request("POST", "dashboard/widgets/install", json={
            "draft_id": draft_id, "size": size, "after_key": after_key, "at_top": at_top,
        })

    async def ai_connections(self) -> dict[str, Any]:
        return await self.request("GET", "ai/connections")

    async def openai_models(self) -> dict[str, Any]:
        return await self.request("GET", "ai/connections/codex/models")

    async def select_ai_connection(self, connection: str, model: str | None = None, openai_options: dict | None = None) -> dict[str, Any]:
        return await self.request(
            "PUT", "ai/selection", json={"connection": connection, "model": model, **({"openai_options": openai_options} if openai_options is not None else {})}
        )

    async def get_agent_instructions(self) -> dict[str, Any]:
        return await self.request("GET", "settings/agent-instructions")

    async def preview_agent_instructions(self, patch: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "settings/agent-instructions/preview", json=patch)

    async def update_agent_instructions(self, patch: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PUT", "settings/agent-instructions", json=patch)

    async def list_chat_commands(self) -> dict[str, Any]:
        return await self.request("GET", "chat/commands")

    async def list_chat_threads(
        self, *, role_id: int | None = None, company_id: int | None = None,
        command_id: str | None = None, query: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if role_id is not None:
            params["role_id"] = role_id
        if company_id is not None:
            params["company_id"] = company_id
        if command_id:
            params["command_id"] = command_id
        if query:
            params["query"] = query
        return await self.request("GET", "chat/threads", params=params)

    async def get_chat_thread(self, thread_id: int) -> dict[str, Any]:
        return await self.request("GET", f"chat/threads/{thread_id}")

    async def create_chat_thread(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "chat/threads", json=payload)

    async def set_chat_thread_context(
        self, thread_id: int, payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request("PATCH", f"chat/threads/{thread_id}", json=payload)

    async def upload_chat_attachment(self, thread_id: int, path: Path) -> dict[str, Any]:
        with path.open("rb") as handle:
            return await self.request(
                "POST", "chat/attachments",
                data={"thread_id": str(thread_id)},
                files={"file": (path.name, handle, "application/octet-stream")},
            )

    async def attach_chat_document(self, thread_id: int, document_id: int) -> dict[str, Any]:
        return await self.request("POST", "chat/attachments/from-document", json={
            "thread_id": thread_id, "document_id": document_id,
        })

    async def send_chat_message(
        self, thread_id: int, payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request("POST", f"chat/threads/{thread_id}/turns", json=payload)

    async def get_chat_turn_status(self, turn_id: int) -> dict[str, Any]:
        return await self.request("GET", f"chat/turns/{turn_id}")

    async def cancel_chat_turn(self, turn_id: int) -> dict[str, Any]:
        return await self.request("POST", f"chat/turns/{turn_id}/cancel")

    async def retry_chat_turn(self, turn_id: int, request_id: str) -> dict[str, Any]:
        return await self.request(
            "POST", f"chat/turns/{turn_id}/retry", json={"request_id": request_id},
        )

    async def rename_chat_thread(self, thread_id: int, title: str) -> dict[str, Any]:
        return await self.request("PATCH", f"chat/threads/{thread_id}", json={"title": title})

    async def delete_chat_thread(self, thread_id: int) -> dict[str, Any]:
        return await self.request("DELETE", f"chat/threads/{thread_id}")

    async def list_documents(self, kind: str | None = None, include_archived: bool = False,
                             include_drafts: bool = False) -> dict[str, Any]:
        params: dict[str, Any] = {"include_archived": include_archived, "include_drafts": include_drafts}
        if kind:
            params["kind"] = kind
        return await self.request("GET", "documents", params=params)

    async def get_document(self, document_id: int, max_chars: int = 20_000,
                           variant: str = "template", record_type: str = "document", offset: int = 0) -> dict[str, Any]:
        if record_type == "draft":
            return await self.request("GET", f"document-drafts/{document_id}")
        return await self.request(
            "GET", f"documents/{document_id}",
            params={"max_chars": max_chars, "variant": variant, "offset": offset},
        )

    async def create_document_draft(self, content: dict[str, Any],
                                    source_document_id: int | None = None) -> dict[str, Any]:
        return await self.request("POST", "document-drafts", json={
            "source_document_id": source_document_id, "content": content,
        })

    async def update_document_draft(self, draft_id: int, content: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PATCH", f"document-drafts/{draft_id}", json={"content": content})

    async def publish_document_draft(self, draft_id: int) -> dict[str, Any]:
        return await self.request("POST", f"document-drafts/{draft_id}/publish")

    async def upload_document(self, path: Path, *, kind: str, label: str | None = None,
                              replace_document_id: int | None = None) -> dict[str, Any]:
        data: dict[str, str] = {"kind": kind}
        if label:
            data["label"] = label
        if replace_document_id is not None:
            data["replace_document_id"] = str(replace_document_id)
        with path.open("rb") as handle:
            return await self.request(
                "POST", "documents", data=data,
                files={"file": (path.name, handle, "application/octet-stream")},
            )

    async def update_document(self, document_id: int, patch: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PATCH", f"documents/{document_id}", json=patch)

    async def purge_document(self, document_id: int) -> dict[str, Any]:
        return await self.request("DELETE", f"documents/{document_id}", params={"confirm": True})

    async def list_companies(self, include_archived: bool = False) -> dict[str, Any]:
        return await self.request("GET", "companies", params={"include_archived": include_archived})

    async def list_presets(self, filters: dict[str, Any] | None = None) -> dict[str, Any]:
        catalog = await self.request("GET", "presets", params={
            key: value for key, value in (filters or {}).items() if value not in (None, "", False)
        })
        installations = await self.request("GET", "preset-installations")
        return {**catalog, "installations": installations.get("items", [])}

    async def get_preset(self, preset_id: str, *, limit: int = 50,
                         cursor: str | None = None) -> dict[str, Any]:
        return await self.request("GET", f"presets/{preset_id}", params={
            "limit": limit, **({"cursor": cursor} if cursor else {}),
        })

    async def search_preset_companies(self, filters: dict[str, Any] | None = None) -> dict[str, Any]:
        return await self.request("GET", "preset-catalog/companies", params={
            key: value for key, value in (filters or {}).items() if value not in (None, "", False)
        })

    async def preview_preset_selection(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "preset-catalog/selections/preview", json=payload)

    async def install_preset_monitors(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "preset-catalog/selections/install", json=payload)

    async def import_preset(self, manifest: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "presets/import", json=manifest)

    async def export_preset(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "presets/export", json=payload)

    async def install_preset(self, preset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", f"presets/{preset_id}/install", json=payload)

    async def update_catalog_recipe(self, company_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", f"companies/{company_id}/catalog-recipe-update", json=payload)

    async def archive_preset_installation(self, installation_id: int) -> dict[str, Any]:
        return await self.request("DELETE", f"preset-installations/{installation_id}")

    async def set_preset_visibility(self, preset_id: str, hidden: bool) -> dict[str, Any]:
        return await self.request("PATCH", f"presets/{preset_id}/visibility", json={"hidden": hidden})

    async def preview_preset_removal(self, preset_id: str) -> dict[str, Any]:
        return await self.request("GET", f"presets/{preset_id}/removal-preview")

    async def remove_preset(self, preset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", f"presets/{preset_id}/remove", json=payload)

    async def get_company(self, company_id: int) -> dict[str, Any]:
        return await self.request("GET", f"companies/{company_id}")

    async def create_company(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", "companies", json=payload)

    async def patch_company(self, company_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PATCH", f"companies/{company_id}", json=payload)

    async def action(self, company_id: int, action: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return await self.request("POST", f"companies/{company_id}/{action}", json=payload)

    async def list_jobs(self, **params: Any) -> dict[str, Any]:
        return await self.request("GET", "jobs", params=params)

    async def get_job(self, job_id: int) -> dict[str, Any]:
        return await self.request("GET", f"jobs/{job_id}")

    async def update_job_tracking(self, job_id: int, patch: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PATCH", f"jobs/{job_id}/tracking", json=patch)

    async def add_job_activity(self, job_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", f"jobs/{job_id}/activities", json=payload)

    async def find_recruiters(self, job_id: int, live_search: bool = True) -> dict[str, Any]:
        return await self.request(
            "POST", f"jobs/{job_id}/recruiters", json={"live_search": live_search},
            timeout=250, headers={"X-JobHound-Actor": "agent"},
        )

    async def interview_prep_options(self) -> dict[str, Any]:
        return await self.request("GET", "interview-prep/options")

    async def discover_companies(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request(
            "POST", "company-discovery", json=payload, timeout=250,
            headers={"X-JobHound-Actor": "agent"},
        )

    async def prepare_interview(self, job_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request(
            "POST", f"jobs/{job_id}/interview-prep", json=payload, timeout=250,
            headers={"X-JobHound-Actor": "agent"},
        )

    async def create_intro_letter(self, job_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request(
            "POST", f"jobs/{job_id}/intro-letter", json=payload, timeout=250,
        )

    async def list_runs(self, company_id: int | None = None, limit: int = 50) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if company_id is not None:
            params["company_id"] = company_id
        return await self.request("GET", "runs", params=params)

    async def get_run(self, run_id: int) -> dict[str, Any]:
        return await self.request("GET", f"runs/{run_id}")
