"""Focused tracker MCP tools using the same loopback contracts as the UI."""
from typing import Annotated, Any, Literal
from pydantic import Field
from .tracker_contracts import FavouriteRequest, BatchRequest, MonitorDeleteRequest

def register_tools(mcp, client, read, write, web_write, destructive):
    @mcp.tool(annotations=read)
    async def get_tracker_activity() -> dict[str, Any]:
        """Inspect installed trackers, all active work, recent runs, batch progress and favourites. Includes scheduled and agent-started work."""
        return await client().request("GET", "trackers/activity")

    @mcp.tool(annotations=read)
    async def list_favourite_companies() -> dict[str, Any]:
        """List local company favourites, including companies not yet installed. No catalog refresh or install."""
        return await client().request("GET", "trackers/favourites")

    @mcp.tool(annotations=write)
    async def set_company_favourite(request: FavouriteRequest) -> dict[str, Any]:
        """Star or unstar a company independently of installation. Use its stable catalog company ID when available; otherwise careers URL."""
        return await client().request("PUT", "trackers/favourites", json=request.model_dump())

    @mcp.tool(annotations=web_write)
    async def run_scrapers(request: BatchRequest) -> dict[str, Any]:
        """Queue one durable batch. Omit company_ids for all active trackers. Skips paused, hidden, archived, unbuilt and busy trackers. Reuse request_id on retry and poll get_scraper_batch."""
        return await client().request("POST", "trackers/batches", json=request.model_dump())

    @mcp.tool(annotations=read)
    async def get_scraper_batch(batch_id: Annotated[int, Field(ge=1)]) -> dict[str, Any]:
        """Read batch ID, terminal state, finished/total count, skips and individual run IDs. 100 percent means finished, including explicit failures."""
        return await client().request("GET", f"trackers/batches/{batch_id}")

    @mcp.tool(annotations=read)
    async def preview_monitor_removal(company_id: Annotated[int, Field(ge=1)]) -> dict[str, Any]:
        """Inspect affected jobs, saved roles, applications, collection memberships and running work before archive or deletion."""
        return await client().request("GET", f"trackers/{company_id}/removal-preview")

    @mcp.tool(annotations=write)
    async def set_monitor_state(company_id: Annotated[int, Field(ge=1)], action: Literal["pause", "resume", "archive", "restore"]) -> dict[str, Any]:
        """Pause/resume or archive/restore tracking without deleting roles or history. Pausing/archiving cancels queued work; in-progress work may finish without resuming tracking."""
        return await client().request("POST", f"trackers/{company_id}/state", json={"action": action})

    @mcp.tool(annotations=destructive)
    async def delete_monitor(company_id: Annotated[int, Field(ge=1)], confirmation: MonitorDeleteRequest) -> dict[str, Any]:
        """Permanently delete one tracker and its jobs across all memberships after preview and explicit user choice. Requires exact name and application-history consent; refuses running work."""
        return await client().request("POST", f"trackers/{company_id}/delete", json=confirmation.model_dump())
