"""Five focused typed tools, all backed by the same host-only routes."""
from typing import Annotated, Any
from pydantic import Field
from .contracts import Proposal, Prepare, Submission


def register_tools(mcp, client, read, web_read, write):
    write = write.model_copy(update={"open_world_hint": True})
    @mcp.tool(annotations=read)
    async def list_scraper_contributions(offset: Annotated[int, Field(ge=0)] = 0,
                                         limit: Annotated[int, Field(ge=1, le=100)] = 30) -> dict[str, Any]:
        """Inspect local public-proposal drafts before creating or retrying one."""
        return await client().request("GET", "contributions", params={"offset": offset, "limit": limit})

    @mcp.tool(annotations=web_read)
    async def get_scraper_contribution(contribution_id: Annotated[str, Field(pattern=r"^contrib_[a-f0-9]{32}$")],
                                       include_content: bool = False, refresh: bool = False) -> dict[str, Any]:
        """Poll preparation to terminal; read authored files and the PR body. Ready is not submitted, verified or published."""
        return await client().request("GET", f"contributions/{contribution_id}", params={"include_content": include_content, "refresh": refresh})

    @mcp.tool(annotations=web_read)
    async def preview_scraper_contribution(proposal: Proposal) -> dict[str, Any]:
        """Inspect public disclosure, current base/identity/open PRs and offline parsing. Does not submit or create monitors."""
        return await client().request("POST", "contributions/preview", json=proposal.model_dump(mode="json"))

    @mcp.tool(annotations=write)
    async def prepare_scraper_contribution(payload: Prepare) -> dict[str, Any]:
        """Only on an explicit human request to contribute publicly. Reuse request_id; poll get_scraper_contribution. Submit via human's GitHub connector."""
        return await client().request("POST", "contributions", json=payload.model_dump(mode="json"))

    @mcp.tool(annotations=write)
    async def record_scraper_contribution_submission(contribution_id: Annotated[str, Field(pattern=r"^contrib_[a-f0-9]{32}$")],
                                                    submission: Submission) -> dict[str, Any]:
        """Verify an actual PR's exact authored content/head before recording it. Never pushes, approves or merges; same PR can refresh review state."""
        return await client().request("POST", f"contributions/{contribution_id}/submission", json=submission.model_dump(mode="json"))
