"""Durable, retry-safe preparation. GitHub writes belong to the human's connector."""
from __future__ import annotations

import io
import json
import threading
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from ..db import iso_now
from .contracts import Prepare, Proposal, Submission, REPOSITORY, canonical_bytes, content_hash, validate_documents
from .github import PublicRepository, RepositoryUnavailable


class ContributionConflict(ValueError):
    pass


class ContributionService:
    def __init__(self, database, repository=None):
        self.db = database
        self.repository = repository or PublicRepository()
        self.lock = threading.RLock()
        self.worker = ThreadPoolExecutor(max_workers=1, thread_name_prefix="jobhound-contribution")
        with self.db.connect() as connection:
            connection.execute("""CREATE TABLE IF NOT EXISTS scraper_contributions (
                id TEXT PRIMARY KEY, run_id TEXT NOT NULL UNIQUE, request_id TEXT NOT NULL UNIQUE,
                request_hash TEXT NOT NULL, proposal_hash TEXT NOT NULL, proposal_json TEXT NOT NULL,
                state TEXT NOT NULL, files_json TEXT, inspection_json TEXT, submission_json TEXT,
                error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
            connection.execute("UPDATE scraper_contributions SET state='failed', error='Preparation interrupted; retry the same request ID.', updated_at=? WHERE state IN ('queued','running')", (iso_now(),))

    def close(self):
        self.worker.shutdown(wait=True)

    def preview(self, proposal: Proposal):
        result = validate_documents(proposal)
        from .validation import parse_fixture
        offline = parse_fixture(proposal)
        result["offline_parsing"] = offline
        try:
            inspection = self.repository.inspect(proposal, result["files"])
            result.update(repository_status="current", inspection=inspection,
                          submission_ready=not inspection["pending_prs"])
        except RepositoryUnavailable as exc:
            result.update(repository_status="unavailable", inspection=None, submission_ready=False)
            result["warnings"].append(str(exc))
        result["repository"] = REPOSITORY
        result["public_disclosure"] = "Only authored public company/recipe/fixture data and validation evidence. No personal profile is included."
        return result

    def list(self, offset=0, limit=30):
        with self.db.connect() as connection:
            total = connection.execute("SELECT COUNT(*) FROM scraper_contributions").fetchone()[0]
            rows = connection.execute("SELECT * FROM scraper_contributions ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?", (limit, offset)).fetchall()
        return {"items": [self._present(dict(row), False) for row in rows], "total": total, "offset": offset}

    def get(self, contribution_id, include_content=False, refresh=False):
        with self.db.connect() as connection:
            row = connection.execute("SELECT * FROM scraper_contributions WHERE id=?", (contribution_id,)).fetchone()
        if row is None:
            raise KeyError("Contribution not found")
        if refresh and row["submission_json"]:
            submission = json.loads(row["submission_json"])
            proposal = Proposal.model_validate_json(row["proposal_json"])
            try:
                remote = self.repository.contribution_status(submission, validate_documents(proposal)["monitor"])
                submission.update(remote, status_checked_at=iso_now(), status_error=None)
            except Exception as exc:
                submission.update(status_error=f"Status unavailable ({type(exc).__name__}); last known receipt retained.")
            self._update(contribution_id, submission_json=canonical_bytes(submission).decode())
            return self.get(contribution_id, include_content)
        return self._present(dict(row), include_content)

    @staticmethod
    def _present(row, include_content):
        proposal = json.loads(row["proposal_json"])
        result = {key: row[key] for key in ("id", "run_id", "state", "error", "created_at", "updated_at", "proposal_hash")}
        result.update(company_id=proposal["company"]["id"], company_name=proposal["company"]["name"],
                      monitor_id=proposal["monitor"]["id"], revision=proposal["monitor"]["revision"],
                      base_commit=proposal["base_commit"], terminal=row["state"] not in {"queued", "running"},
                      runtime_verified=False, preparation_state=row["state"], validation_state="not_checked",
                      publication_state="not_published", repository=REPOSITORY)
        if row["inspection_json"]:
            result["inspection"] = json.loads(row["inspection_json"])
        if row["files_json"]:
            result["download_url"] = f"/api/v1/contributions/{row['id']}/download"
            if include_content:
                result["files"] = json.loads(row["files_json"])
                result["proposal"] = proposal
                result["pr_body"] = pr_body(proposal, row["proposal_hash"])
        if row["submission_json"]:
            result["submission"] = json.loads(row["submission_json"])
            result["review_state"] = result["submission"]["review_state"]
            if result["review_state"] == "merged":
                result["publication_state"] = "awaiting_collection"
            for key in ("runtime_verified", "validation_state", "publication_state", "validation", "status_error", "status_checked_at"):
                if key in result["submission"]:
                    result[key] = result["submission"][key]
        return result

    def prepare(self, request: Prepare):
        normalized = validate_documents(request.proposal)
        request_hash = content_hash(request.model_dump(mode="json"))
        with self.lock, self.db.connect() as connection:
            previous = connection.execute("SELECT * FROM scraper_contributions WHERE request_id=?", (request.request_id,)).fetchone()
            if previous:
                if previous["request_hash"] != request_hash:
                    raise ContributionConflict("Request ID was already used for a different proposal")
                contribution_id = previous["id"]
                if previous["state"] != "failed":
                    return self._present(dict(previous), False)
                connection.execute("UPDATE scraper_contributions SET state='queued', error=NULL, updated_at=? WHERE id=?", (iso_now(), contribution_id))
            else:
                # A second request ID must not create an identical draft.
                previous = connection.execute("SELECT * FROM scraper_contributions WHERE proposal_hash=? AND state!='failed'", (normalized["proposal_hash"],)).fetchone()
                if previous:
                    return self._present(dict(previous), False)
                contribution_id, run_id = "contrib_" + uuid.uuid4().hex, "contribution_run_" + uuid.uuid4().hex
                now = iso_now()
                connection.execute("INSERT INTO scraper_contributions (id,run_id,request_id,request_hash,proposal_hash,proposal_json,state,created_at,updated_at) VALUES (?,?,?,?,?,?,'queued',?,?)",
                                   (contribution_id, run_id, request.request_id, request_hash, normalized["proposal_hash"],
                                    canonical_bytes(request.proposal.model_dump(mode="json")).decode(), now, now))
        # Return the persisted queued receipt even if the fast worker finishes first.
        result = self.get(contribution_id)
        self.worker.submit(self._prepare, contribution_id, request.proposal)
        return result

    def _prepare(self, contribution_id, proposal):
        self._update(contribution_id, state="running")
        try:
            preview = self.preview(proposal)
            self._update(contribution_id, state="ready", files_json=canonical_bytes(preview["files"]).decode(),
                         inspection_json=canonical_bytes({key: value for key, value in preview.items() if key != "files"}).decode())
        except Exception as exc:
            self._update(contribution_id, state="failed", error=f"Proposal could not be prepared ({type(exc).__name__}). Inspect the preview errors; no submission occurred.")

    def _update(self, contribution_id, **values):
        allowed = {"state", "files_json", "inspection_json", "submission_json", "error"}
        if not set(values) <= allowed:
            raise ValueError("Invalid contribution update")
        values["updated_at"] = iso_now()
        with self.db.connect() as connection:
            connection.execute("UPDATE scraper_contributions SET " + ",".join(f"{key}=?" for key in values) + " WHERE id=?", (*values.values(), contribution_id))

    def record_submission(self, contribution_id, submission: Submission):
        item = self.get(contribution_id, True)
        if item["state"] not in {"ready", "submitted"}:
            raise ContributionConflict("Prepare the proposal successfully before recording a PR")
        receipt = self.repository.verify_submission(submission, item["files"])
        if item.get("submission") and item["submission"]["pr_number"] != receipt["pr_number"]:
            raise ContributionConflict("This proposal already has a different PR; reuse its existing submission")
        self._update(contribution_id, state="submitted", submission_json=canonical_bytes(receipt).decode())
        return self.get(contribution_id)

    def download(self, contribution_id):
        item = self.get(contribution_id, True)
        if not item.get("files"):
            raise ContributionConflict("Package is not ready; poll the contribution's run")
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, value in item["files"].items():
                archive.writestr(name, canonical_bytes(value))
            archive.writestr("PR_BODY.md", item["pr_body"])
        return output.getvalue()


def pr_body(proposal, proposal_hash):
    monitor, company = proposal["monitor"], proposal["company"]
    return (f"Add or repair {company['name']} public coverage.\n\n"
            f"JobHound-Monitor: {monitor['id']}\nJobHound-Proposal: {proposal_hash}\n"
            f"Base commit: {proposal['base_commit']}\n\n"
            f"Strategy: {monitor['recipe']['strategy']}. Fixture fetched: {proposal['fixture']['fetched_at']}.\n\n"
            "Author sandbox parsing is provisional. Awaiting trusted live runtime validation and the maintainer's ownership review.\n"
            "No personal criteria, documents, schedules, credentials, or application history are included.\n"
            "Run the repository validators/build/tests; leave this PR draft until the trusted validation lane passes.\n")
