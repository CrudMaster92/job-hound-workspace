"""Host-only proposal endpoints with identical human and agent behavior."""
from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from jsonschema import ValidationError as SchemaError
from ..security import is_loopback
from .contracts import Proposal, Prepare, Submission
from .service import ContributionConflict
from .github import RepositoryUnavailable


def mount_contributions(app, service):
    def local(request: Request):
        if not is_loopback(request.client.host if request.client else None):
            raise HTTPException(403, "Public proposals are managed on the host computer; use a local agent or desktop interface.")

    router = APIRouter(prefix="/api/v1/contributions", dependencies=[Depends(local)])

    def invoke(operation, *args):
        try:
            return operation(*args)
        except KeyError as exc:
            raise HTTPException(404, "Contribution not found") from exc
        except ContributionConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except (ValueError, SchemaError) as exc:
            message = exc.message if isinstance(exc, SchemaError) else str(exc)
            raise HTTPException(422, message[:1000]) from exc
        except RepositoryUnavailable as exc:
            raise HTTPException(503, str(exc)) from exc

    @router.get("")
    def listing(offset: int = Query(0, ge=0), limit: int = Query(30, ge=1, le=100)):
        return service.list(offset, limit)

    @router.post("/preview")
    def preview(payload: Proposal):
        return invoke(service.preview, payload)

    @router.post("")
    def prepare(payload: Prepare):
        return invoke(service.prepare, payload)

    @router.get("/{contribution_id}")
    def get(contribution_id: str, include_content: bool = False, refresh: bool = False):
        return invoke(service.get, contribution_id, include_content, refresh)

    @router.post("/{contribution_id}/submission")
    def submission(contribution_id: str, payload: Submission):
        return invoke(service.record_submission, contribution_id, payload)

    @router.get("/{contribution_id}/download")
    def download(contribution_id: str):
        return Response(invoke(service.download, contribution_id), media_type="application/zip",
                        headers={"Content-Disposition": 'attachment; filename="jobhound-public-proposal.zip"', "Cache-Control": "no-store"})

    app.include_router(router)
