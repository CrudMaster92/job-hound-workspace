"""Structured, deterministic career-document drafts and renderers."""

from __future__ import annotations

import html
import io
from typing import Any, Literal

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


LayoutKey = Literal["corporate", "creative", "intro_letter"]
FitStatus = Literal["underfilled", "balanced", "overflow"]


class DraftModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ExperienceItem(DraftModel):
    job_title: str = Field(min_length=1, max_length=100)
    employer: str = Field(min_length=1, max_length=120)
    location: str = Field(default="", max_length=100)
    dates: str = Field(min_length=1, max_length=60)
    accomplishments: list[str] = Field(min_length=1, max_length=3)

    @field_validator("accomplishments")
    @classmethod
    def clean_bullets(cls, values: list[str]) -> list[str]:
        return [_clean(value, 240) for value in values]


class ResumeContent(DraftModel):
    full_name: str = Field(min_length=1, max_length=100)
    contact_line: str = Field(min_length=1, max_length=240)
    profile: str = Field(min_length=1, max_length=280)
    professional_experience: list[ExperienceItem] = Field(min_length=1, max_length=6)
    education_credentials: list[str] = Field(min_length=1, max_length=6)
    final_section_title: str | None = Field(default=None, max_length=60)
    final_section_items: list[str] = Field(default_factory=list, max_length=6)

    @field_validator("profile")
    @classmethod
    def profile_length(cls, value: str) -> str:
        value = _clean(value, 280)
        words = len(value.split())
        if words < 16 or words > 24:
            raise ValueError("resume profile must contain 16 to 24 words")
        return value

    @field_validator("education_credentials", "final_section_items")
    @classmethod
    def clean_items(cls, values: list[str]) -> list[str]:
        return [_clean(value, 220) for value in values]

    @model_validator(mode="after")
    def final_section_consistent(self):
        if bool(self.final_section_title) != bool(self.final_section_items):
            raise ValueError("final section title and items must either both be provided or both be omitted")
        return self


class IntroLetterContent(DraftModel):
    sender_name: str = Field(min_length=1, max_length=100)
    contact_line: str = Field(min_length=1, max_length=240)
    date_line: str = Field(default="", max_length=80)
    recipient_line: str = Field(default="", max_length=240)
    greeting: str = Field(default="Hello,", min_length=1, max_length=100)
    paragraphs: list[str] = Field(min_length=3, max_length=3)
    signoff: str = Field(default="Sincerely,", min_length=1, max_length=80)

    @field_validator("paragraphs")
    @classmethod
    def concise_paragraphs(cls, values: list[str]) -> list[str]:
        cleaned = [_clean(value, 700) for value in values]
        if any(len(value.split()) > 95 for value in cleaned):
            raise ValueError("intro-letter paragraphs must be concise (95 words or fewer each)")
        return cleaned


class CareerDocumentDraftContent(DraftModel):
    kind: Literal["resume", "intro_letter"]
    label: str = Field(min_length=1, max_length=120)
    layout_key: LayoutKey
    resume: ResumeContent | None = None
    intro_letter: IntroLetterContent | None = None

    @model_validator(mode="after")
    def matching_content(self):
        if self.kind == "resume":
            if self.layout_key not in {"corporate", "creative"} or not self.resume or self.intro_letter:
                raise ValueError("resume drafts require corporate or creative resume content")
        elif self.layout_key != "intro_letter" or not self.intro_letter or self.resume:
            raise ValueError("intro-letter drafts require intro_letter content")
        return self


def _clean(value: str, maximum: int) -> str:
    value = " ".join(str(value).split()).strip()
    if not value:
        raise ValueError("draft text cannot be empty")
    return value[:maximum]


def validate_content(value: dict[str, Any] | CareerDocumentDraftContent) -> CareerDocumentDraftContent:
    return value if isinstance(value, CareerDocumentDraftContent) else CareerDocumentDraftContent.model_validate(value)


def fit_status(value: CareerDocumentDraftContent) -> FitStatus:
    if value.kind == "intro_letter":
        words = sum(len(item.split()) for item in value.intro_letter.paragraphs)  # type: ignore[union-attr]
        return "underfilled" if words < 130 else "overflow" if words > 285 else "balanced"
    resume = value.resume
    assert resume
    words = len(resume.profile.split())
    words += sum(len(item.split()) for item in resume.education_credentials + resume.final_section_items)
    words += sum(
        len(role.job_title.split()) + len(role.employer.split()) + len(role.dates.split())
        + sum(len(item.split()) for item in role.accomplishments)
        for role in resume.professional_experience
    )
    return "underfilled" if words < 245 else "overflow" if words > 575 else "balanced"


def _font(run, name: str, size: float, *, bold: bool = False, color: str = "172235") -> None:
    run.font.name = name
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)


def _shade_paragraph(paragraph, fill: str, accent: str) -> None:
    properties = paragraph._p.get_or_add_pPr()
    shading = OxmlElement("w:shd"); shading.set(qn("w:fill"), fill); properties.append(shading)
    borders = OxmlElement("w:pBdr")
    start = OxmlElement("w:start")
    for key, value in (("val", "single"), ("sz", "20"), ("space", "8"), ("color", accent)):
        start.set(qn(f"w:{key}"), value)
    borders.append(start); properties.append(borders)


def _section_heading(doc: Document, text: str, *, creative: bool, density: FitStatus) -> None:
    paragraph = doc.add_paragraph()
    paragraph.style = doc.styles["Heading 1"]
    paragraph.paragraph_format.space_before = Pt(7 if density != "underfilled" else 10)
    paragraph.paragraph_format.space_after = Pt(3 if density != "underfilled" else 5)
    run = paragraph.add_run(text.upper())
    _font(run, "Aptos Display", 9.5, bold=True, color="147D80" if creative else "175EA8")


def _configure_document(doc: Document, *, creative: bool, density: FitStatus) -> None:
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    margin = 0.52 if creative else 0.62
    section.top_margin = section.bottom_margin = Inches(margin)
    section.left_margin = section.right_margin = Inches(0.68 if creative else 0.72)
    normal = doc.styles["Normal"]
    normal.font.name = "Aptos"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    normal.font.size = Pt(9.2 if density == "overflow" else 9.7)
    normal.font.color.rgb = RGBColor.from_string("243142")
    normal.paragraph_format.space_after = Pt(2.2 if density == "overflow" else 3.2)
    normal.paragraph_format.line_spacing = 1.0 if density == "overflow" else 1.04


def render_docx(value: dict[str, Any] | CareerDocumentDraftContent) -> bytes:
    draft = validate_content(value)
    density = fit_status(draft)
    doc = Document()
    creative = draft.layout_key == "creative"
    _configure_document(doc, creative=creative, density=density)
    if draft.kind == "resume":
        _render_resume(doc, draft.resume, creative=creative, density=density)  # type: ignore[arg-type]
    else:
        _render_letter(doc, draft.intro_letter, density=density)  # type: ignore[arg-type]
    doc.core_properties.author = "JobHound"
    doc.core_properties.title = draft.label
    output = io.BytesIO(); doc.save(output)
    return output.getvalue()


def _render_resume(doc: Document, resume: ResumeContent, *, creative: bool, density: FitStatus) -> None:
    if creative:
        name = doc.add_paragraph(); name.paragraph_format.space_after = Pt(5)
        name.paragraph_format.left_indent = Inches(0.08); name.paragraph_format.right_indent = Inches(0.08)
        _shade_paragraph(name, "183B56", "18A3A6")
        _font(name.add_run(resume.full_name), "Aptos Display", 23, bold=True, color="FFFFFF")
        name.add_run().add_break()
        _font(name.add_run(resume.contact_line), "Aptos", 8.8, color="C9EEF0")
    else:
        name = doc.add_paragraph(); name.alignment = WD_ALIGN_PARAGRAPH.CENTER; name.paragraph_format.space_after = Pt(2)
        _font(name.add_run(resume.full_name), "Aptos Display", 22, bold=True, color="102A43")
        contact = doc.add_paragraph(); contact.alignment = WD_ALIGN_PARAGRAPH.CENTER; contact.paragraph_format.space_after = Pt(6)
        _font(contact.add_run(resume.contact_line), "Aptos", 8.8, color="526579")
    _section_heading(doc, "Profile", creative=creative, density=density)
    doc.add_paragraph(resume.profile)
    _section_heading(doc, "Professional Experience", creative=creative, density=density)
    for role in resume.professional_experience:
        heading = doc.add_paragraph(); heading.paragraph_format.space_before = Pt(3 if density == "overflow" else 4.5); heading.paragraph_format.space_after = Pt(1)
        _font(heading.add_run(role.job_title), "Aptos", 9.5, bold=True, color="183B56" if creative else "172235")
        _font(heading.add_run(f"  |  {role.employer}"), "Aptos", 9.2, bold=True, color="147D80" if creative else "175EA8")
        details = " · ".join(item for item in (role.location, role.dates) if item)
        if details:
            _font(heading.add_run(f"    {details}"), "Aptos", 8.2, color="617184")
        for accomplishment in role.accomplishments:
            paragraph = doc.add_paragraph(style="List Bullet")
            paragraph.paragraph_format.left_indent = Inches(0.18); paragraph.paragraph_format.first_line_indent = Inches(-0.14)
            paragraph.paragraph_format.space_after = Pt(1.2 if density == "overflow" else 2.2)
            paragraph.add_run(accomplishment)
    _section_heading(doc, "Education & Credentials", creative=creative, density=density)
    for item in resume.education_credentials:
        doc.add_paragraph(item)
    if resume.final_section_title:
        _section_heading(doc, resume.final_section_title, creative=creative, density=density)
        for item in resume.final_section_items:
            doc.add_paragraph(item, style="List Bullet")


def _render_letter(doc: Document, letter: IntroLetterContent, *, density: FitStatus) -> None:
    top = doc.add_paragraph(); top.paragraph_format.space_after = Pt(2)
    _font(top.add_run(letter.sender_name), "Aptos Display", 21, bold=True, color="102A43")
    contact = doc.add_paragraph(); contact.paragraph_format.space_after = Pt(18 if density == "underfilled" else 12)
    _font(contact.add_run(letter.contact_line), "Aptos", 9, color="526579")
    for line in (letter.date_line, letter.recipient_line):
        if line:
            paragraph = doc.add_paragraph(line); paragraph.paragraph_format.space_after = Pt(5)
    greeting = doc.add_paragraph(letter.greeting); greeting.paragraph_format.space_before = Pt(10); greeting.paragraph_format.space_after = Pt(10)
    for text in letter.paragraphs:
        paragraph = doc.add_paragraph(text)
        paragraph.paragraph_format.space_after = Pt(14 if density == "underfilled" else 10)
        paragraph.paragraph_format.line_spacing = 1.12
    close = doc.add_paragraph(); close.paragraph_format.space_before = Pt(12)
    close.add_run(f"{letter.signoff}\n{letter.sender_name}")


def render_html(value: dict[str, Any] | CareerDocumentDraftContent) -> str:
    draft = validate_content(value)
    status = fit_status(draft)
    esc = lambda text: html.escape(str(text))
    if draft.kind == "resume":
        resume = draft.resume; assert resume
        roles = "".join(
            f'<section class="role"><div class="role-head"><b>{esc(role.job_title)}</b><strong>{esc(role.employer)}</strong><span>{esc(" · ".join(filter(None, [role.location, role.dates])))}</span></div>'
            + "<ul>" + "".join(f"<li>{esc(item)}</li>" for item in role.accomplishments) + "</ul></section>"
            for role in resume.professional_experience
        )
        final = ""
        if resume.final_section_title:
            final = f'<h2>{esc(resume.final_section_title)}</h2><ul>' + "".join(f"<li>{esc(item)}</li>" for item in resume.final_section_items) + "</ul>"
        body = f'''<header><h1>{esc(resume.full_name)}</h1><p>{esc(resume.contact_line)}</p></header>
<h2>Profile</h2><p>{esc(resume.profile)}</p><h2>Professional Experience</h2>{roles}
<h2>Education &amp; Credentials</h2>{''.join(f'<p>{esc(item)}</p>' for item in resume.education_credentials)}{final}'''
    else:
        letter = draft.intro_letter; assert letter
        body = f'''<header><h1>{esc(letter.sender_name)}</h1><p>{esc(letter.contact_line)}</p></header>
<div class="letter-meta">{esc(letter.date_line)}<br>{esc(letter.recipient_line)}</div><p>{esc(letter.greeting)}</p>
{''.join(f'<p class="letter-paragraph">{esc(item)}</p>' for item in letter.paragraphs)}
<p class="signoff">{esc(letter.signoff)}<br>{esc(letter.sender_name)}</p>'''
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><style>
*{{box-sizing:border-box}}html{{background:#dce3eb}}body{{width:8.5in;min-height:11in;margin:20px auto;padding:.62in .72in;background:#fff;color:#243142;font-family:Aptos,Arial,sans-serif;font-size:9.7pt;line-height:1.2;box-shadow:0 10px 35px #26384a33}}header{{text-align:{'left' if draft.layout_key == 'creative' else 'center'};margin-bottom:12px;{'background:#183b56;color:white;padding:18px 22px;margin:-.12in -.12in 14px;border-left:7px solid #18a3a6' if draft.layout_key == 'creative' else ''}}}h1{{margin:0 0 4px;font-size:23pt;line-height:1}}header p{{margin:0;color:{'#c9eef0' if draft.layout_key == 'creative' else '#526579'};font-size:8.8pt}}h2{{margin:10px 0 4px;color:{'#147d80' if draft.layout_key == 'creative' else '#175ea8'};font-size:9.5pt;letter-spacing:.06em;text-transform:uppercase;border-bottom:1px solid #d9e3ed;padding-bottom:2px}}p{{margin:0 0 5px}}.role{{margin:0 0 5px}}.role-head{{display:flex;align-items:baseline;gap:6px;flex-wrap:wrap}}.role-head strong{{color:{'#147d80' if draft.layout_key == 'creative' else '#175ea8'}}}.role-head span{{margin-left:auto;color:#617184;font-size:8.2pt}}ul{{margin:2px 0 5px;padding-left:18px}}li{{margin:0 0 2px}}.letter-meta{{margin:22px 0 16px;line-height:1.5}}.letter-paragraph{{margin-bottom:12px;line-height:1.45}}.signoff{{margin-top:22px}}@media(max-width:760px){{html{{background:white}}body{{width:100%;min-height:auto;margin:0;padding:24px;box-shadow:none}}}}@media print{{html{{background:white}}body{{margin:0;box-shadow:none}}}}
</style></head><body data-fit="{status}" class="{draft.layout_key}">{body}</body></html>'''
