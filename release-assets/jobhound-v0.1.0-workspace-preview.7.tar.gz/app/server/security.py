"""Trusted-loopback and pairing-code authentication for LAN clients."""

from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from ipaddress import ip_address
from typing import TYPE_CHECKING

from fastapi import HTTPException, Request, Response, status

if TYPE_CHECKING:
    from .db import Database


SESSION_COOKIE = "jobhound_session"
CSRF_COOKIE = "jobhound_csrf"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def is_loopback(host: str | None) -> bool:
    if not host:
        return False
    if host.lower() == "localhost":
        return True
    try:
        return ip_address(host.split("%", 1)[0]).is_loopback
    except ValueError:
        return False


@dataclass
class PairingCode:
    value: str
    expires_at: datetime


class SecurityManager:
    def __init__(self, db: "Database", pairing_ttl_minutes: int = 10) -> None:
        self.db = db
        self.pairing_ttl_minutes = pairing_ttl_minutes
        self._pairing = self.rotate_pairing_code()

    @property
    def pairing_code(self) -> str:
        if self._pairing.expires_at <= utcnow():
            self._pairing = self.rotate_pairing_code()
        return self._pairing.value

    def rotate_pairing_code(self) -> PairingCode:
        code = f"{secrets.randbelow(1_000_000):06d}"
        self._pairing = PairingCode(code, utcnow() + timedelta(minutes=self.pairing_ttl_minutes))
        return self._pairing

    @staticmethod
    def _hash(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def pair(self, code: str, response: Response) -> str:
        if self._pairing.expires_at <= utcnow() or not secrets.compare_digest(code, self._pairing.value):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired pairing code")
        token = secrets.token_urlsafe(32)
        csrf = secrets.token_urlsafe(24)
        self.db.create_session(self._hash(token), self._hash(csrf), utcnow() + timedelta(days=30))
        response.set_cookie(SESSION_COOKIE, token, httponly=True, samesite="strict", secure=False, max_age=30 * 86400)
        response.set_cookie(CSRF_COOKIE, csrf, httponly=False, samesite="strict", secure=False, max_age=30 * 86400)
        self.rotate_pairing_code()
        return csrf

    def authorize(self, request: Request) -> bool:
        if is_loopback(request.client.host if request.client else None):
            return True
        token = request.cookies.get(SESSION_COOKIE)
        csrf_cookie = request.cookies.get(CSRF_COOKIE)
        if not token or not csrf_cookie or not self.db.session_valid(self._hash(token), self._hash(csrf_cookie)):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Pair this device first")
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            submitted = request.headers.get("x-csrf-token", "")
            if not secrets.compare_digest(csrf_cookie, submitted):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Missing or invalid CSRF token")
        return True
