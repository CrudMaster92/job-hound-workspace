"""Canonical application-funnel definitions and aggregate helpers."""

from __future__ import annotations

from typing import Final


APPLICATION_MILESTONES: Final[tuple[str, ...]] = (
    "applied",
    "recruiter_screen",
    "interview",
    "later_stage_interview",
    "offer",
)

APPLICATION_OUTCOMES: Final[tuple[str, ...]] = (
    "accepted",
    "declined",
    "rejected",
    "withdrawn",
)

MILESTONE_LABELS: Final[dict[str, str]] = {
    "applied": "Applied",
    "recruiter_screen": "Recruiter Screen",
    "interview": "Interview",
    "later_stage_interview": "Later-stage Interview",
    "offer": "Offer",
}

OUTCOME_LABELS: Final[dict[str, str]] = {
    "accepted": "Accepted",
    "declined": "Declined",
    "rejected": "Rejected",
    "withdrawn": "Withdrawn",
}


def milestone_rank(value: str | None) -> int:
    """Return a stable one-based funnel rank, or zero outside the funnel."""
    try:
        return APPLICATION_MILESTONES.index(value or "") + 1
    except ValueError:
        return 0


def legacy_stage(milestone: str | None, outcome: str | None) -> str | None:
    """Render the compatibility stage exposed to older clients."""
    if outcome:
        return OUTCOME_LABELS.get(outcome, outcome.replace("_", " ").title())
    if milestone:
        return MILESTONE_LABELS.get(milestone, milestone.replace("_", " ").title())
    return None
