"""Host-only, thread-scoped files used as bounded Chat context."""

from __future__ import annotations

import hashlib
import os
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import RLock
from typing import Any

from .db import Database
from .document_store import DocumentError, MAX_FILE_BYTES, SUPPORTED, _clean_filename, _extract


MAX_ATTACHMENTS_PER_TURN = 5
MAX_ATTACHMENT_CHARS = 30_000
MAX_TOTAL_CHARS = 60_000


class ChatAttachmentStore:
    def __init__(self, database: Database, root: str | Path | None = None) -> None:
        self.database = database
        self.root = Path(root or (Path(database.path).resolve().parent / "chat-attachments")).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()

    def _path(self, name: str) -> Path:
        path = (self.root / name).resolve()
        if path.parent != self.root:
            raise DocumentError("Invalid managed attachment path")
        return path

    @staticmethod
    def public(value: dict[str, Any]) -> dict[str, Any]:
        return {key: item for key, item in value.items() if key not in {"stored_filename", "extracted_text"}}

    def upload(self, *, thread_id: int, original_filename: str, content: bytes) -> dict[str, Any]:
        if not content:
            raise DocumentError("Attachment file is empty")
        if len(content) > MAX_FILE_BYTES:
            raise DocumentError("Attachments are limited to 10 MiB")
        filename = _clean_filename(original_filename)
        extension = Path(filename).suffix.casefold()
        if extension not in SUPPORTED:
            raise DocumentError("Supported attachment formats are PDF, DOCX, and TXT")
        text, status = _extract(extension, content)
        stored = f"{uuid.uuid4().hex}{extension}"
        path = self._path(stored)
        with self._lock:
            fd, temporary_name = tempfile.mkstemp(prefix=".upload-", dir=self.root)
            try:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary_name, path)
                try:
                    value = self.database.create_chat_attachment({
                        "thread_id": thread_id, "original_filename": filename,
                        "stored_filename": stored, "mime_type": SUPPORTED[extension],
                        "extension": extension, "size_bytes": len(content),
                        "sha256": hashlib.sha256(content).hexdigest(), "extracted_text": text,
                        "extraction_status": status,
                        "expires_at": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
                    })
                except Exception:
                    path.unlink(missing_ok=True)
                    raise
            finally:
                Path(temporary_name).unlink(missing_ok=True)
        return self.public(value)

    def from_document(self, *, thread_id: int, document: dict[str, Any]) -> dict[str, Any]:
        value = self.database.create_chat_attachment({
            "thread_id": thread_id, "source_document_id": int(document["id"]),
            "original_filename": document["original_filename"], "stored_filename": None,
            "mime_type": document["mime_type"], "extension": document["extension"],
            "size_bytes": int(document["size_bytes"]), "sha256": document["sha256"],
            "extracted_text": document.get("extracted_text", ""),
            "extraction_status": document["extraction_status"],
            "expires_at": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
        })
        return self.public(value)

    def context(self, thread_id: int, ids: list[int]) -> list[dict[str, Any]]:
        if len(ids) > MAX_ATTACHMENTS_PER_TURN:
            raise DocumentError(f"A chat turn accepts at most {MAX_ATTACHMENTS_PER_TURN} attachments")
        if len(set(ids)) != len(ids):
            raise DocumentError("Attachment IDs must be unique")
        total = 0
        results: list[dict[str, Any]] = []
        for attachment_id in ids:
            value = self.database.get_chat_attachment(attachment_id)
            if not value or int(value["thread_id"]) != thread_id:
                raise DocumentError(f"Attachment {attachment_id} is not available in this chat")
            if value.get("source_document_id") and not self.database.get_document(int(value["source_document_id"])):
                raise DocumentError(f"The library document for attachment {attachment_id} was deleted")
            if value.get("source_interview_id"):
                with self.database.connect() as connection:
                    exists = connection.execute("SELECT 1 FROM interviews WHERE id=?", (value["source_interview_id"],)).fetchone()
                if not exists:
                    raise DocumentError("The interview for this attachment was deleted")
            if value["extraction_status"] == "failed":
                raise DocumentError(f"Text extraction failed for {value['original_filename']}")
            text = str(value.get("extracted_text") or "")
            remaining = max(0, MAX_TOTAL_CHARS - total)
            bounded = text[:min(MAX_ATTACHMENT_CHARS, remaining)]
            results.append({
                "id": int(value["id"]), "filename": value["original_filename"],
                "source_document_id": value.get("source_document_id"),
                "source_interview_id": value.get("source_interview_id"),
                "extraction_status": value["extraction_status"], "text": bounded,
                "text_truncated": len(bounded) < len(text),
            })
            total += len(bounded)
        return results

    def delete(self, attachment_id: int) -> bool:
        value = self.database.delete_chat_attachment(attachment_id)
        if not value:
            return False
        if value.get("stored_filename"):
            self._path(value["stored_filename"]).unlink(missing_ok=True)
        return True

