"""Bounded, cached client for JobHound's curated public preset catalog."""

from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import socket
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urljoin, urlsplit

import httpx

from .external_http import external_trust_env, external_client_kwargs
from . import preset_snapshot

DEFAULT_CATALOG_URL = "https://crudmaster92.github.io/job-hound-presets/api/v1/catalog.json"
MAX_CATALOG_BYTES = 2_000_000
MAX_ARTIFACT_BYTES = 5_000_000


class PresetCatalogError(RuntimeError):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _validate_public_https(url: str) -> None:
    parsed = urlsplit(url)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or not host or parsed.username or parsed.password:
        raise PresetCatalogError("Preset catalog requests require a credential-free HTTPS URL")
    try:
        addresses = [ipaddress.ip_address(host)]
    except ValueError:
        try:
            addresses = list({
                ipaddress.ip_address(item[4][0])
                for item in socket.getaddrinfo(host, parsed.port or 443)
            })
        except (OSError, ValueError) as exc:
            raise PresetCatalogError("Preset catalog host could not be resolved") from exc
    if not addresses or any(not address.is_global for address in addresses):
        raise PresetCatalogError("Preset catalog host must resolve only to public internet addresses")


class PresetCatalogClient:
    def __init__(self, data_root: Path, *, catalog_url: str | None = None, ttl_hours: int = 24, snapshot_directory: Path | None = None) -> None:
        self.catalog_url = catalog_url or os.getenv("JOBHOUND_PRESET_CATALOG_URL", DEFAULT_CATALOG_URL)
        parsed = urlsplit(self.catalog_url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Preset catalog must use a credential-free HTTPS URL")
        self.origin = f"{parsed.scheme}://{parsed.netloc}"
        self.base_url = self.catalog_url.rsplit("/", 1)[0] + "/"
        self.cache_root = data_root / "preset-catalog"
        self.cache_root.mkdir(parents=True, exist_ok=True)
        self.catalog_path = self.cache_root / "catalog.json"
        self.meta_path = self.cache_root / "metadata.json"
        self.ttl = timedelta(hours=max(1, ttl_hours))
        self.snapshot_directory = snapshot_directory or Path(__file__).with_name("preset_snapshot")
        self._snapshot_active = False

    @staticmethod
    def _decode(response: httpx.Response, limit: int) -> dict:
        declared = int(response.headers.get("content-length", "0") or 0)
        if declared > limit or len(response.content) > limit:
            raise PresetCatalogError("Preset catalog response exceeded its size limit")
        try:
            value = response.json()
        except ValueError as exc:
            raise PresetCatalogError("Preset catalog returned invalid JSON") from exc
        if not isinstance(value, dict):
            raise PresetCatalogError("Preset catalog response must be an object")
        return value

    def _safe_url(self, relative_path: str) -> str:
        if not relative_path or relative_path.startswith(("/", "\\")) or ".." in relative_path.split("/"):
            raise PresetCatalogError("Preset catalog contained an unsafe artifact path")
        result = urljoin(self.base_url, relative_path)
        parsed = urlsplit(result)
        if f"{parsed.scheme}://{parsed.netloc}" != self.origin:
            raise PresetCatalogError("Preset artifact escaped the curated catalog origin")
        return result

    def _cached(self) -> dict | None:
        if not self.catalog_path.is_file():
            return None
        try:
            value = json.loads(self.catalog_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return value if isinstance(value, dict) else None

    def _fresh(self) -> bool:
        try:
            meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
            checked = datetime.fromisoformat(str(meta["checked_at"]).replace("Z", "+00:00"))
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            return False
        return _now() - checked < self.ttl

    def refresh(self, *, force: bool = False) -> dict:
        self._snapshot_active = False
        cached = self._cached()
        if cached and not force and self._fresh():
            return {**cached, "catalog_status": "cached", "catalog_error": None}
        headers: dict[str, str] = {"Accept": "application/json", "User-Agent": "JobHound/1.0"}
        try:
            _validate_public_https(self.catalog_url)
            if self.meta_path.is_file():
                meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
                if meta.get("etag"):
                    headers["If-None-Match"] = str(meta["etag"])
            with httpx.Client(timeout=8, follow_redirects=False, **external_client_kwargs()) as client:
                response = client.get(self.catalog_url, headers=headers)
            if response.status_code == 304 and cached:
                self._write_meta(response.headers.get("etag"))
                return {**cached, "catalog_status": "current", "catalog_error": None}
            response.raise_for_status()
            value = self._decode(response, MAX_CATALOG_BYTES)
            if value.get("format") != "jobhound-preset-catalog" or value.get("catalog_version") != 3:
                raise PresetCatalogError("Unsupported preset catalog version")
            if not isinstance(value.get("collections"), list) or not isinstance(value.get("search_pages"), list):
                raise PresetCatalogError("Preset catalog is missing collections or search pages")
            self._atomic_json(self.catalog_path, value)
            self._write_meta(response.headers.get("etag"))
            return {**value, "catalog_status": "current", "catalog_error": None}
        except (httpx.HTTPError, OSError, ValueError, PresetCatalogError) as exc:
            if cached:
                return {**cached, "catalog_status": "stale", "catalog_error": str(exc)}
            try:
                snapshot, meta = preset_snapshot.catalog(self.snapshot_directory, self.catalog_url)
            except (OSError, ValueError, TypeError, KeyError):
                raise PresetCatalogError(str(exc)) from exc
            self._snapshot_active = True
            return {**snapshot, "catalog_status": "stale", "catalog_error": str(exc),
                    "catalog_source": "release_snapshot", "snapshot_captured_at": meta.get("captured_at")}

    @staticmethod
    def _hash(value: dict) -> str:
        return preset_snapshot.canonical_hash(value)

    def _artifact(self, reference: dict, *, force: bool = False) -> dict:
        relative = str(reference.get("path") or "")
        expected = str(reference.get("sha256") or "")
        if len(expected) != 64:
            raise PresetCatalogError("Preset catalog artifact has no canonical hash")
        self._safe_url(relative)
        if self._snapshot_active:
            try:
                return preset_snapshot.artifact(self.snapshot_directory, relative, expected)
            except (OSError, ValueError, TypeError) as exc:
                raise PresetCatalogError("Packaged preset artifact missing or invalid; update the workspace release") from exc
        safe_name = hashlib.sha256(relative.encode()).hexdigest() + ".json"
        cache_path = self.cache_root / "artifacts" / safe_name
        cached = None
        if cache_path.is_file():
            try:
                candidate = json.loads(cache_path.read_text(encoding="utf-8"))
                if isinstance(candidate, dict) and self._hash(candidate) == expected:
                    cached = candidate
            except (OSError, json.JSONDecodeError):
                pass
        if cached is not None and not force:
            return cached
        try:
            artifact_url = self._safe_url(relative)
            _validate_public_https(artifact_url)
            with httpx.Client(timeout=10, follow_redirects=False, **external_client_kwargs()) as client:
                response = client.get(artifact_url, headers={"Accept": "application/json", "User-Agent": "JobHound/1.0"})
            response.raise_for_status()
            value = self._decode(response, MAX_ARTIFACT_BYTES)
            if self._hash(value) != expected:
                raise PresetCatalogError("Preset artifact failed its catalog hash check")
            self._atomic_json(cache_path, value)
            return value
        except (httpx.HTTPError, OSError, ValueError, PresetCatalogError) as live_error:
            if cached is not None:
                return cached
            try:
                preset_snapshot.catalog(self.snapshot_directory, self.catalog_url)
                return preset_snapshot.artifact(self.snapshot_directory, relative, expected)
            except (OSError, ValueError, TypeError):
                raise live_error

    def get_search_companies(self, *, force: bool = False) -> list[dict]:
        catalog = self.refresh(force=force)
        return [company for reference in catalog["search_pages"]
                for company in self._artifact(reference, force=force).get("companies", [])]

    def get_collection(self, collection_id: str, *, force: bool = False) -> dict:
        catalog = self.refresh(force=force)
        entry = next((item for item in catalog["collections"] if item.get("id") == collection_id), None)
        if not entry:
            raise KeyError(collection_id)
        return self._artifact(entry, force=force)

    def get_collection_members(self, collection_id: str, *, force: bool = False) -> list[dict]:
        detail = self.get_collection(collection_id, force=force)
        return [company for reference in detail.get("member_pages", [])
                for company in self._artifact(reference, force=force).get("companies", [])]

    def get_company(self, reference: dict, *, force: bool = False) -> dict:
        return self._artifact(reference, force=force)

    def get_monitor(self, reference: dict, *, force: bool = False) -> dict:
        return self._artifact(reference, force=force)

    def get_bundle(self, collection_id: str, *, force: bool = False) -> dict:
        catalog = self.refresh(force=force)
        entry = next((item for item in catalog["collections"] if item.get("id") == collection_id), None)
        if not entry:
            raise KeyError(collection_id)
        return self._artifact({"path": entry.get("bundle_path"), "sha256": entry.get("bundle_sha256")}, force=force)

    def _write_meta(self, etag: str | None) -> None:
        self._atomic_json(self.meta_path, {"checked_at": _now().isoformat(), "etag": etag})

    @staticmethod
    def _atomic_json(path: Path, value: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)
