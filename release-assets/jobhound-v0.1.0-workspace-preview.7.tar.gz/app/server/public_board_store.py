"""Additive references into the existing saved-role and application tables."""
import hashlib
import json
from .db import iso_now


SCHEMA = """
CREATE TABLE IF NOT EXISTS public_board_companies (
 public_company_id TEXT PRIMARY KEY,
 company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS public_board_jobs (
 public_job_id TEXT PRIMARY KEY,
 job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
 snapshot_json TEXT NOT NULL,
 verified INTEGER NOT NULL DEFAULT 1
);
"""


class PublicBoardStore:
    def __init__(self, db):
        self.db = db
        with db.connect() as connection:
            connection.executescript(SCHEMA)

    def rows(self):
        with self.db.connect() as connection:
            return [dict(row) for row in connection.execute(
                "SELECT p.*,COALESCE(t.saved,0) saved FROM public_board_jobs p "
                "LEFT JOIN job_tracking t ON t.job_id=p.job_id")]

    def save(self, job, saved=True, *, verified=True, actor_type="human"):
        now = iso_now()
        snapshot = json.dumps(job, ensure_ascii=False, sort_keys=True)
        with self.db.connect() as connection:
            row = connection.execute("SELECT job_id FROM public_board_jobs WHERE public_job_id=?", (job["id"],)).fetchone()
            if row:
                local_id = int(row["job_id"])
            else:
                # Exact catalog-company and source identity only; titles are never an identity.
                row = connection.execute(
                    "SELECT j.id FROM jobs j JOIN company_catalog_sources s ON s.company_id=j.company_id "
                    "WHERE s.catalog_company_id=? AND (j.canonical_url=? OR j.url=?) "
                    "ORDER BY j.id LIMIT 1", (job["company_id"], job["source_url"], job["source_url"])).fetchone()
                if row:
                    local_id = int(row["id"])
                else:
                    company = connection.execute("SELECT company_id FROM public_board_companies WHERE public_company_id=?", (job["company_id"],)).fetchone()
                    if company:
                        company_id = int(company["company_id"])
                    else:
                        result = connection.execute(
                            "INSERT INTO companies(name,careers_url,kind,state,schedule_kind,criteria_json,created_at,updated_at) "
                            "VALUES(?,'','public','manual','manual','{}',?,?)", (job["company_name"], now, now))
                        company_id = int(result.lastrowid)
                        connection.execute("INSERT INTO public_board_companies VALUES(?,?)", (job["company_id"], company_id))
                    identity = hashlib.sha256(("public|" + job["id"]).encode()).hexdigest()
                    result = connection.execute(
                        "INSERT INTO jobs(company_id,source_job_id,stable_key,title,location,remote_mode,employment_type,posted_date,"
                        "description,salary_min,salary_max,salary_currency,salary_period,url,canonical_url,source,origin,content_hash,"
                        "is_active,first_seen_at,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'public-board','public',?,?,?,?)",
                        (company_id, job.get("source_job_id"), identity, job["title"], job.get("location") or "",
                         job.get("work_mode") or "unknown", job.get("employment_type"), job.get("posted_at"), job.get("description") or "",
                         job.get("salary_min"), job.get("salary_max"), job.get("salary_currency"), job.get("salary_period"),
                         job["source_url"], job["source_url"], hashlib.sha256(snapshot.encode()).hexdigest(),
                         int(job.get("status") == "active"), job["first_seen_at"], job["last_seen_at"]))
                    local_id = int(result.lastrowid)
                    connection.execute("INSERT INTO job_matches(job_id,criteria_version,is_match,match_reasons_json,unread,dismissed) VALUES(?,1,0,'[]',0,0)", (local_id,))
                connection.execute("INSERT INTO public_board_jobs VALUES(?,?,?,?)", (job["id"], local_id, snapshot, int(verified)))
            connection.execute("UPDATE public_board_jobs SET snapshot_json=?,verified=? WHERE public_job_id=?", (snapshot, int(verified), job["id"]))
        # Keep the same activity and saved-role behavior used by the existing UI and agents.
        self.db.update_job_tracking(local_id, saved=saved, actor_type=actor_type)
        return {**job, "saved": saved, "local_job_id": local_id, "verified": verified}
