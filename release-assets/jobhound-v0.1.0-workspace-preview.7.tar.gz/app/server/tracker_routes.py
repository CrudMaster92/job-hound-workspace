"""Tracker workspace HTTP routes. Global app authorization applies to every route."""
from fastapi import APIRouter
from .tracker_contracts import FavouriteRequest, BatchRequest, MonitorStateRequest, MonitorDeleteRequest
from .tracker_management import TrackerService

def mount_trackers(app, db, scheduler):
    service = TrackerService(db, scheduler)
    app.state.trackers = service
    router = APIRouter(prefix="/api/v1/trackers", tags=["trackers"])

    @router.get("/activity")
    def activity():
        return service.snapshot()

    @router.get("/favourites")
    def favourites():
        return service.favourites()

    @router.put("/favourites")
    def favourite(payload: FavouriteRequest):
        return service.favourite(payload)

    @router.post("/batches", status_code=202)
    def start_batch(payload: BatchRequest):
        from .capabilities import require_local_scrapers
        require_local_scrapers()
        return service.start_batch(payload)

    @router.get("/batches/{batch_id}")
    def batch(batch_id: int):
        return service.batch(batch_id)

    @router.get("/{company_id}/removal-preview")
    def removal_preview(company_id: int):
        return service.removal_preview(company_id)

    @router.post("/{company_id}/state")
    def state(company_id: int, payload: MonitorStateRequest):
        return service.set_state(company_id, payload.action)

    @router.post("/{company_id}/delete")
    def delete(company_id: int, payload: MonitorDeleteRequest):
        return service.delete(company_id, payload)

    app.include_router(router)
