"""Private host-notification preferences reuse the canonical board contract."""
from datetime import datetime
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import AwareDatetime, Field, field_validator, model_validator
from .public_board_contracts import Contract, BoardQuery


class DailyNotification(Contract):
    enabled: bool = False
    human_requested: bool = False
    local_time: str = Field(default="09:00", pattern=r"^(?:[01][0-9]|2[0-3]):[0-5][0-9]$")
    delivery: Literal["message", "artifact"] = "message"
    host_schedule_id: str | None = Field(default=None, max_length=300)

    @model_validator(mode="after")
    def approved(self):
        if self.enabled and (not self.human_requested or not self.host_schedule_id):
            raise ValueError("Enable only after a human-requested host reminder was actually created")
        return self


class DeliveryCheckpoint(Contract):
    feed_generation: str | None = Field(default=None, max_length=100)
    last_delivery_at: AwareDatetime | None = None
    sent_job_ids: list[str] = Field(default_factory=list, max_length=10_000)


class AgentSearchPreferences(Contract):
    format: Literal["jobhound-agent-search"] = "jobhound-agent-search"
    version: Literal[1] = 1
    query: BoardQuery
    timezone: str = Field(default="UTC", max_length=100)
    daily_notification: DailyNotification = Field(default_factory=DailyNotification)
    checkpoint: DeliveryCheckpoint = Field(default_factory=DeliveryCheckpoint)

    @field_validator("timezone")
    @classmethod
    def supported_timezone(cls, value):
        try:
            ZoneInfo(value)
        except (ValueError, KeyError) as exc:
            raise ValueError("Use a supported IANA timezone") from exc
        return value
