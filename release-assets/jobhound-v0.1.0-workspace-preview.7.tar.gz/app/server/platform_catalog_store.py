"""CSV-backed catalog of external platforms where candidates can be discovered."""

from __future__ import annotations

import csv
import os
import re
import tempfile
import unicodedata
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


FIELDS = (
    "id", "name", "home_url", "profile_url", "description", "industry_keywords",
    "location_keywords", "countries", "regions", "work_types", "discovery_type",
    "visibility_scheme", "default_tracked", "source_url",
)
LIST_FIELDS = {"industry_keywords", "location_keywords", "countries", "regions", "work_types"}


def _terms(value: str | list[str] | None) -> list[str]:
    if isinstance(value, list):
        values = value
    else:
        values = str(value or "").split("|")
    return [item.strip() for item in values if item and item.strip()]


def _text(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value.casefold())
    return " ".join("".join(char for char in normalized if not unicodedata.combining(char)).split())


def _slug(value: str) -> str:
    result = re.sub(r"[^a-z0-9]+", "-", _text(value)).strip("-")
    return result[:64]


class PlatformCatalog:
    def __init__(self, custom_directory: str | Path) -> None:
        self.builtin_directory = Path(__file__).with_name("platform_catalog")
        self.custom_directory = Path(custom_directory)
        self.custom_path = self.custom_directory / "custom.csv"

    def _validate(self, raw: dict[str, Any]) -> dict[str, Any]:
        platform_id = str(raw.get("id") or "").strip()
        name = str(raw.get("name") or "").strip()
        if not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?", platform_id):
            raise ValueError("id must be a lowercase slug of 1 to 64 characters")
        if not name or len(name) > 100:
            raise ValueError("name is required and must be at most 100 characters")
        urls: dict[str, str] = {}
        for field in ("home_url", "profile_url", "source_url"):
            value = str(raw.get(field) or "").strip()
            if field == "home_url" and not value:
                raise ValueError("home_url is required")
            if value:
                parsed = urlparse(value)
                if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                    raise ValueError(f"{field} must be an HTTP or HTTPS URL")
            urls[field] = value
        countries = [item.upper() for item in _terms(raw.get("countries"))]
        if not countries or any(
            item != "GLOBAL" and not re.fullmatch(r"[A-Z]{2}", item) for item in countries
        ):
            raise ValueError("countries must contain GLOBAL or ISO two-letter country codes")
        regions = [item.upper() for item in _terms(raw.get("regions"))]
        if any(not re.fullmatch(r"[A-Z]{2}-[A-Z0-9]{1,3}", item) for item in regions):
            raise ValueError("regions must contain ISO subdivision codes such as CA-QC")
        if any(item.split("-", 1)[0] not in countries for item in regions) and "GLOBAL" not in countries:
            raise ValueError("each region's country must also appear in countries")
        scheme = str(raw.get("visibility_scheme") or "binary").strip().casefold()
        if scheme not in {"binary", "linkedin"}:
            raise ValueError("visibility_scheme must be binary or linkedin")
        return {
            "id": platform_id,
            "name": name,
            **urls,
            "description": str(raw.get("description") or "").strip()[:500],
            "industry_keywords": _terms(raw.get("industry_keywords")),
            "location_keywords": _terms(raw.get("location_keywords")),
            "countries": countries,
            "regions": regions,
            "work_types": _terms(raw.get("work_types")),
            "discovery_type": str(raw.get("discovery_type") or "recruiter database").strip()[:80],
            "visibility_scheme": scheme,
            "default_tracked": str(raw.get("default_tracked") or "false").strip().casefold()
            in {"1", "true", "yes"},
        }

    def _files(self) -> list[Path]:
        builtins = sorted(self.builtin_directory.glob("*.csv"))
        custom = sorted(self.custom_directory.glob("*.csv")) if self.custom_directory.exists() else []
        return [*builtins, *custom]

    def load(self) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
        entries: list[dict[str, Any]] = []
        warnings: list[dict[str, str]] = []
        seen: set[str] = set()
        for path in self._files():
            try:
                with path.open("r", encoding="utf-8-sig", newline="") as handle:
                    reader = csv.DictReader(handle)
                    if not reader.fieldnames or not {"id", "name", "home_url"} <= set(reader.fieldnames):
                        raise ValueError("CSV header must include id, name, and home_url")
                    for line_number, row in enumerate(reader, start=2):
                        try:
                            entry = self._validate(row)
                            if entry["id"] in seen:
                                raise ValueError(f"duplicate platform id {entry['id']}")
                            seen.add(entry["id"])
                            entry["catalog_source"] = "custom" if path.parent == self.custom_directory else "builtin"
                            entries.append(entry)
                        except ValueError as exc:
                            warnings.append({"file": path.name, "line": str(line_number), "message": str(exc)})
            except (OSError, ValueError, csv.Error) as exc:
                warnings.append({"file": path.name, "line": "", "message": str(exc)})
        return entries, warnings

    def get(self, platform_id: str) -> dict[str, Any] | None:
        entries, _ = self.load()
        return next((item for item in entries if item["id"] == platform_id), None)

    def search(
        self, *, query: str = "", country: str = "", region: str = "", industry: str = "",
    ) -> dict[str, Any]:
        entries, warnings = self.load()
        query_value = _text(query)
        country_value = country.strip().upper()
        region_value = region.strip().upper()
        industry_value = _text(industry)
        filtered = []
        for item in entries:
            haystack = _text(" ".join([
                item["name"], item["description"], *item["industry_keywords"],
                *item["location_keywords"], *item["countries"], *item["regions"],
                *item["work_types"], item["discovery_type"],
            ]))
            if query_value and query_value not in haystack:
                continue
            if country_value and "GLOBAL" not in item["countries"] and country_value not in item["countries"]:
                continue
            if region_value and "GLOBAL" not in item["countries"] and region_value not in item["regions"]:
                continue
            if industry_value and not any(industry_value in _text(value) for value in item["industry_keywords"]):
                continue
            filtered.append(item)
        return {"platforms": filtered, "count": len(filtered), "warnings": warnings}

    def add_custom(self, value: dict[str, Any]) -> dict[str, Any]:
        raw = dict(value)
        raw["id"] = str(raw.get("id") or _slug(str(raw.get("name") or "")))
        raw["default_tracked"] = "false"
        entry = self._validate(raw)
        existing, _ = self.load()
        if any(item["id"] == entry["id"] for item in existing):
            raise ValueError(f"platform id {entry['id']} already exists")
        self.custom_directory.mkdir(parents=True, exist_ok=True)
        rows: list[dict[str, str]] = []
        if self.custom_path.exists():
            with self.custom_path.open("r", encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
        serialized = {
            field: (
                "|".join(entry[field]) if field in LIST_FIELDS
                else "true" if field == "default_tracked" and entry[field]
                else "false" if field == "default_tracked"
                else str(entry.get(field) or "")
            )
            for field in FIELDS
        }
        rows.append(serialized)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix="platform-catalog-", suffix=".csv", dir=self.custom_directory, text=True,
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=FIELDS)
                writer.writeheader()
                writer.writerows(rows)
            os.replace(temporary_name, self.custom_path)
        finally:
            if os.path.exists(temporary_name):
                os.unlink(temporary_name)
        return {**entry, "catalog_source": "custom"}
