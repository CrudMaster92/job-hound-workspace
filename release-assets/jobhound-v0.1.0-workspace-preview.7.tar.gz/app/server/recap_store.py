"""Durable recap settings, queue and atomic report publication."""
import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .db import iso_now
from .recap_contracts import RecapSettings, DEFAULT_PROMPT
from .scheduler import next_occurrence


class RecapStore:
    def __init__(self, db):
        self.db = db
        with db.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS recap_settings (
                    id INTEGER PRIMARY KEY CHECK(id=1), value_json TEXT NOT NULL,
                    next_run_at TEXT, checkpoint TEXT, snapshot_json TEXT NOT NULL DEFAULT '{}');
                CREATE TABLE IF NOT EXISTS recap_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT UNIQUE NOT NULL,
                    status TEXT NOT NULL, created_at TEXT NOT NULL, finished_at TEXT,
                    window_start TEXT NOT NULL, window_end TEXT NOT NULL,
                    settings_json TEXT NOT NULL, report_json TEXT, error TEXT,
                    thread_id INTEGER REFERENCES chat_threads(id) ON DELETE SET NULL,
                    message_id INTEGER REFERENCES chat_messages(id) ON DELETE SET NULL,
                    lease_until TEXT);
                CREATE UNIQUE INDEX IF NOT EXISTS recap_one_active ON recap_runs((1))
                    WHERE status IN ('queued','running');
                CREATE TABLE IF NOT EXISTS recap_requests (
                    request_id TEXT PRIMARY KEY, run_id INTEGER NOT NULL REFERENCES recap_runs(id));
                CREATE TABLE IF NOT EXISTS recap_repairs (
                    recap_id INTEGER NOT NULL, company_id INTEGER NOT NULL,
                    requested_at TEXT NOT NULL, run_id INTEGER,
                    PRIMARY KEY(recap_id,company_id));
            """)
            settings = RecapSettings(timezone=db.get_settings()["timezone"]).model_dump()
            conn.execute("INSERT OR IGNORE INTO recap_settings(id,value_json,next_run_at) VALUES(1,?,?)",
                         (json.dumps(settings), self.next_due(settings)))

    @staticmethod
    def next_due(settings, now=None):
        return next_occurrence(settings, after=now) if settings["enabled"] else None

    def settings(self):
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM recap_settings WHERE id=1").fetchone()
        return {**json.loads(row["value_json"]), "next_run_at": row["next_run_at"],
                "default_prompt": DEFAULT_PROMPT}

    def update_settings(self, value):
        settings = value.model_dump()
        with self.db.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            old = json.loads(conn.execute("SELECT value_json FROM recap_settings WHERE id=1").fetchone()[0])
            schedule_keys = ("enabled", "schedule_kind", "interval_hours", "local_time", "weekday", "timezone")
            conn.execute("UPDATE recap_settings SET value_json=? WHERE id=1", (json.dumps(settings),))
            if any(old[k] != settings[k] for k in schedule_keys):
                conn.execute("UPDATE recap_settings SET next_run_at=? WHERE id=1", (self.next_due(settings),))
        return self.settings()

    @staticmethod
    def present(row):
        if row is None:
            return None
        value = dict(row)
        value["report"] = json.loads(value.pop("report_json")) if value.get("report_json") else None
        value.pop("report_json", None)
        for key in ("settings_json", "lease_until", "request_id"):
            value.pop(key, None)
        value["terminal"] = value["status"] in {"complete", "failed"}
        value["chat_url"] = f"/chat?thread={value['thread_id']}" if value["thread_id"] else None
        return value

    def get(self, run_id=None):
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM recap_runs WHERE id=?", (run_id,)).fetchone() if run_id else conn.execute(
                "SELECT * FROM recap_runs WHERE status='complete' ORDER BY id DESC LIMIT 1").fetchone()
        return self.present(row)

    def state(self):
        with self.db.connect() as conn:
            last = conn.execute("SELECT * FROM recap_runs ORDER BY id DESC LIMIT 1").fetchone()
        return {"latest": self.get(), "last_run": self.present(last), "settings": self.settings()}

    def enqueue(self, request_id, *, thread_id=None, scheduled=False, now=None):
        now = now or datetime.now(timezone.utc)
        stamp = now.isoformat()
        with self.db.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            config = conn.execute("SELECT * FROM recap_settings WHERE id=1").fetchone()
            settings = json.loads(config["value_json"])
            if scheduled:
                if not settings["enabled"] or not config["next_run_at"] or config["next_run_at"] > stamp:
                    return None
                request_id = "scheduled:" + config["next_run_at"]
            row = conn.execute("SELECT * FROM recap_runs WHERE request_id=? OR id=(SELECT run_id FROM recap_requests WHERE request_id=?)",
                               (request_id, request_id)).fetchone()
            if row:
                return self.present(row)
            active = conn.execute("SELECT * FROM recap_runs WHERE status IN ('queued','running')").fetchone()
            if active:
                if thread_id and active["thread_id"] != thread_id:
                    raise ValueError("Another recap is running. Open its chat or retry after it finishes.")
                if not scheduled:
                    conn.execute("INSERT OR IGNORE INTO recap_requests VALUES(?,?)", (request_id, active["id"]))
                return self.present(active)
            if not thread_id:
                title = f"Daily recap · {now.astimezone(ZoneInfo(settings['timezone'])).strftime('%b %d, %Y · %H:%M')}"
                cursor = conn.execute("INSERT INTO chat_threads(title,request_id,created_at,updated_at) VALUES(?,?,?,?)",
                                      (title, "recap:" + request_id, stamp, stamp))
                thread_id = cursor.lastrowid
                conn.execute("INSERT INTO chat_messages(thread_id,role,content,metadata_json,created_at) VALUES(?,'user',?,'{}',?)",
                             (thread_id, "Prepare my daily recap from existing JobHound results.", stamp))
            start = config["checkpoint"] or (now - timedelta(hours=24)).isoformat()
            cursor = conn.execute("""INSERT INTO recap_runs(request_id,status,created_at,window_start,window_end,settings_json,thread_id)
                VALUES(?,'queued',?,?,?,?,?)""", (request_id, stamp, start, stamp, json.dumps(settings), thread_id))
            row = conn.execute("SELECT * FROM recap_runs WHERE id=?", (cursor.lastrowid,)).fetchone()
            if scheduled:
                conn.execute("UPDATE recap_settings SET next_run_at=? WHERE id=1", (self.next_due(settings, now),))
        return self.present(row)

    def claim(self):
        now = datetime.now(timezone.utc)
        with self.db.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM recap_runs WHERE status='queued' OR (status='running' AND lease_until<?) LIMIT 1",
                               (now.isoformat(),)).fetchone()
            if not row:
                return None
            conn.execute("UPDATE recap_runs SET status='running',lease_until=? WHERE id=?",
                         ((now + timedelta(minutes=6)).isoformat(), row["id"]))
        return dict(row)

    def publish(self, run, report, snapshot, content):
        from .chat_commands import public_command
        now = iso_now()
        metadata = {"command_used": public_command("daily_recap"), "daily_recap": report,
                    "provider": report["provider"], "model": report["model"]}
        with self.db.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            current = conn.execute("SELECT * FROM recap_runs WHERE id=?", (run["id"],)).fetchone()
            if current["status"] in {"complete", "failed"}:
                return
            thread_id = current["thread_id"]
            if not thread_id:
                raise ValueError("The recap chat was deleted before the report completed")
            cursor = conn.execute("INSERT INTO chat_messages(thread_id,role,content,metadata_json,created_at) VALUES(?,'assistant',?,?,?)",
                                  (thread_id, content, json.dumps(metadata), now))
            conn.execute("UPDATE chat_threads SET updated_at=?,command_id=CASE WHEN command_id='daily_recap' THEN NULL ELSE command_id END WHERE id=?",
                         (now, thread_id))
            conn.execute("UPDATE recap_runs SET status='complete',finished_at=?,report_json=?,message_id=?,lease_until=NULL WHERE id=?",
                         (now, json.dumps(report), cursor.lastrowid, run["id"]))
            conn.execute("UPDATE recap_settings SET checkpoint=?,snapshot_json=? WHERE id=1",
                         (run["window_end"], json.dumps(snapshot)))

    def fail(self, run_id, error):
        with self.db.connect() as conn:
            conn.execute("UPDATE recap_runs SET status='failed',finished_at=?,error=?,lease_until=NULL WHERE id=? AND status<>'complete'",
                         (iso_now(), str(error)[:1000], run_id))
