"""Validated local storage and deterministic text extraction for career documents."""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import tempfile
import uuid
import zipfile
from functools import lru_cache
from pathlib import Path
from threading import RLock
from typing import Any

from docx import Document as DocxDocument
from pypdf import PdfReader

from .db import Database
from .career_document_drafts import fit_status, render_docx, render_html, validate_content
from .default_document_catalog import BY_KEY, DEFAULT_DOCUMENTS, DefaultDocument, asset_path


MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_EXTRACTED_CHARS = 200_000
SUPPORTED = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".txt": "text/plain",
}


class DocumentError(ValueError):
    """A safe, actionable document validation or storage error."""


def _clean_filename(value: str) -> str:
    name = Path(value or "document").name
    name = re.sub(r"[\x00-\x1f<>:\"/\\|?*]+", "_", name).strip(" .")
    return (name or "document")[:255]


def _clean_label(value: str | None, filename: str) -> str:
    label = " ".join((value or Path(filename).stem).split()).strip()
    if not label:
        raise DocumentError("Document label cannot be empty")
    return label[:120]


def _extract(extension: str, content: bytes) -> tuple[str, str]:
    try:
        if extension == ".txt":
            if b"\x00" in content:
                raise DocumentError("TXT documents cannot contain NUL bytes")
            text = content.decode("utf-8")
        elif extension == ".pdf":
            if not content.startswith(b"%PDF-"):
                raise DocumentError("The file content is not a valid PDF")
            try:
                reader = PdfReader(io.BytesIO(content))
            except Exception as exc:
                raise DocumentError("The file content is not a valid PDF") from exc
            text = "\n\n".join(page.extract_text() or "" for page in reader.pages)
        else:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                names = set(archive.namelist())
                if "[Content_Types].xml" not in names or "word/document.xml" not in names:
                    raise DocumentError("The file content is not a valid DOCX document")
            document = DocxDocument(io.BytesIO(content))
            text = "\n".join(paragraph.text for paragraph in document.paragraphs)
        normalized = text.replace("\x00", "").strip()[:MAX_EXTRACTED_CHARS]
        return normalized, "complete" if normalized else "empty"
    except DocumentError:
        raise
    except Exception:
        return "", "failed"


@lru_cache(maxsize=8)
def _packaged_text(filename: str) -> tuple[str, str]:
    return _extract(".docx", asset_path(filename).read_bytes())


class DocumentStore:
    def __init__(self, database: Database, root: str | Path | None = None) -> None:
        self.database = database
        self.root = Path(root or (Path(database.path).resolve().parent / "documents")).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()

    @staticmethod
    def public(document: dict[str, Any], *, include_text: bool = False,
               max_chars: int = 20_000) -> dict[str, Any]:
        excluded = {"stored_filename", "extracted_text", "structured_content_json"}
        result = {key: value for key, value in document.items() if key not in excluded}
        result["archived"] = bool(document.get("archived_at"))
        template_key = document.get("template_key")
        result["is_default_template"] = bool(template_key and template_key in BY_KEY)
        result["example_available"] = result["is_default_template"]
        result["is_generated"] = bool(document.get("structured_content_json"))
        result["record_type"] = "document"
        if document.get("structured_content_json"):
            try:
                result["structured_content"] = json.loads(document["structured_content_json"])
            except (TypeError, ValueError):
                result["structured_content"] = None
        result["example_filename"] = (
            BY_KEY[str(template_key)].example_docx if result["is_default_template"] else None
        )
        if include_text:
            text = str(document.get("extracted_text") or "")
            result["text"] = text[:max_chars]
            result["text_truncated"] = len(text) > max_chars
        return result

    def _managed_path(self, stored_filename: str) -> Path:
        path = (self.root / stored_filename).resolve()
        if path.parent != self.root:
            raise DocumentError("Invalid managed document path")
        return path

    def upload(self, *, kind: str, original_filename: str, content: bytes,
               label: str | None = None, replace_document_id: int | None = None,
               template_key: str | None = None, layout_key: str | None = None,
               source_document_id: int | None = None,
               structured_content: dict[str, Any] | None = None,
               fit_status_value: str | None = None) -> tuple[dict[str, Any], bool]:
        if kind not in {"resume", "intro_letter"}:
            raise DocumentError("Document type must be resume or intro_letter")
        if not content:
            raise DocumentError("Document file is empty")
        if len(content) > MAX_FILE_BYTES:
            raise DocumentError("Documents are limited to 10 MiB")
        filename = _clean_filename(original_filename)
        extension = Path(filename).suffix.casefold()
        if extension not in SUPPORTED:
            raise DocumentError("Supported document formats are PDF, DOCX, and TXT")
        extracted_text, extraction_status = _extract(extension, content)
        digest = hashlib.sha256(content).hexdigest()
        duplicate = self.database.find_document_by_hash(kind, digest)
        if duplicate:
            if template_key:
                existing_key = duplicate.get("template_key")
                if existing_key not in {None, template_key}:
                    raise DocumentError("That document is already assigned to another default template")
                if existing_key is None:
                    duplicate = self.database.assign_document_template_key(
                        int(duplicate["id"]), template_key,
                    )
            return duplicate, True
        stored_filename = f"{uuid.uuid4().hex}{extension}"
        path = self._managed_path(stored_filename)
        with self._lock:
            fd, temporary_name = tempfile.mkstemp(prefix=".upload-", dir=self.root)
            try:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary_name, path)
                try:
                    document = self.database.create_document({
                        "kind": kind,
                        "label": _clean_label(label, filename),
                        "original_filename": filename,
                        "stored_filename": stored_filename,
                        "mime_type": SUPPORTED[extension],
                        "extension": extension,
                        "size_bytes": len(content),
                        "sha256": digest,
                        "extracted_text": extracted_text,
                        "extraction_status": extraction_status,
                        "template_key": template_key,
                        "layout_key": layout_key,
                        "source_document_id": source_document_id,
                        "structured_content": structured_content,
                        "fit_status": fit_status_value,
                    }, replace_document_id)
                except Exception:
                    path.unlink(missing_ok=True)
                    raise
            finally:
                Path(temporary_name).unlink(missing_ok=True)
        return document, False

    @staticmethod
    def public_draft(draft: dict[str, Any]) -> dict[str, Any]:
        return {
            **draft,
            "preview_url": f"/api/v1/document-drafts/{draft['id']}/preview.html",
            "download_url": f"/api/v1/document-drafts/{draft['id']}/download.docx",
            "save_url": f"/api/v1/document-drafts/{draft['id']}/publish",
        }

    def create_draft(self, content: dict[str, Any], *, source_document_id: int | None = None,
                     draft_id: int | None = None) -> dict[str, Any]:
        validated = validate_content(content)
        if source_document_id is not None and not self.database.get_document(source_document_id):
            raise KeyError(source_document_id)
        payload = {
            "kind": validated.kind,
            "label": validated.label,
            "layout_key": validated.layout_key,
            "source_document_id": source_document_id,
            "content": validated.model_dump(mode="json"),
            "fit_status": fit_status(validated),
        }
        if draft_id is None:
            draft = self.database.create_document_draft(payload)
        else:
            current = self.database.get_document_draft(draft_id)
            if not current:
                raise KeyError(draft_id)
            if current.get("published_document_id"):
                raise DocumentError("A saved draft cannot be revised; start a new draft from the saved document")
            draft = self.database.update_document_draft(draft_id, payload)
        return self.public_draft(draft or {})

    def read_draft(self, draft_id: int) -> dict[str, Any]:
        draft = self.database.get_document_draft(draft_id)
        if not draft:
            raise KeyError(draft_id)
        return self.public_draft(draft)

    def draft_docx(self, draft_id: int) -> tuple[dict[str, Any], bytes]:
        draft = self.database.get_document_draft(draft_id)
        if not draft:
            raise KeyError(draft_id)
        return draft, render_docx(draft["content"])

    def draft_html(self, draft_id: int) -> str:
        draft = self.database.get_document_draft(draft_id)
        if not draft:
            raise KeyError(draft_id)
        return render_html(draft["content"])

    def generated_html(self, document_id: int) -> str:
        document = self.database.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        raw = document.get("structured_content_json")
        if not raw:
            raise DocumentError("A formatted HTML preview is available only for generated documents")
        return render_html(json.loads(raw))

    def publish_draft(self, draft_id: int) -> tuple[dict[str, Any], bool]:
        draft = self.database.get_document_draft(draft_id)
        if not draft:
            raise KeyError(draft_id)
        if draft.get("published_document_id"):
            existing = self.database.get_document(int(draft["published_document_id"]))
            if existing:
                return existing, True
        if draft["fit_status"] == "overflow":
            raise DocumentError("This draft overflows one page. Shorten it before saving")
        content = render_docx(draft["content"])
        filename = _clean_filename(f"{draft['label']}.docx")
        document, duplicate = self.upload(
            kind=draft["kind"], original_filename=filename, content=content,
            label=draft["label"], layout_key=draft["layout_key"],
            source_document_id=draft.get("source_document_id"),
            structured_content=draft["content"], fit_status_value=draft["fit_status"],
        )
        self.database.publish_document_draft(draft_id, int(document["id"]))
        return document, duplicate

    def ensure_default_templates(self) -> list[dict[str, Any]]:
        seeded = set(self.database.get_settings().get("default_document_seed_keys", []))
        results: list[dict[str, Any]] = []
        for item in DEFAULT_DOCUMENTS:
            if item.key in seeded:
                continue
            path = asset_path(item.template_docx)
            document, _ = self.upload(
                kind=item.kind,
                original_filename=item.template_docx,
                content=path.read_bytes(),
                label=item.label,
                template_key=item.key,
            )
            self.database.mark_default_document_seeded(item.key)
            seeded.add(item.key)
            results.append(document)
        return results

    @staticmethod
    def _catalog_item(document: dict[str, Any]) -> DefaultDocument:
        item = BY_KEY.get(str(document.get("template_key") or ""))
        if not item:
            raise DocumentError("A filled example is available only for a built-in template")
        return item

    def read(self, document_id: int, *, variant: str = "template",
             max_chars: int = 20_000, offset: int = 0) -> dict[str, Any]:
        document = self.database.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        if variant == "template":
            result = self.public(document)
            text = str(document.get("extracted_text") or "")
            result.update(text=text[offset:offset+max_chars], offset=offset,
                          next_offset=offset+max_chars if offset+max_chars<len(text) else None,
                          text_truncated=offset>0 or offset+max_chars<len(text))
            return result
        if variant != "example":
            raise DocumentError("Document variant must be template or example")
        item = self._catalog_item(document)
        text, status = _packaged_text(item.example_docx)
        result = self.public(document)
        result.update({
            "variant": "example",
            "variant_filename": item.example_docx,
            "text": text[offset:offset+max_chars],
            "offset": offset,
            "next_offset": offset+max_chars if offset+max_chars<len(text) else None,
            "text_truncated": offset>0 or offset+max_chars<len(text),
            "extraction_status": status,
        })
        return result

    def original_path(self, document_id: int) -> tuple[dict[str, Any], Path]:
        document = self.database.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        path = self._managed_path(document["stored_filename"])
        if not path.is_file():
            raise DocumentError("The stored document file is missing")
        return document, path

    def download_path(self, document_id: int, *, variant: str = "template") -> tuple[dict[str, Any], Path]:
        if variant == "template":
            return self.original_path(document_id)
        if variant != "example":
            raise DocumentError("Document variant must be template or example")
        document = self.database.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        item = self._catalog_item(document)
        presented = dict(document)
        presented.update({
            "original_filename": item.example_docx,
            "mime_type": SUPPORTED[".docx"],
            "extension": ".docx",
        })
        return presented, asset_path(item.example_docx)

    def preview_path(self, document_id: int, *, variant: str = "template") -> tuple[str, Path]:
        document = self.database.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        item = self._catalog_item(document)
        if variant == "template":
            filename = item.template_pdf
        elif variant == "example":
            filename = item.example_pdf
        else:
            raise DocumentError("Document variant must be template or example")
        return filename, asset_path(filename)

    def purge(self, document_id: int) -> None:
        document = self.database.get_document(document_id)
        if not document:
            raise KeyError(document_id)
        if not document.get("archived_at"):
            raise DocumentError("Archive the document before permanently deleting it")
        path = self._managed_path(document["stored_filename"])
        if not path.exists():
            self.database.delete_document(document_id)
            return
        staged = self._managed_path(f".purging-{uuid.uuid4().hex}")
        with self._lock:
            path.replace(staged)
            try:
                if not self.database.delete_document(document_id):
                    raise KeyError(document_id)
            except Exception:
                staged.replace(path)
                raise
            staged.unlink(missing_ok=True)

    def export_zip(self) -> Path:
        handle = tempfile.NamedTemporaryFile(prefix="jobhound-documents-", suffix=".zip", delete=False)
        handle.close()
        export_path = Path(handle.name)
        documents = self.database.list_documents(include_archived=True)
        manifest = [self.public(item) for item in documents]
        with zipfile.ZipFile(export_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.json", json.dumps({"documents": manifest}, indent=2, ensure_ascii=False))
            for item in documents:
                try:
                    _, path = self.original_path(int(item["id"]))
                except (KeyError, DocumentError):
                    continue
                status = "archived" if item.get("archived_at") else "active"
                folder = "resumes" if item["kind"] == "resume" else "intro-letters"
                archive.write(path, f"{status}/{folder}/{item['id']}-{_clean_filename(item['original_filename'])}")
        return export_path
