"""Packaged JobHound career-document templates and fictional examples."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DefaultDocument:
    key: str
    kind: str
    label: str
    template_docx: str
    example_docx: str
    template_pdf: str
    example_pdf: str


ASSET_ROOT = Path(__file__).resolve().parent / "default_documents"

DEFAULT_DOCUMENTS = (
    DefaultDocument(
        key="corporate_resume",
        kind="resume",
        label="Corporate Resume Template",
        template_docx="corporate-resume-template.docx",
        example_docx="corporate-resume-example.docx",
        template_pdf="corporate-resume-template.pdf",
        example_pdf="corporate-resume-example.pdf",
    ),
    DefaultDocument(
        key="creative_resume",
        kind="resume",
        label="Creative Resume Template",
        template_docx="creative-resume-template.docx",
        example_docx="creative-resume-example.docx",
        template_pdf="creative-resume-template.pdf",
        example_pdf="creative-resume-example.pdf",
    ),
    DefaultDocument(
        key="intro_letter",
        kind="intro_letter",
        label="Three-Paragraph Intro Letter Template",
        template_docx="intro-letter-template.docx",
        example_docx="intro-letter-example.docx",
        template_pdf="intro-letter-template.pdf",
        example_pdf="intro-letter-example.pdf",
    ),
)

BY_KEY = {item.key: item for item in DEFAULT_DOCUMENTS}


def asset_path(filename: str) -> Path:
    path = (ASSET_ROOT / filename).resolve()
    if path.parent != ASSET_ROOT.resolve() or not path.is_file():
        raise FileNotFoundError(filename)
    return path
