"""Typed HTTP boundary; existing application middleware enforces local access."""
from fastapi import HTTPException, Query
from .recap_contracts import RecapRequest, RecapSettings, RecapRun, RecapSettingsView, RecapState


def mount_recaps(app, service):
    @app.get("/api/v1/recap/settings", response_model=RecapSettingsView)
    def get_recap_settings():
        return service.store.settings()

    @app.put("/api/v1/recap/settings", response_model=RecapSettingsView)
    def update_recap_settings(value: RecapSettings):
        return service.store.update_settings(value)

    @app.get("/api/v1/recap", response_model=RecapState | RecapRun)
    def get_daily_recap(run_id: int | None = Query(default=None, ge=1)):
        if run_id is None:
            return service.store.state()
        run = service.store.get(run_id)
        if not run:
            raise HTTPException(404, "Recap run not found")
        return run

    @app.post("/api/v1/recap/runs", status_code=202, response_model=RecapRun)
    async def run_daily_recap(value: RecapRequest):
        return service.store.enqueue(value.request_id)
