"""Render one dashboard card as a shareable PNG for local agent clients."""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import quote


class DashboardCardExportError(RuntimeError):
    """Base class for actionable card-rendering failures."""


class DashboardCardExportUnavailable(DashboardCardExportError):
    """Raised when the optional browser runtime is not installed."""


class DashboardCardExportTimeout(DashboardCardExportError):
    """Raised when the export page does not finish rendering in time."""


@dataclass(frozen=True)
class DashboardCardExporter:
    timeout_ms: int = 15_000

    async def render(self, *, base_url: str, card_key: str, theme: str) -> bytes:
        try:
            from playwright.async_api import TimeoutError as PlaywrightTimeoutError
            from playwright.async_api import async_playwright
        except ImportError as exc:
            raise DashboardCardExportUnavailable(
                "Dashboard card images require JobHound's browser support. "
                "Re-run the JobHound installer or install the browser optional dependencies."
            ) from exc

        url = (
            f"{base_url.rstrip('/')}/__export/dashboard-card/"
            f"{quote(card_key, safe='')}?theme={quote(theme, safe='')}"
        )
        try:
            async with async_playwright() as playwright:
                try:
                    browser = await playwright.chromium.launch(headless=True)
                except Exception as exc:
                    raise DashboardCardExportUnavailable(
                        "Dashboard card images require JobHound's Chromium runtime. "
                        "Re-run the JobHound installer so Playwright can install Chromium."
                    ) from exc
                try:
                    page = await browser.new_page(
                        viewport={"width": 1120 if card_key == "daily_recap" else 720, "height": 900}, device_scale_factor=2,
                        color_scheme="light" if theme == "light" else "dark",
                    )
                    await page.goto(url, wait_until="domcontentloaded", timeout=self.timeout_ms)
                    await page.locator('[data-dashboard-export-ready="true"]').wait_for(
                        state="attached", timeout=self.timeout_ms,
                    )
                    card = page.locator("[data-dashboard-export-card]")
                    await card.wait_for(state="visible", timeout=self.timeout_ms)
                    return await card.screenshot(type="png", animations="disabled")
                finally:
                    await browser.close()
        except PlaywrightTimeoutError as exc:
            raise DashboardCardExportTimeout(
                f"Dashboard card '{card_key}' did not finish rendering within "
                f"{self.timeout_ms // 1000} seconds."
            ) from exc
        except DashboardCardExportError:
            raise
        except Exception as exc:
            raise DashboardCardExportUnavailable(
                "JobHound could not open its private dashboard card export page. "
                "Make sure JobHound is running with a current frontend build, then retry."
            ) from exc
