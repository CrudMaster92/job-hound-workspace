"""Deterministic, privacy-preserving geographic helpers for the Jobs map."""

from __future__ import annotations

from math import asin, cos, radians, sin, sqrt
import re
import unicodedata
from typing import Any

import httpx


HOME_GEOCODER_URL = "https://nominatim.openstreetmap.org/search"
HOME_GEOCODER_USER_AGENT = "JobHound/0.1 (local personal job-search app)"


class HomeAddressError(ValueError):
    """A Home address could not be safely resolved to a precise map point."""


# Approximate city centres place public postings usefully without implying street accuracy.
PLACES: tuple[tuple[float, float, tuple[str, ...]], ...] = (
    (43.6532, -79.3832, ("toronto", "toronto on", "toronto ontario")),
    (45.5019, -73.5674, ("montreal", "montreal qc", "montreal quebec")),
    (49.2827, -123.1207, ("vancouver", "vancouver bc", "vancouver british columbia")),
    (45.4215, -75.6972, ("ottawa", "ottawa on", "ottawa ontario")),
    (51.0447, -114.0719, ("calgary", "calgary ab", "calgary alberta")),
    (53.5461, -113.4938, ("edmonton", "edmonton ab", "edmonton alberta")),
    (49.8951, -97.1384, ("winnipeg", "winnipeg mb", "winnipeg manitoba")),
    (44.6488, -63.5752, ("halifax", "halifax ns", "halifax nova scotia")),
    (40.7128, -74.0060, ("new york", "new york city", "nyc", "new york ny")),
    (37.7749, -122.4194, ("san francisco", "san francisco ca", "bay area")),
    (34.0522, -118.2437, ("los angeles", "los angeles ca")),
    (41.8781, -87.6298, ("chicago", "chicago il")),
    (42.3601, -71.0589, ("boston", "boston ma")),
    (47.6062, -122.3321, ("seattle", "seattle wa")),
    (30.2672, -97.7431, ("austin", "austin tx")),
    (32.7767, -96.7970, ("dallas", "dallas tx", "dallas fort worth", "dfw")),
    (29.7604, -95.3698, ("houston", "houston tx")),
    (38.9072, -77.0369, ("washington dc", "washington d c", "district of columbia")),
    (39.9526, -75.1652, ("philadelphia", "philadelphia pa")),
    (33.4484, -112.0740, ("phoenix", "phoenix az")),
    (25.7617, -80.1918, ("miami", "miami fl")),
    (35.1495, -90.0490, ("memphis", "memphis tn", "memphis tennessee")),
    (30.1105, -97.3153, ("bastrop", "bastrop tx", "bastrop texas")),
    (51.5074, -0.1278, ("london", "london uk", "london england")),
    (53.4808, -2.2426, ("manchester", "manchester uk", "manchester england")),
    (53.3498, -6.2603, ("dublin", "dublin ireland")),
    (48.8566, 2.3522, ("paris", "paris france")),
    (52.5200, 13.4050, ("berlin", "berlin germany")),
    (48.1351, 11.5820, ("munich", "munich germany", "munchen")),
    (52.3676, 4.9041, ("amsterdam", "amsterdam netherlands")),
    (50.8503, 4.3517, ("brussels", "brussels belgium")),
    (47.3769, 8.5417, ("zurich", "zurich switzerland")),
    (40.4168, -3.7038, ("madrid", "madrid spain")),
    (41.3874, 2.1686, ("barcelona", "barcelona spain")),
    (38.7223, -9.1393, ("lisbon", "lisbon portugal")),
    (45.4642, 9.1900, ("milan", "milan italy")),
    (41.9028, 12.4964, ("rome", "rome italy")),
    (55.6761, 12.5683, ("copenhagen", "copenhagen denmark")),
    (59.3293, 18.0686, ("stockholm", "stockholm sweden")),
    (59.9139, 10.7522, ("oslo", "oslo norway")),
    (60.1699, 24.9384, ("helsinki", "helsinki finland")),
    (52.2297, 21.0122, ("warsaw", "warsaw poland")),
    (50.0755, 14.4378, ("prague", "prague czechia", "prague czech republic")),
    (48.2082, 16.3738, ("vienna", "vienna austria")),
    (37.9838, 23.7275, ("athens", "athens greece")),
    (41.0082, 28.9784, ("istanbul", "istanbul turkey")),
    (25.2048, 55.2708, ("dubai", "dubai uae", "dubai united arab emirates")),
    (24.4539, 54.3773, ("abu dhabi", "abu dhabi uae")),
    (32.0853, 34.7818, ("tel aviv", "tel aviv israel")),
    (19.4326, -99.1332, ("mexico city", "ciudad de mexico", "cdmx")),
    (-23.5505, -46.6333, ("sao paulo", "sao paulo brazil")),
    (-22.9068, -43.1729, ("rio de janeiro", "rio de janeiro brazil")),
    (-34.6037, -58.3816, ("buenos aires", "buenos aires argentina")),
    (-33.4489, -70.6693, ("santiago", "santiago chile")),
    (4.7110, -74.0721, ("bogota", "bogota colombia")),
    (-12.0464, -77.0428, ("lima", "lima peru")),
    (1.3521, 103.8198, ("singapore", "singapore sg")),
    (22.3193, 114.1694, ("hong kong", "hong kong hk")),
    (35.6762, 139.6503, ("tokyo", "tokyo japan")),
    (34.6937, 135.5023, ("osaka", "osaka japan")),
    (37.5665, 126.9780, ("seoul", "seoul south korea")),
    (31.2304, 121.4737, ("shanghai", "shanghai china")),
    (39.9042, 116.4074, ("beijing", "beijing china")),
    (28.6139, 77.2090, ("new delhi", "delhi", "delhi india")),
    (19.0760, 72.8777, ("mumbai", "mumbai india")),
    (12.9716, 77.5946, ("bengaluru", "bangalore", "bengaluru india")),
    (13.7563, 100.5018, ("bangkok", "bangkok thailand")),
    (3.1390, 101.6869, ("kuala lumpur", "kuala lumpur malaysia")),
    (-6.2088, 106.8456, ("jakarta", "jakarta indonesia")),
    (-33.8688, 151.2093, ("sydney", "sydney australia")),
    (-37.8136, 144.9631, ("melbourne", "melbourne australia")),
    (-27.4698, 153.0251, ("brisbane", "brisbane australia")),
    (-31.9523, 115.8613, ("perth", "perth australia")),
    (-36.8509, 174.7645, ("auckland", "auckland new zealand")),
    (-1.2921, 36.8219, ("nairobi", "nairobi kenya")),
    (-26.2041, 28.0473, ("johannesburg", "johannesburg south africa")),
    (-33.9249, 18.4241, ("cape town", "cape town south africa")),
    (30.0444, 31.2357, ("cairo", "cairo egypt")),
    (6.5244, 3.3792, ("lagos", "lagos nigeria")),
)


def _normalized(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", value.casefold()).split())


def resolve_location(value: str | None) -> tuple[float, float] | None:
    normalized = _normalized(value or "")
    if not normalized or normalized in {"remote", "unspecified", "multiple locations", "worldwide"}:
        return None
    padded = f" {normalized} "
    candidates: list[tuple[int, float, float]] = []
    for latitude, longitude, aliases in PLACES:
        for alias in aliases:
            key = _normalized(alias)
            if f" {key} " in padded:
                candidates.append((len(key), latitude, longitude))
    if not candidates:
        return None
    _, latitude, longitude = max(candidates)
    return latitude, longitude


async def geocode_home_address(value: str) -> dict[str, Any]:
    """Resolve a user-entered postal address through the fixed OpenStreetMap endpoint."""
    address = " ".join(value.split())
    if len(address) < 12:
        raise HomeAddressError(
            "Enter a full Home address with street number, street, city, region, postal or ZIP code, and country"
        )
    try:
        async with httpx.AsyncClient(timeout=12, follow_redirects=False) as client:
            response = await client.get(
                HOME_GEOCODER_URL,
                params={"q": address, "format": "jsonv2", "addressdetails": 1, "limit": 1},
                headers={"User-Agent": HOME_GEOCODER_USER_AGENT},
            )
            response.raise_for_status()
            matches = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise HomeAddressError(
            "Home address verification is unavailable. Check your connection and try again"
        ) from exc
    if not isinstance(matches, list) or not matches:
        raise HomeAddressError(
            "Home address was not found. Include the street number, city, region, postal or ZIP code, and country"
        )
    match = matches[0]
    details = match.get("address") if isinstance(match, dict) else None
    details = details if isinstance(details, dict) else {}
    road = next((details.get(key) for key in (
        "road", "pedestrian", "footway", "residential", "neighbourhood"
    ) if details.get(key)), None)
    city = next((details.get(key) for key in (
        "city", "town", "village", "municipality", "county"
    ) if details.get(key)), None)
    missing = []
    if not details.get("house_number"):
        missing.append("street number")
    if not road:
        missing.append("street")
    if not city:
        missing.append("city")
    if not details.get("postcode"):
        missing.append("postal or ZIP code")
    if not details.get("country"):
        missing.append("country")
    if missing:
        raise HomeAddressError(
            f"Home address is incomplete or imprecise. Check the {', '.join(missing)}"
        )
    try:
        latitude, longitude = float(match["lat"]), float(match["lon"])
    except (KeyError, TypeError, ValueError) as exc:
        raise HomeAddressError("Home address did not return valid map coordinates") from exc
    canonical = " ".join(str(match.get("display_name") or address).split())
    return {
        "address": canonical,
        "label": canonical,
        "city": city,
        "region": details.get("state") or details.get("region"),
        "country": details.get("country"),
        "latitude": latitude,
        "longitude": longitude,
    }


def distance_km(a_latitude: float, a_longitude: float, b_latitude: float, b_longitude: float) -> float:
    radius_km = 6371.0088
    d_lat = radians(b_latitude - a_latitude)
    d_lon = radians(b_longitude - a_longitude)
    a = sin(d_lat / 2) ** 2 + cos(radians(a_latitude)) * cos(radians(b_latitude)) * sin(d_lon / 2) ** 2
    return radius_km * 2 * asin(sqrt(a))


def add_geography(job: dict[str, Any], home: dict[str, Any] | None) -> dict[str, Any]:
    result = dict(job)
    point = resolve_location(str(result.get("location") or result.get("location_city") or ""))
    result["latitude"] = point[0] if point else None
    result["longitude"] = point[1] if point else None
    result["distance_from_home_km"] = None
    if point and home and home.get("latitude") is not None and home.get("longitude") is not None:
        result["distance_from_home_km"] = round(distance_km(
            float(home["latitude"]), float(home["longitude"]), point[0], point[1]
        ), 1)
    return result
