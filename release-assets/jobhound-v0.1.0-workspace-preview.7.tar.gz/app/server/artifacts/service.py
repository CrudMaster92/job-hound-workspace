"""Durable artifacts; only generated storage names reach the filesystem."""
import base64
import hashlib
import json
import os
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event, RLock
from ..ai_connections.cancellation import ProviderCancelled, run_cancellable
from .contracts import ArtifactError, ArtifactProposal, CreateArtifact
from .render import MIMES


class ArtifactService:
    def __init__(self, database):
        self.db = database
        self.root = Path(database.path).absolute().parent / 'chat-workspaces'
        self.root.mkdir(exist_ok=True)
        self.lock = RLock()
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='jobhound-files')
        self.cancellations = {}
        with self.db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS chat_artifacts (
              id INTEGER PRIMARY KEY, thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE);
            CREATE TABLE IF NOT EXISTS chat_artifact_revisions (
              artifact_id INTEGER NOT NULL REFERENCES chat_artifacts(id) ON DELETE CASCADE,
              revision INTEGER NOT NULL, thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
              turn_id INTEGER, request_id TEXT NOT NULL, fingerprint TEXT NOT NULL,
              filename TEXT NOT NULL, format TEXT NOT NULL, source_json TEXT NOT NULL,
              state TEXT NOT NULL DEFAULT 'pending', error TEXT, stored_name TEXT, size_bytes INTEGER,
              created_at REAL NOT NULL, PRIMARY KEY(artifact_id,revision), UNIQUE(thread_id,request_id));
            ''')
            c.execute("UPDATE chat_artifact_revisions SET state='failed',error='Rendering was interrupted; create a new revision to retry.' WHERE state='pending'")

    def close(self):
        with self.lock:
            for cancellation in self.cancellations.values():
                cancellation.set()
        self.pool.shutdown(wait=True, cancel_futures=False)

    def _path(self, thread_id, stored_name):
        # Detect reparse points as well as symlinks before touching managed files.
        folder = self.root / str(int(thread_id))
        for path in [self.root, folder]:
            if path.is_symlink() or (getattr(path, 'is_junction', lambda: False)()) or (path.exists() and getattr(path.lstat(), 'st_file_attributes', 0) & 0x400):
                raise ArtifactError('Managed workspace cannot be a link')
        if Path(stored_name).name != stored_name:
            raise ArtifactError('Invalid managed file')
        folder.mkdir(exist_ok=True)
        path = folder / stored_name
        if path.is_symlink() or (path.exists() and getattr(path.lstat(),'st_file_attributes',0) & 0x400):
            raise ArtifactError('Managed file cannot be a link')
        if not path.resolve().is_relative_to(self.root.resolve()):
            raise ArtifactError('File escaped the chat workspace')
        return path

    def _public(self, row, *, content=False):
        item = {k: row[k] for k in ('artifact_id','revision','thread_id','turn_id','filename','format','state','error','size_bytes','created_at')}
        item['terminal'] = item['state'] != 'pending'
        suffix = f"/api/v1/chat/threads/{row['thread_id']}/artifacts/{row['artifact_id']}?revision={row['revision']}"
        item['read_url'] = suffix
        item['download_url'] = suffix.replace('?revision=', '/download?revision=') if row['state'] == 'complete' else None
        item['preview_url'] = suffix.replace('?revision=', '/preview?revision=') if row['state'] == 'complete' else None
        if content:
            item['content'] = json.loads(row['source_json'])
        return item

    def _row(self, thread_id, artifact_id, revision=None):
        with self.db.connect() as c:
            row = c.execute('SELECT * FROM chat_artifact_revisions WHERE thread_id=? AND artifact_id=? AND (? IS NULL OR revision=?) ORDER BY revision DESC LIMIT 1', (thread_id,artifact_id,revision,revision)).fetchone()
        if not row:
            raise ArtifactError('Chat file not found',404)
        return dict(row)

    def read(self, thread_id, artifact_id, revision=None, *, content=False):
        return self._public(self._row(thread_id,artifact_id,revision),content=content)

    def list(self, thread_id, *, offset=0, limit=50):
        if not self.db.get_chat_thread(thread_id):
            raise ArtifactError('Chat not found',404)
        with self.db.connect() as c:
            rows=c.execute('SELECT * FROM chat_artifact_revisions WHERE thread_id=? ORDER BY created_at DESC,artifact_id DESC,revision DESC LIMIT ? OFFSET ?', (thread_id,limit+1,offset)).fetchall()
        return {'items':[self._public(row) for row in rows[:limit]],'next_offset':offset+limit if len(rows)>limit else None}

    def create(self, thread_id, request: CreateArtifact, *, turn_id=None, cancel_event=None):
        if not self.db.get_chat_thread(thread_id):
            raise ArtifactError('Chat not found',404)
        proposal = ArtifactProposal.model_validate(request.model_dump(exclude={'request_id'}))
        fingerprint = hashlib.sha256(proposal.model_dump_json().encode()).hexdigest()
        with self.lock, self.db.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT * FROM chat_artifact_revisions WHERE thread_id=? AND request_id=?',(thread_id,request.request_id)).fetchone()
            if old:
                if old['fingerprint'] != fingerprint:
                    raise ArtifactError('Request ID already used for different content',409)
                return self._public(old)
            if turn_id is not None and c.execute('SELECT count(*) FROM chat_artifact_revisions WHERE thread_id=? AND turn_id=?',(thread_id,turn_id)).fetchone()[0] >= 5:
                raise ArtifactError('A turn can create at most five file revisions')
            if c.execute("SELECT count(*) FROM chat_artifact_revisions WHERE state='pending'").fetchone()[0] >= 20:
                raise ArtifactError('File queue is full; wait for pending files',429)
            artifact_id=proposal.artifact_id
            revision=1
            if artifact_id is None:
                artifact_id=c.execute('INSERT INTO chat_artifacts(thread_id) VALUES(?)',(thread_id,)).lastrowid
            else:
                old=c.execute('SELECT * FROM chat_artifact_revisions WHERE artifact_id=? AND thread_id=? ORDER BY revision DESC LIMIT 1',(artifact_id,thread_id)).fetchone()
                if not old:
                    raise ArtifactError('Chat file not found',404)
                if old['revision'] != proposal.expected_revision or old['state'] == 'pending':
                    raise ArtifactError('File changed or is rendering; read its latest revision',409)
                revision=old['revision']+1
            c.execute('INSERT INTO chat_artifact_revisions(artifact_id,revision,thread_id,turn_id,request_id,fingerprint,filename,format,source_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
                      (artifact_id,revision,thread_id,turn_id,request.request_id,fingerprint,proposal.filename,proposal.format,proposal.content.model_dump_json(),time.time()))
            c.execute('UPDATE chat_threads SET private_local=1 WHERE id=?',(thread_id,))
        cancellation=cancel_event if cancel_event is not None else Event()
        with self.lock:
            self.cancellations[(artifact_id,revision)]=cancellation
        pending=self.read(thread_id,artifact_id,revision)
        self.pool.submit(self._render,thread_id,artifact_id,revision,proposal,cancellation)
        return pending

    def _render(self, thread_id, artifact_id, revision, proposal, cancellation):
        path=None
        try:
            result=run_cancellable([sys.executable,'-m','server.artifacts.worker'], input=proposal.model_dump_json(),cancel_event=cancellation,timeout=60)
            if result.returncode:
                raise ArtifactError('File rendering failed; check the content and format limits')
            data=base64.b64decode(result.stdout,validate=True)
            if len(data)>10*1024*1024:
                raise ArtifactError('File exceeds 10 MiB')
            if cancellation.is_set():
                raise ProviderCancelled()
            name=uuid.uuid4().hex+'.'+proposal.format
            path=self._path(thread_id,name)
            with path.open('xb') as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            if cancellation.is_set():
                raise ProviderCancelled()
            with self.db.connect() as c:
                c.execute("UPDATE chat_artifact_revisions SET state='complete',stored_name=?,size_bytes=? WHERE artifact_id=? AND revision=?",(name,len(data),artifact_id,revision))
        except Exception as exc:
            if path is not None:
                path.unlink(missing_ok=True)
            state='cancelled' if isinstance(exc,ProviderCancelled) else 'failed'
            message='File rendering cancelled' if state=='cancelled' else 'File rendering failed; check content, dependencies and format limits.'
            with self.db.connect() as c:
                c.execute('UPDATE chat_artifact_revisions SET state=?,error=? WHERE artifact_id=? AND revision=?',(state,message,artifact_id,revision))
        finally:
            with self.lock:
                self.cancellations.pop((artifact_id,revision),None)

    def wait(self, thread_id, item, cancellation=None):
        deadline=time.monotonic()+65
        while not item['terminal']:
            if cancellation is not None and cancellation.is_set():
                raise ProviderCancelled('File creation cancelled')
            if time.monotonic()>deadline:
                return item
            time.sleep(.05)
            item=self.read(thread_id,item['artifact_id'],item['revision'])
        return item

    def download(self, thread_id, artifact_id, revision=None):
        row=self._row(thread_id,artifact_id,revision)
        if row['state']!='complete':
            raise ArtifactError('File is not ready',409)
        return self._path(thread_id,row['stored_name']), row['filename'], MIMES[row['format']]
