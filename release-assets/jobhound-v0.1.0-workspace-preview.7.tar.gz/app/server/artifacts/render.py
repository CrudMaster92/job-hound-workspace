"""Deterministic renderers: no templates, scripts, URLs or formulas execute."""
import csv
import io
import json
from html import escape
from .contracts import ArtifactProposal

MIMES = {'txt':'text/plain','md':'text/markdown','json':'application/json','csv':'text/csv',
         'docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
         'pdf':'application/pdf','xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}


def render(value: ArtifactProposal) -> bytes:
    content, fmt = value.content, value.format
    if fmt in {'txt','md'}:
        return content.text.encode('utf-8')
    if fmt == 'json':
        return (json.dumps(json.loads(content.text), ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    output = io.BytesIO()
    if fmt == 'csv':
        text = io.StringIO(newline='')
        def cell(v):
            if isinstance(v, str) and v.lstrip().startswith(('=','+','-','@')):
                return "'" + v
            return v
        sheet = content.sheets[0]
        csv.writer(text).writerows([[cell(v) for v in row] for row in ([sheet.headers] if sheet.headers else []) + sheet.rows])
        return text.getvalue().encode('utf-8-sig')
    if fmt == 'xlsx':
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter
        book = Workbook()
        book.remove(book.active)
        for sheet in content.sheets:
            ws = book.create_sheet(sheet.name)
            for row in ([sheet.headers] if sheet.headers else []) + sheet.rows:
                ws.append(row)
            for row in ws:
                for cell in row:
                    if isinstance(cell.value, str):
                        cell.data_type = 's'
            if sheet.headers:
                ws.freeze_panes = 'A2'
                ws.auto_filter.ref = ws.dimensions
                for cell in ws[1]:
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.fill = PatternFill('solid', fgColor='243B53')
            for i in range(1, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(i)].width = min(60, max(14, max((len(str(ws.cell(r,i).value or '')) for r in range(1,min(ws.max_row,100)+1)), default=14)+2))
        book.save(output)
    elif fmt == 'docx':
        from docx import Document
        from docx.shared import Pt
        document = Document()
        document.styles['Normal'].font.size = Pt(11)
        if content.title:
            document.add_heading(content.title, 0)
        if content.text:
            for paragraph in content.text.split('\n\n'):
                document.add_paragraph(paragraph)
        for block in content.blocks:
            if block.kind == 'heading':
                document.add_heading(block.text, 1)
            elif block.kind == 'paragraph':
                document.add_paragraph(block.text)
            elif block.kind == 'list':
                for item in block.items:
                    document.add_paragraph(item, style='List Bullet')
            elif block.rows:
                table = document.add_table(rows=0, cols=max(map(len,block.rows)))
                table.style = 'Light Shading Accent 1'
                for row in block.rows:
                    cells = table.add_row().cells
                    for cell, text in zip(cells,row):
                        cell.text = text
        document.save(output)
    elif fmt == 'pdf':
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib import colors
        styles = getSampleStyleSheet()
        def paragraph(text, style='BodyText'):
            return Paragraph(escape(text).replace('\n','<br/>'), styles[style])
        story = []
        if content.title:
            story.append(paragraph(content.title,'Title'))
        for text in content.text.split('\n\n') if content.text else []:
            story.extend([paragraph(text), Spacer(1,8)])
        for block in content.blocks:
            if block.kind in {'heading','paragraph'}:
                story.extend([paragraph(block.text,'Heading1' if block.kind == 'heading' else 'BodyText'),Spacer(1,8)])
            elif block.kind == 'list':
                story.extend(paragraph('• ' + item) for item in block.items)
            elif block.rows:
                count=max(map(len,block.rows))
                rows=[[paragraph(cell) for cell in row] + ['']*(count-len(row)) for row in block.rows]
                table=LongTable(rows,colWidths=[468/count]*count,repeatRows=1)
                table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E8EEF4')),('GRID',(0,0),(-1,-1),0.3,colors.grey)]))
                story.extend([table,Spacer(1,8)])
        SimpleDocTemplate(output, leftMargin=72, rightMargin=72).build(story or [paragraph(' ')])
    return output.getvalue()
