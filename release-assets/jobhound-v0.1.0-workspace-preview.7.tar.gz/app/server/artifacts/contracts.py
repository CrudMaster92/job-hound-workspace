"""No executable content or filesystem paths cross this boundary."""
import json
import re
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)


class Block(Strict):
    kind: Literal['heading', 'paragraph', 'list', 'table']
    text: str = Field(default='', max_length=20000)
    items: list[str] = Field(default_factory=list, max_length=200)
    rows: list[list[str]] = Field(default_factory=list, max_length=500)


class Sheet(Strict):
    name: str = Field(min_length=1, max_length=31)
    headers: list[str] = Field(default_factory=list, max_length=100)
    rows: list[list[str | float | bool | None]] = Field(default_factory=list, max_length=5000)

    @model_validator(mode='after')
    def bounds(self):
        if re.search(r'[\\/*?:\[\]]', self.name) or self.name.startswith("'") or self.name.endswith("'"):
            raise ValueError('Invalid sheet name')
        if any(len(row) > 100 for row in self.rows):
            raise ValueError('Sheets support at most 100 columns')
        return self


class ArtifactContent(Strict):
    title: str = Field(default='', max_length=240)
    text: str = Field(default='', max_length=200000)
    blocks: list[Block] = Field(default_factory=list, max_length=200)
    sheets: list[Sheet] = Field(default_factory=list, max_length=10)

    @model_validator(mode='after')
    def bounds(self):
        if len(self.model_dump_json().encode()) > 1_000_000:
            raise ValueError('Source content is limited to 1 MB')
        names = [sheet.name.casefold() for sheet in self.sheets]
        if len(names) != len(set(names)):
            raise ValueError('Sheet names must be unique')
        if any(len(row) > 30 for block in self.blocks for row in block.rows):
            raise ValueError('Document tables support at most 30 columns')
        return self


class ArtifactProposal(Strict):
    filename: str = Field(min_length=1, max_length=160)
    format: Literal['txt', 'md', 'json', 'csv', 'docx', 'pdf', 'xlsx']
    content: ArtifactContent
    artifact_id: int | None = Field(default=None, ge=1)
    expected_revision: int | None = Field(default=None, ge=1)

    @model_validator(mode='after')
    def valid(self):
        if re.search(r'[<>:"/\\|?*\x00-\x1f]', self.filename) or self.filename.endswith((' ', '.')):
            raise ValueError('Use a filename, not a path')
        if self.filename.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}:
            raise ValueError('Reserved filename')
        if not self.filename.lower().endswith('.' + self.format):
            raise ValueError('Filename extension must match format')
        if (self.artifact_id is None) != (self.expected_revision is None):
            raise ValueError('Revisions require artifact_id and expected_revision')
        if self.format == 'json':
            json.loads(self.content.text, parse_constant=lambda x: (_ for _ in ()).throw(ValueError('JSON must be finite')))
        if self.format in {'csv','xlsx'} and not self.content.sheets:
            raise ValueError('Tables require at least one sheet')
        if self.format == 'csv' and len(self.content.sheets) != 1:
            raise ValueError('CSV supports one sheet')
        return self


class CreateArtifact(ArtifactProposal):
    request_id: str = Field(min_length=8, max_length=120)


class ArtifactError(ValueError):
    def __init__(self, message, status=422):
        super().__init__(message)
        self.status = status
