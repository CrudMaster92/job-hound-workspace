"""Controlled, revisioned chat files shared by human and agent clients."""
