"""Isolated process for bounded, cancellable deterministic rendering."""
import base64
import sys
from .contracts import ArtifactProposal
from .render import render

if __name__ == '__main__':
    try:
        data = render(ArtifactProposal.model_validate_json(sys.stdin.read(1_100_000)))
        if len(data) > 10 * 1024 * 1024:
            raise ValueError('Output exceeds 10 MiB')
        sys.stdout.write(base64.b64encode(data).decode('ascii'))
    except Exception:
        sys.stderr.write('File rendering failed; check the content and format limits.')
        sys.exit(1)
