from html import escape
import json
from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from ..interviews.routes import local_connection
from .contracts import ArtifactError, CreateArtifact


def mount_artifacts(app, service):
    def local(request: Request):
        local_connection(request)
    router=APIRouter(prefix='/api/v1/chat/threads/{thread_id}/artifacts',dependencies=[Depends(local)])

    @app.exception_handler(ArtifactError)
    async def error(request, exc):
        return JSONResponse({'detail':str(exc)},status_code=exc.status)

    @router.get('')
    def listing(thread_id: int, offset: int = Query(0,ge=0), limit: int = Query(50,ge=1,le=50)):
        return service.list(thread_id,offset=offset,limit=limit)

    @router.post('', status_code=202)
    def create(thread_id: int, payload: CreateArtifact):
        return service.create(thread_id,payload)

    @router.get('/{artifact_id}')
    def read(thread_id: int, artifact_id: int, revision: int | None = Query(None,ge=1), include_content: bool=False):
        return service.read(thread_id,artifact_id,revision,content=include_content)

    @router.get('/{artifact_id}/download')
    def download(thread_id: int, artifact_id: int, revision: int | None = Query(None,ge=1)):
        path,name,mime=service.download(thread_id,artifact_id,revision)
        return FileResponse(path,filename=name,media_type=mime,headers={'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'})

    @router.get('/{artifact_id}/preview')
    def preview(thread_id: int, artifact_id: int, revision: int | None = Query(None,ge=1)):
        item=service.read(thread_id,artifact_id,revision,content=True)
        source=item['content']
        body=f"<h1>{escape(source['title'] or item['filename'])}</h1>"
        if item['format'] not in {'xlsx','csv'}:
            body+=f"<pre>{escape(source['text'])}</pre>"
        for block in source['blocks'] if item['format'] in {'pdf','docx'} else []:
            if block['kind']=='heading': body+=f"<h2>{escape(block['text'])}</h2>"
            elif block['kind']=='paragraph': body+=f"<p>{escape(block['text'])}</p>"
            elif block['kind']=='list': body+='<ul>'+''.join('<li>'+escape(i)+'</li>' for i in block['items'])+'</ul>'
            else: body+='<table>'+''.join('<tr>'+''.join('<td>'+escape(v)+'</td>' for v in row)+'</tr>' for row in block['rows'])+'</table>'
        for sheet in source['sheets'] if item['format'] in {'xlsx','csv'} else []:
            body+='<h2>'+escape(sheet['name'])+'</h2><table>'
            body+=''.join('<tr>'+''.join('<td>'+escape(str(v) if v is not None else '')+'</td>' for v in row)+'</tr>' for row in ([sheet['headers']] if sheet['headers'] else [])+sheet['rows'][:100])+'</table>'
            if len(sheet['rows'])>100: body+='<p>Preview shows the first 100 rows. Download for all rows.</p>'
        return HTMLResponse('<!doctype html><html><head><meta charset="utf-8"><title>File preview</title><style>body{font:16px system-ui;max-width:960px;margin:32px auto;padding:16px}pre,p,td{white-space:pre-wrap;overflow-wrap:anywhere}table{border-collapse:collapse;display:block;overflow:auto}td{border:1px solid #aaa;padding:8px}</style></head><body>'+body+'</body></html>',headers={'Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; sandbox",'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

    app.include_router(router)
