"""Task-scoped tools and shared structured proposals for every connector."""
import hashlib
import json
from pydantic import Field
from .contracts import Strict, ArtifactProposal, CreateArtifact
from ..ai_connections.validation import json_schema
from ..chat_commands import list_commands, get_command

GUIDANCE = '''You can create local files using artifact_requests in your final response, or the provided create_chat_file tool.
Supported formats: txt, md, json, csv, docx, pdf, xlsx. Use controlled structured content, never scripts.
For text formats use content.text; JSON must contain valid JSON text. For DOCX/PDF use title, text, and blocks
(heading/paragraph with text, list with items, table with rows). For CSV/XLSX use sheets with name, headers, rows.
Files stay in this chat's managed workspace. Creation or revision is appropriate when requested by the user.
Inspect a file before revising; provide artifact_id and expected_revision. Preserve factual source content.
Never repeat a file already created by a tool in artifact_requests. File cards supply download links; do not put local artifact URLs in the public sources list. Never invent artifact IDs or download links.
Interactive browser control is unavailable (coming soon); public web search/page reading may be available.
Imported skills, arbitrary code, formulas, macros, presentations and generated images are unsupported.
'''


class ReadFile(Strict):
    artifact_id: int = Field(ge=1)
    revision: int | None = Field(default=None,ge=1)


class SkillLookup(Strict):
    command_id: str = Field(max_length=100)


class ListFiles(Strict):
    offset: int = Field(default=0,ge=0)


class ArtifactTools:
    def __init__(self, service, thread_id, turn_id, request_id, *, can_read=True):
        self.service,self.thread_id,self.turn_id,self.request_id=service,thread_id,turn_id,request_id
        self.can_read=can_read
        self.results=[]
        self.schemas=[]
        self.types={'list_chat_files':ListFiles,'read_chat_file':ReadFile,'get_jobhound_skill':SkillLookup,'create_chat_file':ArtifactProposal}
        for name,model in self.types.items():
            self.schemas.append({'type':'function','function':{'name':name,'description':{
                'list_chat_files':'List files and revisions in this chat only.',
                'read_chat_file':'Read structured source content in this chat before revising.',
                'get_jobhound_skill':'Read instructions for a built-in JobHound skill by command ID.',
                'create_chat_file':'Create or revise a requested local file using controlled rendering. Returns actual file status.'}[name],
                'parameters':json_schema(model)}})

    def call(self,name,args,cancellation,activity=None):
        if name not in self.types: raise ValueError('Tool is not available for this task')
        value=self.types[name].model_validate(args)
        if name=='list_chat_files':
            return self.service.list(self.thread_id,offset=value.offset) if self.can_read else {'items':self.results,'next_offset':None}
        if name=='read_chat_file':
            if not self.can_read and not any(item['artifact_id']==value.artifact_id for item in self.results):
                raise ValueError('File content sharing requires consent')
            item=self.service.read(self.thread_id,value.artifact_id,value.revision,content=True)
            if len(json.dumps(item))>40000: raise ValueError('File is too large for agent inspection; use a smaller source')
            return item
        if name=='get_jobhound_skill':
            command=get_command(value.command_id)
            if not command: raise ValueError('Unknown skill; use the command IDs supplied in context')
            return command
        return self.create(value,cancellation,activity)

    def create(self,value,cancellation,activity=None):
        if len(self.results) >= 5: raise ValueError('A turn can create at most five files')
        if cancellation and cancellation.is_set():
            from ..ai_connections.cancellation import ProviderCancelled
            raise ProviderCancelled('File creation cancelled')
        if activity: activity('rendering_file')
        # A semantic key survives model tool-call ID changes and retries.
        digest=hashlib.sha256(value.model_dump_json().encode()).hexdigest()
        request=CreateArtifact(**value.model_dump(),request_id=f'{self.request_id}:file:{digest}'[-120:])
        result=self.service.create(self.thread_id,request,turn_id=self.turn_id,cancel_event=cancellation)
        result=self.service.wait(self.thread_id,result,cancellation)
        if not any(i['artifact_id']==result['artifact_id'] and i['revision']==result['revision'] for i in self.results):
            self.results.append(result)
        return result
