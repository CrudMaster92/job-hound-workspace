"""Bounded public board contracts, shared by HTTP and local agent tools."""
from typing import Literal
from urllib.parse import urlsplit
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class PublicJob(Contract):
    id: str = Field(min_length=1, max_length=300, pattern=r"^[A-Za-z0-9_.:-]+$")
    company_id: str = Field(min_length=1, max_length=300)
    company_name: str = Field(min_length=1, max_length=300)
    collection_ids: list[str] = Field(default_factory=list, max_length=100)
    title: str = Field(min_length=1, max_length=1000)
    location: str = Field(default="", max_length=2000)
    work_mode: str = Field(default="unknown", max_length=100)
    employment_type: str | None = Field(default=None, max_length=300)
    salary_text: str | None = Field(default=None, max_length=1000)
    salary_min: float | None = None
    salary_max: float | None = None
    salary_currency: str | None = Field(default=None, max_length=30)
    salary_period: str | None = Field(default=None, max_length=30)
    source_url: str = Field(max_length=4000)
    source_job_id: str | None = Field(default=None, max_length=1000)
    posted_at: str | None = Field(default=None, max_length=100)
    first_seen_at: str = Field(max_length=100)
    last_seen_at: str = Field(max_length=100)
    status: Literal["active", "closed", "expired"] = "active"
    monitor_ids: list[str] = Field(default_factory=list, max_length=100)
    description: str = Field(default="", max_length=200000)
    search_text: str = Field(default="", max_length=30000)
    detail_ref: dict[str, str] | None = None

    @field_validator("source_url")
    @classmethod
    def public_link(cls, value):
        parsed = urlsplit(value)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("An HTTP(S) source URL without credentials is required")
        return value


class PublicCompany(Contract):
    id: str = Field(min_length=1, max_length=300)
    name: str = Field(min_length=1, max_length=160)
    careers_url: str | None = Field(default=None, max_length=2000, pattern=r"^https?://")


class FavouritesTransfer(Contract):
    format: Literal["jobhound-board-favourites"]
    version: Literal[1]
    exported_at: str = Field(max_length=100)
    jobs: list[PublicJob] = Field(default_factory=list, max_length=500)
    companies: list[PublicCompany] = Field(default_factory=list, max_length=500)
    omitted_local_jobs: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def bounded_transfer(self):
        if len(self.model_dump_json().encode("utf-8")) > 8 * 1024 * 1024:
            raise ValueError("Favourites transfer exceeds 8 MiB")
        return self


class FavouritesImport(Contract):
    transfer: FavouritesTransfer
    preview_token: str = Field(min_length=32, max_length=100)
    actor_type: Literal["human", "agent"] = "human"


class SavedUpdate(Contract):
    saved: bool
    actor_type: Literal["human", "agent"] = "human"


class BoardQuery(Contract):
    query: str = Field(default="", max_length=500)
    location: str = Field(default="", max_length=500)
    company_ids: list[str] = Field(default_factory=list, max_length=100)
    collection_ids: list[str] = Field(default_factory=list, max_length=100)
    work_modes: list[Literal["remote", "hybrid", "onsite", "unknown"]] = Field(default_factory=list, max_length=4)
    employment_types: list[str] = Field(default_factory=list, max_length=30)
    salary_listed: bool = False
    posted_within_days: Literal[1, 7, 30] | None = None
    sort: Literal["newest", "oldest", "title", "company"] = "newest"
    view: Literal["all", "saved", "favourite_companies"] = "all"
    limit: int = Field(default=25, ge=1, le=100)
    offset: int = Field(default=0, ge=0)
