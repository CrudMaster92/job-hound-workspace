"""Typed local tracker workspace contracts shared by HTTP and MCP."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid")

class FavouriteRequest(Contract):
    name: str = Field(min_length=1, max_length=160)
    favourite: bool
    catalog_company_id: str | None = Field(default=None, min_length=1, max_length=300)
    careers_url: str | None = Field(default=None, pattern=r"^https?://", max_length=2000)
    collection_id: str | None = Field(default=None, max_length=300)
    company_id: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def identity(self):
        if not self.catalog_company_id and not self.careers_url and self.company_id is None:
            raise ValueError("Provide a catalog company ID or careers URL")
        return self

class BatchRequest(Contract):
    request_id: str = Field(min_length=1, max_length=160)
    company_ids: list[int] | None = Field(default=None, min_length=1, max_length=200)

    @model_validator(mode="after")
    def positive_ids(self):
        if self.company_ids and any(value < 1 for value in self.company_ids):
            raise ValueError("Company IDs must be positive")
        return self

class MonitorStateRequest(Contract):
    action: Literal["pause", "resume", "archive", "restore"]

class MonitorDeleteRequest(Contract):
    confirm_name: str = Field(min_length=1, max_length=160)
    delete_applications: bool = False

TRACKER_SCHEMA = """
CREATE TABLE IF NOT EXISTS tracker_favourites (
  company_key TEXT PRIMARY KEY, details_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS scraper_batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL UNIQUE,
  selection_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS scraper_batch_items (
  batch_id INTEGER NOT NULL REFERENCES scraper_batches(id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL, company_name TEXT NOT NULL,
  run_id INTEGER REFERENCES runs(id) ON DELETE SET NULL, skip_reason TEXT,
  PRIMARY KEY(batch_id, company_id)
);
"""
