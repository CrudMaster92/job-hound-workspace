"""Bounded adapters for using a user's locally authenticated agent subscription."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Callable, Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .agent_instructions import compose_chat_prompt
from .artifacts.contracts import ArtifactProposal
from .library import LibraryRequest
from .chat_jobs import JobRequest
from .ai_connections.validation import json_schema
from .career_document_drafts import CareerDocumentDraftContent
from .dashboard_widgets import WidgetAgentAnswer, widget_agent_provider_schema, widget_prompt


class MonitorSuggestion(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=160)
    careers_url: str
    reason: str
    create_now: bool

    @field_validator("careers_url")
    @classmethod
    def public_url(cls, value: str) -> str:
        parsed = urlsplit(value.strip())
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
            raise ValueError("careers_url must be an absolute HTTP(S) URL")
        return value.strip()


class MonitorAction(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: Literal["rebuild", "repair"]
    company_id: int = Field(ge=1)
    reason: str = Field(min_length=1, max_length=1000)
    execute_now: bool


class ChatSource(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=240)
    url: str

    @field_validator("url")
    @classmethod
    def source_url(cls, value: str) -> str:
        value = value.strip()
        if re.fullmatch(r"/documents\?(?:document=[1-9]\d*|interview=[1-9]\d*(?:&time=\d+(?:\.\d+)?)?)", value):
            return value
        parsed = urlsplit(value)
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
            raise ValueError("source URL must be HTTP(S) or a JobHound document reference")
        return value


class AgentAnswer(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reply: str
    artifact_requests: list[ArtifactProposal] = Field(default_factory=list, max_length=5)
    library_requests: list[LibraryRequest] = Field(default_factory=list, max_length=3)
    job_requests: list[JobRequest] = Field(default_factory=list, max_length=3)
    suggestions: list[MonitorSuggestion] = Field(max_length=12)
    actions: list[MonitorAction] = Field(max_length=4)
    sources: list[ChatSource] = Field(max_length=20)


class DocumentAgentAnswer(BaseModel):
    """Structured response for the persistent career-document chat skill."""

    model_config = ConfigDict(extra="forbid")

    reply: str
    artifact_requests: list[ArtifactProposal] = Field(default_factory=list, max_length=5)
    library_requests: list[LibraryRequest] = Field(default_factory=list, max_length=3)
    job_requests: list[JobRequest] = Field(default_factory=list, max_length=3)
    draft: CareerDocumentDraftContent | None = None
    suggestions: list[MonitorSuggestion] = Field(default_factory=list, max_length=0)
    actions: list[MonitorAction] = Field(default_factory=list, max_length=0)
    sources: list[ChatSource] = Field(max_length=20)


class ChatProviderError(RuntimeError):
    pass


Runner = Callable[..., subprocess.CompletedProcess[str]]


class LocalAgentProvider:
    """Runs one constrained agent turn without reading or handling provider credentials."""

    EXECUTABLES = {"codex": "codex", "hermes": "hermes", "claude": "claude", "openclaw": "openclaw"}

    def __init__(self, runner: Runner = subprocess.run) -> None:
        self.runner = runner

    def statuses(self) -> list[dict[str, Any]]:
        results = []
        for provider, command in self.EXECUTABLES.items():
            executable = shutil.which(command)
            results.append({"id": provider, "label": provider.title(), "available": bool(executable),
                            "detail": "Local command found" if executable else f"{command} is not installed"})
        return results

    def run(self, *, provider: str, model: str | None, browsing: bool, message: str,
            history: list[dict[str, Any]], context: dict[str, Any],
            instructions: dict[str, str] | None = None) -> dict[str, Any]:
        executable = shutil.which(self.EXECUTABLES.get(provider, ""))
        if not executable:
            raise ChatProviderError(f"{provider.title()} is not installed or is not on PATH")
        answer_model = self._answer_model(context)
        schema = json_schema(
            widget_agent_provider_schema() if answer_model is WidgetAgentAnswer else answer_model
        )
        prompt = self._prompt(message, history, context, browsing, instructions)
        with tempfile.TemporaryDirectory(prefix="jobhound-chat-") as temp_dir:
            schema_path = Path(temp_dir, "answer-schema.json")
            output_path = Path(temp_dir, "answer.json")
            schema_path.write_text(json.dumps(schema), encoding="utf-8")
            if provider == "codex":
                command = [executable, "exec", "-", "--ephemeral", "--sandbox", "read-only", "--skip-git-repo-check",
                           "--output-schema", str(schema_path), "--output-last-message", str(output_path)]
                if model:
                    command[2:2] = ["--model", model]
                result = self.runner(
                    command, input=prompt, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=240,
                )
                raw = output_path.read_text(encoding="utf-8") if output_path.exists() else ""
            elif provider == "hermes":
                command = [executable, "--oneshot", prompt, "--safe-mode"]
                if model:
                    command.extend(["--model", model])
                result = self.runner(
                    command, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=240,
                )
                raw = result.stdout
            elif provider == "claude":
                command = [executable, "-p", prompt, "--output-format", "text", "--permission-mode", "plan"]
                if model:
                    command.extend(["--model", model])
                result = self.runner(
                    command, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=240,
                )
                raw = result.stdout
            else:
                command = [executable, "agent", "--message", prompt, "--json"]
                result = self.runner(
                    command, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=240,
                )
                raw = result.stdout
            if result.returncode != 0:
                raise ChatProviderError((result.stderr or result.stdout or "Agent command failed")[-2000:])
            try:
                payload = self._extract_json(raw)
                return answer_model.model_validate(payload).model_dump(mode="json")
            except (ValueError, json.JSONDecodeError) as exc:
                raise ChatProviderError(f"{provider.title()} returned an invalid structured response: {exc}") from exc

    @staticmethod
    def _extract_json(raw: str) -> dict[str, Any]:
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            start, end = raw.find("{"), raw.rfind("}")
            if start < 0 or end <= start:
                raise
            value = json.loads(raw[start:end + 1])
        if isinstance(value, dict) and isinstance(value.get("result"), str):
            return LocalAgentProvider._extract_json(value["result"])
        return value

    @staticmethod
    def _answer_model(context: dict[str, Any]):
        command = context.get("active_command") or {}
        if command.get("id") == "create_widget":
            return WidgetAgentAnswer
        return DocumentAgentAnswer if command.get("id") == "edit_document" else AgentAnswer

    @staticmethod
    def _prompt(message: str, history: list[dict[str, Any]], context: dict[str, Any],
                browsing: bool, instructions: dict[str, str] | None = None) -> str:
        answer_model = LocalAgentProvider._answer_model(context)
        if answer_model is WidgetAgentAnswer:
            return widget_prompt(message, current_draft=context.get("current_widget_draft"))
        return compose_chat_prompt(
            message, history, context, browsing, instructions,
            output_schema=json_schema(answer_model),
        )
