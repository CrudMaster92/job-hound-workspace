"""Shared presentation and validation for external job-platform profiles."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any


def validate_visibility(definition: dict[str, Any], visibility: str) -> None:
    allowed = ({"unknown", "not_visible", "recruiters_only", "all_members"}
               if definition.get("visibility_scheme") == "linkedin"
               else {"unknown", "not_visible", "visible"})
    if visibility not in allowed:
        raise ValueError(f"unsupported {definition.get('name', 'platform')} visibility state")


def present_profile(value: dict[str, Any], definition: dict[str, Any] | None = None, *, enabled: bool = True) -> dict[str, Any]:
    platform = str(value["platform"])
    definition = definition or {
        "id": platform, "name": platform.replace("-", " ").title(), "home_url": "",
        "profile_url": "", "description": "", "industry_keywords": [],
        "location_keywords": [], "countries": [], "regions": [], "work_types": [],
        "discovery_type": "recruiter database", "visibility_scheme": "binary",
        "catalog_missing": True,
    }
    confirmed_at = value.get("confirmed_at")
    reminder_days = int(value.get("reminder_days") or 0)
    next_review_at = None
    reminder_due = confirmed_at is None
    if confirmed_at and reminder_days:
        confirmed = datetime.fromisoformat(str(confirmed_at).replace("Z", "+00:00"))
        next_review = confirmed + timedelta(days=reminder_days)
        next_review_at = next_review.isoformat()
        reminder_due = next_review <= datetime.now(timezone.utc)
    elif confirmed_at:
        reminder_due = False
    return {
        **value,
        **definition,
        "platform": platform,
        "label": definition["name"],
        "settings_url": definition.get("profile_url", ""),
        "settings_label": "Manage profile visibility",
        "next_review_at": next_review_at,
        "reminder_due": enabled and reminder_due,
    }


def present_profiles(values: list[dict[str, Any]], definitions: list[dict[str, Any]], *, enabled: bool = True) -> dict[str, Any]:
    by_id = {item["id"]: item for item in definitions}
    profiles = [present_profile(value, by_id.get(str(value["platform"])), enabled=enabled) for value in values]
    profiles.sort(key=lambda item: (
        {"linkedin": 0, "indeed": 1}.get(item["platform"], 2), item["label"].casefold()
    ))
    return {
        "profile_visibility_enabled": enabled,
        "profiles": profiles,
        "reminders_due": sum(1 for item in profiles if item["reminder_due"]),
        "disclaimer": "Visibility is user- or agent-confirmed and is not independently verified by JobHound.",
    }
