"""Portable, validated company-and-scraper presets."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator, model_validator

from .db import Database, iso_now, normalize
from .scrapers import ScraperRecipe
from .scheduler import next_occurrence
from .preset_catalog_client import PresetCatalogClient, PresetCatalogError


class PresetCompany(BaseModel):
    model_config = ConfigDict(extra="forbid")

    key: str = Field(min_length=1, max_length=80, pattern=r"^[a-z0-9][a-z0-9-]*$")
    name: str = Field(min_length=1, max_length=160)
    careers_url: HttpUrl
    logo_url: HttpUrl | None = None
    recipe: ScraperRecipe

    @model_validator(mode="after")
    def recipe_matches_company(self) -> "PresetCompany":
        if canonical_url(str(self.careers_url)) != canonical_url(self.recipe.careers_url):
            raise ValueError("recipe careers_url must match the company careers_url")
        return self


class PresetManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    format: str = Field(default="jobhound-preset", pattern=r"^jobhound-preset$")
    version: int = Field(default=1, ge=1, le=1)
    id: str = Field(min_length=1, max_length=80, pattern=r"^[a-z0-9][a-z0-9-]*$")
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=600)
    tags: list[str] = Field(default_factory=list, max_length=20)
    companies: list[PresetCompany] = Field(min_length=1, max_length=200)

    @field_validator("tags")
    @classmethod
    def clean_tags(cls, values: list[str]) -> list[str]:
        cleaned: list[str] = []
        for raw in values:
            value = " ".join(raw.split()).strip()[:40]
            if value and value.casefold() not in {item.casefold() for item in cleaned}:
                cleaned.append(value)
        return cleaned

    @model_validator(mode="after")
    def unique_companies(self) -> "PresetManifest":
        keys = [item.key for item in self.companies]
        urls = [canonical_url(str(item.careers_url)) for item in self.companies]
        if len(keys) != len(set(keys)):
            raise ValueError("company keys must be unique")
        if len(urls) != len(set(urls)):
            raise ValueError("company careers URLs must be unique")
        return self


class CatalogPresetCompany(BaseModel):
    model_config = ConfigDict(extra="forbid")

    key: str
    catalog_company_id: str
    catalog_monitor_id: str
    catalog_revision: int = Field(ge=1)
    name: str
    legal_name: str | None = None
    aliases: list[str] = Field(default_factory=list)
    careers_url: HttpUrl
    logo_url: HttpUrl | None = None
    recipe: ScraperRecipe
    verification: dict[str, Any]

    @model_validator(mode="after")
    def recipe_matches_monitor(self) -> "CatalogPresetCompany":
        if canonical_url(str(self.careers_url)) != canonical_url(self.recipe.careers_url):
            raise ValueError("catalog recipe careers_url must match its monitor")
        return self


class CatalogPresetManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    format: str = Field(pattern=r"^jobhound-preset$")
    version: int = Field(ge=2, le=2)
    id: str
    revision: int = Field(ge=1)
    name: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    facets: dict[str, Any] = Field(default_factory=dict)
    suggested_criteria: dict[str, list[str]] = Field(default_factory=dict)
    source: dict[str, Any] | None = None
    companies: list[CatalogPresetCompany]


class PresetInstallRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    company_keys: list[str] = Field(min_length=1, max_length=200)
    request_id: str = Field(min_length=8, max_length=120)


class CatalogSelectionItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    company_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")
    monitor_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{0,99}$")
    revision: int = Field(ge=1)


class CatalogSelectionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    format: str = Field(default="jobhound-catalog-install", pattern=r"^jobhound-catalog-install$")
    version: int = Field(default=1, ge=1, le=1)
    catalog_version: int = Field(default=3, ge=3, le=3)
    source_commit: str | None = Field(default=None, max_length=100)
    mode: str = Field(pattern=r"^(collection|monitors)$")
    collection_id: str | None = Field(default=None, pattern=r"^[a-z0-9][a-z0-9-]{0,79}$")
    selections: list[CatalogSelectionItem] = Field(min_length=1, max_length=200)

    @model_validator(mode="after")
    def valid_selection(self) -> "CatalogSelectionRequest":
        if (self.mode == "collection") != bool(self.collection_id):
            raise ValueError("collection mode requires collection_id; monitor mode forbids it")
        identities = [(item.company_id, item.monitor_id) for item in self.selections]
        if len(identities) != len(set(identities)):
            raise ValueError("catalog selections must be unique")
        return self


class CatalogSelectionInstallRequest(CatalogSelectionRequest):
    request_id: str = Field(min_length=8, max_length=120)


class PresetExportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1, max_length=80, pattern=r"^[a-z0-9][a-z0-9-]*$")
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=600)
    tags: list[str] = Field(default_factory=list, max_length=20)
    company_ids: list[int] = Field(min_length=1, max_length=200)


class PresetVisibilityRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    hidden: bool


class PresetRemovalRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    confirm_name: str = Field(min_length=1, max_length=120)
    delete_applications: bool = False


def canonical_url(value: str) -> str:
    parsed = urlsplit(value.strip())
    path = parsed.path.rstrip("/") or "/"
    return urlunsplit((parsed.scheme.casefold(), parsed.netloc.casefold(), path, parsed.query, ""))


def slug(value: str, fallback: str = "company") -> str:
    result = re.sub(r"[^a-z0-9]+", "-", value.casefold()).strip("-")
    return (result or fallback)[:80]


class PresetService:
    def __init__(self, db: Database, scheduler: Any, catalog_client: PresetCatalogClient | None = None) -> None:
        self.db = db
        self.scheduler = scheduler
        self.builtin_directory = Path(__file__).with_name("preset_catalog")
        self.catalog_client = catalog_client or PresetCatalogClient(Path(db.path).parent)

    def _catalog_existing(self, monitor_id: str, careers_url: str, names: list[str],
                          active: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
        exact = self.db.find_company_by_catalog_monitor(monitor_id)
        if exact:
            return exact
        candidate = active.get(canonical_url(careers_url))
        if not candidate or self.db.get_catalog_source(int(candidate["id"])):
            return None
        accepted = {normalize(value) for value in names if value}
        return candidate if normalize(str(candidate.get("name") or "")) in accepted else None

    def _remote_catalog(self, *, force: bool = False) -> dict[str, Any] | None:
        try:
            return self.catalog_client.refresh(force=force)
        except PresetCatalogError as exc:
            self._catalog_error = str(exc)[:500]
            return None

    def _remote(self, preset_id: str, selected_keys: set[str] | None = None) -> CatalogPresetManifest | None:
        try:
            catalog = self.catalog_client.refresh()
            summary = next(item for item in catalog["collections"] if item.get("id") == preset_id)
            detail = self.catalog_client.get_collection(preset_id)
            companies = []
            for member in self.catalog_client.get_collection_members(preset_id):
                for monitor_ref in member.get("monitors", []):
                    if selected_keys is not None and monitor_ref.get("id") not in selected_keys:
                        continue
                    monitor = self.catalog_client.get_monitor(monitor_ref)
                    companies.append({
                        "key": monitor["id"], "catalog_company_id": member["company_id"],
                        "catalog_monitor_id": monitor["id"], "catalog_revision": monitor["revision"],
                        "name": member["name"], "legal_name": member.get("legal_name"),
                        "aliases": member.get("aliases", []), "careers_url": monitor["careers_url"], "logo_url": member.get("logo_url"),
                        "recipe": monitor["recipe"], "verification": monitor["verification"],
                    })
            return CatalogPresetManifest.model_validate({
                "format": "jobhound-preset", "version": 2, "id": detail["id"],
                "revision": detail["revision"], "name": detail["name"],
                "description": detail.get("description", ""), "tags": detail.get("tags", []),
                "facets": detail.get("facets", {}),
                "suggested_criteria": detail.get("suggested_criteria", {}),
                "source": detail.get("source"), "companies": companies,
            })
        except Exception as exc:
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            return None

    def _builtin(self, preset_id: str) -> PresetManifest | None:
        path = self.builtin_directory / f"{preset_id}.json"
        if not path.is_file():
            return None
        return PresetManifest.model_validate_json(path.read_text(encoding="utf-8"))

    def _imported(self, preset_id: str) -> PresetManifest | None:
        with self.db.connect() as connection:
            row = connection.execute(
                "SELECT manifest_json FROM imported_presets WHERE preset_id=?", (preset_id,)
            ).fetchone()
        return PresetManifest.model_validate_json(row[0]) if row else None

    def get_manifest(self, preset_id: str, selected_keys: set[str] | None = None) -> PresetManifest | CatalogPresetManifest:
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,79}", preset_id):
            raise KeyError(preset_id)
        value = self._remote(preset_id, selected_keys) or self._builtin(preset_id) or self._imported(preset_id)
        if not value:
            raise KeyError(preset_id)
        return value

    def get_preset_page(self, preset_id: str, *, limit: int = 50, cursor: str | None = None) -> dict[str, Any]:
        offset = int(cursor or 0)
        if offset < 0:
            raise ValueError("Invalid preset cursor")
        catalog = self._remote_catalog()
        entry = next((item for item in (catalog or {}).get("collections", []) if item.get("id") == preset_id), None)
        if entry:
            members = self.catalog_client.get_collection_members(preset_id)
            active = {canonical_url(str(item.get("careers_url") or "")): item
                      for item in self.db.list_companies(include_archived=True)}
            companies = []
            for member in members:
                for monitor in member.get("monitors", []):
                    existing = self._catalog_existing(
                        str(monitor.get("id") or ""), str(monitor.get("careers_url") or ""),
                        [str(member.get("name") or ""), str(member.get("legal_name") or ""),
                         *map(str, member.get("aliases") or [])], active,
                    )
                    source = self.db.get_catalog_source(int(existing["id"])) if existing else None
                    companies.append({
                        "key": monitor["id"], "name": member["name"],
                        "careers_url": monitor["careers_url"], "logo_url": member.get("logo_url"),
                        "adapter": monitor["adapter"], "catalog_company_id": member["company_id"],
                        "catalog_monitor_id": monitor["id"], "catalog_revision": monitor["revision"],
                        "verification": monitor.get("verification"),
                        "parent": member.get("parent"), "facets": member.get("facets", {}),
                        "existing_company_id": existing.get("id") if existing else None,
                        "status": "archived" if existing and existing.get("archived_at") else "installed" if existing else "available",
                        "update_available": bool(source and int(monitor["revision"]) > int(source.get("installed_revision") or 0)),
                    })
            page = companies[offset:offset + limit]
            return {**entry, "source": "catalog", "companies": page,
                    "source_commit": catalog.get("source_commit"),
                    "catalog_status": catalog.get("catalog_status", "current"),
                    "catalog_error": catalog.get("catalog_error"),
            "catalog_source": catalog.get("catalog_source", "live_or_cache"),
            "catalog_generated_at": catalog.get("generated_at"),
                    "next_cursor": str(offset + limit) if offset + limit < len(companies) else None}
        manifest = self._builtin(preset_id) or self._imported(preset_id)
        if not manifest:
            raise KeyError(preset_id)
        active = {canonical_url(str(item.get("careers_url") or "")): item
                  for item in self.db.list_companies(include_archived=True)}
        rows = []
        for item in manifest.companies:
            existing = active.get(canonical_url(str(item.careers_url)))
            rows.append({"key": item.key, "name": item.name, "careers_url": str(item.careers_url),
                         "logo_url": str(item.logo_url) if item.logo_url else None,
                         "adapter": item.recipe.strategy, "existing_company_id": existing.get("id") if existing else None,
                         "status": "archived" if existing and existing.get("archived_at") else "installed" if existing else "available"})
        page = rows[offset:offset + limit]
        return {"id": manifest.id, "name": manifest.name, "description": manifest.description,
                "tags": manifest.tags, "source": "builtin" if self._builtin(preset_id) else "imported",
                "company_count": len(rows), "companies": page,
                "next_cursor": str(offset + limit) if offset + limit < len(rows) else None}

    def list_presets(self, *, query: str = "", collection_type: str = "", industry: str = "",
                     role_family: str = "", city: str = "", adapter: str = "",
                     force_refresh: bool = False) -> dict[str, Any]:
        manifests: list[tuple[PresetManifest, str]] = []
        for path in sorted(self.builtin_directory.glob("*.json")):
            manifests.append((PresetManifest.model_validate_json(path.read_text(encoding="utf-8")), "builtin"))
        with self.db.connect() as connection:
            rows = connection.execute(
                "SELECT manifest_json FROM imported_presets ORDER BY name COLLATE NOCASE"
            ).fetchall()
        manifests.extend((PresetManifest.model_validate_json(row[0]), "imported") for row in rows)
        active = {
            canonical_url(str(item.get("careers_url") or "")): item
            for item in self.db.list_companies(include_archived=True)
        }
        states = {item["preset_id"]: item for item in self.db.list_preset_pack_states()}
        items = []
        for manifest, source in manifests:
            companies = []
            for item in manifest.companies:
                existing = active.get(canonical_url(str(item.careers_url)))
                companies.append({
                    "key": item.key, "name": item.name,
                    "careers_url": str(item.careers_url), "logo_url": str(item.logo_url) if item.logo_url else None,
                    "adapter": item.recipe.strategy,
                    "existing_company_id": existing.get("id") if existing else None,
                    "status": (
                        "archived" if existing and existing.get("archived_at")
                        else "installed" if existing else "available"
                    ),
                })
            items.append({
                "id": manifest.id, "name": manifest.name,
                "description": manifest.description, "tags": manifest.tags,
                "source": source, "company_count": len(companies), "companies": companies,
                "installed_locally": manifest.id in states,
                "hidden": bool(states.get(manifest.id, {}).get("hidden_at")),
                "member_count": int(states.get(manifest.id, {}).get("member_count") or 0),
            })
        remote = self._remote_catalog(force=force_refresh)
        if remote:
            search_companies = self.catalog_client.get_search_companies() if query else []
            matching_collections = {collection_id for company in search_companies
                                    if query.casefold() in " ".join([str(company.get("name") or ""), str(company.get("legal_name") or ""), *map(str, company.get("aliases") or [])]).casefold()
                                    for collection_id in company.get("collection_ids", [])}
            for entry in remote.get("collections", []):
                companies = []
                if adapter:
                    companies = [monitor for member in self.catalog_client.get_collection_members(entry["id"])
                                 for monitor in member.get("monitors", []) if monitor.get("adapter") == adapter]
                query_match = (not query or query.casefold() in " ".join([
                    str(entry.get("name") or ""), str(entry.get("description") or ""),
                    *map(str, entry.get("tags") or [])]).casefold() or entry["id"] in matching_collections)
                value = {
                    **entry, "source": "catalog", "companies": companies,
                    "query_match": query_match,
                    "installed_locally": entry["id"] in states,
                    "hidden": bool(states.get(entry["id"], {}).get("hidden_at")),
                    "member_count": int(states.get(entry["id"], {}).get("member_count") or 0),
                }
                items = [item for item in items if item["id"] != entry["id"]]
                if query_match:
                    items.append(value)
        folded = query.casefold().strip()
        def matches(item: dict[str, Any]) -> bool:
            facets = item.get("facets") or {}
            locations = facets.get("locations") or []
            haystack = " ".join([str(item.get("name") or ""), str(item.get("description") or ""),
                                  *map(str, item.get("tags") or []),
                                  *[str(company.get("name") or "") for company in item.get("companies") or []]]).casefold()
            return (
                (not folded or item.get("query_match") or folded in haystack)
                and (not collection_type or collection_type in (facets.get("collection_types") or []))
                and (not industry or industry in (facets.get("industries") or []))
                and (not role_family or role_family in (facets.get("role_families") or []))
                and (not city or any(str(value.get("city") or "").casefold() == city.casefold() for value in locations))
                and (not adapter or any(str(company.get("adapter") or "") == adapter for company in item.get("companies") or []))
            )
        items = sorted((item for item in items if matches(item)), key=lambda item: str(item["name"]).casefold())
        return {"items": items, "count": len(items), "community_status": "available" if remote and remote.get("catalog_source") != "release_snapshot" else "offline",
                "catalog_status": remote.get("catalog_status") if remote else "unavailable",
                "catalog_error": remote.get("catalog_error") if remote else getattr(self, "_catalog_error", "Public catalog is unavailable; bundled and imported presets remain usable."),
                "catalog_source": remote.get("catalog_source", "live_or_cache") if remote else None,
                "catalog_generated_at": remote.get("generated_at") if remote else None,
                "snapshot_captured_at": remote.get("snapshot_captured_at") if remote else None,
                "source_commit": remote.get("source_commit") if remote else None}

    @staticmethod
    def _catalog_haystack(company: dict[str, Any]) -> str:
        facets = company.get("facets") or {}
        return " ".join(map(str, [
            company.get("name") or "", company.get("legal_name") or "",
            *(company.get("aliases") or []), *(facets.get("industries") or []),
            *(facets.get("specialties") or []), *(facets.get("tags") or []),
        ])).casefold()

    def discovery_catalog(self, *, force_refresh: bool = False) -> dict[str, Any]:
        """Return compact catalog references for deterministic recommendation ranking."""
        catalog = self.catalog_client.refresh(force=force_refresh)
        return {
            "catalog": catalog,
            "companies": self.catalog_client.get_search_companies(force=force_refresh),
        }

    def discovery_company(self, reference: dict[str, Any]) -> dict[str, Any]:
        """Resolve one ranked company and add local install state without fetching its recipe."""
        detail = self.catalog_client.get_company(reference)
        monitors = []
        active = {canonical_url(str(item.get("careers_url") or "")): item
                  for item in self.db.list_companies(include_archived=True)}
        for monitor in detail.get("monitors", []):
            existing = self._catalog_existing(
                str(monitor.get("id") or ""), str(monitor.get("careers_url") or ""),
                [str(detail.get("name") or ""), str(detail.get("legal_name") or ""),
                 *map(str, detail.get("aliases") or [])], active,
            )
            monitors.append({
                **monitor,
                "existing_company_id": existing.get("id") if existing else None,
                "status": "archived" if existing and existing.get("archived_at") else
                          "installed" if existing else "available",
            })
        return {**detail, "monitors": monitors}

    def discovery_collection(self, collection_id: str) -> dict[str, Any]:
        """Resolve every compact member page for one recommended collection, without recipes."""
        active = {canonical_url(str(item.get("careers_url") or "")): item
                  for item in self.db.list_companies(include_archived=True)}
        companies = []
        for member in self.catalog_client.get_collection_members(collection_id):
            monitors = []
            for monitor in member.get("monitors", []):
                existing = self._catalog_existing(
                    str(monitor.get("id") or ""), str(monitor.get("careers_url") or ""),
                    [str(member.get("name") or ""), str(member.get("legal_name") or ""),
                     *map(str, member.get("aliases") or [])], active,
                )
                monitors.append({
                    **monitor,
                    "existing_company_id": existing.get("id") if existing else None,
                    "status": "archived" if existing and existing.get("archived_at") else
                              "installed" if existing else "available",
                })
            companies.append({**member, "monitors": monitors})
        return {"companies": companies}

    def search_catalog_companies(self, *, query: str = "", industry: str = "",
                                 specialty: str = "", tag: str = "", collection_id: str = "",
                                 adapter: str = "", verification: str = "", limit: int = 50,
                                 cursor: str | None = None, force_refresh: bool = False) -> dict[str, Any]:
        catalog = self.catalog_client.refresh(force=force_refresh)
        companies = self.catalog_client.get_search_companies(force=force_refresh)
        folded = query.casefold().strip()

        def matches(company: dict[str, Any]) -> bool:
            facets = company.get("facets") or {}
            return (
                (not folded or folded in self._catalog_haystack(company))
                and (not industry or industry in (facets.get("industries") or []))
                and (not specialty or specialty in (facets.get("specialties") or []))
                and (not tag or tag.casefold() in {str(value).casefold() for value in facets.get("tags") or []})
                and (not collection_id or collection_id in (company.get("collection_ids") or []))
                and (not adapter or adapter in (company.get("adapters") or []))
                and (not verification or verification in (company.get("verification_statuses") or []))
            )

        filtered = sorted((item for item in companies if matches(item)),
                          key=lambda item: (str(item.get("name") or "").casefold(), str(item.get("id") or "")))
        try:
            offset = int(cursor or 0)
        except ValueError as exc:
            raise ValueError("Invalid catalog company cursor") from exc
        if offset < 0:
            raise ValueError("Invalid catalog company cursor")
        page = []
        active = {canonical_url(str(item.get("careers_url") or "")): item
                  for item in self.db.list_companies(include_archived=True)}
        for reference in filtered[offset:offset + limit]:
            detail = self.catalog_client.get_company(reference, force=force_refresh)
            monitors = []
            for monitor in detail.get("monitors", []):
                existing = self._catalog_existing(
                    str(monitor.get("id") or ""), str(monitor.get("careers_url") or ""),
                    [str(detail.get("name") or ""), str(detail.get("legal_name") or ""),
                     *map(str, detail.get("aliases") or [])], active,
                )
                monitors.append({
                    **monitor,
                    "existing_company_id": existing.get("id") if existing else None,
                    "status": "archived" if existing and existing.get("archived_at") else
                              "installed" if existing else "available",
                })
            page.append({**reference, "logo_url": detail.get("logo_url"),
                         "website_url": detail.get("website_url"), "monitors": monitors})
        return {
            "items": page, "count": len(page), "total": len(filtered),
            "next_cursor": str(offset + limit) if offset + limit < len(filtered) else None,
            "catalog_status": catalog.get("catalog_status", "current"),
            "catalog_error": catalog.get("catalog_error"),
            "catalog_source": catalog.get("catalog_source", "live_or_cache"),
            "catalog_generated_at": catalog.get("generated_at"),
            "source_commit": catalog.get("source_commit"),
        }

    def _resolve_catalog_selection(self, request: CatalogSelectionRequest) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        catalog = self.catalog_client.refresh()
        if request.source_commit and request.source_commit != catalog.get("source_commit"):
            try:
                catalog = self.catalog_client.refresh(force=True)
            except PresetCatalogError:
                pass
        references = {item.get("id"): item for item in self.catalog_client.get_search_companies()}
        allowed: set[tuple[str, str]] | None = None
        collection_name = None
        if request.collection_id:
            detail = self.catalog_client.get_collection(request.collection_id)
            collection_name = detail.get("name")
            allowed = {
                (str(member.get("company_id") or ""), str(monitor.get("id") or ""))
                for member in self.catalog_client.get_collection_members(request.collection_id)
                for monitor in member.get("monitors", [])
            }
        resolved: list[dict[str, Any]] = []
        unavailable: list[dict[str, Any]] = []
        company_cache: dict[str, dict[str, Any]] = {}
        for selection in request.selections:
            identity = (selection.company_id, selection.monitor_id)
            if allowed is not None and identity not in allowed:
                unavailable.append({**selection.model_dump(), "reason": "not_in_collection"})
                continue
            reference = references.get(selection.company_id)
            if not reference:
                unavailable.append({**selection.model_dump(), "reason": "company_unavailable"})
                continue
            if selection.company_id not in company_cache:
                company_cache[selection.company_id] = self.catalog_client.get_company(reference)
            company = company_cache[selection.company_id]
            monitor = next((item for item in company.get("monitors", [])
                            if item.get("id") == selection.monitor_id), None)
            if not monitor:
                unavailable.append({**selection.model_dump(), "reason": "monitor_unavailable"})
                continue
            active = {canonical_url(str(item.get("careers_url") or "")): item
                      for item in self.db.list_companies(include_archived=True)}
            existing = self._catalog_existing(
                selection.monitor_id, str(monitor.get("careers_url") or ""),
                [str(company.get("name") or ""), str(company.get("legal_name") or ""),
                 *map(str, company.get("aliases") or [])], active,
            )
            resolved.append({
                "company_id": selection.company_id, "monitor_id": selection.monitor_id,
                "requested_revision": selection.revision, "revision": monitor.get("revision"),
                "changed": int(monitor.get("revision") or 0) != selection.revision,
                "name": company.get("name"), "legal_name": company.get("legal_name"),
                "logo_url": company.get("logo_url"), "website_url": company.get("website_url"),
                "adapter": monitor.get("adapter"), "careers_url": monitor.get("careers_url"),
                "verification": monitor.get("verification"), "monitor_reference": monitor,
                "existing_company_id": existing.get("id") if existing else None,
                "status": "archived" if existing and existing.get("archived_at") else
                          "installed" if existing else "available",
            })
        meta = {
            "format": request.format, "version": request.version, "catalog_version": 3,
            "mode": request.mode, "collection_id": request.collection_id,
            "collection_name": collection_name,
            "requested_source_commit": request.source_commit,
            "source_commit": catalog.get("source_commit"),
            "source_changed": bool(request.source_commit and request.source_commit != catalog.get("source_commit")),
            "catalog_status": catalog.get("catalog_status", "current"),
            "catalog_error": catalog.get("catalog_error"),
            "catalog_source": catalog.get("catalog_source", "live_or_cache"),
            "catalog_generated_at": catalog.get("generated_at"),
            "unavailable": unavailable,
        }
        return meta, resolved

    def preview_catalog_selection(self, request: CatalogSelectionRequest) -> dict[str, Any]:
        meta, resolved = self._resolve_catalog_selection(request)
        return {**meta, "items": [{key: value for key, value in item.items()
                                    if key != "monitor_reference"} for item in resolved],
                "count": len(resolved)}

    def install_catalog_selection(self, request: CatalogSelectionInstallRequest) -> dict[str, Any]:
        from .capabilities import require_local_scrapers
        require_local_scrapers()
        # A lost response must remain retryable even when the catalog is now offline
        # or has changed. Reuse the same persisted result before any remote reads.
        with self.db.connect() as connection:
            prior = connection.execute(
                "SELECT preset_id,result_json FROM preset_installations WHERE request_id=?",
                (request.request_id,),
            ).fetchone()
        if prior:
            result = json.loads(prior[1])
            return {**result, "kind": "catalog_selection"} if prior[0] == "catalog-selection" else result
        meta, resolved = self._resolve_catalog_selection(request)
        if meta["unavailable"]:
            raise ValueError("One or more selected catalog monitors are no longer available")
        if any(item["changed"] for item in resolved):
            raise ValueError("Catalog revisions changed; refresh and review the selection before installing")
        if request.mode == "collection" and request.collection_id:
            return self.install(request.collection_id, PresetInstallRequest(
                company_keys=[item.monitor_id for item in request.selections],
                request_id=request.request_id,
            ))
        companies = []
        for item in resolved:
            monitor = self.catalog_client.get_monitor(item["monitor_reference"])
            companies.append(CatalogPresetCompany.model_validate({
                "key": item["monitor_id"], "catalog_company_id": item["company_id"],
                "catalog_monitor_id": item["monitor_id"], "catalog_revision": monitor["revision"],
                "name": item["name"], "legal_name": item.get("legal_name"),
                "careers_url": monitor["careers_url"], "logo_url": item.get("logo_url"),
                "recipe": monitor["recipe"], "verification": monitor["verification"],
            }))
        result = self._install_items(
            preset_id="catalog-selection", preset_name="Catalog selection", companies=companies,
            requested_keys=[item.monitor_id for item in request.selections],
            request_id=request.request_id, create_memberships=False,
        )
        return {**result, "kind": "catalog_selection"}

    def import_manifest(self, raw: dict[str, Any]) -> dict[str, Any]:
        manifest = PresetManifest.model_validate(raw)
        if self._builtin(manifest.id):
            raise ValueError("A bundled preset already uses this id")
        payload = manifest.model_dump_json()
        now = iso_now()
        with self.db.connect() as connection:
            connection.execute(
                """INSERT INTO imported_presets(preset_id,name,manifest_json,created_at,updated_at)
                VALUES(?,?,?,?,?) ON CONFLICT(preset_id) DO UPDATE SET
                name=excluded.name,manifest_json=excluded.manifest_json,updated_at=excluded.updated_at""",
                (manifest.id, manifest.name, payload, now, now),
            )
        return next(item for item in self.list_presets()["items"] if item["id"] == manifest.id)

    def export_manifest(self, request: PresetExportRequest) -> dict[str, Any]:
        companies: list[PresetCompany] = []
        seen_keys: set[str] = set()
        for company_id in dict.fromkeys(request.company_ids):
            company = self.db.get_company(company_id)
            recipe = self.db.get_recipe(company_id) if company else None
            if not company or company.get("archived_at"):
                raise ValueError(f"Active company {company_id} was not found")
            if not recipe:
                raise ValueError(f"{company['name']} has no active scraper recipe")
            key = slug(str(company["name"]), f"company-{company_id}")
            suffix = 2
            base = key
            while key in seen_keys:
                key, suffix = f"{base}-{suffix}", suffix + 1
            seen_keys.add(key)
            companies.append(PresetCompany(
                key=key, name=company["name"], careers_url=company["careers_url"],
                logo_url=company.get("logo_url"),
                recipe=recipe["recipe"],
            ))
        return PresetManifest(
            id=request.id, name=request.name, description=request.description,
            tags=request.tags, companies=companies,
        ).model_dump(mode="json")

    def install(self, preset_id: str, request: PresetInstallRequest) -> dict[str, Any]:
        from .capabilities import require_local_scrapers
        require_local_scrapers()
        selected = set(request.company_keys)
        manifest = self.get_manifest(preset_id, selected)
        available = {item.key: item for item in manifest.companies}
        unknown = sorted(selected - set(available))
        if unknown:
            raise ValueError(f"Unknown company keys: {', '.join(unknown)}")
        return self._install_items(
            preset_id=manifest.id, preset_name=manifest.name,
            companies=list(manifest.companies), requested_keys=request.company_keys,
            request_id=request.request_id, create_memberships=True,
        )

    def _install_items(self, *, preset_id: str, preset_name: str,
                       companies: list[PresetCompany | CatalogPresetCompany],
                       requested_keys: list[str], request_id: str,
                       create_memberships: bool) -> dict[str, Any]:
        available = {item.key: item for item in companies}
        with self.db.connect() as connection:
            prior = connection.execute(
                "SELECT result_json FROM preset_installations WHERE request_id=?", (request_id,)
            ).fetchone()
        if prior:
            return json.loads(prior[0])

        settings = self.db.get_settings()
        existing = {
            canonical_url(str(item.get("careers_url") or "")): item
            for item in self.db.list_companies(include_archived=True)
        }
        installed: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        runs: list[dict[str, Any]] = []
        installation_id: int | None = None
        now = iso_now()
        with self.db.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO preset_installations
                (preset_id,preset_name,request_id,installed_at,result_json)
                VALUES(?,?,?,?,?)""", (preset_id, preset_name, request_id, now, "{}")
            )
            installation_id = int(cursor.lastrowid)

        for key in requested_keys:
            item = available[key]
            if isinstance(item, CatalogPresetCompany):
                match = self._catalog_existing(
                    item.catalog_monitor_id, str(item.careers_url),
                    [item.name, item.legal_name or "", *item.aliases], existing,
                )
            else:
                match = existing.get(canonical_url(str(item.careers_url)))
            if match and not match.get("archived_at"):
                skipped.append({"key": key, "company_id": match["id"], "reason": "already_installed"})
                if create_memberships:
                    self.db.upsert_preset_membership(
                        preset_id=preset_id, preset_name=preset_name, company_id=match["id"],
                        company_key=key, origin="matched_existing",
                    )
                if isinstance(item, CatalogPresetCompany):
                    prior_source = self.db.get_catalog_source(int(match["id"]))
                    if not prior_source:
                        # A URL match establishes identity, not proof that the local recipe already
                        # equals the catalog recipe. Keep revision zero so approval is still required.
                        self.db.set_catalog_source(match["id"], company_key=item.catalog_company_id,
                                                   monitor_id=item.catalog_monitor_id, revision=0,
                                                   sha256=None, source_commit=None)
                continue
            if match:
                self.db.update_company(match["id"], {"archived_at": None, "state": "active"})
                company = self.db.get_company(match["id"]) or match
                operation = "restored"
            else:
                company = self.db.create_company({
                    "name": item.name, "careers_url": str(item.careers_url),
                    "logo_url": str(item.logo_url) if item.logo_url else None,
                    "schedule_kind": settings["default_schedule_kind"],
                    "interval_hours": settings["default_interval_hours"],
                    "local_time": settings["default_local_time"],
                    "weekday": settings["default_weekday"],
                    "criteria": {name: {"mode": "inherit", "values": []}
                                 for name in ("cities", "title_terms", "keywords")},
                    "build_now": False,
                })
                operation = "installed"
            recipe = self.db.save_recipe(company["id"], item.recipe.model_dump(mode="json"),
                                         "Installed from preset", activate=True)
            run = self.scheduler.enqueue(company["id"], "scrape")
            if not run.get("reused"):
                run = self.db.update_run(run["id"], progress_detail_json={
                    "origin": "installation", "stage": "queued", "collection_name": preset_name,
                    "message": "Tracker installed; first check queued",
                }) or run
            runs.append(run)
            installed.append({
                "key": key, "company_id": company["id"], "name": item.name,
                "operation": operation, "recipe_version": recipe["version"], "run_id": run["id"],
            })
            if item.logo_url:
                self.db.update_company(company["id"], {"logo_url": str(item.logo_url)})
            if create_memberships:
                self.db.upsert_preset_membership(
                    preset_id=preset_id, preset_name=preset_name, company_id=company["id"],
                    company_key=key, origin=operation,
                )
            if isinstance(item, CatalogPresetCompany):
                catalog = self._remote_catalog() or {}
                self.db.set_catalog_source(company["id"], company_key=item.catalog_company_id,
                                           monitor_id=item.catalog_monitor_id, revision=item.catalog_revision,
                                           sha256=None, source_commit=catalog.get("source_commit"))
            with self.db.connect() as connection:
                connection.execute(
                    """INSERT INTO preset_installation_companies
                    (installation_id,company_id,company_key,installed_at)
                    VALUES(?,?,?,?)""", (installation_id, company["id"], key, now)
                )

        result = {
            "installation_id": installation_id, "preset_id": preset_id,
            "preset_name": preset_name, "installed": installed, "skipped": skipped,
            "runs": runs, "terminal": not bool(runs),
        }
        with self.db.connect() as connection:
            connection.execute(
                "UPDATE preset_installations SET result_json=? WHERE id=?",
                (json.dumps(result), installation_id),
            )
        return result

    def queue_catalog_update(self, company_id: int, *, request_id: str,
                             expected_revision: int) -> dict[str, Any]:
        from .capabilities import require_local_scrapers
        require_local_scrapers()
        prior = self.db.get_catalog_update_by_request(request_id)
        if prior:
            run = self.db.get_run(int(prior["run_id"]))
            return {"run": run, "catalog_update": prior}
        company = self.db.get_company(company_id)
        source = self.db.get_catalog_source(company_id)
        if not company or not source:
            raise KeyError(company_id)
        catalog = self._remote_catalog(force=True)
        if not catalog:
            raise RuntimeError("The curated preset catalog is unavailable")
        summary = None
        for collection in catalog.get("collections", []):
            for member in self.catalog_client.get_collection_members(collection["id"], force=True):
                for monitor in member.get("monitors", []):
                    if monitor.get("id") == source["catalog_monitor_id"]:
                        summary = {**monitor, "catalog_company_id": member["company_id"]}
                        break
                if summary:
                    break
            if summary:
                break
        if not summary:
            raise RuntimeError("This catalog monitor is no longer published")
        revision = int(summary.get("revision") or 0)
        if revision != expected_revision:
            raise ValueError(f"Catalog revision changed; review revision {revision} before approving")
        if revision <= int(source.get("installed_revision") or 0):
            raise ValueError("This monitor is already on the current catalog revision")
        monitor = self.catalog_client.get_monitor(summary, force=True)
        recipe = ScraperRecipe.model_validate(monitor["recipe"])
        candidate = self.db.save_recipe(company_id, recipe.model_dump(mode="json"),
                                        f"Curated catalog revision {revision}; awaiting validation", activate=False)
        run = self.scheduler.enqueue(company_id, "catalog_update")
        linked = self.db.link_catalog_update(
            run["id"], request_id=request_id, company_id=company_id,
            recipe_version=int(candidate["version"]), company_key=summary["catalog_company_id"],
            monitor_id=monitor["id"], revision=revision,
            sha256=summary.get("sha256"), source_commit=catalog.get("source_commit"),
        )
        return {"run": run, "catalog_update": linked}

    def set_company_memberships(self, company_id: int, preset_ids: list[str]) -> list[dict[str, Any]]:
        manifests = {item.id: item for item in (
            [self._builtin(preset_id) or self._imported(preset_id) for preset_id in preset_ids]
        ) if item}
        names = {key: value.name for key, value in manifests.items()}
        missing_ids = set(preset_ids) - set(names)
        if missing_ids:
            remote = self._remote_catalog()
            if remote:
                names.update({
                    str(item["id"]): str(item["name"])
                    for item in remote.get("collections", [])
                    if item.get("id") in missing_ids and item.get("name")
                })
        # Existing local membership state is sufficient while the public
        # catalog is offline; it has already been validated on installation.
        for item in self.db.list_preset_pack_states():
            if item["preset_id"] in missing_ids and item.get("preset_name"):
                names.setdefault(str(item["preset_id"]), str(item["preset_name"]))
        missing = sorted(set(preset_ids) - set(names))
        if missing:
            raise ValueError(f"Unknown preset ids: {', '.join(missing)}")
        return self.db.set_company_preset_memberships(company_id, preset_ids, names)

    def set_hidden(self, preset_id: str, hidden: bool) -> dict[str, Any]:
        state = self.db.set_preset_hidden(preset_id, hidden)
        if not state:
            raise KeyError(preset_id)
        if hidden:
            with self.db.connect() as connection:
                connection.execute(
                    """UPDATE runs SET status='cancelled',progress=100,
                    message='Cancelled because its preset pack was hidden',finished_at=?
                    WHERE status='queued' AND company_id IN (
                      SELECT m.company_id FROM company_preset_memberships m
                      WHERE m.preset_id=? AND NOT EXISTS(
                        SELECT 1 FROM company_preset_memberships other
                        JOIN preset_pack_state p ON p.preset_id=other.preset_id
                        WHERE other.company_id=m.company_id AND p.hidden_at IS NULL
                      )
                    )""", (iso_now(), preset_id),
                )
        else:
            settings = self.db.get_settings()
            for membership in self.db.list_company_preset_memberships():
                if membership["preset_id"] != preset_id:
                    continue
                company = self.db.get_company(int(membership["company_id"]))
                if company and company.get("state") == "active" and not self.db.is_company_hidden(int(company["id"])):
                    self.db.update_company(int(company["id"]), {
                        "next_run_at": next_occurrence(company, default_timezone=settings["timezone"]),
                    })
        return state

    def removal_preview(self, preset_id: str) -> dict[str, Any]:
        state = self.db.get_preset_pack_state(preset_id)
        if not state:
            raise KeyError(preset_id)
        with self.db.connect() as connection:
            rows = connection.execute(
                """SELECT m.company_id,c.name,m.origin,
                (SELECT COUNT(*) FROM company_preset_memberships x
                 WHERE x.company_id=m.company_id) membership_count,
                (SELECT COUNT(*) FROM jobs j WHERE j.company_id=m.company_id) job_count,
                (SELECT COUNT(*) FROM jobs j JOIN job_tracking t ON t.job_id=j.id
                 WHERE j.company_id=m.company_id AND t.milestone IS NOT NULL) application_count,
                (SELECT COUNT(*) FROM runs r WHERE r.company_id=m.company_id
                 AND r.status='running') running_count,
                (SELECT COUNT(*) FROM runs r WHERE r.company_id=m.company_id
                 AND r.status='queued') queued_count
                FROM company_preset_memberships m JOIN companies c ON c.id=m.company_id
                WHERE m.preset_id=? ORDER BY c.name COLLATE NOCASE""", (preset_id,),
            ).fetchall()
        companies = []
        for raw in rows:
            item = dict(raw)
            item["action"] = (
                "delete" if item["origin"] == "installed" and item["membership_count"] == 1
                else "preserve_shared" if item["membership_count"] > 1
                else "preserve_existing"
            )
            companies.append(item)
        deleted = [item for item in companies if item["action"] == "delete"]
        return {
            "preset_id": preset_id, "preset_name": state["preset_name"],
            "companies": companies,
            "delete_company_count": len(deleted),
            "delete_job_count": sum(int(item["job_count"]) for item in deleted),
            "delete_application_count": sum(int(item["application_count"]) for item in deleted),
            "running_count": sum(int(item["running_count"]) for item in deleted),
            "queued_count": sum(int(item["queued_count"]) for item in deleted),
        }

    def remove_pack(self, preset_id: str, request: PresetRemovalRequest) -> dict[str, Any]:
        preview = self.removal_preview(preset_id)
        if request.confirm_name != preview["preset_name"]:
            raise ValueError("Type the preset name exactly to confirm permanent removal")
        if preview["delete_application_count"] and not request.delete_applications:
            raise ValueError("Confirm deletion of application history before removing this preset")
        if preview["running_count"]:
            raise RuntimeError("Wait for running scraper work to finish before removing this preset")
        delete_ids = [item["company_id"] for item in preview["companies"] if item["action"] == "delete"]
        with self.db.connect() as connection:
            if delete_ids:
                placeholders = ",".join("?" for _ in delete_ids)
                connection.execute(
                    f"UPDATE runs SET status='cancelled',progress=100,finished_at=?,message=? "
                    f"WHERE status='queued' AND company_id IN ({placeholders})",
                    (iso_now(), "Cancelled because its preset pack was removed", *delete_ids),
                )
            connection.execute("DELETE FROM preset_installations WHERE preset_id=?", (preset_id,))
            connection.execute("DELETE FROM preset_pack_state WHERE preset_id=?", (preset_id,))
            connection.execute("DELETE FROM imported_presets WHERE preset_id=?", (preset_id,))
        deleted = [company_id for company_id in delete_ids if self.db.delete_company(company_id)]
        return {**preview, "deleted_company_ids": deleted, "removed": True}

    def archive_installation(self, installation_id: int) -> dict[str, Any]:
        with self.db.connect() as connection:
            row = connection.execute(
                "SELECT id,preset_id,preset_name FROM preset_installations WHERE id=?", (installation_id,)
            ).fetchone()
            company_ids = [r[0] for r in connection.execute(
                "SELECT company_id FROM preset_installation_companies WHERE installation_id=?",
                (installation_id,),
            ).fetchall()]
        if not row:
            raise KeyError(installation_id)
        archived = []
        for company_id in company_ids:
            company = self.db.get_company(company_id)
            if company and not company.get("archived_at"):
                self.db.update_company(company_id, {
                    "state": "archived", "archived_at": iso_now(), "next_run_at": None,
                })
                archived.append(company_id)
        with self.db.connect() as connection:
            connection.execute(
                "UPDATE preset_installations SET archived_at=? WHERE id=?", (iso_now(), installation_id)
            )
        return {"installation_id": installation_id, "archived_company_ids": archived,
                "archived_count": len(archived)}

    def list_installations(self) -> dict[str, Any]:
        with self.db.connect() as connection:
            rows = connection.execute(
                """SELECT id,preset_id,preset_name,installed_at,archived_at,result_json
                FROM preset_installations ORDER BY id DESC"""
            ).fetchall()
        items = [{**dict(row), "result": json.loads(row["result_json"])} for row in rows]
        for item in items:
            item.pop("result_json", None)
        return {"items": items, "count": len(items)}
