"""Durable favourites, batch checks, and inspectable tracker lifecycle operations."""
from collections import Counter
import json
from urllib.parse import urlsplit, urlunsplit
from fastapi import HTTPException
from .db import iso_now, _row
from .tracker_contracts import FavouriteRequest, BatchRequest, MonitorDeleteRequest
from .scheduler import next_occurrence

TERMINAL = {"complete", "partial", "failed", "cancelled", "interrupted"}

def company_key(catalog_id, url):
    if catalog_id:
        return "catalog:" + catalog_id
    parsed = urlsplit(url or "")
    return "source:" + urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), parsed.path.rstrip("/"), parsed.query, ""))

class TrackerService:
    def __init__(self, db, scheduler):
        self.db, self.scheduler = db, scheduler

    def favourites(self):
        with self.db.connect() as c:
            items = [{**json.loads(row["details_json"]), "key": row["company_key"], "created_at": row["created_at"]}
                     for row in c.execute("SELECT * FROM tracker_favourites ORDER BY created_at DESC,company_key")]
        return {"items": items, "count": len(items)}

    def favourite(self, request: FavouriteRequest):
        if request.company_id is not None:
            company = self.db.get_company(request.company_id)
            if not company:
                raise HTTPException(404, "Local company not found")
            source = self.db.get_catalog_source(request.company_id)
            request = request.model_copy(update={"name": company["name"],
                "catalog_company_id": source["catalog_company_id"] if source else None,
                "careers_url": company.get("careers_url") or None})
            if not request.catalog_company_id and not request.careers_url:
                raise HTTPException(422, "This company has no catalogue identity or careers URL to favourite")
        key = company_key(request.catalog_company_id, request.careers_url)
        with self.db.connect() as c:
            if request.favourite:
                c.execute("INSERT INTO tracker_favourites VALUES(?,?,?) ON CONFLICT(company_key) DO UPDATE SET details_json=excluded.details_json",
                          (key, request.model_dump_json(), iso_now()))
            else:
                c.execute("DELETE FROM tracker_favourites WHERE company_key=?", (key,))
        return {"key": key, "favourite": request.favourite}

    def snapshot(self):
        with self.db.connect() as c:
            runs = [_row(row) for row in c.execute("SELECT r.*,c.name company_name FROM runs r JOIN companies c ON c.id=r.company_id WHERE r.status IN ('queued','running') ORDER BY r.id")]
            recent = [_row(row) for row in c.execute("SELECT r.*,c.name company_name FROM runs r JOIN companies c ON c.id=r.company_id WHERE r.status NOT IN ('queued','running') ORDER BY r.id DESC LIMIT 30")]
            monitors = [dict(row) for row in c.execute("""SELECT c.id,c.name,c.careers_url,c.adapter,c.state,c.archived_at,
                c.last_run_at,c.next_run_at,c.schedule_kind,c.consecutive_failures,c.active_recipe_version,
                s.catalog_company_id,
                (SELECT COUNT(*) FROM jobs j WHERE j.company_id=c.id AND j.is_active=1) raw_job_count,
                (SELECT COUNT(*) FROM jobs j JOIN job_matches m ON m.job_id=j.id WHERE j.company_id=c.id AND j.is_active=1 AND m.is_match=1) matching_job_count,
                (SELECT MAX(id) FROM runs r WHERE r.company_id=c.id) latest_run_id
                FROM companies c LEFT JOIN company_catalog_sources s ON s.company_id=c.id WHERE c.kind='monitor' ORDER BY c.name COLLATE NOCASE""")]
            latest_ids = [m["latest_run_id"] for m in monitors if m["latest_run_id"]]
            latest = {row["id"]: _row(row) for row in c.execute("SELECT * FROM runs WHERE id IN (" + ",".join("?" for _ in latest_ids) + ")", latest_ids)} if latest_ids else {}
            batch_ids = [row[0] for row in c.execute("SELECT id FROM scraper_batches ORDER BY id DESC LIMIT 10")]
        favourite_keys = {item["key"] for item in self.favourites()["items"]}
        memberships = self.db.list_company_preset_memberships()
        for monitor in monitors:
            monitor["memberships"] = [m for m in memberships if m["company_id"] == monitor["id"]]
            monitor["is_hidden"] = bool(monitor["memberships"]) and all(m["hidden_at"] for m in monitor["memberships"])
            monitor["favourite_key"] = company_key(monitor["catalog_company_id"], monitor["careers_url"])
            monitor["favourite"] = monitor["favourite_key"] in favourite_keys
            monitor["latest_run"] = latest.get(monitor.pop("latest_run_id"))
        return {"updated_at": iso_now(), "active_runs": runs, "recent_runs": recent, "monitors": monitors,
                "batches": [self.batch(i) for i in batch_ids], "favourites": self.favourites()["items"],
                "counts": {"running": sum(r["status"] == "running" for r in runs),
                           "queued": sum(r["status"] == "queued" for r in runs),
                           "attention": sum(m["state"] == "needs_attention" or (m.get("latest_run") or {}).get("status") in {"failed", "partial"} for m in monitors if not m["archived_at"]),
                           "installed": sum(not m["archived_at"] for m in monitors)}}

    def start_batch(self, request: BatchRequest):
        from .capabilities import require_local_scrapers
        require_local_scrapers()
        selection = json.dumps(sorted(set(request.company_ids)) if request.company_ids is not None else None)
        with self.db._lock, self.db.connect() as c:
            c.execute("BEGIN IMMEDIATE")
            old = c.execute("SELECT * FROM scraper_batches WHERE request_id=?", (request.request_id,)).fetchone()
            if old:
                if old["selection_json"] != selection:
                    raise HTTPException(409, "This request ID belongs to a different selection")
                batch_id = old["id"]
            else:
                rows = c.execute("SELECT * FROM companies WHERE kind='monitor' ORDER BY id").fetchall()
                by_id = {row["id"]: row for row in rows}
                ids = sorted(set(request.company_ids)) if request.company_ids is not None else list(by_id)
                batch_id = c.execute("INSERT INTO scraper_batches(request_id,selection_json,created_at) VALUES(?,?,?)",
                                     (request.request_id, selection, iso_now())).lastrowid
                for company_id in ids:
                    company = by_id.get(company_id)
                    reason, run_id = None, None
                    if not company:
                        reason = "not_found"
                    elif company["archived_at"]:
                        reason = "archived"
                    elif company["state"] != "active":
                        reason = company["state"]
                    elif self.db.is_company_hidden(company_id):
                        reason = "hidden"
                    elif not company["active_recipe_version"]:
                        reason = "no_recipe"
                    else:
                        active = c.execute("SELECT id FROM runs WHERE company_id=? AND status IN ('queued','running') LIMIT 1", (company_id,)).fetchone()
                        if active:
                            reason = "already_busy"
                        else:
                            run_id = c.execute("INSERT INTO runs(company_id,kind,status,recipe_version,queued_at) VALUES(?,'scrape','queued',?,?)",
                                               (company_id, company["active_recipe_version"], iso_now())).lastrowid
                    c.execute("INSERT INTO scraper_batch_items VALUES(?,?,?,?,?)", (batch_id, company_id, company["name"] if company else "Unknown tracker", run_id, reason))
        self.scheduler.wake()
        return self.batch(batch_id)

    def batch(self, batch_id):
        with self.db.connect() as c:
            batch = c.execute("SELECT * FROM scraper_batches WHERE id=?", (batch_id,)).fetchone()
            if not batch:
                raise HTTPException(404, "Scraper batch not found")
            items = []
            for row in c.execute("SELECT i.*,r.status,r.progress,r.message,r.progress_detail_json,r.raw_count,r.matched_count FROM scraper_batch_items i LEFT JOIN runs r ON r.id=i.run_id WHERE i.batch_id=? ORDER BY i.company_name COLLATE NOCASE", (batch_id,)):
                item = _row(row)
                item["status"] = "skipped" if item["skip_reason"] else item["status"] or "removed"
                items.append(item)
        statuses = Counter(item["status"] for item in items)
        total = sum(not item["skip_reason"] for item in items)
        finished = sum(count for status, count in statuses.items() if status in TERMINAL or status == "removed")
        terminal = statuses["queued"] + statuses["running"] == 0
        outcome = "running" if not terminal else "finished_with_issues" if any(statuses[s] for s in ("failed", "partial", "cancelled", "interrupted", "removed")) else "complete"
        return {"id": batch["id"], "created_at": batch["created_at"], "status": outcome, "terminal": terminal,
                "total": total, "finished": finished, "skipped": statuses["skipped"],
                "percent": round(100 * finished / total) if total else 100,
                "counts": dict(statuses), "items": items}

    def removal_preview(self, company_id):
        company = self.db.get_company(company_id)
        if not company or company.get("kind") != "monitor":
            raise HTTPException(404, "Tracker not found")
        with self.db.connect() as c:
            jobs = c.execute("SELECT COUNT(*) FROM jobs WHERE company_id=?", (company_id,)).fetchone()[0]
            saved = c.execute("SELECT COUNT(*) FROM job_tracking t JOIN jobs j ON j.id=t.job_id WHERE j.company_id=? AND t.saved=1", (company_id,)).fetchone()[0]
            applications = c.execute("SELECT COUNT(*) FROM job_tracking t JOIN jobs j ON j.id=t.job_id WHERE j.company_id=? AND t.milestone IS NOT NULL", (company_id,)).fetchone()[0]
            active = c.execute("SELECT COUNT(*) FROM runs WHERE company_id=? AND status='running'", (company_id,)).fetchone()[0]
            queued = c.execute("SELECT COUNT(*) FROM runs WHERE company_id=? AND status='queued'", (company_id,)).fetchone()[0]
        return {"company_id": company_id, "name": company["name"], "job_count": jobs, "saved_count": saved,
                "application_count": applications, "running_count": active, "queued_count": queued,
                "memberships": self.db.list_company_preset_memberships(company_id), "archived": bool(company["archived_at"])}

    def set_state(self, company_id, action):
        if action in {"resume", "restore"}:
            from .capabilities import require_local_scrapers
            require_local_scrapers()
        # The same write lock is used by the queue claimant and enqueue paths.
        with self.db._lock:
            company = self.db.get_company(company_id)
            if not company or company.get("kind") != "monitor":
                raise HTTPException(404, "Tracker not found")
            if action in {"resume", "restore"}:
                if not company.get("active_recipe_version"):
                    raise HTTPException(409, "Build and activate a scraper first")
                changes = {"state": "active", "archived_at": None}
                changes["next_run_at"] = next_occurrence(company, default_timezone=self.db.get_settings()["timezone"])
            else:
                changes = {"state": "archived" if action == "archive" else "paused", "next_run_at": None}
                if action == "archive":
                    changes["archived_at"] = iso_now()
                with self.db.connect() as c:
                    c.execute("UPDATE runs SET status='cancelled',progress=100,finished_at=?,message=? WHERE company_id=? AND status='queued'", (iso_now(), "Cancelled because tracking was " + action + "d", company_id))
            result = self.db.update_company(company_id, changes)
        return {"monitor": result, "action": action, "running_work": "An in-progress check may finish; the chosen tracking state is preserved."}

    def delete(self, company_id, request: MonitorDeleteRequest):
        with self.db._lock, self.db.connect() as c:
            c.execute("BEGIN IMMEDIATE")
            preview = self.removal_preview(company_id)
            if request.confirm_name != preview["name"]:
                raise HTTPException(409, "Type the company name exactly to confirm permanent deletion")
            if preview["application_count"] and not request.delete_applications:
                raise HTTPException(409, "Explicitly confirm deletion of application history")
            if preview["running_count"]:
                raise HTTPException(409, "Wait for the running check or repair to finish before deleting")
            c.execute("DELETE FROM companies WHERE id=?", (company_id,))
        return {**preview, "deleted": True}
